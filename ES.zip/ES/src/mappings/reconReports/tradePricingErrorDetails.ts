import { APIMappingEntities } from '../../models/api.model';

const tradePricingDetailsQuery = () => `
  query TradePricingErrorDetailsQuery(
    $dates: [Date]!
    $sourceSystems: [String]
    $statuses: [String]
  ) {
    TradePricingErrorDetails(
      dates: $dates
      sourceSystems: $sourceSystems
      statuses: $statuses
    ) {
      id
      modified
      cobDate
      contractName
      counterParty
      error
      jobName
      portfolio
      status
      tradeType
      oos
      userComment
      mx {
        tradeID
        type
        instrument
        family
        group
      }
      report {
        name
        description
      }
      sky {
        tradeID
        type
        instrument
      }
      sourceSystem {
        name
        environment
      }
      added {
        by
      }
      updated {
        time
      }
    }
  }
`;

export default {
  '/feed-monitor/recon-reports/trade-pricing-error-data/csv': {
    get: {
      name: 'tradePricingErrorData',
      summary: 'Export trade pricing error data csv',
      description: 'Returns all trade pricing error data in csv file',
      filename: 'feed_monitor_trade_pricing_error',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Trade pricing error data' }],
      parameters: [
        {
          name: 'dates',
          in: 'query',
          description: 'Filter by cob dates',
          required: true,
          type: 'string',
        },
        {
          name: 'sourceSystems',
          in: 'query',
          description: 'Filter by source systems',
          required: false,
          type: 'string',
        },
        {
          name: 'statuses',
          in: 'query',
          description: 'Filter by status',
          required: false,
          type: 'string',
        },
      ],
      dataSource: {
        query: tradePricingDetailsQuery,
        queryVariables: (params) => params,
        returnDataName: 'TradePricingErrorDetails',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'cobDate',
        fields: [
          {
            field: 'userComment',
            name: 'User Comment',
            typeOf: 'string'
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string'
          },
          {
            field: 'updated.time',
            name: 'Updated Time',
            typeOf: 'dateTime',
          },
          {
            field: 'sourceSystem.name',
            name: 'Source System',
            typeOf: 'string'
          },
          {
            field: 'cobDate',
            name: 'COB Date',
            typeOf: 'date',
          },
          {
            field: 'status',
            name: 'Status',
            typeOf: 'string',
          },
          {
            field: 'oos',
            name: 'OOS',
            typeOf: 'string'
          },
          {
            field: 'report.name',
            name: 'Report',
            typeOf: 'string',
          },
          {
            field: 'portfolio',
            name: 'Portfolio',
            typeOf: 'string'
          },
          {
            field: 'report.description',
            name: 'Report Description',
            typeOf: 'string'
          },
          {
            field: 'sourceSystem.environment',
            name: 'Source System Environment',
            typeOf: 'string'
          },
          {
            field: 'sky.tradeID',
            name: 'Sky Trade ID',
            typeOf: 'string'
          },
          {
            field: 'mx.tradeID',
            name: 'Murex Trade ID',
            typeOf: 'string'
          },
          {
            field: 'mx.family',
            name: 'Murex Family',
            typeOf: 'string'
          },
          {
            field: 'mx.type',
            name: 'Murex Type',
            typeOf: 'string'
          },
          {
            field: 'mx.group',
            name: 'Murex Group',
            typeOf: 'string'
          },
          {
            field: 'mx.instrument',
            name: 'Murex Instrument',
            typeOf: 'string'
          },
          {
            field: 'counterParty',
            name: 'Counter Party',
            typeOf: 'string'
          },
          {
            field: 'tradeType',
            name: 'Trade Type',
            typeOf: 'string'
          },
          {
            field: 'contractName',
            name: 'Contract Name',
            typeOf: 'string'
          },
          {
            field: 'jobName',
            name: 'Job Name',
            typeOf: 'string'
          },
          {
            field: 'error',
            name: 'Error Message',
            typeOf: 'string'
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Trade Pricing Error Data',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

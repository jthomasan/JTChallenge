import { APIMappingEntities } from '../../models/api.model';

const dailyTradeDetailsQuery = () => `
  query DailyTradeReconDetailsQuery(
    $dates: [Date]!
    $sourceSystems: [String]
    $statuses: [String]
  ) {
    DailyTradeReconDetails(
      dates: $dates
      sourceSystems: $sourceSystems
      statuses: $statuses
    ) {
      id
      modified
      COBDate
      maRRSDealNumber
      MREDealNumber
      maRRSPortfolio
      MREPortfolio
      tradeFamily
      tradeGroup
      tradeType
      instrument
      effectiveMaturity
      sourceSystem
      valuationType
      status
      reason
      systemComment
      userComment
      added {
        by
      }
      updated {
        time
      }
    }
  }
`;

export default {
  '/feed-monitor/recon-reports/daily-trade-reconciliation/csv': {
    get: {
      name: 'dailyTradeReconciliation',
      summary: 'Export daily trade reconciliation csv',
      description: 'Returns all daily trade reconciliation in csv file',
      filename: 'feed_monitor_daily_trade_reconciliation',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Daily trade reconciliation' }],
      parameters: [
        {
          name: 'dates',
          in: 'query',
          description: 'Filter by cob dates',
          required: true,
          type: 'string',
        },
        {
          name: 'sourceSystems',
          in: 'query',
          description: 'Filter by source systems',
          required: false,
          type: 'string',
        },
        {
          name: 'statuses',
          in: 'query',
          description: 'Filter by status',
          required: false,
          type: 'string',
        },
      ],
      dataSource: {
        query: dailyTradeDetailsQuery,
        queryVariables: (params) => params,
        returnDataName: 'DailyTradeReconDetails',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'cobDate',
        fields: [
          {
            field: 'userComment',
            name: 'User Comment',
            typeOf: 'string',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'updated.time',
            name: 'Updated Time',
            typeOf: 'dateTime',
          },
          {
            field: 'sourceSystem',
            name: 'Source System',
            typeOf: 'string',
          },
          {
            field: 'valuationType',
            name: 'Valuation Type',
            typeOf: 'string',
          },
          {
            field: 'COBDate',
            name: 'COB Date',
            typeOf: 'date',
          },
          {
            field: 'status',
            name: 'Recon Status',
            typeOf: 'string',
          },
          {
            field: 'reason',
            name: 'Reason',
            typeOf: 'string',
          },
          {
            field: 'systemComment',
            name: 'System Comment',
            typeOf: 'string',
          },
          {
            field: 'maRRSDealNumber',
            name: 'MaRRS Deal Number',
            typeOf: 'string',
          },
          {
            field: 'MREDealNumber',
            name: 'MRE Deal Number',
            typeOf: 'string',
          },
          {
            field: 'maRRSPortfolio',
            name: 'MaRRS Portfolio',
            typeOf: 'string',
          },
          {
            field: 'MREPortfolio',
            name: 'MRE Portfolio',
            typeOf: 'string',
          },
          {
            field: 'tradeFamily',
            name: 'Trade Family',
            typeOf: 'string',
          },
          {
            field: 'tradeGroup',
            name: 'Trade Group',
            typeOf: 'string',
          },
          {
            field: 'tradeType',
            name: 'Trade Type',
            typeOf: 'string',
          },
          {
            field: 'instrument',
            name: 'Instrument',
            typeOf: 'string',
          },
          {
            field: 'effectiveMaturity',
            name: 'Effective Maturity',
            typeOf: 'string',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Daily Trade Reconciliation',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

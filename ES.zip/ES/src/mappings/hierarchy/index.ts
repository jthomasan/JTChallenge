import nodes from './nodes';
import { APIMappingEntities } from '../../models/api.model';
import portfolios from './portfolios';

export default {
  ...nodes,
  ...portfolios,
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';
import referenceDataConfigurationProcessor from '../../processors/refDataConfig/referenceDataConfigurationProcessor';

const portfolioRunListQuery = () => `
{
  PortfolioRunList { 
    id
    title
    parent
    fullPath
    currentReports {
      id
      text
    }
    inheritedReports {
      id
      text
    }
    excludedReports {
      id
      text
    }
  }
}
`;

const reportsDisplayRenderer = (data: { id: string; text: string }[]) =>
  data.map((i) => i.text).join(';');

const customProcessorExportFields = [
  {
    field: 'title',
    name: 'Node Name',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'fullPath',
    name: 'Full Path',
    typeOf: 'string',
  },
  {
    field: 'currentReports',
    name: 'Current Report(s)',
    typeOf: 'array',
    displayRenderer: reportsDisplayRenderer,
  },
  {
    field: 'inheritedReports',
    name: 'Inherited Report(s)',
    typeOf: 'array',
    displayRenderer: reportsDisplayRenderer,
  },
  {
    field: 'excludedReports',
    name: 'Exclude from Inherited',
    typeOf: 'array',
    displayRenderer: reportsDisplayRenderer,
  },
];

export default {
  '/reference-data/configuration/portfolio-runList/csv': {
    get: {
      name: 'refDataConfigurationPortfolioRunList',
      summary: 'Export Ref data Configuration Portfolio Runlist csv',
      description: 'Returns all data in csv file',
      filename: 'ref_data_configuration_portfolio_runlist',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Ref Data Configuration' }],
      parameters: [],
      dataSource: {
        query: portfolioRunListQuery,
        returnDataName: 'PortfolioRunList',
      },
      exportInfo: {
        customProcessor: referenceDataConfigurationProcessor.bind(
          null,
          customProcessorExportFields,
        ),
        sortField: 'node.value',
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Ref Data Configuration Portfolio Runlist',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

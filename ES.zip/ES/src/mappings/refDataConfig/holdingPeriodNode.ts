import { APIMappingEntities } from '../../models/api.model';
import referenceDataConfigurationProcessor from '../../processors/refDataConfig/referenceDataConfigurationProcessor';

const holdingPeriodNodeQuery = () => `
{
  HoldingPeriodNodes {
    id
    modified
    parent
    title
    fullPath
    isForHoldingPeriod
    excludeInternalTrades
    added {
      by
      time
    }
  }
}
`;

const customProcessorExportFields = [
  {
    field: 'title',
    name: 'Node Name',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'fullPath',
    name: 'Full Path',
    typeOf: 'string',
  },
  {
    field: 'isForHoldingPeriod',
    name: 'Is for Holding Period?',
    typeOf: 'boolean',
  },
  {
    field: 'excludeInternalTrades',
    name: 'Exclude Internal trades',
    typeOf: 'string',
  },
  {
    field: 'added.by',
    name: 'Last Edited By',
    typeOf: 'string',
  },
  {
    field: 'added.time',
    name: 'Last Edited Time',
    typeOf: 'dateTime',
  },
];

export default {
  '/reference-data/configuration/holding-period-node/csv': {
    get: {
      name: 'refDataConfigurationHoldingPeriodNode',
      summary: 'Export Ref data Configuration Ref Data Mapping csv',
      description: 'Returns all data in csv file',
      filename: 'ref_data_configuration_holding_period_node',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Ref Data Configuration' }],
      parameters: [],
      dataSource: {
        query: holdingPeriodNodeQuery,
        returnDataName: 'HoldingPeriodNodes',
      },
      exportInfo: {
        customProcessor: referenceDataConfigurationProcessor.bind(
          null,
          customProcessorExportFields,
        ),
        sortField: 'title',
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Ref Data Configuration Holding Period Node',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

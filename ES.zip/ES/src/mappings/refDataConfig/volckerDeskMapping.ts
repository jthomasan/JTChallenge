import { APIMappingEntities } from '../../models/api.model';
import referenceDataConfigurationProcessor from '../../processors/refDataConfig/referenceDataConfigurationProcessor';

const volkerDeskMappingQuery = () => `
{
    VolckerDeskMappings {
        id
        modified
        isForVolcker
        parent
        title
        fullPath
        volckerDesk {
          id
          text
        }
        inheritedVolckerDesk {
          id
          text
        }
        added {
          by
          time
        }
      }
}
`;

const customProcessorExportFields = [
  {
    field: 'title',
    name: 'Node Name',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'fullPath',
    name: 'Full Path',
    typeOf: 'string',
  },
  {
    field: 'isForVolcker',
    name: 'Is for Volcker?',
    typeOf: 'boolean',
  },
  {
    field: 'volckerDesk.text',
    name: 'Volcker Desk Name',
    typeOf: 'string',
  },
  {
    field: 'added.by',
    name: 'Last Edited By',
    typeOf: 'string',
  },
  {
    field: 'added.time',
    name: 'Last Edited Time',
    typeOf: 'dateTime',
  },
];

export default {
  '/reference-data/configuration/volcker-desk-mapping/csv': {
    get: {
      name: 'refDataConfigurationVolckerDeskMapping',
      summary: 'Export Ref data Configuration Ref Data Mapping csv',
      description: 'Returns all data in csv file',
      filename: 'ref_data_configuration_volcker_desk_mapping',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Ref Data Configuration' }],
      parameters: [],
      dataSource: {
        query: volkerDeskMappingQuery,
        returnDataName: 'VolckerDeskMappings',
      },
      exportInfo: {
        customProcessor: referenceDataConfigurationProcessor.bind(
          null,
          customProcessorExportFields,
        ),
        sortField: 'title',
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Ref Data Configuration Volcker Desk Mappings',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

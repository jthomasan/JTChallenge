import { APIMappingEntities } from '../../models/api.model';
import tradePricingErrorDownloadProcessor from '../../processors/riskData/tradePricingErrorDownload';
import { getArgs } from '..';

interface PricingErrorProps {
  cob: string;
  isPortfolioNode: boolean;
  portfolioNode: string;
  reports: string[];
  snapshot: string;
  sourceSystemEnvironments: string[];
}

const riskDataPricingErrorsQuery = (params: PricingErrorProps) => `
  {
    RiskDataPricingErrors (
        ${getArgs(params)}
    ) {
      businessDate
      report
      reportDescription
      portfolio
      skyTradeID
      murexTradeID
      mxFamily
      mxType
      mxGroup
      mxInstrument
      counterParty
      contractName
      jobName
      errorMessage
    }
  }
`;

export default {
  '/feed-monitor/risk-data/pricing-error-download/csv': {
    get: {
      name: 'pricingErrorDownload',
      summary: 'Export pricing error download csv',
      description: 'Returns all pricing error download in csv file',
      filename: 'feed_monitor_trade_pricing_error',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Pricing Error Download' }],
      parameters: [
        {
          name: 'cob',
          in: 'query',
          description: 'Search by cob date',
          required: true,
          type: 'string',
        },
        {
          name: 'isPortfolioNode',
          in: 'query',
          description: 'Search by isPortfolioNode',
          required: true,
          type: 'boolean',
        },
        {
          name: 'portfolioNode',
          in: 'query',
          description: 'Search by portfolioNode',
          required: true,
          type: 'string',
        },
        {
          name: 'reports',
          in: 'query',
          description: 'Search by reports',
          type: 'array',
        },
        {
          name: 'snapshot',
          in: 'query',
          description: 'Search by snapshot',
          required: true,
          type: 'string',
        },
        {
          name: 'sourceSystemEnvironments',
          in: 'query',
          description: 'Search by sourceSystemEnvironments',
          type: 'string',
        },
      ],
      dataSource: {
        query: riskDataPricingErrorsQuery,
        returnDataName: 'RiskDataPricingErrors',
      },
      exportInfo: {
        customProcessor: tradePricingErrorDownloadProcessor,
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Pricing Error Download',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

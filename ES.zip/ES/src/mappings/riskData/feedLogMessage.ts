import { APIMappingEntities } from '../../models/api.model';
import { getArgs } from '..';

interface Request {
  feedIDs: string[];
}

const feedLogMessagesQuery = (params: Request) => `
  {
    FeedLogMessages (${getArgs(params)}) {
      feedID
      reportName
      portfolio
      message
    }
  }
`;

export default {
  '/feed-monitor/risk-data/feed-log-messages/csv': {
    get: {
      name: 'feedLogMessage',
      summary: 'Export csv',
      description: 'Returns all data in csv file',
      filename: 'feed_monitor_feed_logs',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed Monitor' }],
      parameters: [
        {
          name: 'feedIDs',
          in: 'query',
          description: 'Search by feed ids',
          required: true,
          type: 'array',
        },
      ],
      dataSource: {
        query: feedLogMessagesQuery,
        returnDataName: 'FeedLogMessages',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'portfolio',
        fields: [
          {
            field: 'feedID',
            name: 'Feed ID',
            typeOf: 'number',
          },
          {
            field: 'reportName',
            name: 'Report Name',
            typeOf: 'string',
          },
          {
            field: 'portfolio',
            name: 'Portfolio',
            typeOf: 'string',
          },
          {
            field: 'message',
            name: 'Log',
            typeOf: 'string',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Feed log messages',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

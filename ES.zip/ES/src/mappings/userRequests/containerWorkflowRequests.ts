import { APIMappingEntities } from '../../models/api.model';

interface Request {
  date: string;
  type: string;
}

const feedLogMessagesQuery = () => `
  query WorkflowRequests($date: Date!, $type: WorkflowType!) {
    WorkflowRequests(date: $date, type: $type) {
      businessDate
      runDate
      portfolio
      container
      status
      snapshot
      sourceSystem {
        id
        name
      }
      comment
      isProcessed
      added {
        by
        time
      }
      lastUpdated {
        time
      }

      message
    }
  }
`;

export default {
  '/feed-monitor/user-requests/container-workflow-requests/csv': {
    get: {
      name: 'containerWorkflowRequests',
      summary: 'Export csv',
      description: 'Returns all data in csv file',
      filename: ({ query }) => {
        const type = (query.type as string) ?? '';
        const date = (query.date as string) ?? '';

        return `feed_monitor_requests_${type.toLowerCase()}_${date.replace(/\-/g, '')}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed Monitor' }],
      parameters: [
        {
          name: 'date',
          in: 'query',
          description: 'Search by date',
          required: true,
          type: 'string',
        },
        {
          name: 'type',
          in: 'query',
          description: 'Search by workflow request type',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: feedLogMessagesQuery,
        queryVariables: (params: Request) => params,
        returnDataName: 'WorkflowRequests',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'container',
        fields: [
          {
            field: 'businessDate',
            name: 'COB Date',
            typeOf: 'date',
          },
          {
            field: 'runDate',
            name: 'Requested Date',
            typeOf: 'date',
          },
          {
            field: 'portfolio',
            name: 'Portfolio Node',
            typeOf: 'string',
          },
          {
            field: 'container',
            name: 'Container',
            typeOf: 'string',
          },
          {
            field: 'status',
            name: 'Status',
            typeOf: 'string',
          },
          {
            field: 'snapshot',
            name: 'Snapshot',
            typeOf: 'string',
          },
          {
            field: 'sourceSystem.name',
            name: 'Source System',
            typeOf: 'string',
          },
          {
            field: 'comment',
            name: 'Comment',
            typeOf: 'string',
          },
          {
            field: 'isProcessed',
            name: 'Is Processed',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Requested By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
          {
            field: 'lastUpdated.time',
            name: 'Modified Time',
            typeOf: 'dateTime',
          },
          {
            field: 'message',
            name: 'Log',
            typeOf: 'string',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Workflow requests',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

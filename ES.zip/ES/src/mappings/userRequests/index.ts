import { APIMappingEntities } from '../../models/api.model';
import containerWorkflowRequests from './containerWorkflowRequests';
import reportWorkflowRequests from './reportWorkflowRequests';

export default {
  ...containerWorkflowRequests,
  ...reportWorkflowRequests,
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

interface Request {
  date: string;
  type: string;
}

const feedLogMessagesQuery = () => `
  query WorkflowRequests($date: Date!, $type: WorkflowType!) {
    WorkflowRequests(date: $date, type: $type) {
      sourceBusinessDate
      businessDate
      runDate
      portfolio
      report
      status
      snapshot
      useVersion
      comment
      isProcessed
      added {
        by
        time
      }
      lastUpdated {
        time
      }

      message
    }
  }
`;

const TypeNameRemap = {
  RELOAD: 'ROLLBACK',
};

export default {
  '/feed-monitor/user-requests/report-workflow-requests/csv': {
    get: {
      name: 'reportWorkflowRequests',
      summary: 'Export csv',
      description: 'Returns all data in csv file',
      filename: ({ query }) => {
        let type = (query.type as string) ?? '';
        const date = (query.date as string) ?? '';

        if (type in TypeNameRemap) {
          type = TypeNameRemap[type];
        }

        return `feed_monitor_requests_${type.toLowerCase()}_${date.replace(/\-/g, '')}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed Monitor' }],
      parameters: [
        {
          name: 'date',
          in: 'query',
          description: 'Search by date',
          required: true,
          type: 'string',
        },
        {
          name: 'type',
          in: 'query',
          description: 'Search by workflow request type',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: feedLogMessagesQuery,
        queryVariables: (params: Request) => params,
        returnDataName: 'WorkflowRequests',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'added.time',
        fields: [
          {
            field: 'sourceBusinessDate',
            name: 'Source COB',
            typeOf: 'date',
          },
          {
            field: 'businessDate',
            name: 'COB Date',
            typeOf: 'date',
          },
          {
            field: 'runDate',
            name: 'Requested Date',
            typeOf: 'date',
          },
          {
            field: 'portfolio',
            name: 'Portfolio Node',
            typeOf: 'string',
          },
          {
            field: 'report',
            name: 'Report',
            typeOf: 'string',
          },
          {
            field: 'status',
            name: 'Status',
            typeOf: 'string',
          },
          {
            field: 'snapshot',
            name: 'Snapshot',
            typeOf: 'string',
          },
          {
            field: 'useVersion',
            name: 'Version',
            typeOf: 'string',
          },
          {
            field: 'comment',
            name: 'Comment',
            typeOf: 'string',
          },
          {
            field: 'isProcessed',
            name: 'Is Processed',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Requested By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
          {
            field: 'lastUpdated.time',
            name: 'Modified Time',
            typeOf: 'dateTime',
          },
          {
            field: 'message',
            name: 'Log',
            typeOf: 'string',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Workflow requests',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

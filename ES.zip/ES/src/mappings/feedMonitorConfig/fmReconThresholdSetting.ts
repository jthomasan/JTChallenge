import { APIMappingEntities } from '../../models/api.model';

export const fmThresholdSettingConfigQuery = ({ reconType }: any) => `
  {
    ReconThresholdSetting (reconType: "${reconType}") {
        id
        modified
        statusName
        range
        isActive
        added {
          by
          time
        }
    }
  }
`;

const exportFields = [
  {
    field: 'statusName',
    name: 'Status',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'range',
    name: 'Range Value',
    typeOf: 'number',
  },
  {
    field: 'added.time',
    name: 'Added Time',
    typeOf: 'dateTime',
  },
  {
    field: 'added.by',
    name: 'Added By',
    typeOf: 'string',
  },
  {
    field: 'isActive',
    name: 'Is Active',
    typeOf: 'boolean',
  },
];

enum ReconTypeOptions {
  DailyTradeReconciliation = '3',
  MurexRiskEnginevsTradeDB = '1',
  PastCashReconciliation = '4',
  TradePricingErrorData = '5',
}

const ReconTypeExportFileNames = {
  [ReconTypeOptions.DailyTradeReconciliation]: 'daily_trade',
  [ReconTypeOptions.MurexRiskEnginevsTradeDB]: 'MRE_DB',
  [ReconTypeOptions.PastCashReconciliation]: 'past_cash',
  [ReconTypeOptions.TradePricingErrorData]: 'pricing_error',
};

export default {
  '/feed-monitor/configuration/recon-threshold-setting-config/csv': {
    get: {
      name: 'feedMonitorConfigurationReconThresholdSetting',
      summary: 'Export Feed Monitor Configuration Recond Threshold Setting Config',
      description: 'Returns all data in csv file',
      filename: ({ query }) => {
        const type = Number(query.reconType ?? '0');

        const typeNameMap = ReconTypeExportFileNames[type];

        return `feed_monitor_config_${typeNameMap}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed monitor Configuration' }],
      parameters: [
        {
          name: 'reconType',
          in: 'query',
          description: 'Search by recon type',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: fmThresholdSettingConfigQuery,
        returnDataName: 'ReconThresholdSetting',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'statusName',
        fields: exportFields,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            name: 'Feed Monitor Configuration Recond Threshold Setting Config',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

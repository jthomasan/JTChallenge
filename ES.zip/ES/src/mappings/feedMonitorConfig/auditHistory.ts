import { APIMappingEntities } from '../../models/api.model';
import staticDataAuditHistoryProcessor from '../../processors/staticData/staticDataAuditHistoryProcessor';

const fmConfigAuditHistoryQuery = () => `
query getFMConfigAuditHistory($configTypeId: ID!, $auditId: ID!) {
  FMConfigAuditHistory(configTypeId: $configTypeId, auditId: $auditId) {
    columns {
      field
      title
      type
    }
    rows
  }
}
`;

const fmConfigAuditHistoryQueryVariables = ({ configTypeId, auditId }) => ({
  auditId,
  configTypeId,
});

export default {
  '/feed-monitor/configuration/audit-history/csv': {
    get: {
      name: 'fmConfigAuditHistory',
      summary: 'Export feed monitor configuration data audit history csv',
      description: 'Returns all feed monitor configuration audit histories in csv file',
      filename: 'Feed_Monitor_Configuration_Audit_History_{args.datasetName}',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed Monitor Configuration Audit History' }],
      parameters: [
        {
          name: 'configTypeId',
          in: 'query',
          description: 'Search by type id',
          required: false,
          type: 'string',
        },
        {
          name: 'auditId',
          in: 'query',
          description: 'Search by audit id',
          required: false,
          type: 'string',
        },
      ],
      dataSource: {
        query: fmConfigAuditHistoryQuery,
        queryVariables: fmConfigAuditHistoryQueryVariables,
        returnDataName: 'FMConfigAuditHistory',
      },
      exportInfo: {
        customProcessor: staticDataAuditHistoryProcessor,
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Feed Monitor Configuration audit history',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const ctdMappingQuery = () => `
{  
    CsvConfiguration {
        id
        modified
        name
        description
        isActive
        pollIntervalInMinute
        folderPath
        fileNamePattern
        tableName
        columnsMapping
        preUploadSqlStatement
        postUploadSqlStatement
        etlJobTypeId
        enableFileWatcher
        bulkUploadBatchSize
        bulkUploadTimeOutInSeconds
        startFooterLineText
        skipFooterLineCount
        specialQuoteHandler
        hasHeader
        columnDelimiter
        textQualifier
        escapeCharactor
        sendCompleteEmailToOwner
        sendErrorEmailToOwner
        completeEmailToList
        completeEmailCcList
        errorEmailToList
        errorEmailCcList 
        added {
          by
          time
        }
      }
}
`;

const customProcessorExportFields = [
  {
    field: 'name',
    name: 'Name',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'description',
    name: 'Description',
    typeOf: 'string',
  },
  {
    field: 'isActive',
    name: 'Is Active',
    typeOf: 'boolean',
  },
  {
    field: 'added.time',
    name: 'Added Time',
    typeOf: 'dateTime',
  },
  {
    field: 'added.by',
    name: 'Added By',
    typeOf: 'string',
  },
  {
    field: 'pollIntervalInMinute',
    name: 'Poll Interval In Minute',
    typeOf: 'number',
  },
  {
    field: 'folderPath',
    name: 'Folder Path',
    typeOf: 'string',
  },
  {
    field: 'fileNamePattern',
    name: 'File Name Pattern',
    typeOf: 'string',
  },
  {
    field: 'tableName',
    name: 'Table Name',
    typeOf: 'string',
  },
  {
    field: 'columnsMapping',
    name: 'Columns Mapping',
    typeOf: 'string',
  },
  {
    field: 'preUploadSqlStatement',
    name: 'Pre Upload Sql Statement',
    typeOf: 'string',
  },
  {
    field: 'postUploadSqlStatement',
    name: 'Post Upload Sql Statement',
    typeOf: 'string',
  },
  {
    field: 'etlJobTypeId',
    name: 'ETL Job Type ID',
    typeOf: 'string',
  },
  {
    field: 'enableFileWatcher',
    name: 'Enable File Watcher',
    typeOf: 'boolean',
  },
  {
    field: 'bulkUploadBatchSize',
    name: 'Bulk Upload Batch Size',
    typeOf: 'string',
  },
  {
    field: 'bulkUploadTimeOutInSeconds',
    name: 'Bulk Upload Time Out In Seconds',
    typeOf: 'string',
  },
  {
    field: 'startFooterLineText',
    name: 'Start Footer Line Text',
    typeOf: 'string',
  },
  {
    field: 'skipFooterLineCount',
    name: 'Skip Footer Line Count',
    typeOf: 'number',
  },
  {
    field: 'specialQuoteHandler',
    name: 'Special Quote Handler',
    typeOf: 'boolean',
  },
  {
    field: 'hasHeader',
    name: 'Has Header',
    typeOf: 'boolean',
  },
  {
    field: 'columnDelimiter',
    name: 'Column Delimiter',
    typeOf: 'string',
  },
  {
    field: 'textQualifier',
    name: 'Text Qualifier',
    typeOf: 'string',
  },
  {
    field: 'escapeCharactor',
    name: 'Escape Charactor',
    typeOf: 'string',
  },
  {
    field: 'sendCompleteEmailToOwner',
    name: 'Send Complete Email To Owner',
    typeOf: 'boolean',
  },
  {
    field: 'sendErrorEmailToOwner',
    name: 'Send Error Email To Owner',
    typeOf: 'boolean',
  },
  {
    field: 'completeEmailToList',
    name: 'Complete Email To List',
    typeOf: 'string',
  },
  {
    field: 'completeEmailCcList',
    name: 'Complete Email Cc List',
    typeOf: 'string',
  },
  {
    field: 'errorEmailToList',
    name: 'Error Email To List',
    typeOf: 'string',
  },
  {
    field: 'errorEmailCcList',
    name: 'Error Email Cc List',
    typeOf: 'string',
  },
];

export default {
  '/feed-monitor/configuration/csv-config/csv': {
    get: {
      name: 'feedMonitorConfigurationCSV',
      summary: 'Export Feed Monitor Configuration CSV Config',
      description: 'Returns all data in csv file',
      filename: 'feed_monitor_configuration_csv_config',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed monitor Configuration' }],
      parameters: [],
      dataSource: {
        query: ctdMappingQuery,
        returnDataName: 'CsvConfiguration',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'name',
        fields: customProcessorExportFields,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Feed Monitor Configuration CSV Config',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataGlobalProductLinesQuery = () => `
{
  StaticDataGlobalProductLines {
    id
    modified
    description
    isActive
    added{
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/global-product-lines/csv': {
    get: {
      name: 'staticDataGlobalProductLines',
      summary: 'Export static data Global Product Lines csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_global_product_lines',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGlobalProductLinesQuery,
        returnDataName: 'StaticDataGlobalProductLines',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'description',
        fields: [
          {
            field: 'description',
            name: 'Global Product Line',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Global Product Lines',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

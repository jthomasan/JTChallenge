import { APIMappingEntities } from '../../models/api.model';

const staticDataCreditStressCreditIndicesQuery = () => `
{
  StaticDataCreditStressCreditIndices {
    modified
    CRIndexType {
      id
      text
    }
    longStress
    shortStress
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/credit-stress-credit-indices/csv': {
    get: {
      name: 'staticDataCreditStressCreditIndices',
      summary: 'Export static data Credit Stress Credit Indices csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_credit_stress_credit_indices',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCreditStressCreditIndicesQuery,
        returnDataName: 'StaticDataCreditStressCreditIndices',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'CRIndexType.text',
        fields: [
          {
            field: 'CRIndexType.text',
            name: 'CR Index Type',
            typeOf: 'string',
          },
          {
            field: 'longStress',
            name: 'Long Stress',
            typeOf: 'number',
          },
          {
            field: 'shortStress',
            name: 'Short Stress',
            typeOf: 'number',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Credit Stress Credit Indices',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataSpecificRiskLongTermIssueQuery = () => `
{
  StaticDataSpecificRiskLongTermIssues {
    id
    modified
    ratingBandSecTypeSystem {
      id
      text
    }
    resecuritisationExposures
    securitisationExposures
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/specific-risk-long-term-issue/csv': {
    get: {
      name: 'staticDataSpecificRiskLongTermIssue',
      summary: 'Export static data Specific Risk Long Term Issue csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_specific_risk_long_term_issue',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataSpecificRiskLongTermIssueQuery,
        returnDataName: 'StaticDataSpecificRiskLongTermIssues',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'ratingBandSecTypeSystem.text',
        fields: [
          {
            field: 'ratingBandSecTypeSystem.text',
            name: 'Rating Band Sec',
            typeOf: 'string',
          },
          {
            field: 'securitisationExposures',
            name: 'Securitisation Exposures (%)',
            typeOf: 'number',
          },
          {
            field: 'resecuritisationExposures',
            name: 'Securitisation Exposures (%)',
            typeOf: 'number',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Specific Risk Long Term Issue',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

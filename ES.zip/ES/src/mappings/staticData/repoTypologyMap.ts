import { APIMappingEntities } from '../../models/api.model';

const staticDataRepoTypologyMapQuery = () => `
{
  StaticDataRepoTypologyMaps {
    modified
    typology
    mapValue  
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/repo-typology-map/csv': {
    get: {
      name: 'staticDataRepoTypologyMap',
      summary: 'Export static data Repo Typology Map csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_repo_typology_map',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataRepoTypologyMapQuery,
        returnDataName: 'StaticDataRepoTypologyMaps',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'typology',
        fields: [
          {
            field: 'typology',
            name: 'Typology',
            typeOf: 'string',
          },
          {
            field: 'mapValue',
            name: 'Map Value',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Repo Typology Map',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

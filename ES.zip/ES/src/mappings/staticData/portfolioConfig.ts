import { APIMappingEntities } from '../../models/api.model';

const staticDataPortfolioConfigQuery = () => `
{
  StaticDataPortfolioConfigs {
    id
    modified
    portfolio {
      id
      text
    }
    container {
      id
      text
    }
    sources {
      id
      text
    }
    officialSource {
      id
      text
    }

    isActive
    added {
      by
      time
    }
  }
}
`;

interface Option {
  id: string;
  text: string;
}

const sourcesDisplayRenderer = (options: Option[]) =>
  options.map((option) => option.text).join(',');

export default {
  '/reference-data/static-data/portfolio-config/csv': {
    get: {
      name: 'staticDataPortfolioConfig',
      summary: 'Export static data Portfolio Config csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_portfolio_config',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataPortfolioConfigQuery,
        returnDataName: 'StaticDataPortfolioConfigs',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'portfolio.text',
        fields: [
          {
            field: 'portfolio.text',
            name: 'Portfolio',
            typeOf: 'string',
          },
          {
            field: 'container.text',
            name: 'Container',
            typeOf: 'string',
          },
          {
            field: 'sources',
            name: 'Source Systems',
            typeOf: 'array',
            displayRenderer: sourcesDisplayRenderer,
          },
          {
            field: 'officialSource.text',
            name: 'Official Source',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Portfolio Config',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

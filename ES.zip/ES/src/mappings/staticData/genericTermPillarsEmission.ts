import { APIMappingEntities } from '../../models/api.model';

const staticDataGenericTermPillarsEmissionQuery = () => `
{
  StaticDataGenericTermPillarsEmissions {
    modified
    net13m_24m
    net19m_30m
    net25m_36m
    net4m_18m
    net4m_12m
    term
    termUnit
    net0m_3m
    net31m_42m
    net0m_12m
    net37m_48m
    net49m_60m
  } 
}
`;

export default {
  '/reference-data/static-data/generic-term-pillars-emission/csv': {
    get: {
      name: 'staticDataGenericTermPillarsEmission',
      summary: 'Export static data Generic Term Pillars Emission csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_generic_term_pillars_emission',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGenericTermPillarsEmissionQuery,
        returnDataName: 'StaticDataGenericTermPillarsEmissions',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net0m_3m',
            name: 'Net0m_3m',
            typeOf: 'number',
          },
          {
            field: 'net4m_18m',
            name: 'Net4m_18m',
            typeOf: 'number',
          },
          {
            field: 'net19m_30m',
            name: 'Net19m_30m',
            typeOf: 'number',
          },
          {
            field: 'net31m_42m',
            name: 'Net31m_42m',
            typeOf: 'number',
          },
          {
            field: 'net4m_12m',
            name: 'Net4m_12m',
            typeOf: 'number',
          },
          {
            field: 'net13m_24m',
            name: 'Net13m_24m',
            typeOf: 'number',
          },
          {
            field: 'net25m_36m',
            name: 'Net25m_36m',
            typeOf: 'number',
          },
          {
            field: 'net0m_12m',
            name: 'Net0m_12m',
            typeOf: 'number',
          },
          {
            field: 'net37m_48m',
            name: 'Net37m_48m',
            typeOf: 'number',
          },
          {
            field: 'net49m_60m',
            name: 'Net49m_60m',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Generic Term Pillars Emission',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

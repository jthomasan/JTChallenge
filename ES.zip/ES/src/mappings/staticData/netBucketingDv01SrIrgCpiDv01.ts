import { APIMappingEntities } from '../../models/api.model';

const staticDataNetBucketingDv01SrIrgCpiDv01Query = () => `
{
  StaticDataNetBucketingDV01List {
    modified
    term
    termUnit
    net2m_3m
    net3m
    net1y
    net3y
    net5y
    net10y
    net10yPlus
    net20y
    net20yPlus
    net30yPlus
    net1yPlus
    net3mCom
    netLess1yCom
    net1yCom
    net3yCom
    net5yCom
    net10yCom
    nFA2y
    nFA5y
    nFA10y
    nFA30y
    net1mFXO
    net2mFXO
    net3mFXO
    net6mFXO
    net1yFXO
    net2yFXO
    net3yFXO
    net4yFXO
    net5yFXO
    net7yFXO
    net10yFXO
    net6mPlus
    net2yPlus
    net3mRAT
    net1yRAT
    net2yRAT
    net3yRAT
    net5yRAT
    net7yRAT
    net10yRAT
    net15yRAT
    net20yRAT
    net25yRAT
    net30yPlusRAT
  }
}
`;

export default {
  '/reference-data/static-data/net-bucketing-dv01-sr-irg-cpi-dv01/csv': {
    get: {
      name: 'staticDataNetBucketingDv01SrIrgCpiDv01',
      summary: 'Export static data Net Bucketing Dv01 Sr Irg Cpi Dv01 csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_net_bucketing_dv01_sr_irg_cpi_dv01',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataNetBucketingDv01SrIrgCpiDv01Query,
        returnDataName: 'StaticDataNetBucketingDV01List',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'number',
          },
          {
            field: 'net2m_3m',
            name: 'Net2m_3m',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: 'Net3m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: 'Net1y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: 'Net3y',
            typeOf: 'number',
          },
          {
            field: 'net5y',
            name: 'Net5y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: 'Net10y',
            typeOf: 'number',
          },
          {
            field: 'net10yPlus',
            name: 'Net10yPlus',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: 'Net20y',
            typeOf: 'number',
          },
          {
            field: 'net20yPlus',
            name: 'Net20yPlus',
            typeOf: 'number',
          },
          {
            field: 'net30yPlus',
            name: 'Net30yPlus',
            typeOf: 'number',
          },
          {
            field: 'net1yPlus',
            name: 'Net1yPlus',
            typeOf: 'number',
          },
          {
            field: 'net3mCom',
            name: 'Net3mCom',
            typeOf: 'number',
          },
          {
            field: 'netLess1yCom',
            name: 'NetLess1yCom',
            typeOf: 'number',
          },
          {
            field: 'net1yCom',
            name: 'Net1yCom',
            typeOf: 'number',
          },
          {
            field: 'net3yCom',
            name: 'Net3yCom',
            typeOf: 'number',
          },
          {
            field: 'net5yCom',
            name: 'Net5yCom',
            typeOf: 'number',
          },
          {
            field: 'net10yCom',
            name: 'Net10yCom',
            typeOf: 'number',
          },
          {
            field: 'nFA2y',
            name: 'NFA2y',
            typeOf: 'number',
          },
          {
            field: 'nFA5y',
            name: 'NFA5y',
            typeOf: 'number',
          },
          {
            field: 'nFA10y',
            name: 'NFA10y',
            typeOf: 'number',
          },
          {
            field: 'nFA30y',
            name: 'NFA30y',
            typeOf: 'number',
          },
          {
            field: 'net1mFXO',
            name: 'Net1mFXO',
            typeOf: 'number',
          },
          {
            field: 'net2mFXO',
            name: 'Net2mFXO',
            typeOf: 'number',
          },
          {
            field: 'net3mFXO',
            name: 'Net3mFXO',
            typeOf: 'number',
          },
          {
            field: 'net6mFXO',
            name: 'Net6mFXO',
            typeOf: 'number',
          },
          {
            field: 'net1yFXO',
            name: 'Net1yFXO',
            typeOf: 'number',
          },
          {
            field: 'net2yFXO',
            name: 'Net2yFXO',
            typeOf: 'number',
          },
          {
            field: 'net3yFXO',
            name: 'Net3yFXO',
            typeOf: 'number',
          },
          {
            field: 'net4yFXO',
            name: 'Net4yFXO',
            typeOf: 'number',
          },
          {
            field: 'net5yFXO',
            name: 'Net5yFXO',
            typeOf: 'number',
          },
          {
            field: 'net7yFXO',
            name: 'Net7yFXO',
            typeOf: 'number',
          },
          {
            field: 'net10yFXO',
            name: 'Net10yFXO',
            typeOf: 'number',
          },
          {
            field: 'net6mPlus',
            name: 'Net6mPlus',
            typeOf: 'number',
          },
          {
            field: 'net2yPlus',
            name: 'Net2yPlus',
            typeOf: 'number',
          },
          {
            field: 'net3mRAT',
            name: 'Net3mRAT',
            typeOf: 'number',
          },
          {
            field: 'net1yRAT',
            name: 'Net1yRAT',
            typeOf: 'number',
          },
          {
            field: 'net2yRAT',
            name: 'Net2yRAT',
            typeOf: 'number',
          },
          {
            field: 'net3yRAT',
            name: 'Net3yRAT',
            typeOf: 'number',
          },
          {
            field: 'net5yRAT',
            name: 'Net5yRAT',
            typeOf: 'number',
          },
          {
            field: 'net7yRAT',
            name: 'Net7yRAT',
            typeOf: 'number',
          },
          {
            field: 'net10yRAT',
            name: 'Net10yRAT',
            typeOf: 'number',
          },
          {
            field: 'net15yRAT',
            name: 'Net15yRAT',
            typeOf: 'number',
          },
          {
            field: 'net20yRAT',
            name: 'Net20yRAT',
            typeOf: 'number',
          },
          {
            field: 'net25yRAT',
            name: 'Net25yRAT',
            typeOf: 'number',
          },
          {
            field: 'net30yPlusRAT',
            name: 'Net30yPlusRAT',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Net Bucketing Dv01 Sr Irg Cpi Dv01',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

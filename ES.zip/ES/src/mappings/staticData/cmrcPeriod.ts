import { APIMappingEntities } from '../../models/api.model';

const cmrcPeriodQuery = () => `
{
  CMRCPeriods {        
    id
    modified
    cmrcPeriodDate
    isActive
    isCmrcReported
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/limit-cmrc-period/csv': {
    get: {
      name: 'limitDataCMRCPeriod',
      summary: 'Export limit data CMRC Period csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_cmrc_period',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Limit Data' }],
      parameters: [],
      dataSource: {
        query: cmrcPeriodQuery,
        returnDataName: 'CMRCPeriods',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'cmrcPeriodDate',
            name: 'Cmrc Period',
            typeOf: 'string',
            sorting: true,
          },
          {
            field: 'isCmrcReported',
            name: 'Cmrc Reported',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data CMRC Periods',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

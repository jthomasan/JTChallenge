import { APIMappingEntities } from '../../models/api.model';

const staticDataMarketRiskBusinessGroupQuery = () => `
{
  StaticDataMarketRiskBusinessGroups {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/market-risk-business-group/csv': {
    get: {
      name: 'staticDataMarketRiskBusinessGroup',
      summary: 'Export static data Market Risk Business Group csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_market_risk_business_group',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataMarketRiskBusinessGroupQuery,
        returnDataName: 'StaticDataMarketRiskBusinessGroups',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'value',
        fields: [
          {
            field: 'value',
            name: 'Name',
            typeOf: 'string',
          },
          {
            field: 'description',
            name: 'Description',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Market Risk Business Group',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataLmeNonDeliveryDayQuery = () => `
{
  StaticDataLMENonDeliveryDays {
    modified
    date
    isLMENonDelivery
  }
}
`;

export default {
  '/reference-data/static-data/lme-non-delivery-day/csv': {
    get: {
      name: 'staticDataLmeNonDeliveryDay',
      summary: 'Export static data Lme Non Delivery Day csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_lme_non_delivery_day',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataLmeNonDeliveryDayQuery,
        returnDataName: 'StaticDataLMENonDeliveryDays',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'date',
        fields: [
          {
            field: 'date',
            name: 'LME Non-Delivery Days',
            typeOf: 'date',
          },
          {
            field: 'isLMENonDelivery',
            name: 'Is LME Non Delivery Day',
            typeOf: 'boolean',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Lme Non Delivery Day',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

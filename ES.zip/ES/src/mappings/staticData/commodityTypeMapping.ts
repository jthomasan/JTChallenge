import { APIMappingEntities } from '../../models/api.model';

const staticDataCommodityTypeMappingQuery = () => `
{
  StaticDataCommodityTypeMappings {
    id
    modified
    MXRiskLabel1
    MXRiskLabel3
    commodity{
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/commodity-type-mapping/csv': {
    get: {
      name: 'staticDataCommodityTypeMapping',
      summary: 'Export static data Commodity Type Mapping csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_commodity_type_mapping',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCommodityTypeMappingQuery,
        returnDataName: 'StaticDataCommodityTypeMappings',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'commodity.text',
        fields: [
          {
            field: 'MXRiskLabel1',
            name: 'MX_RiskLabel1',
            typeOf: 'string',
          },
          {
            field: 'MXRiskLabel3',
            name: 'MX_RiskLabel3',
            typeOf: 'string',
          },
          {
            field: 'commodity.text',
            name: 'Commodity Underlying Code',
            typeOf: 'string',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Commodity Type Mapping',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

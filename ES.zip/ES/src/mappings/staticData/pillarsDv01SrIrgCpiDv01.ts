import { APIMappingEntities } from '../../models/api.model';

const staticDataPillarsDv01SrIrgCpiDv01Query = () => `
{
  StaticDataPillarsDV01List {
    modified
    term
    net1d
    t_N
    net7d
    net1m
    net2m
    net3m
    net4m
    net5m
    net6m
    net9m
    net1y
    net1y3m
    net1y6m
    net1y9m
    net2y
    net3y
    net4y
    net5y
    net6y
    net7y
    net8y
    net9y
    net10y
    net15y
    net20y
    net25y
    net30y
    net40y
  }
}
`;

export default {
  '/reference-data/static-data/pillars-dv01-sr-irg-cpi-dv01/csv': {
    get: {
      name: 'staticDataPillarsDv01SrIrgCpiDv01',
      summary: 'Export static data Pillars Dv01 Sr Irg Cpi Dv01 csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_pillars_dv01_sr_irg_cpi_dv01',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataPillarsDv01SrIrgCpiDv01Query,
        returnDataName: 'StaticDataPillarsDV01List',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'term',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'number',
          },
          {
            field: 'net1d',
            name: '1d',
            typeOf: 'number',
          },
          {
            field: 't_N',
            name: 'T/N',
            typeOf: 'number',
          },
          {
            field: 'net7d',
            name: '7d',
            typeOf: 'number',
          },
          {
            field: 'net1m',
            name: '1m',
            typeOf: 'number',
          },
          {
            field: 'net2m',
            name: '2m',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: '3m',
            typeOf: 'number',
          },
          {
            field: 'net4m',
            name: '4m',
            typeOf: 'number',
          },
          {
            field: 'net5m',
            name: '5m',
            typeOf: 'number',
          },
          {
            field: 'net6m',
            name: '6m',
            typeOf: 'number',
          },
          {
            field: 'net9m',
            name: '9m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: '1y',
            typeOf: 'number',
          },
          {
            field: 'net1y3m',
            name: '1y3m',
            typeOf: 'number',
          },
          {
            field: 'net1y6m',
            name: '1y6m',
            typeOf: 'number',
          },
          {
            field: 'net1y9m',
            name: '1y9m',
            typeOf: 'number',
          },
          {
            field: 'net2y',
            name: '2y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: '3y',
            typeOf: 'number',
          },
          {
            field: 'net4y',
            name: '4y',
            typeOf: 'number',
          },
          {
            field: 'net5y',
            name: '5y',
            typeOf: 'number',
          },
          {
            field: 'net6y',
            name: '6y',
            typeOf: 'number',
          },
          {
            field: 'net7y',
            name: '7y',
            typeOf: 'number',
          },
          {
            field: 'net8y',
            name: '8y',
            typeOf: 'number',
          },
          {
            field: 'net9y',
            name: '9y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: '10y',
            typeOf: 'number',
          },
          {
            field: 'net15y',
            name: '15y',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: '20y',
            typeOf: 'number',
          },
          {
            field: 'net25y',
            name: '25y',
            typeOf: 'number',
          },
          {
            field: 'net30y',
            name: '30y',
            typeOf: 'number',
          },
          {
            field: 'net40y',
            name: '40y',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Pillars Dv01 Sr Irg Cpi Dv01',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

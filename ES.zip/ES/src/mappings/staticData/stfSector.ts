import { APIMappingEntities } from '../../models/api.model';

const staticDataSTFSectorQuery = () => `
  {
    StaticDataSTFSectors {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/stf-sector/csv': {
    get: {
      name: 'staticDataSTFSector',
      summary: 'Export static data STF sector csv',
      description: 'Returns all static data STF sectors in csv file',
      filename: 'Static_Data_STF_Sector',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataSTFSectorQuery,
        returnDataName: 'StaticDataSTFSectors',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Value',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data STF Sector',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

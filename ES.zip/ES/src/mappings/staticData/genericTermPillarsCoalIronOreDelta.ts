import { APIMappingEntities } from '../../models/api.model';

const staticDataGenericTermPillarsCoalIronOreDeltaQuery = () => `
{
  StaticDataGenericTermPillarsCoalIronOreDeltas {
    modified
    net7m_12m
    net4m_6m
    net2y
    term
    termUnit
    net0m_3m
    net3y_5y
  } 
}
`;

export default {
  '/reference-data/static-data/generic-term-pillars-coal-iron-ore-delta/csv': {
    get: {
      name: 'staticDataGenericTermPillarsCoalIronOreDelta',
      summary: 'Export static data Generic Term Pillars Coal Iron Ore Delta csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_generic_term_pillars_coal_iron_ore_delta',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGenericTermPillarsCoalIronOreDeltaQuery,
        returnDataName: 'StaticDataGenericTermPillarsCoalIronOreDeltas',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net0m_3m',
            name: 'Net0m_3m',
            typeOf: 'number',
          },
          {
            field: 'net4m_6m',
            name: 'Net4m_6m',
            typeOf: 'number',
          },
          {
            field: 'net7m_12m',
            name: 'Net7m_12m',
            typeOf: 'number',
          },
          {
            field: 'net2y',
            name: 'Net2y',
            typeOf: 'number',
          },
          {
            field: 'net3y_5y',
            name: 'Net3y_5y',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Generic Term Pillars Coal Iron Ore Delta',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

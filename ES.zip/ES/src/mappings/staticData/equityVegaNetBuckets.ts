import { APIMappingEntities } from '../../models/api.model';

const staticDataEquityVegaNetBucketsQuery = () => `
{
  StaticDataEquityVegaNetBuckets {
    modified
    term
    termUnit
    net1m
    net2m
    net3m
    net6m
    net1y
    net2y
    net3y
    net4y
  }
}
`;

export default {
  '/reference-data/static-data/equity-vega-net-buckets/csv': {
    get: {
      name: 'staticDataEquityVegaNetBuckets',
      summary: 'Export static data Equity Vega Net Buckets csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_equity_vega_net_buckets',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataEquityVegaNetBucketsQuery,
        returnDataName: 'StaticDataEquityVegaNetBuckets',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net1m',
            name: 'Net1m',
            typeOf: 'number',
          },
          {
            field: 'net2m',
            name: 'Net2m',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: 'Net3m',
            typeOf: 'number',
          },
          {
            field: 'net6m',
            name: 'Net6m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: 'Net1y',
            typeOf: 'number',
          },
          {
            field: 'net2y',
            name: 'Net2y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: 'Net3y',
            typeOf: 'number',
          },
          {
            field: 'net4y',
            name: 'Net4y',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Equity Vega Net Buckets',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataIssuerTypeQuery = () => `
  {
    StaticDataIssuerTypes {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/issuer-type/csv': {
    get: {
      name: 'staticDataIssuerType',
      summary: 'Export static data issuer type csv',
      description: 'Returns all static data issuer types in csv file',
      filename: 'Static_Data_Issuer_Type',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataIssuerTypeQuery,
        returnDataName: 'StaticDataIssuerTypes',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Value',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Issuer Type',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataCapletSwaptionVegaBucketQuery = () => `
  {
    StaticDataCapletSwaptionVegaBuckets {
      term
      termUnit
      modified
      net1m
      net3m
      net6m
      net1y
      net2y
      net3y
      net4y
      net5y
      net7y
      net10y
      net15y
      net20y
      net25y
      net30yPlus
    }
  }
`;

export default {
  '/reference-data/static-data/caplet-swaption-vega-bucket/csv': {
    get: {
      name: 'staticDataCapletSwaptionVegaBucket',
      summary: 'Export static data caplet swaption vega bucket csv',
      description: 'Returns all static data caplet swaption vega buckets in csv file',
      filename: 'Static_Data_Caplet_Swaption_Vega_Bucket',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCapletSwaptionVegaBucketQuery,
        returnDataName: 'StaticDataCapletSwaptionVegaBuckets',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Days to Maturity',
            typeOf: 'string',
            field: 'term',
            sorting: true,
            customSortingField: 'termUnit',
          },
          {
            name: 'Net1m',
            typeOf: 'number',
            field: 'net1m',
          },
          {
            name: 'Net3m',
            typeOf: 'number',
            field: 'net3m',
          },
          {
            name: 'Net6m',
            typeOf: 'number',
            field: 'net6m',
          },
          {
            name: 'Net1y',
            typeOf: 'number',
            field: 'net1y',
          },
          {
            name: 'Net2y',
            typeOf: 'number',
            field: 'net2y',
          },
          {
            name: 'Net3y',
            typeOf: 'number',
            field: 'net3y',
          },
          {
            name: 'Net4y',
            typeOf: 'number',
            field: 'net4y',
          },
          {
            name: 'Net5y',
            typeOf: 'number',
            field: 'net5y',
          },
          {
            name: 'Net7y',
            typeOf: 'number',
            field: 'net7y',
          },
          {
            name: 'Net10y',
            typeOf: 'number',
            field: 'net10y',
          },
          {
            name: 'Net15y',
            typeOf: 'number',
            field: 'net15y',
          },
          {
            name: 'Net20y',
            typeOf: 'number',
            field: 'net20y',
          },
          {
            name: 'Net25y',
            typeOf: 'number',
            field: 'net25y',
          },
          {
            name: 'Net30yPlus',
            typeOf: 'number',
            field: 'net30yPlus',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            name: 'Static Data Caplet Swaption Vega Bucket',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

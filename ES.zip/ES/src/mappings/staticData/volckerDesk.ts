import { APIMappingEntities } from '../../models/api.model';

const staticDataVolckerDeskQuery = () => `
{
  StaticDataVolckerDesk {
    id
    modified
    name
    description
    isActive
    reportingCategory {
      id
      text
    }
    GlobalBusinessUnit {
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/volcker-desk/csv': {
    get: {
      name: 'staticDataVolckerDesk',
      summary: 'Export static data Volcker Desk csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_volcker_desk',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataVolckerDeskQuery,
        returnDataName: 'StaticDataVolckerDesk',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'name',
        fields: [
          {
            field: 'name',
            name: 'Name',
            typeOf: 'string',
          },
          {
            field: 'description',
            name: 'Description',
            typeOf: 'string',
          },
          {
            field: 'GlobalBusinessUnit.text',
            name: 'GlobalBusinessUnit',
            typeOf: 'string',
          },
          {
            field: 'reportingCategory.text',
            name: 'ReportingCategory',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Volcker Desk',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

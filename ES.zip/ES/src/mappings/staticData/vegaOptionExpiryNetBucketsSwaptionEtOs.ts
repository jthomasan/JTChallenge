import { APIMappingEntities } from '../../models/api.model';

const staticDataVegaOptionExpiryNetBucketsSwaptionEtOsQuery = () => `
{
  StaticDataVegaOptionExpiryNetBucktsSwaptionEtos {
    modified
    net10y
    net30yPlus
    net20y
    net1y
    net3m
    term
    termUnit
    net20yPlus
    net3y
  } 
}
`;

export default {
  '/reference-data/static-data/vega-option-expiry-net-buckets-swaption-et-os/csv': {
    get: {
      name: 'staticDataVegaOptionExpiryNetBucketsSwaptionEtOs',
      summary: 'Export static data Vega Option Expiry Net Buckets Swaption Et Os csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_vega_option_expiry_net_buckets_swaption_et_os',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataVegaOptionExpiryNetBucketsSwaptionEtOsQuery,
        returnDataName: 'StaticDataVegaOptionExpiryNetBucktsSwaptionEtos',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net3m',
            name: 'Net3m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: 'Net1y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: 'Net3y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: 'Net10y',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: 'Net20y',
            typeOf: 'number',
          },
          {
            field: 'net20yPlus',
            name: 'Net20yPlus',
            typeOf: 'number',
          },
          {
            field: 'net30yPlus',
            name: 'Net30yPlus',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Vega Option Expiry Net Buckets Swaption Et Os',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataCreditStressCdsRatingQuery = () => `
{
  StaticDataCreditStressCDSRatings {
    modified
    anzRatingTypeSystem {
      id
      text
    }
    longStress
    shortStress
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/credit-stress-cds-rating/csv': {
    get: {
      name: 'staticDataCreditStressCdsRating',
      summary: 'Export static data Credit Stress Cds Rating csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_credit_stress_cds_ratings',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCreditStressCdsRatingQuery,
        returnDataName: 'StaticDataCreditStressCDSRatings',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'anzRatingTypeSystem.text',
        fields: [
          {
            field: 'anzRatingTypeSystem.text',
            name: 'Rating',
            typeOf: 'string',
          },
          {
            field: 'longStress',
            name: 'Long Stress',
            typeOf: 'number',
          },
          {
            field: 'shortStress',
            name: 'Short Stress',
            typeOf: 'number',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Credit Stress Cds Rating',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

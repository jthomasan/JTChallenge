import { APIMappingEntities } from '../../models/api.model';
import haircutReferenceProcessor from '../../processors/staticData/haircutReferenceProcessor';

const staticDataHaircutReferenceQuery = () => `
{
  StaticDataHaircutReferences {
    id
    modified
    tier
    counterpartySector
    counterpartyCcr
    rating
    maturityBucket
    haircut
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/haircut-reference/csv': {
    get: {
      name: 'staticDataHaircutReference',
      summary: 'Export static data Haircut Reference csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_haircut_reference',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataHaircutReferenceQuery,
        returnDataName: 'StaticDataHaircutReferences',
      },
      exportInfo: {
        customProcessor: haircutReferenceProcessor,
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Haircut Reference',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

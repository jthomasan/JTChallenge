import { APIMappingEntities } from '../../models/api.model';

const staticDataExcessReasonsQuery = () => `
{
  StaticDataExcessReasons {
    id
    modified
    description
    isActive
    added{
      time
      by
    }
  }
}
`;

export default {
  '/reference-data/static-data/excess-reasons/csv': {
    get: {
      name: 'staticDataExcessReasons',
      summary: 'Export static data Excess Reasons csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_excess_reasons',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataExcessReasonsQuery,
        returnDataName: 'StaticDataExcessReasons',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'description',
        fields: [
          {
            field: 'description',
            name: 'Reason',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Excess Reasons',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

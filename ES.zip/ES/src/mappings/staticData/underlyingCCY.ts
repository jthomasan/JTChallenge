import { APIMappingEntities } from '../../models/api.model';

const staticDataUnderlyingCCYQuery = () => `
  {
    StaticDataUnderlyingCCYs {
      id
      modified
      name
      description
      comment
      offShore
      isMajor
      isISO
      ccyPreciousMetalsNonPMTypeSystem {
        id
        text
      }
      ccyOnshoreOffshoreTypeSystem {
        id
        text
      }
      ccyMajorMinorTypeSystem {
        id
        text
      }
      ccyGroupTypeSystem {
        id
        text
      }
      ccyFamilyLMTypeSystem {
        id
        text
      }
      ccyFamilyFXTypeSystem {
        id
        text
      }
      ccyFamilyFXOTypeSystem {
        id
        text
      }
      ccyCdsDeliverableTypeSystem {
        id
        text
      }
      Curve {
        id
        text
      }
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/underlying-ccy/csv': {
    get: {
      name: 'staticDataUnderlyingCCY',
      summary: 'Export static data underlying ccy csv',
      description: 'Returns all static data underlying ccys in csv file',
      filename: 'Static_Data_Underlying_CCY',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataUnderlyingCCYQuery,
        returnDataName: 'StaticDataUnderlyingCCYs',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Underlying - CCY',
            typeOf: 'string',
            field: 'name',
            sorting: true,
          },
          {
            name: 'Description',
            typeOf: 'string',
            field: 'description',
          },
          {
            name: 'OffShore',
            typeOf: 'string',
            field: 'offShore',
          },
          {
            name: 'Is ISO',
            typeOf: 'boolean',
            field: 'isISO',
          },
          {
            name: 'Is Major',
            typeOf: 'boolean',
            field: 'isMajor',
          },
          {
            name: 'Grp: CCY family FXO',
            typeOf: 'string',
            field: 'ccyFamilyFXOTypeSystem.text',
          },
          {
            name: 'Grp: CCY Group',
            typeOf: 'string',
            field: 'ccyGroupTypeSystem.text',
          },
          {
            name: 'Grp: CCY CDS Deliverable',
            typeOf: 'string',
            field: 'ccyCdsDeliverableTypeSystem.text',
          },
          {
            name: 'Curve',
            typeOf: 'string',
            field: 'Curve.text',
          },
          {
            name: 'Comment',
            typeOf: 'string',
            field: 'comment',
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            name: 'Static Data Underlying CCY',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

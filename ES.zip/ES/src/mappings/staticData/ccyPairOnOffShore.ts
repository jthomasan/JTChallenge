import { APIMappingEntities } from '../../models/api.model';

const staticDataCCYPairOnOffShoreQuery = () => `
  {
    StaticDataCCYPairOnOffShores {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/ccy-pair-on-off-shore/csv': {
    get: {
      name: 'staticDataCCYPairOnOffShore',
      summary: 'Export static data CCY Pair On Off Shore csv',
      description: 'Returns all static data CCY Pair On Off Shores in csv file',
      filename: 'Static_Data_CCY_Pair_OnOffShore',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCCYPairOnOffShoreQuery,
        returnDataName: 'StaticDataCCYPairOnOffShores',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Value',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data CCY Pair On Off Shore',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

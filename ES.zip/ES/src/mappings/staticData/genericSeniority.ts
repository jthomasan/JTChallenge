import { APIMappingEntities } from '../../models/api.model';

const staticDataGenericSeniorityQuery = () => `
  {
    StaticDataGenericSeniorities {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/generic-seniority/csv': {
    get: {
      name: 'staticDataGenericSeniority',
      summary: 'Export static data generic seniority csv',
      description: 'Returns all static data generic seniorities in csv file',
      filename: 'Static_Data_Generic_Seniority',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGenericSeniorityQuery,
        returnDataName: 'StaticDataGenericSeniorities',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Value',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Generic Seniority',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataSpecRiskTradeExclusionQuery = () => `
{
  StaticDataSpecRiskTradeExclusions {
    id
    modified
    reportName {
      id
      text
    }
    tradeNumber
    comment
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/spec-risk-trade-exclusion/csv': {
    get: {
      name: 'staticDataSpecRiskTradeExclusion',
      summary: 'Export static data Spec Risk Trade Exclusion csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_spec_risk_trade_exclusion',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataSpecRiskTradeExclusionQuery,
        returnDataName: 'StaticDataSpecRiskTradeExclusions',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'reportName',
        fields: [
          {
            field: 'reportName.text',
            name: 'Report Type',
            typeOf: 'string',
          },
          {
            field: 'tradeNumber',
            name: 'Trade Number',
            typeOf: 'number',
          },
          {
            field: 'comment',
            name: 'Comment',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Spec Risk Trade Exclusion',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataLegalEntityQuery = () => `
  {
    StaticDataLegalEntities {
      id
      modified
      name
      hierarchy {
        id
        text
      }
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/legal-entity/csv': {
    get: {
      name: 'staticDataLegalEntity',
      summary: 'Export static data legal entity csv',
      description: 'Returns all static data legal entities in csv file',
      filename: 'Static_Data_Legal_Entity',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataLegalEntityQuery,
        returnDataName: 'StaticDataLegalEntities',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Name',
            typeOf: 'string',
            field: 'name',
            sorting: true,
          },
          {
            name: 'Legal Entity Hierarchy',
            typeOf: 'string',
            field: 'hierarchy.text',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Legal Entity',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

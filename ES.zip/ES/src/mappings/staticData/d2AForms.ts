import { APIMappingEntities } from '../../models/api.model';

const staticDataD2AFormsQuery = () => `
{
  StaticDataDTwoAForms {
    id
    modified
    version
    order
    formCode
    returnIdentifier {
      id
      text
    }
    formName
    calculateTwoLevels
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/d2-a-forms/csv': {
    get: {
      name: 'staticDataD2AForms',
      summary: 'Export static data D2 A Forms csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_d2_a_forms',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataD2AFormsQuery,
        returnDataName: 'StaticDataDTwoAForms',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'formName',
        fields: [
          {
            field: 'formName',
            name: 'Form Name',
            typeOf: 'string',
          },
          {
            field: 'formCode',
            name: 'Form Code',
            typeOf: 'string',
          },
          {
            field: 'returnIdentifier.text',
            name: 'Return Identifier',
            typeOf: 'string',
          },
          {
            field: 'version',
            name: 'Version',
            typeOf: 'number',
          },
          {
            field: 'calculateTwoLevels',
            name: 'Calculate Two Levels',
            typeOf: 'string',
          },
          {
            field: 'order',
            name: 'Order',
            typeOf: 'number',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data D2 A Forms',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

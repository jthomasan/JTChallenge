import { APIMappingEntities } from '../../models/api.model';

const staticDataGrpStfGeographyQuery = () => `
{
  StaticDataGrpSTFGeographies {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/grp-stf-geography/csv': {
    get: {
      name: 'staticDataGrpStfGeography',
      summary: 'Export static data Grp Stf Geography csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_grp_stf_geography',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGrpStfGeographyQuery,
        returnDataName: 'StaticDataGrpSTFGeographies',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'value',
        fields: [
          {
            field: 'value',
            name: 'Value',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Grp Stf Geography',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

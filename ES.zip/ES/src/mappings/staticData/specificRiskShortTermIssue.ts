import { APIMappingEntities } from '../../models/api.model';

const staticDataSpecificRiskShortTermIssueQuery = () => `
{
  StaticDataSpecificRiskShortTermIssues {
    id
    modified
    sTRatingBandTypeSystem {
      id
      text
    }
    resecuritisationExposures
    securitisationExposures
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/specific-risk-short-term-issue/csv': {
    get: {
      name: 'staticDataSpecificRiskShortTermIssue',
      summary: 'Export static data Specific Risk Short Term Issue csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_specific_risk_short_term_issue',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataSpecificRiskShortTermIssueQuery,
        returnDataName: 'StaticDataSpecificRiskShortTermIssues',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'sTRatingBandTypeSystem.text',
        fields: [
          {
            field: 'sTRatingBandTypeSystem.text',
            name: 'ST Rating Band',
            typeOf: 'string',
          },
          {
            field: 'securitisationExposures',
            name: 'Securitisation Exposures (%)',
            typeOf: 'number',
          },
          {
            field: 'resecuritisationExposures',
            name: 'Re-Securitisation Exposures (%)',
            typeOf: 'number',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Specific Risk Short Term Issue',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

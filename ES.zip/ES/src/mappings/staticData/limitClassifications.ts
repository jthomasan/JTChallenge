import { APIMappingEntities } from '../../models/api.model';

const staticDataLimitClassificationsQuery = () => `
{
  StaticDataLimitClassifications {
    id
    modified
    description
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/limit-classifications/csv': {
    get: {
      name: 'staticDataLimitClassifications',
      summary: 'Export static data Limit Classifications csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_limit_classifications',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataLimitClassificationsQuery,
        returnDataName: 'StaticDataLimitClassifications',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'description',
        fields: [
          {
            field: 'description',
            name: 'Classification',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Limit Classifications',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const requireDir = require('require-dir');

const requires = requireDir('./');

export default Object.values(requires).reduce((acc: any, curr: any) => {
  return {
    ...acc,
    ...curr.default,
  };
}, {}) as APIMappingEntities;

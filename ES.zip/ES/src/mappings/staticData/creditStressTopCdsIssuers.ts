import { APIMappingEntities } from '../../models/api.model';

const staticDataCreditStressTopCdsIssuersQuery = () => `
{
  StaticDataCreditStressTopCDSIssuers {
    modified
    Issuer {
      id
      text
    }
    longStress
    shortStress
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/credit-stress-top-cds-issuers/csv': {
    get: {
      name: 'staticDataCreditStressTopCdsIssuers',
      summary: 'Export static data Credit Stress Top Cds Issuers csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_credit_stress_top_cds_issuers',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCreditStressTopCdsIssuersQuery,
        returnDataName: 'StaticDataCreditStressTopCDSIssuers',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'Issuer.text',
        fields: [
          {
            field: 'Issuer.text',
            name: 'Issuer',
            typeOf: 'string',
          },
          {
            field: 'longStress',
            name: 'Long Stress',
            typeOf: 'number',
          },
          {
            field: 'shortStress',
            name: 'Short Stress',
            typeOf: 'number',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Credit Stress Top Cds Issuers',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataGenericTermPillarsPetroleumDeltaQuery = () => `
{
  StaticDataGenericTermPillarsPetroleumDeltas {
    modified
    term
    termUnit
    net5y_8y
    net0y_5y
  } 
}
`;

export default {
  '/reference-data/static-data/generic-term-pillars-petroleum-delta/csv': {
    get: {
      name: 'staticDataGenericTermPillarsPetroleumDelta',
      summary: 'Export static data Generic Term Pillars Petroleum Delta csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_generic_term_pillars_petroleum_delta',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGenericTermPillarsPetroleumDeltaQuery,
        returnDataName: 'StaticDataGenericTermPillarsPetroleumDeltas',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net0y_5y',
            name: 'Net0y_5y',
            typeOf: 'number',
          },
          {
            field: 'net5y_8y',
            name: 'Net5y_8y',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Generic Term Pillars Petroleum Delta',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

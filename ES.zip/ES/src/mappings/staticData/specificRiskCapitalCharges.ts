import { APIMappingEntities } from '../../models/api.model';

const staticDataSpecificRiskCapitalChargesQuery = () => `
{
  StaticDataSpecificRiskCapitalCharges {
    id
    modified
    ratingBandTypeSystem {
      id
      text
    }
    tenor {
      id
      text
    }
    sRCapitalCharge
    sRCategory {
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/specific-risk-capital-charges/csv': {
    get: {
      name: 'staticDataSpecificRiskCapitalCharges',
      summary: 'Export static data Specific Risk Capital Charges csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_specific_risk_capital_charges',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataSpecificRiskCapitalChargesQuery,
        returnDataName: 'StaticDataSpecificRiskCapitalCharges',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'sRCategory.text',
        fields: [
          {
            field: 'sRCategory.text',
            name: 'Category',
            typeOf: 'string',
          },
          {
            field: 'ratingBandTypeSystem.text',
            name: 'Rating Band',
            typeOf: 'string',
          },
          {
            field: 'tenor.text',
            name: 'Tenor',
            typeOf: 'string',
          },
          {
            field: 'sRCapitalCharge',
            name: 'Capital Charge (%)',
            typeOf: 'number',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Specific Risk Capital Charges',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

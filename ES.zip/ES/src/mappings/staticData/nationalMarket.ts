import { APIMappingEntities } from '../../models/api.model';

const staticDataNationalMarketQuery = () => `
{
  StaticDataNationalMarkets {
    id
    modified
    securityMarket
    nationalMarketTypeSystem {
      id
      text
    }
    comment
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/national-market/csv': {
    get: {
      name: 'staticDataNationalMarket',
      summary: 'Export static data National Market csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_national_market',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataNationalMarketQuery,
        returnDataName: 'StaticDataNationalMarkets',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'securityMarket',
        fields: [
          {
            field: 'securityMarket',
            name: 'Security Market',
            typeOf: 'string',
          },
          {
            field: 'nationalMarketTypeSystem.text',
            name: 'Grp: National Market',
            typeOf: 'string',
          },
          {
            field: 'comment',
            name: 'Comment',
            typeOf: 'string',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data National Market',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

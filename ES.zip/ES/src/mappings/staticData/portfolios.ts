import { APIMappingEntities } from '../../models/api.model';
import staticDataPortfoliosProcessor from '../../processors/staticData/staticDataPortfoliosProcessor';

const staticDataPortfoliosQuery = () => `
{
  StaticDataPortfolios {
    id
    modified
    name
    comment
    isActive
    isEaR
    isFinance
    reportRunList
    volckerDeskName
    accountingTypeSystem {
      id
      text
    }
    assetTypeSystem {
      id
      text
    }
    capitalHierarchy {
      id
      text
    }
    bookTypeSystem {
      id
      text
    }
    creditBookTypeSystem {
      id
      text
    }    
    tradeBookingSystem {
      id
      text
    }
    aggregateTradeCubeFlag
    riskHierarchy {
      id
      value
      fullPath
    }
    financeHierarchy {
      id
      value
    }
    geographyHierarchy {
      id
      value
    }
    hyperionUnit {
      id
      text
    }
    added {
      by
      time
    }
    exclusion {
      by
      reason
    }
    isLEGroupSubset
    mxLegalEntityCode
    quarantine {
      isQuarantined
      date
    }
    reviewDate
    reviewer {
      id
      text
    } 
    source {
      id
      text
    }
    syntheticPortfolio {
      id
      text
    }
    isReviewed
  }
}
`;

export default {
  '/reference-data/static-data/portfolios/csv': {
    get: {
      name: 'staticDataPortfolios',
      summary: 'Export static data portfolios csv',
      description: 'Returns all static data portfolios in csv file',
      filename: 'Static_Data_Portfolios',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataPortfoliosQuery,
        returnDataName: 'StaticDataPortfolios',
      },
      exportInfo: {
        customProcessor: staticDataPortfoliosProcessor,
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Portfolio',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

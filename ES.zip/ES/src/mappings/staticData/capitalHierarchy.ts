import { APIMappingEntities } from '../../models/api.model';

const staticDataCapitalHierarchyQuery = () => `
  {
    StaticDataCapitalHierarchies {
      id
      name
      isActive
      stressFactor
      tenDayStd
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/capital-hierarchy/csv': {
    get: {
      name: 'staticDataCapitalHierarchy',
      summary: 'Export static data capital hierarchy csv',
      description: 'Returns all static data capital hierarchies in csv file',
      filename: 'Static_Data_Capital_Hierarchy',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCapitalHierarchyQuery,
        returnDataName: 'StaticDataCapitalHierarchies',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Name',
            typeOf: 'string',
            field: 'name',
            sorting: true,
          },
          {
            name: '10/1 Day Std Var',
            typeOf: 'number',
            field: 'tenDayStd',
          },
          {
            name: 'Stress Var',
            typeOf: 'number',
            field: 'stressFactor',
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Capital Hierarchy',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

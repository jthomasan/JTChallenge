import { APIMappingEntities } from '../../models/api.model';

const staticDataEquityUnderlyingSpecificRiskMapQuery = () => `
{
  StaticDataEquityUnderlyingSpecificRiskMaps {
    id
    modified
    mappedTicker {
      id
      text
    }
    ticker {
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/equity-underlying-specific-risk-map/csv': {
    get: {
      name: 'staticDataEquityUnderlyingSpecificRiskMap',
      summary: 'Export static data Equity Underlying Specific Risk Map csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_equity_underlying_specific_risk_map',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataEquityUnderlyingSpecificRiskMapQuery,
        returnDataName: 'StaticDataEquityUnderlyingSpecificRiskMaps',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'ticker.text',
        fields: [
          {
            field: 'ticker.text',
            name: 'Underlying - EQ',
            typeOf: 'string',
          },
          {
            field: 'mappedTicker.text',
            name: 'Mapped Underlying EQ',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Equity Underlying Specific Risk Map',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

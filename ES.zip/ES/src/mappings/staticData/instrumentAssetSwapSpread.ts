import { getArgs } from '..';
import { APIMappingEntities } from '../../models/api.model';

const staticDataInstrumentAssetSwapSpreadQuery = (params: any) => `
  {
    StaticDataInstrumentAssetSwapSpreads(${getArgs(params)})
  }
`;

export default {
  '/reference-data/static-data/instrument-asset-swap-spread/csv': {
    get: {
      name: 'staticDataInstrumentAssetSwapSpread',
      summary: 'Export static data instrument asset swap spread csv',
      description: 'Returns all static data instrument asset swap spreads in csv file',
      filename: ({ query }) => {
        const date = (query.cob as string) ?? '';

        return `static_data_instrument_asset_swap_spread_${date.replace(/\-/g, '')}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [
        {
          name: 'cob',
          in: 'query',
          description: 'Search by cob date',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: staticDataInstrumentAssetSwapSpreadQuery,
        returnDataName: 'StaticDataInstrumentAssetSwapSpreads',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Instrument',
            typeOf: 'string',
            field: 'name',
            sorting: true,
          },
          {
            name: 'ISIN',
            typeOf: 'string',
            field: 'ISIN',
          },
          {
            name: 'Spread',
            typeOf: 'string',
            field: 'spread',
          },
          {
            name: 'Is Live',
            typeOf: 'boolean',
            field: 'isLive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Instrument Asset Swap Spread',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

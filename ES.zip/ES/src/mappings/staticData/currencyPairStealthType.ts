import { APIMappingEntities } from '../../models/api.model';

const staticDataCurrencyPairStealthTypeQuery = () => `
{
  StaticDataCurrencyPairStealthTypes {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/currency-pair-stealth-type/csv': {
    get: {
      name: 'staticDataCurrencyPairStealthType',
      summary: 'Export static data Currency Pair Stealth Type csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_currency_pair_stealth_type',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCurrencyPairStealthTypeQuery,
        returnDataName: 'StaticDataCurrencyPairStealthTypes',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'value',
            name: 'Value',
            typeOf: 'string',
            sorting: 'true',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
        responses: {
          '200': {
            description: 'An array of strings',
            schema: {
              title: 'Static Data Currency Pair Stealth Type',
              type: 'array',
              items: {
                type: 'string',
              },
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

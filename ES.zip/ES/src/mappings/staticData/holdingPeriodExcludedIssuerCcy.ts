import { APIMappingEntities } from '../../models/api.model';

const staticDataHoldingPeriodExcludedIssuerCcyQuery = () => `
{
  StaticDataHoldingPeriodExcludedIssuerCcys {
    modified
    issuer {
      id
      text
      description
    }
    ccy {
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/holding-period-excluded-issuer-ccy/csv': {
    get: {
      name: 'staticDataHoldingPeriodExcludedIssuerCcy',
      summary: 'Export static data Holding Period Excluded Issuer Ccy csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_holding_period_excluded_issuer_ccy',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataHoldingPeriodExcludedIssuerCcyQuery,
        returnDataName: 'StaticDataHoldingPeriodExcludedIssuerCcys',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'issuer.text',
        fields: [
          {
            field: 'issuer.text',
            name: 'Issuer',
            typeOf: 'string',
          },
          {
            field: 'issuer.description',
            name: 'Issuer Description',
            typeOf: 'string',
          },
          {
            field: 'ccy.text',
            name: 'Currency',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Holding Period Excluded Issuer Ccy',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataUnderlyingIrCurveQuery = () => `
{
  StaticDataUnderlyingIRCurves {
    id
    modified
    description
    SCCYTypeTypeSystem {
      id
      text
    }
    tenorLowerDays
    tenorUpperDays
    curveTypeSystem {
      id
      text
    }
    curve
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/underlying-ir-curve/csv': {
    get: {
      name: 'staticDataUnderlyingIrCurve',
      summary: 'Export static data Underlying Ir Curve csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_underlying_ir_curve',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataUnderlyingIrCurveQuery,
        returnDataName: 'StaticDataUnderlyingIRCurves',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'curve',
            name: 'Curve',
            typeOf: 'string',
            sorting: 'true',
          },
          {
            field: 'description',
            name: 'Description',
            typeOf: 'string',
          },
          {
            field: 'tenorLowerDays',
            name: 'TenorLowerDays',
            typeOf: 'string',
          },
          {
            field: 'tenorUpperDays',
            name: 'TenorUpperDays',
            typeOf: 'string',
          },
          {
            field: 'SCCYTypeTypeSystem.text',
            name: 'SingleCurveType',
            typeOf: 'string',
          },
          {
            field: 'curveTypeSystem.text',
            name: 'CurveType',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
        responses: {
          '200': {
            description: 'An array of strings',
            schema: {
              title: 'Static Data Underlying Ir Curve',
              type: 'array',
              items: {
                type: 'string',
              },
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataNetBucketingXccyBasisBasisGammaQuery = () => `
{
  StaticDataNetBucketXccyBasisGammas {
    modified
    net10y
    net30yPlus
    net20y
    net10yPlus
    net1y
    net3m
    term
    termUnit
    netUnder3m
    net5y
    net3y
  } 
}
`;

export default {
  '/reference-data/static-data/net-bucketing-xccy-basis-basis-gamma/csv': {
    get: {
      name: 'staticDataNetBucketingXccyBasisBasisGamma',
      summary: 'Export static data Net Bucketing Xccy Basis Basis Gamma csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_net_bucketing_xccy_basis_basis_gamma',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataNetBucketingXccyBasisBasisGammaQuery,
        returnDataName: 'StaticDataNetBucketXccyBasisGammas',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'netUnder3m',
            name: 'NetUnder3m',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: 'Net3m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: 'Net1y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: 'Net3y',
            typeOf: 'number',
          },
          {
            field: 'net5y',
            name: 'Net5y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: 'Net10y',
            typeOf: 'number',
          },
          {
            field: 'net10yPlus',
            name: 'Net10yPlus',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: 'Net20y',
            typeOf: 'number',
          },
          {
            field: 'net30yPlus',
            name: 'Net30yPlus',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Net Bucketing Xccy Basis Basis Gamma',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

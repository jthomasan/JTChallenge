import { APIMappingEntities } from '../../models/api.model';

const staticDataHoldingPeriodTradeQuery = ({ cob }) => `
{
  StaticDataHoldingPeriodTrades (cob: ${cob}) {
    modified
    currencyName
    family
    group
    issuerName
    baseNotional
    instrumentName
    isInMRE
    isExcludedTrade
    isLongDated
    isReplacedTrade
    isSettlementTrade
    maturityDate
    notional
    portfolioName
    rank
    replaceDate
    replaced
    reportDate
    nb
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/holding-period-trade/csv': {
    get: {
      name: 'staticDataHoldingPeriodTrade',
      summary: 'Export static data Holding Period Trade csv',
      description: 'Returns all data in csv file',
      filename: ({ query }) => {
        const date = (query.cob as string) ?? '';

        return `static_data_holding_period_trade_${date.replace(/\-/g, '')}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [
        {
          name: 'cob',
          in: 'query',
          description: 'Search by cob date',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: staticDataHoldingPeriodTradeQuery,
        returnDataName: 'StaticDataHoldingPeriodTrades',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'nb',
        fields: [
          {
            field: 'reportDate',
            name: 'Report Date',
            typeOf: 'string',
          },
          {
            field: 'family',
            name: 'Family',
            typeOf: 'string',
          },
          {
            field: 'group',
            name: 'Group',
            typeOf: 'string',
          },
          {
            field: 'nb',
            name: 'Trade ID',
            typeOf: 'string',
          },
          {
            field: 'isInMRE',
            name: 'Status',
            typeOf: 'boolean',
          },
          {
            field: 'instrumentName',
            name: 'Instrument',
            typeOf: 'string',
          },
          {
            field: 'portfolioName',
            name: 'Portfolio',
            typeOf: 'string',
          },
          {
            field: 'currencyName',
            name: 'Currency',
            typeOf: 'string',
          },
          {
            field: 'notional',
            name: 'Notional',
            typeOf: 'string',
          },
          {
            field: 'baseNotional',
            name: 'Base Notional',
            typeOf: 'numeric',
          },
          {
            field: 'maturityDate',
            name: 'Maturity Date',
            typeOf: 'string',
          },
          {
            field: 'issuerName',
            name: 'Issuer',
            typeOf: 'string',
          },
          {
            field: 'rank',
            name: 'Rank',
            typeOf: 'string',
          },
          {
            field: 'isLongDated',
            name: 'Is Long Dated',
            typeOf: 'boolean',
          },
          {
            field: 'isSettlementTrade',
            name: 'Is Settlement Trade',
            typeOf: 'boolean',
          },
          {
            field: 'isExcludedTrade',
            name: 'Is Excluded Trade',
            typeOf: 'boolean',
          },
          {
            field: 'replaceDate',
            name: 'Replace Date',
            typeOf: 'string',
          },
          {
            field: 'replaced',
            name: 'Replaced ID',
            typeOf: 'numeric',
          },
          {
            field: 'isReplacedTrade',
            name: 'Is Replaced Trade',
            typeOf: 'boolean',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Holding Period Trade',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

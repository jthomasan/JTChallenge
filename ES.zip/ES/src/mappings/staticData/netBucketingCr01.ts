import { APIMappingEntities } from '../../models/api.model';

const staticDataNetBucketingCr01Query = () => `
{
  StaticDataNetBucketingCR01List {
    modified
    term
    termUnit
    net3m
    net1y
    net3y
    net5y
    net10y
    net20y
    net30yPlus
  }
}
`;

export default {
  '/reference-data/static-data/net-bucketing-cr01/csv': {
    get: {
      name: 'staticDataNetBucketingCr01',
      summary: 'Export static data Net Bucketing Cr01 csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_net_bucketing_cr01',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataNetBucketingCr01Query,
        returnDataName: 'StaticDataNetBucketingCR01List',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: 'Net3m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: 'Net1y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: 'Net3y',
            typeOf: 'number',
          },
          {
            field: 'net5y',
            name: 'Net5y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: 'Net10y',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: 'Net20y',
            typeOf: 'number',
          },
          {
            field: 'net30yPlus',
            name: 'Net30yPlus',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Net Bucketing Cr01',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

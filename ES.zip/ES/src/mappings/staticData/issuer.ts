import { APIMappingEntities } from '../../models/api.model';

const staticDataIssuerQuery = () => `
{
  StaticDataIssuers
}
`;

export default {
  '/reference-data/static-data/issuer/csv': {
    get: {
      name: 'staticDataIssuer',
      summary: 'Export static data Issuer csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_issuer',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataIssuerQuery,
        returnDataName: 'StaticDataIssuers',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'issuerCode',
        fields: [
          {
            field: 'issuerCode',
            name: 'Issuer Code',
            typeOf: 'string',
            sorting: true,
          },
          {
            field: 'isUpdatedFromAc',
            name: 'Is Updated from AC',
            typeOf: 'boolean',
          },
          {
            field: 'isAcQuarantine',
            name: 'Is in AC Quarantine',
            typeOf: 'boolean',
          },
          {
            field: 'description',
            name: 'Description',
            typeOf: 'string',
          },
          {
            field: 'ultimateParentCompanyName',
            name: 'BB Ultimate Parent Name',
            typeOf: 'string',
          },
          {
            field: 'ultimateParentTickerExchange',
            name: 'BB Ultimate Parent Equity Ticker',
            typeOf: 'string',
          },
          {
            field: 'parentRelation',
            name: 'Parent/Issuer Relation',
            typeOf: 'string',
          },
          {
            field: 'bbBicsLevel1SectorName',
            name: 'BICS Level 1',
            typeOf: 'string',
          },
          {
            field: 'bbBicsLevel2IndustryGroupName',
            name: 'BICS Level 2',
            typeOf: 'string',
          },
          {
            field: 'bbBicsLevel3IndustryName',
            name: 'BICS Level 3',
            typeOf: 'string',
          },
          {
            field: 'castParentName',
            name: 'BB Parent Name',
            typeOf: 'string',
          },
          {
            field: 'dvParentEntityName',
            name: 'BB One up Parent',
            typeOf: 'string',
          },
          {
            field: 'ackey',
            name: 'AC Key',
            typeOf: 'string',
          },
          {
            field: 'issuerEquityTicker',
            name: 'Issuer Equity Ticker',
            typeOf: 'string',
          },
          {
            field: 'Country.countryCode',
            name: 'Country',
            typeOf: 'string',
          },
          {
            field: 'countryDescription',
            name: 'Country Description',
            typeOf: 'string',
          },
          {
            field: 'countryCurrency',
            name: 'Country Currency',
            typeOf: 'string',
          },
          {
            field: 'isOECD',
            name: 'OECD Flag',
            typeOf: 'boolean',
          },
          {
            field: 'parentIssuer.text',
            name: 'Parent Issuer',
            typeOf: 'string',
          },
          {
            field: 'parentIssuerDescription',
            name: 'Parent Issuer Description',
            typeOf: 'string',
          },
          {
            field: 'issuerTypeTypeSystem.text',
            name: 'Issuer Type',
            typeOf: 'string',
          },
          {
            field: 'APRAApproved',
            name: 'APRA Approved',
            typeOf: 'boolean',
          },
          {
            field: 'CICSIssuerCode',
            name: 'CICS Issuer Code',
            typeOf: 'string',
          },
          {
            field: 'isExclude',
            name: 'Exclude',
            typeOf: 'boolean',
          },
          {
            field: 'SRCategory.text',
            name: 'Cat_Override_Iss',
            typeOf: 'string',
          },
          {
            field: 'ratingBandTypeSystem.text',
            name: 'RatBnd_Override_Iss',
            typeOf: 'string',
          },
          {
            field: 'commentISS',
            name: 'Comment ISS',
            typeOf: 'string',
          },
          {
            field: 'issuerFamilyTypeSystem.text',
            name: 'Issuer Family',
            typeOf: 'string',
          },
          {
            field: 'issuerGuaranteedTypeSystem.text',
            name: 'Issuer Guaranteed',
            typeOf: 'string',
          },
          {
            field: 'parentOwned',
            name: '100% Parent Owned',
            typeOf: 'boolean',
          },
          {
            field: 'snpIssueRating.text',
            name: 'SNP Rating',
            typeOf: 'string',
          },
          {
            field: 'moIssueRating.text',
            name: 'MO Rating',
            typeOf: 'string',
          },
          {
            field: 'fitchIssueRating.text',
            name: 'Fitch Rating',
            typeOf: 'string',
          },
          {
            field: 'derivedRating',
            name: 'Derived Rating',
            typeOf: 'string',
          },
          {
            field: 'SPRatingType',
            name: 'S&P Rating Type',
            typeOf: 'string',
          },
          {
            field: 'mdyIssuer',
            name: 'Moodys Rating Type',
            typeOf: 'string',
          },
          {
            field: 'FTRatingType',
            name: 'Fitch Rating Type',
            typeOf: 'string',
          },
          {
            field: 'sector',
            name: 'Sector',
            typeOf: 'string',
          },
          {
            field: 'STFSectorTypeSystem.text',
            name: 'STF Sector',
            typeOf: 'string',
          },
          {
            field: 'amountOutstanding',
            name: 'Amount Outstanding',
            typeOf: 'string',
          },
          {
            field: 'issuerUtilisation',
            name: 'Issuer Utilisation',
            typeOf: 'string',
          },
          {
            field: 'isDataReview',
            name: 'Is Data Reviewed',
            typeOf: 'boolean',
          },
          {
            field: 'isIgnore',
            name: 'Is Additional Data',
            typeOf: 'string',
          },
          {
            field: 'murexVersions',
            name: 'Murex Versions',
            typeOf: 'string',
          },
          {
            field: 'isMurexRiskless',
            name: 'Credit Riskless',
            typeOf: 'boolean',
          },
          {
            field: 'countryOfDomicile',
            name: 'Country Of Domicile',
            typeOf: 'string',
          },
          {
            field: 'industrySector',
            name: 'Industry Sector',
            typeOf: 'string',
          },
          {
            field: 'industryGroup',
            name: 'Industry Group',
            typeOf: 'string',
          },
          {
            field: 'marketSectorDescription',
            name: 'Market Sector Description',
            typeOf: 'string',
          },
          {
            field: 'comment',
            name: 'Comment',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            name: 'Static Data Issuer',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

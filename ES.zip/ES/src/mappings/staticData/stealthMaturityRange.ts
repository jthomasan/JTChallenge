import { APIMappingEntities } from '../../models/api.model';

const staticDataStealthMaturityRangeQuery = () => `
{
  StaticDataStealthMaturityRanges {
    id
    modified
    name
    rangeFrom
    rangeTo
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/stealth-maturity-range/csv': {
    get: {
      name: 'staticDataStealthMaturityRange',
      summary: 'Export static data Stealth Maturity Range csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_stealth_maturity_range',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataStealthMaturityRangeQuery,
        returnDataName: 'StaticDataStealthMaturityRanges',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'name',
            name: 'Name',
            typeOf: 'string',
          },
          {
            field: 'rangeFrom',
            name: 'From',
            typeOf: 'number',
            sorting: 'true',
          },
          {
            field: 'rangeTo',
            name: 'To',
            typeOf: 'number',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Stealth Maturity Range',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

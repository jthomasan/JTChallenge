import * as express from 'express';
import * as cors from 'cors';
import * as cookieParser from 'cookie-parser';

import './env';
import './helpers/interceptor';
import routes from './routes';
import { logger, loggerMiddleware } from './middleware/logger';
import appErrorHandler from './middleware/appErrorHandler';

const { env } = process;

const app = express();

app.set('port', env.APP_PORT);
app.set('host', env.APP_HOST);
app.use(cookieParser());
app.use(cors());
app.use(loggerMiddleware);

app.use('/export', routes);
app.use(appErrorHandler);
app.set('query parser fn', {
  comma: true,
});

app.get('/version', (req, res) =>
  res.send({
    app: `merv-web-es@${process.env.npm_package_version}`,
  }),
);

app.listen(app.get('port'), () => {
  // eslint-disable-next-line no-console
  logger.info(`Server listening at http://${env.APP_HOST}:${env.APP_PORT}`);
});

export default app;

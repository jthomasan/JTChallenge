import { RouteConstructor } from './routerConstructor';
import { entities } from './__mocks__/apiMappings';

describe('Router Constructor Tests', () => {
  it('should return routes based on spec', () => {
    const routerFunc = RouteConstructor.constructAPIRoutes(entities);
    const routes = routerFunc.stack.map((item) => item.route);

    expect(routes).toMatchSnapshot();
  });
});

import { Router, Response, NextFunction } from 'express';
import { ControllerConstructor } from '../controllers/controllerConstructor';
import { APIMappingEntities, EndPointInfo } from '../models/api.model';
import { generateProcessor } from '../processors/genericExportProcessor';
import { InterceptedRequest } from './types';

/** Class creates routes based on the spec. */
export class RouteConstructor {
  /**
   * Create api routes.
   * @param {APIMappingEntities} entites - api info.
   * @returns {Router} router list
   */
  public static constructAPIRoutes(entities: APIMappingEntities): Router {
    const router = Router();

    Object.entries(entities).forEach(([path, endPointInfo]) => {
      const [[method, requestInfo]] = Object.entries(endPointInfo) as [[string, EndPointInfo]];
      const {
        parameters,
        filename,
        dataSource: { query, queryVariables, returnDataName },
        exportInfo,
      } = requestInfo;

      let processor: any;

      if (exportInfo.fields.length > 0) {
        processor = generateProcessor(exportInfo.fields, exportInfo.sortField);
      } else {
        processor = exportInfo.customProcessor;
      }

      // Create controllers
      const controllerObj = new ControllerConstructor(
        parameters,
        filename,
        query,
        queryVariables,
        returnDataName,
        processor,
      );

      // Create routes
      router[method](path, async (req: InterceptedRequest, res: Response, next: NextFunction) => {
        try {
          await controllerObj.fetchData(req, res);
        } catch (err) {
          next(err);
        }
      });
    });

    return router;
  }
}

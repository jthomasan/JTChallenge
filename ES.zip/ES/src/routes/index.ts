import { Router, Response, NextFunction } from 'express';
import * as swaggerUi from 'swagger-ui-express';

import swaggerSpec from '../helpers/swaggerSpec';
import { RouteConstructor } from './routerConstructor';
import apiMappings from '../mappings';
import { InterceptedRequest } from './types';
import d2aGenerateXBRLHandler from './d2aGenerateXBRLHandler';

const router = Router();

// Swagger spec
(swaggerSpec as any).paths = { ...apiMappings };

router.use('/swagger', swaggerUi.serve);
router.get('/swagger', swaggerUi.setup(swaggerSpec));

// export route for Apra D2A
router.get('/XBRL/zip', logRequest, d2aGenerateXBRLHandler);
router.use('/', logRequest, setHeaders, RouteConstructor.constructAPIRoutes(apiMappings));

export default router;

// Set response headers content types as csv
function setHeaders(req: InterceptedRequest, res: Response, next: NextFunction) {
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Pragma', 'no-cache');
  next();
}

function logRequest(req: InterceptedRequest, res: Response, next: NextFunction) {
  req.logger.info({ hostname: req.hostname, method: req.method, url: req.url }, 'export start...');
  next();
}

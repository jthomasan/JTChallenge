import { Request } from 'express';

export interface InterceptedRequest extends Request {
  logger: any;
  reqId: string;
}

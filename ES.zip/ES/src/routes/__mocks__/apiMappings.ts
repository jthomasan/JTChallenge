import { APIMappingEntities } from '../../models/api.model';

export const entities: APIMappingEntities = {
  '/reference-data/hierarchy/nodes/csv': {
    get: {
      name: 'nodes',
      summary: 'Export nodes csv',
      description: 'Returns all nodes in csv file',
      filename: 'Hierarchy_Nodes',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Reference Data - (Hierarchy)' }],
      parameters: [
        {
          name: 'id',
          in: 'query',
          description: 'Search by node id',
          required: false,
          type: 'string',
        },
        {
          name: 'typeId',
          in: 'query',
          description: 'Search by hierarchy type id',
          required: false,
          type: 'string',
        },
        {
          name: 'cob',
          in: 'query',
          description: 'Search by close of business date',
          required: false,
          type: 'string',
          default: '',
        },
      ],
      dataSource: {
        query: () => '',
        returnDataName: 'Nodes',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Some name',
            typeOf: 'string',
            field: 'some.name',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Nodes',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
  '/reference-data/hierarchy/portfolios/csv': {
    get: {
      name: 'portfolios',
      summary: 'Export portfolios csv',
      description: 'Returns all portfolios in csv file',
      filename: 'Hierarchy_Portfolios',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Reference Data - (Hierarchy)' }],
      parameters: [
        {
          name: 'nodeId',
          in: 'query',
          description: 'Search by node id',
          required: false,
          type: 'string',
        },
        {
          name: 'titleSearch',
          in: 'query',
          description: 'Search by title',
          required: false,
          type: 'string',
        },
        {
          name: 'cob',
          in: 'query',
          description: 'Search by close of business date',
          required: false,
          type: 'string',
        },
      ],
      dataSource: {
        query: () => '',
        returnDataName: 'Portfolios',
      },
      exportInfo: {
        customProcessor: () => {},
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Portfolios',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
};

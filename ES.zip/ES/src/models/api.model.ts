import { Request } from 'express';

export interface Parameter {
  name: string;
  in: string;
  description?: string;
  required: boolean;
  type: string;
  default?: string;
}

export interface DataSource {
  query: (params?: any) => string;
  queryVariables?: (params?: any) => Record<string, any>;
  returnDataName: string;
}

export interface Field {
  name: string;
  typeOf: 'string' | 'number' | 'boolean' | 'dateTime' | 'date';
  field: string;
  displayRenderer?: (params: any) => string;
}

export interface ExportInfo {
  customProcessor: Function | null;
  sortField?: string;
  fields: Field[];
}

export interface EndPointInfo {
  name: string;
  filename: string | ((request: Request) => string);
  parameters: Parameter[];
  dataSource: DataSource;
  exportInfo: ExportInfo;
  [name: string]: any;
}

export interface APIMapping {
  get: EndPointInfo;
}

export interface APIMappingEntities {
  [path: string]: APIMapping;
}

export interface NodeParam {
  id?: string;
  typeId?: string;
  cob: string;
}

export interface Node {
  id: string;
  title: string;
  children: string[];
  parent: string;
  fullPath: string;
}

export interface NodeEntities {
  [id: string]: Node;
}

export interface PortfolioParam {
  nodeId?: string;
  typeId: string;
  titleSearch: string;
  cob: string;
}

export interface Portfolio {
  id: number;
  title: string;
  isActive: boolean;
  parent: Parent;
  createdOn: string;
  source: string;
}

export interface Parent {
  nodeId: string;
}

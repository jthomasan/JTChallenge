import { get } from 'lodash';

/**
 * Creates an array of elements, sorted in ascending order by the results of
 * running each element in a collection through each iteratee. This method
 * performs a stable sort, that is, it preserves the original sort order of
 * equal elements. The iteratees are invoked with one argument: (value).
 */
export const sortBy = (data: any[], fields: string[]) => {
  const copyData = [...data];
  const collator = new Intl.Collator(undefined, {
    numeric: true,
    sensitivity: 'base',
  });
  const compareByType = (a: any, b: any, field: string) => {
    const valueA = get(a, field);
    const valueB = get(b, field);
    return typeof valueA === 'string' || typeof valueB === 'string'
      ? collator.compare(valueA || '', valueB || '')
      : (valueA || null) - (valueB || null);
  };

  return copyData.sort((a, b) =>
    fields.reduce((acc, sortDescriptor) => acc || compareByType(a, b, sortDescriptor), 0),
  );
};

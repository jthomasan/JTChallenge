import * as swaggerJSDoc from 'swagger-jsdoc';

const { env } = process;

// Swagger definition
const swaggerDefinition = {
  info: {
    title: env.APP_NAME,
    version: env.APP_VERSION,
  },
  basePath: '/export',
};

// Options for the swagger docs
const swaggerOptions = {
  // import swaggerDefinitions
  swaggerDefinition,
  // path to the API docs
  apis: [],
};

const swaggerSpec = swaggerJSDoc(swaggerOptions);

export default swaggerSpec;

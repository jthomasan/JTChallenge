import axios from 'axios';

axios.interceptors.response.use(
  (response) => {
    // Return error when errors array persist on the response
    if (response.data.errors) {
      return Promise.reject(response.data.errors);
    }

    const areNullPersist = Object.keys(response.data.data).find(
      (item) => response.data.data[item] === null,
    );

    // Return error when data array returns null
    if (areNullPersist) {
      return Promise.reject(Error('Received null response'));
    }

    return response.data;
  },
  (error) => {
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data);
    }
    return Promise.reject(error.message);
  },
);

import { PassThrough } from 'stream';
import { streamDataToClient } from './streamService';
import { nodes } from './__mocks__/mockData';

describe('Stream Service Tests', () => {
  it('should stream the data when providing as a collection', async () => {
    const mockWritable = new PassThrough();

    let streamedData = '';

    // Collect data from the stream
    mockWritable.on('data', (data) => {
      streamedData += data;
    });

    await streamDataToClient(mockWritable as any, async (callback) => {
      nodes.data.Nodes.forEach((item) => {
        callback(item.title);
      });

      callback(null);
    });

    expect(streamedData).toMatchSnapshot();
    mockWritable.end();
  });
});

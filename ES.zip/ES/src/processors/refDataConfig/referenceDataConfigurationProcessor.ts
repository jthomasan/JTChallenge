import { keyBy, sortBy } from 'lodash';
import { Processor, ProcessorInfo } from '../index';
import {
  mapDataToField,
  generateContents as generateGenericContents,
  generateHeaders,
} from '../genericExportProcessor';

export default (exportFields: ProcessorInfo[], streamData: (data: string) => void): Processor => {
  // Set csv headers
  const setHeader = () => {
    streamData(generateHeaders(exportFields));
  };

  const generateContents = (processorInfo: ProcessorInfo[], data: any, depth: number): string => {
    const indentedField = processorInfo[0];
    const indentedContent = `"${' '.repeat(depth * 4)}${mapDataToField(
      indentedField.field,
      indentedField.typeOf,
      data,
      indentedField.displayRenderer,
    )}"`;
    const restContent = generateGenericContents(processorInfo.slice(1, processorInfo.length), data);
    return indentedContent.concat(',').concat(restContent);
  };

  const setContents = (data: any[]) => {
    // make sure all configuration data have id and parent to identify the row and its parent
    const sortingColumnInfo = exportFields.find((item) => item.sorting);
    const sortedData = sortingColumnInfo ? sortBy(data, [sortingColumnInfo.field]) : data;
    const dataMap = keyBy(sortedData, 'id');
    const parentMap = new Map();
    let root = null;
    sortedData.forEach((node) => {
      if (!dataMap[node.parent]) {
        root = dataMap[node.id];
      }
      if (parentMap.has(node.parent)) {
        parentMap.set(node.parent, parentMap.get(node.parent).concat(node.id));
      } else {
        parentMap.set(node.parent, [node.id]);
      }
    });

    const fetchToStream = (rootNode: any, depth: number) => {
      // Push the data to stream as it gets formatted
      streamData(generateContents(exportFields, rootNode, depth));
      const children = parentMap.get(rootNode.id);
      children?.forEach((id) => {
        fetchToStream(dataMap[id], depth + 1);
      });
    };

    if (root) {
      fetchToStream(root, 0);
      // Close the stream
      streamData(null);
    } else {
      // Close the stream if nodes are empty
      streamData('"No results found"/n');
      streamData(null);
    }
  };

  return { setHeader, setContents };
};

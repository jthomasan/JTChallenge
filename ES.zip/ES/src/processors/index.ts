import nodesProcessor from './hierarchy/nodesProcessor';
import portfoliosProcessor from './hierarchy/portfoliosProcessor';
import staticDataPortfoliosProcessor from './staticData/staticDataPortfoliosProcessor';
import haircutReferenceProcessor from './staticData/haircutReferenceProcessor';
import staticDataAuditHistoryProcessor from './staticData/staticDataAuditHistoryProcessor';
import referenceDataConfigurationProcessor from './refDataConfig/referenceDataConfigurationProcessor';

export interface ProcessorInfo {
  name: string;
  typeOf: string;
  field: string;
  sorting?: boolean;
  displayRenderer?: (params: any) => string;
}

export interface Processor {
  setHeader: () => void;
  setContents: (data: any, response?: any) => void;
}

export default {
  nodes: nodesProcessor as () => Processor,
  portfolios: portfoliosProcessor,
  staticDataPortfolios: staticDataPortfoliosProcessor,
  haircutReference: haircutReferenceProcessor,
  staticDataAuditHistory: staticDataAuditHistoryProcessor,
  referenceDataConfiguration: referenceDataConfigurationProcessor,
};

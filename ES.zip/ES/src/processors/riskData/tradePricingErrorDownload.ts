import { Processor } from '../index';

interface TradePricingError {
  businessDate: string;
  report: string;
  reportDescription: string;
  portfolio: string;
  skyTradeID: number;
  murexTradeID: number;
  mxFamily: string;
  mxType: string;
  mxGroup: string;
  mxInstrument: string;
  counterParty: string;
  contractName: string;
  jobName: string;
  errorMessage: string;
}

export default (streamData: (data: string) => void): Processor => {
  // Set csv headers
  const setHeader = () => {
    streamData(
      `"Portfolio","Business Date","Report","Skylib TradeID","Murex TradeID","Mx Family","Mx Type","Mx Group","Mx Instrument","Counterparty","Contract Name","Job Name","Error Message"\n`,
    );
  };

  const setContents = (list: TradePricingError[]) => {
    if (!list?.length) {
      streamData(`"No results found"\n`);
      streamData(null);
    } else {
      list.forEach((item) => {
        streamData(
          `"${item.portfolio}","${item.businessDate}","${item.report} - ${
            item.reportDescription
          }","${item.skyTradeID}","${item.murexTradeID}","${item.mxFamily}","${item.mxType}","${
            item.mxGroup
          }","${item.mxInstrument}","${item.counterParty}","${item.contractName}","${
            item.jobName
          }","${item.errorMessage.replace(/"/g, '""')}"\n`,
        );
      });
      streamData(null);
    }
  };

  return { setHeader, setContents };
};

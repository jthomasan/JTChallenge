import { generateProcessor } from './genericExportProcessor';
import { staticDataCapitalHierarchies } from './__mocks__/staticDataCapitalHierarchies';

describe('Generic Post Processor Tests', () => {
  const fields = [
    {
      name: 'Name',
      typeOf: 'string',
      field: 'name',
      sorting: true,
    },
    {
      name: '10/1 Day Std Var',
      typeOf: 'number',
      field: 'tenDayStd',
    },
    {
      name: 'Stress Var',
      typeOf: 'number',
      field: 'stressFactor',
    },
    {
      name: 'Is Active',
      typeOf: 'boolean',
      field: 'isActive',
    },
    {
      name: 'Added By',
      typeOf: 'string',
      field: 'added.by',
    },
    {
      name: 'Added Time',
      typeOf: 'date',
      field: 'added.time',
    },
  ];

  it('should push the data to stream function', () => {
    let csvStrings = '';
    const processor = generateProcessor(fields);

    const callbackFunc = (data: string) => {
      csvStrings += data;
    };

    const { setHeader, setContents } = processor(callbackFunc);
    setHeader();
    setContents(staticDataCapitalHierarchies.data.StaticDataCapitalHierarchies);

    expect(csvStrings).toMatchSnapshot();
  });

  it('should return message and close the stream when data is empty', () => {
    let csvStrings = '';
    const processor = generateProcessor(fields);

    const callbackFunc = (data: string) => {
      csvStrings += data;
    };

    const { setHeader, setContents } = processor(callbackFunc);
    setHeader();
    setContents([]);

    expect(csvStrings).toMatchSnapshot();
  });
});

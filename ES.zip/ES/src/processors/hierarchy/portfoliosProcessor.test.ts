import handleAllPortfolios from './portfoliosProcessor';
import { portfolios } from '../__mocks__/portfolios';

describe('Portfolios Helper Tests', () => {
  it('should push the data to stream function', () => {
    let csvStrings = '';

    const callbackFunc = (data: string) => {
      csvStrings += data;
    };

    const { setHeader, setContents } = handleAllPortfolios(callbackFunc);
    setHeader();
    setContents(portfolios.data.Portfolios, portfolios.data);

    expect(csvStrings).toMatchSnapshot();
  });

  it('should return message and close the stream when portfolios are empty', () => {
    let csvStrings = '';

    const callbackFunc = (data: string) => {
      csvStrings += data;
    };

    const { setHeader, setContents } = handleAllPortfolios(callbackFunc);
    setHeader();
    setContents([], {});

    expect(csvStrings).toMatchSnapshot();
  });
});

import handleAllNodes from './nodesProcessor';
import { nodes } from '../__mocks__/nodes';

describe('Nodes Helper Tests', () => {
  it('should push the data to stream function', () => {
    let csvStrings = '';

    const callbackFunc = (data: string) => {
      csvStrings += data;
    };

    const { setHeader, setContents } = handleAllNodes(callbackFunc);
    setHeader();
    setContents(nodes.data.Nodes);

    expect(csvStrings).toMatchSnapshot();
  });

  it('should return message and close the stream when nodes are empty', () => {
    let csvStrings = '';

    const callbackFunc = (data: string) => {
      csvStrings += data;
    };

    const { setHeader, setContents } = handleAllNodes(callbackFunc);
    setHeader();
    setContents([]);

    expect(csvStrings).toMatchSnapshot();
  });
});

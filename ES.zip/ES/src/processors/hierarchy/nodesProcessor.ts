import { keyBy } from 'lodash';
import { Node, NodeEntities } from '../../models/hierarchyModel';
import { Processor } from '../index';

// Create node tree
const fetchToStream = (
  node: Node,
  entities: NodeEntities,
  streamData: (data: string) => void,
  count = 0,
) => {
  // Push the data to stream as it gets formatted
  streamData(`"${' '.repeat(count * 4)}${node.title}","${node.fullPath}"\n`);

  node.children.forEach((id) => {
    fetchToStream(entities[id], entities, streamData, count + 1);
  });
};

export default (streamData: (data: string) => void): Processor => {
  // Set csv headers
  const setHeader = () => {
    streamData(`"Node Name","Full Path"\n`);
  };

  const setContents = (nodes: Node[]) => {
    const nodeEntities = keyBy(nodes, 'id');
    const rootNode = nodes.find((node) => node.parent === '');

    if (rootNode) {
      fetchToStream(rootNode, nodeEntities, streamData);
      // Close the stream
      streamData(null);
    } else {
      // Close the stream if nodes are empty
      streamData('"No results found"/n');
      streamData(null);
    }
  };

  return { setHeader, setContents };
};

import * as moment from 'moment';
import { sortBy } from 'lodash';
import { StaticDataPortfolio } from '../../models/staticDataPortfolioModel';
import { Processor } from '../index';

const formatDate = (value: string) =>
  (value && moment(value).format('DD/MM/YYYY hh:mm:ss A')) || '';
const formatBoolean = (value: boolean) => value?.toString().toUpperCase() || 'FALSE';

export default (streamData: (data: string) => void): Processor => {
  // Set csv headers
  const setHeader = () => {
    streamData(
      `"Name","Capital Hierarchy","Grp: Asset Type","Grp: Book Type","Grp: Hyperion Unit","Grp: Synthetic Portfolio","Grp: Credit Book","Trade Booking System","Aggregate Trade Cube Flag","Is LEGroup Subset","Is Finance","Is EaR","Accounting Type","Risk Portfolio Hierarchy","Volcker Desk Name","Risk Portfolio Full Path","Geography Hierarchy","Finance Hierarchy","Legal Entity Code","Source","Report Run List","Is Quarantined","Quarantined Date","Comment","Added By","Added Time","Is Active","Reason For Exclusion","Excluded By","RIO Interface Mapping","Review Date","Reviewer","Is Reviewed"\n`,
    );
  };

  const setContents = (staticDataPortfolio: StaticDataPortfolio[]) => {
    if (staticDataPortfolio.length === 0) {
      streamData(`"No results found"\n`);
      streamData(null);
    } else {
      const data = sortBy(staticDataPortfolio, ['name']);
      data.forEach((portfolio) => {
        const quarantinedDate = formatDate(portfolio.quarantine.date);
        const addedDate = formatDate(portfolio.added.time);
        const reviewedDate = formatDate(portfolio.reviewDate);
        const isLEGroupSubset = formatBoolean(portfolio.isLEGroupSubset);
        const isFinance = formatBoolean(portfolio.isFinance);
        const isEaR = formatBoolean(portfolio.isEaR);
        const isQuarantine = formatBoolean(portfolio.quarantine.isQuarantined);
        const isActive = formatBoolean(portfolio.isActive);
        const isReviewed = formatBoolean(portfolio.isReviewed);
        const isAggregateTradeCubeFlag = formatBoolean(portfolio.aggregateTradeCubeFlag);

        streamData(
          `"${portfolio.name}","${portfolio.capitalHierarchy.text || ''}","${portfolio
            .assetTypeSystem.text || ''}","${portfolio.bookTypeSystem.text || ''}","${portfolio
            .hyperionUnit.text || ''}","${portfolio.syntheticPortfolio?.text || ''}","${portfolio
            .creditBookTypeSystem?.text || ''}","${portfolio.tradeBookingSystem?.text ||
            ''}","${isAggregateTradeCubeFlag || ''}","${isLEGroupSubset || ''}","${isFinance ||
            ''}","${isEaR || ''}","${portfolio.accountingTypeSystem.text || ''}","${portfolio
            .riskHierarchy.value || ''}","${portfolio.volckerDeskName || ''}","${portfolio
            .riskHierarchy.fullPath || ''}","${portfolio.geographyHierarchy.value ||
            ''}","${portfolio.financeHierarchy.value || ''}","${portfolio.mxLegalEntityCode ||
            ''}","${portfolio.source.text || ''}","${portfolio.reportRunList ||
            ''}","${isQuarantine || ''}","${quarantinedDate || ''}","${portfolio.comment ||
            ''}","${portfolio.added.by || ''}","${addedDate || ''}","${isActive || ''}","${portfolio
            .exclusion.reason || ''}","${portfolio.exclusion.by || ''}","","${reviewedDate ||
            ''}","${portfolio.reviewer?.text || ''}","${isReviewed || ''}"\n`,
        );
      });
      streamData(null);
    }
  };

  return { setHeader, setContents };
};

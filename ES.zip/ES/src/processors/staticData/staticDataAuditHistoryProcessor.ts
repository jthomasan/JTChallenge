import { isEmpty } from 'lodash';
import { Processor } from '../index';
import { formatStrings } from '../genericExportProcessor';

interface Column {
  field: string;
  title: string;
  type: string;
}

interface AuditHistory {
  columns: Column[];
  rows: any[];
}

const normaliseValues = (value: any, typeOf: string): any => {
  switch (typeOf) {
    case 'text': {
      return formatStrings.string(value);
    }

    case 'numeric': {
      return formatStrings.number(value);
    }

    default: {
      return formatStrings[typeOf](value);
    }
  }
};

const setColumnHeaders = (columns: Column[]) => {
  const contents = columns.reduce((acc, curr) => `${acc}"${curr.title}",`, '');
  return `${contents.slice(0, contents.length - 1)}\n`;
};

export default (streamData: (data: string) => void): Processor => {
  // Set csv headers
  const setHeader = () => {
    streamData(``);
  };

  const setContents = (data: AuditHistory) => {
    if (!data || isEmpty(data)) {
      streamData(`"No results found"\n`);
      streamData(null);
    } else {
      const { columns, rows } = data;

      streamData(setColumnHeaders(columns));

      rows.forEach((item) => {
        const row = columns.reduce((acc, curr) => {
          const value = item[curr.field];
          return `${acc}"${normaliseValues(value, curr.type)}",`;
        }, '');

        streamData(`${row}\n`);
      });
      streamData(null);
    }
  };

  return { setHeader, setContents };
};

/* eslint-disable import/no-unresolved */
/* eslint-disable import/no-extraneous-dependencies */
import slash from 'slash2';
import { IConfig, IPlugin } from 'umi-types';

// eslint-disable-next-line import/no-extraneous-dependencies
import themeOverride from './anzTheme';
import defaultSettings from './defaultSettings'; // https://umijs.org/config/
import themePluginConfig from './themePluginConfig'; // preview.pro.ant.design only do not use in your production ;
// preview.pro.ant.design 专用环境变量，请不要在你的项目中使用它。

const releaseVersion = require('../../package.json').version;
const packageVersion = require('../package.json').version;

const { pwa } = defaultSettings;
const { ANT_DESIGN_PRO_ONLY_DO_NOT_USE_IN_YOUR_PRODUCTION, MOCK, OIDC_DOMAIN } = process.env;

const isAntDesignProPreview = ANT_DESIGN_PRO_ONLY_DO_NOT_USE_IN_YOUR_PRODUCTION === 'site';
const plugins: IPlugin[] = [
  [
    'umi-plugin-react',
    {
      antd: true,
      dva: {
        hmr: true,
      },
      locale: {
        // default false
        enable: true,
        // default zh-CN
        default: 'en-US',
        // default true, when it is true, will use `navigator.language` overwrite default
        baseNavigator: true,
      },
      dynamicImport: {
        loadingComponent: './components/PageLoading/index',
        webpackChunkName: true,
        level: 3,
      },
      pwa: pwa
        ? {
            workboxPluginMode: 'InjectManifest',
            workboxOptions: {
              importWorkboxFrom: 'local',
            },
          }
        : false, // default close dll, because issue https://github.com/ant-design/ant-design-pro/issues/4665
      // dll features https://webpack.js.org/plugins/dll-plugin/
      // dll: {
      //   include: ['dva', 'dva/router', 'dva/saga', 'dva/fetch'],
      //   exclude: ['@babel/runtime', 'netlify-lambda'],
      // },
    },
  ],
  [
    'umi-plugin-apollo-anz',
    {
      // uri: 'http://localhost:4000/graphql',
      // uri: 'http://auq5892s.unix.anz:4000/graphql',
      // uri: 'http://merv-ui-merv-dev-srddev01-mw.apps.cpaas.service.test/mock-graphql',
      uri: '/graphql',
      // mock: true,
      hooksImportFrom: 'react-apollo',
      // options: '../config/apolloOptions.ts',
    },
  ],
  [
    'umi-plugin-pro-block',
    {
      moveMock: false,
      moveService: false,
      modifyRequest: true,
      autoAddMenu: true,
    },
  ],
];

if (isAntDesignProPreview) {
  // 针对 preview.pro.ant.design 的 GA 统计代码
  plugins.push([
    'umi-plugin-ga',
    {
      code: 'UA-72788897-6',
    },
  ]);
  plugins.push(['umi-plugin-antd-theme', themePluginConfig]);
}

export default {
  plugins,
  hash: true,
  targets: {
    ie: 11,
  },
  mock: {
    exclude: ['mock/gql/**/*.js'],
  },
  // umi routes: https://umijs.org/zh/guide/router.html
  routes: [
    {
      path: '/',
      component: '../layouts/SecurityLayout',
      routes: [
        {
          path: '/',
          component: '../layouts/SideMenuLayout',
          Routes: ['src/pages/Authorized'],
          routes: [
            {
              name: 'home',
              icon: 'dashboard',
              path: '/home',
              component: './home',
              routes: [
                {
                  name: 'home',
                  shortname: 'home',
                  icon: 'home',
                  path: '/home/welcome',
                  component: './home/welcome',
                },
                {
                  name: 'Dashboard',
                  shortname: 'Dashboard',
                  icon: 'dashboard',
                  path: '/home/dashboard',
                  component: './home/dashboard',
                  authority: {
                    devOnly: true,
                  },
                },
                {
                  name: 'Tasks',
                  shortname: 'Tasks',
                  icon: 'unordered-list',
                  path: '/home/tasks',
                  component: './home/tasks',
                  authority: {
                    devOnly: true,
                  },
                },
              ],
            },
            {
              name: 'market-risk-reporting',
              icon: 'bar-chart',
              path: '/market-risk-reporting',
              authority: {
                devOnly: true,
              },
              routes: [
                {
                  name: 'Reports',
                  shortname: 'Reports',
                  icon: 'file-done',
                  path: '/market-risk-reporting/2',
                  component: './exception/501',
                },
                {
                  name: 'Reports Extractor',
                  shortname: 'Extractor',
                  icon: 'setting',
                  path: '/market-risk-reporting/3',
                  component: './exception/501',
                },
              ],
            },
            {
              name: 'rates-repository',
              icon: 'percentage',
              path: '/rates-repository',
              routes: [
                {
                  name: 'Rates Repository',
                  shortname: 'Rates Repo.',
                  icon: 'select',
                  path: '/rates-repository',
                  component: './rates-repository'
                }
              ],
            },
            {
              name: 'market-risk-limits',
              icon: 'column-height',
              path: '/market-risk-limits',
              routes: [
                {
                  name: 'Approved Limits',
                  shortname: 'Approved',
                  icon: 'check-square',
                  path: '/market-risk-limits/approved-limits',
                  component: './market-risk-limits/approved-limits',
                },
                {
                  name: 'Pending Limits',
                  shortname: 'Pending',
                  icon: 'file-sync',
                  path: '/market-risk-limits/pending-limits',
                  component: './market-risk-limits/pending-limits',
                  authority: {
                    devOnly: true,
                  },
                },
                {
                  name: 'Default Limits',
                  shortname: 'Default',
                  icon: 'profile',
                  path: '/market-risk-limits/default-limits',
                  component: './market-risk-limits/default-limits',
                },
                {
                  name: 'Bulk Upload',
                  shortname: 'Bulk Upload',
                  icon: 'upload',
                  path: '/market-risk-limits/bulk-upload',
                  component: './market-risk-limits/bulk-upload',
                  authority: {
                    devOnly: true,
                  },
                },
                {
                  name: 'Limit Summary',
                  path: '/market-risk-limits/limit-summary/:id',
                  component: './market-risk-limits/limit-summary',
                  hideInMenu: true,
                },
                {
                  name: 'Submission Summary',
                  path: '/market-risk-limits/submission-summary/:id',
                  component: './market-risk-limits/submission-summary',
                  hideInMenu: true,
                },
                {
                  name: 'New Limit',
                  path: '/market-risk-limits/new-limit',
                  component: './market-risk-limits/new-limit',
                  hideInMenu: true,
                },
                {
                  name: 'Edit Draft Limit',
                  path: '/market-risk-limits/edit-draft-limit/:id',
                  component: './market-risk-limits/edit-draft-limit',
                  ignoreParamInTitle: true,
                  hideInMenu: true,
                },
              ],
            },
            {
              path: '/excess-management',
              name: 'excess-management',
              icon: 'diff',
              authority: {
                devOnly: true,
              },
              routes: [
                {
                  name: 'Excess Generation',
                  shortname: 'Generation',
                  icon: 'interaction',
                  writeAuthority: ['EXCESS.WRITE'],
                  path: '/excess-management/excess-generation',
                  component: './excess-management/excess-generation',
                },
                {
                  name: 'Approved Excesses',
                  shortname: 'Approved',
                  icon: 'check-square',
                  path: '/excess-management/approved-excess',
                  component: './excess-management/approved-excess',
                },
                {
                  name: 'Pending Excesses',
                  shortname: 'Pending',
                  icon: 'file-sync',
                  path: '/excess-management/pending-excess',
                  component: './excess-management/pending-excess',
                },
                {
                  name: 'Excess Summary',
                  path: '/excess-management/excess-summary/:id',
                  component: './excess-management/excess-summary',
                  hideInMenu: true,
                },
                {
                  name: 'Cancelled Excesses',
                  shortname: 'Cancelled',
                  icon: 'close-square',
                  path: '/excess-management/cancelled-excess',
                  component: './excess-management/cancelled-excess',
                },
                {
                  name: 'Management Trigger Events',
                  shortname: 'Mgt Tgr Events',
                  icon: 'file-markdown',
                  path: '/excess-management/management-trigger-events',
                  component: './excess-management/management-trigger-events',
                },
                {
                  name: 'Intraday Trigger Events',
                  shortname: 'Int Tgr Events',
                  icon: 'exception',
                  path: '/excess-management/intraday-trigger-events',
                  component: './excess-management/intraday-trigger-events',
                },
              ],
            },
            {
              path: '/reference-data',
              name: 'reference-data',
              icon: 'table',
              routes: [
                {
                  name: 'Hierarchy',
                  shortname: 'Hierarchy',
                  icon: 'apartment',
                  path: '/reference-data/hierarchy/:hierarchyType?/:nodeId?',
                  authority: ['REF_DATA.READ'],
                  writeAuthority: ['REF_DATA.WRITE'],
                  component: './reference-data/hierarchy',
                },
                {
                  name: 'Static Data',
                  shortname: 'Static Data',
                  icon: 'database',
                  path: '/reference-data/static-data/:category?/:dataset?',
                  authority: ['REF_DATA.READ'],
                  writeAuthority: ['REF_DATA.WRITE'],
                  component: './reference-data/static-data',
                },
                {
                  name: 'Configuration',
                  shortname: 'Configuration',
                  icon: 'setting',
                  path: '/reference-data/configuration',
                  authority: ['REF_DATA.READ'],
                  writeAuthority: ['REF_DATA.WRITE'],
                  component: './reference-data/configuration',
                },
                {
                  name: 'Pending Updates',
                  shortname: 'Pend. Updts',
                  icon: 'profile',
                  path: '/reference-data/pending-updates',
                  authority: {
                    devOnly: true,
                  },
                  component: './exception/501',
                },
                {
                  name: 'MRE Position',
                  shortname: 'MRE Pos.',
                  icon: 'warning',
                  path: '/reference-data/mre-position',
                  authority: {
                    devOnly: true,
                  },
                  component: './exception/501',
                },
              ],
            },
            {
              path: '/feed-monitor',
              name: 'feed-monitor',
              icon: 'database',
              routes: [
                {
                  name: 'Risk Data',
                  shortname: 'Risk Data',
                  icon: 'apartment',
                  path: '/feed-monitor/risk-data/:cobDate?/:nodeId?',
                  authority: ['FEED_MONITOR.READ'],
                  writeAuthority: ['FEED_MONITOR.WRITE'],
                  component: './feed-monitor/risk-data',
                },
                {
                  name: 'User Requests',
                  shortname: 'User Req.',
                  icon: 'team',
                  path: '/feed-monitor/user-requests/:tab?',
                  authority: ['FEED_MONITOR.READ'],
                  writeAuthority: ['FEED_MONITOR.WRITE'],
                  component: './feed-monitor/user-requests',
                },
                {
                  name: 'Signoff Summary',
                  shortname: 'Signoff',
                  icon: 'file',
                  path: '/feed-monitor/signoff-summary',
                  authority: ['FEED_MONITOR.READ'],
                  writeAuthority: ['FEED_MONITOR.WRITE'],
                  component: './feed-monitor/signoff-summary',
                },
                {
                  name: 'Reconciliation Reports',
                  shortname: 'Recon. Report',
                  icon: 'file-search',
                  path: '/feed-monitor/recon-reports/:reconType?',
                  authority: ['FEED_MONITOR.READ'],
                  writeAuthority: ['FEED_MONITOR.WRITE'],
                  component: './feed-monitor/recon-reports',
                },
                {
                  name: 'Status Report',
                  shortname: 'Status',
                  icon: 'sync',
                  path: '/feed-monitor/status',
                  authority: ['FEED_MONITOR.READ'],
                  writeAuthority: ['FEED_MONITOR.WRITE'],
                  component: './feed-monitor/status',
                },
                {
                  name: 'Specific Risk Report Management',
                  shortname: 'Spec. Risk',
                  icon: 'profile',
                  path: '/feed-monitor/specific-risk/:measureType?',
                  authority: ['FEED_MONITOR.READ'],
                  writeAuthority: ['FEED_MONITOR.WRITE'],
                  component: './feed-monitor/specific-risk',
                },
                {
                  name: 'Holding Period Run Management',
                  shortname: 'Hldg. Pd. Mgt.',
                  icon: 'profile',
                  path: '/feed-monitor/holding-period-run',
                  authority: ['FEED_MONITOR.READ'],
                  writeAuthority: ['FEED_MONITOR.WRITE'],
                  component: './feed-monitor/holding-period-run',
                },
                {
                  name: 'Configuration',
                  shortname: 'Configuration',
                  icon: 'setting',
                  path: '/feed-monitor/configuration',
                  authority: {
                    scopes: ['FEED_MONITOR.READ'],
                    devOnly: true,
                  },
                  writeAuthority: ['FEED_MONITOR.WRITE'],
                  component: './feed-monitor/configuration',
                },
              ],
            },
            {
              name: 'apra-d2a',
              icon: 'area-chart',
              path: '/apra-d2a',
              routes: [
                {
                  name: 'Report Browser',
                  shortname: 'Browser',
                  icon: 'file',
                  path: '/apra-d2a/report-browser',
                  component: './apra-d2a/report-browser',
                },
                {
                  name: 'Report Admin',
                  shortname: 'Admin',
                  icon: 'setting',
                  path: '/apra-d2a/report-admin',
                  component: './apra-d2a/report-admin',
                },
              ],
            },
            {
              name: 'backtesting',
              icon: 'fund',
              path: '/backtesting',
              routes: [
                {
                  name: 'Run Management',
                  shortname: 'Run Mgt.',
                  icon: 'play-circle',
                  path: '/backtesting/im-run-management',
                  component: './backtesting/im-run-management',
                  authority: ['BACK_TESTING.READ'],
                  writeAuthority: ['BACK_TESTING.WRITE'],
                },
                {
                  name: 'Dashboard',
                  shortname: 'Dashboard',
                  icon: 'select',
                  path: '/backtesting/im-dashboard/:selectedType?',
                  component: './backtesting/im-dashboard',
                  authority: ['BACK_TESTING.READ'],
                },
                {
                  name: 'Analysis',
                  shortname: 'Analysis',
                  icon: 'file-search',
                  path: '/backtesting/im-analysis/:analysisType?',
                  component: './backtesting/analysis',
                  authority: ['BACK_TESTING.READ'],
                },
                {
                  name: 'Configuration',
                  shortname: 'Configuration',
                  icon: 'setting',
                  path: '/backtesting/im-configuration',
                  component: './backtesting/im-configuration',
                  authority: ['BACK_TESTING.READ'],
                  writeAuthority: ['BACK_TESTING.WRITE']
                },
                {
                  name: 'Exception Browser',
                  shortname: 'Exceptions',
                  icon: 'schedule',
                  path: '/backtesting/exceptions',
                  component: './exception/501',
                  authority: {
                    devOnly: true,
                  },
                },
              ],
            },
            {
              path: '/exception/403',
              component: './exception/403',
            },
            {
              path: '/',
              redirect: '/home/welcome',
            },
            {
              component: '404',
            },
          ],
        },
      ],
    },
  ],
  theme: themeOverride,
  define: {
    ANT_DESIGN_PRO_ONLY_DO_NOT_USE_IN_YOUR_PRODUCTION:
      ANT_DESIGN_PRO_ONLY_DO_NOT_USE_IN_YOUR_PRODUCTION || '', // preview.pro.ant.design only do not use in your production ; preview.pro.ant.design 专用环境变量，请不要在你的项目中使用它。
    REACT_APP_VERSION: `v${packageVersion}`,
    REACT_RELEASE_VERSION: `v${releaseVersion}`,
    IS_MOCK_DISABLED: MOCK === 'none',
    'process.env.OIDC_DOMAIN': OIDC_DOMAIN,
  },
  ignoreMomentLocale: true,
  lessLoaderOptions: {
    javascriptEnabled: true,
  },
  disableRedirectHoist: true,
  cssLoaderOptions: {
    modules: true,
    getLocalIdent: (
      context: {
        resourcePath: string;
      },
      _: string,
      localName: string,
    ) => {
      if (
        context.resourcePath.includes('node_modules') ||
        context.resourcePath.includes('ant.design.pro.less') ||
        context.resourcePath.includes('global.less')
      ) {
        return localName;
      }

      const match = context.resourcePath.match(/src(.*)/);

      if (match && match[1]) {
        const antdProPath = match[1].replace('.less', '');
        const arr = slash(antdProPath)
          .split('/')
          .map((a: string) => a.replace(/([A-Z])/g, '-$1'))
          .map((a: string) => a.toLowerCase());
        return `antd-pro${arr.join('-')}-${localName}`.replace(/--/g, '-');
      }

      return localName;
    },
  },
  manifest: {
    basePath: '/',
  }, // chainWebpack: webpackPlugin,
  proxy: {
    '/export': {
      target: 'http://localhost:4001/',
      changeOrigin: true,
    },
    '/login': {
      target: 'http://localhost:4000/',
      changeOrigin: true,
    },
    '/oidc': {
      target: 'http://localhost:4000/',
      changeOrigin: true,
    },
    '/graphql': {
      target: 'http://localhost:4000/',
      changeOrigin: true,
    },
  },
} as IConfig;

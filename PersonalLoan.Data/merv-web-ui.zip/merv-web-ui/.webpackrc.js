export default {
  module: {
    rules: [],
  },
};

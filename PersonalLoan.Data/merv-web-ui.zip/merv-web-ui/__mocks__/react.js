/* eslint-disable no-underscore-dangle */
const React = require('react');

const originals = {
  useRef: React.useRef,
  useState: React.useState,
  useEffect: React.useEffect,
  useContext: React.useContext,
  useCallback: React.useCallback,
};

let { useContext } = React;

let useRef = jest.fn((def) => ({ current: def }));
let useState = jest.fn((def) => [typeof def === 'function' ? def() : def, jest.fn()]);
let useEffect = jest.fn();
let useCallback = jest.fn((fn) => (...args) => fn(...args));

React.useRef = jest.fn((...args) => useRef(...args));
React.useState = jest.fn((...args) => useState(...args));
React.useEffect = jest.fn((...args) => useEffect(...args));
React.useContext = jest.fn((...args) => useContext(...args));

React.useCallback = jest.fn((...args) => useCallback(...args));

React._mockUseRef = (mock) => {
  useRef = mock;
};

React._mockUseState = (mock) => {
  useState = mock;
};

React._mockUseEffect = (mock) => {
  useEffect = mock;
};

React._mockUseContext = (mock) => {
  useContext = mock;
};

React._mockUseCallback = (mock) => {
  useCallback = mock;
};

/**
 * Because I can't be bothered changing all existing tests to use jest.mock('react')
 * or testing-library/react-hooks
 */
React._unmock = () => {
  React._mockUseRef(originals.useRef);
  React._mockUseState(originals.useState);
  React._mockUseEffect(originals.useEffect);
  React._mockUseContext(originals.useContext);
  React._mockUseCallback(originals.useCallback);
};

module.exports = React;

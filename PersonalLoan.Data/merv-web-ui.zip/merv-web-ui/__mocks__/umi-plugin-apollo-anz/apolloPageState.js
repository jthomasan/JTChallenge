const apolloPageState = jest.genMockFromModule('umi-plugin-apollo-anz/apolloPageState');

apolloPageState.useGQLPageState = () => ['', jest.fn()];
apolloPageState.useGQLActivePage = () => [
  { _selected: 'mockPage' },
  jest.fn(),
  { id: 'MOCKPAGE:mockPage', pageType: 'MOCKPAGE' },
];

module.exports = apolloPageState;

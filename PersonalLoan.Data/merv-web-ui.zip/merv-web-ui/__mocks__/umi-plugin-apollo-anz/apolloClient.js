const apolloClient = jest.genMockFromModule('umi-plugin-apollo-anz/apolloClient');

apolloClient.useApolloClient = jest.fn(() => ({
  readQuery: jest.fn(() => ({ page: { _selected: '' } })),
  writeQuery: jest.fn(),
  readFragment: jest.fn(),
  writeFragment: jest.fn(),
}));

apolloClient.useQuery = jest.fn().mockReturnValue({ data: { page: { _selected: 'mockPage' } } });

apolloClient.useMutation = jest.fn().mockReturnValue([jest.fn()]);

const doLazyQueryMock = jest.fn();
apolloClient.useLazyQuery = jest
  .fn()
  .mockReturnValue([doLazyQueryMock, { data: [], loading: false }]);

apolloClient.gql = jest
  .fn()
  .mockImplementation((strings, ...keys) =>
    strings.reduce((acc, string, i) => acc + string + (keys[i] ? keys[i] : ''), ''),
  );

module.exports = apolloClient;

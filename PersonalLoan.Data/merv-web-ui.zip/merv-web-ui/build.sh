#!/bin/bash

yarn build
docker-compose build merv-ui
docker tag dtrqa.docker.service.anz/merv/merv-ui:latest dtrqa.docker.service.anz/merv/merv-ui:working
docker push dtrqa.docker.service.anz/merv/merv-ui:working
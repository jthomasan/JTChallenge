const fabric = require('@umijs/fabric');

const newExports = { ...fabric.stylelint };

newExports.rules['order/properties-order'] = null;

module.exports = newExports;

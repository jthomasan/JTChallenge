// Category
const category = "Underlyings";

// Type
const type = "Underlying-IR Curve";

// GQL Schema
const schemaQuery =
  "StaticDataUnderlyingIRCurves: [StaticDataUnderlyingIRCurve]";
const schemaType = `
  type StaticDataUnderlyingIRCurve {
    Curve: ID!
    modified: Boolean!
    description: String
    SCCYTypeTypeSystem: SCCYTypeTypeSystemOptions
    tenorLowerDays: String
    tenorUpperDays: String
    curveTypeSystem: CurveTypeSystemOptions
    curve: String
    isActive: Boolean!
    added: Added
  }
  
  type SCCYTypeTypeSystemOptions {
    id: ID
    text: String
  }
  
  type CurveTypeSystemOptions {
    id: ID
    text: String
  }
  
  `;

// Query
const queryName = "StaticDataUnderlyingIRCurves";
const query = `
{
  StaticDataUnderlyingIRCurves {
    Curve
    modified
    description
    SCCYTypeTypeSystem {
      id
      text
    }
    tenorLowerDays
    tenorUpperDays
    curveTypeSystem {
      id
      text
    }
    curve
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataUnderlyingIRCurves: {
      url: "reference-data/curve-with-attributes",
      dataPath: "$",
    },
  },
  StaticDataUnderlyingIRCurve: {
    modified: false,
  },
  SCCYTypeTypeSystemOptions: {
    text: "$.value",
  },
  CurveTypeSystemOptions: {
    text: "$.text",
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "curve",
    title: "Curve",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "description",
    title: "Description",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "tenorLowerDays",
    title: "TenorLowerDays",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "tenorUpperDays",
    title: "TenorUpperDays",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "SCCYTypeTypeSystem.text",
    title: "SingleCurveType",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "curveTypeSystem.text",
    title: "CurveType",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    description: "",
    modified: false,
    isActive: true,
    added: {
      by: "ranan1",
      time: "2012-02-21T21:29:16.997+0000",
    },
    SCCYTypeTypeSystem: null,
    tenorLowerDays: null,
    tenorUpperDays: null,
    curveTypeSystem: null,
    Curve: 1,
    curve: "AUD",
  },
  {
    description: "",
    modified: false,
    isActive: true,
    added: {
      by: "ranan1",
      time: "2012-02-21T21:29:16.997+0000",
    },
    SCCYTypeTypeSystem: null,
    tenorLowerDays: null,
    tenorUpperDays: null,
    curveTypeSystem: null,
    Curve: 2,
    curve: "CAD",
  },
  {
    description: "",
    modified: false,
    isActive: true,
    added: {
      by: "ranan1",
      time: "2012-02-21T21:29:16.997+0000",
    },
    SCCYTypeTypeSystem: null,
    tenorLowerDays: null,
    tenorUpperDays: null,
    curveTypeSystem: null,
    Curve: 3,
    curve: "CHF",
  },
  {
    description: "",
    modified: false,
    isActive: true,
    added: {
      by: "ranan1",
      time: "2012-02-21T21:29:16.997+0000",
    },
    SCCYTypeTypeSystem: null,
    tenorLowerDays: null,
    tenorUpperDays: null,
    curveTypeSystem: null,
    Curve: 4,
    curve: "CN1",
  },
  {
    description: "",
    modified: false,
    isActive: true,
    added: {
      by: "ranan1",
      time: "2012-02-21T21:29:16.997+0000",
    },
    SCCYTypeTypeSystem: null,
    tenorLowerDays: null,
    tenorUpperDays: null,
    curveTypeSystem: null,
    Curve: 5,
    curve: "CNY",
  },
  {
    description: "",
    modified: false,
    isActive: true,
    added: {
      by: "ranan1",
      time: "2012-02-21T21:29:16.997+0000",
    },
    SCCYTypeTypeSystem: null,
    tenorLowerDays: null,
    tenorUpperDays: null,
    curveTypeSystem: null,
    Curve: 6,
    curve: "DKK",
  },
  {
    description: "",
    modified: false,
    isActive: true,
    added: {
      by: "ranan1",
      time: "2012-02-21T21:29:16.997+0000",
    },
    SCCYTypeTypeSystem: null,
    tenorLowerDays: null,
    tenorUpperDays: null,
    curveTypeSystem: null,
    Curve: 7,
    curve: "EUR",
  },
  {
    description: "",
    modified: false,
    isActive: true,
    added: {
      by: "ranan1",
      time: "2012-02-21T21:29:16.997+0000",
    },
    SCCYTypeTypeSystem: null,
    tenorLowerDays: null,
    tenorUpperDays: null,
    curveTypeSystem: null,
    Curve: 8,
    curve: "FJD",
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

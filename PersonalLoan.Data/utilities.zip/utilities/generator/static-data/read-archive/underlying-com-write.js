// Type
const type = 'Underlying-COM';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataUnderlyingCOM';
const selectors = [
  {
    name: 'PriceQuotationTypeSystem',
    title: 'Grp: COM Price Quotation',
    query: `
  {
    PriceQuotationTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery: 'PriceQuotationTypeSystem: [PriceQuotationTypeSystemOption]',
    apiMappings: {
      Query: {
        PriceQuotationTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1006)]',
        },
      },
    },
    mockData: [
      {
        id: 1,
        text: 'AUD',
      },
      {
        id: 2,
        text: 'CAD',
      },
    ],
  },
  {
    name: 'ProductGroupTypeSystem',
    title: 'Grp: COM Type',
    query: `
  {
    ProductGroupTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery: 'ProductGroupTypeSystem: [ProductGroupTypeSystemOption]',
    apiMappings: {
      Query: {
        ProductGroupTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1007)]',
        },
      },
    },
    mockData: [
      {
        id: 1299,
        text: 'Base Metals',
      },
      {
        id: 1300,
        text: 'Coal',
      },
    ],
  },
  {
    name: 'ProductSubGroupTypeSystem',
    title: 'Grp: COM Sub-Type',
    query: `
  {
    ProductSubGroupTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery: 'ProductSubGroupTypeSystem: [ProductSubGroupTypeSystemOption]',
    apiMappings: {
      Query: {
        ProductSubGroupTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1008)]',
        },
      },
    },
    mockData: [
      {
        id: 1299,
        text: 'CANOLA',
      },
      {
        id: 1300,
        text: 'COAL',
      },
    ],
  },
  {
    name: 'ApraStressLabelTypeSystem',
    title: 'Grp: COM APRA Stress Label',
    query: `
  {
    ApraStressLabelTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery: 'ApraStressLabelTypeSystem: [APRAStressLabelTypeSystemOption]',
    apiMappings: {
      Query: {
        ApraStressLabelTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1002)]',
        },
      },
    },
    mockData: [
      {
        id: 1299,
        text: 'Aluminium',
      },
      {
        id: 1300,
        text: 'Barley',
      },
    ],
  },
  {
    name: 'AnzStressLabelTypeSystem',
    title: 'Grp: COM ANZ Stress Group',
    query: `
  {
    AnzStressLabelTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery: 'AnzStressLabelTypeSystem: [ANZStressLabelTypeSystemOption]',
    apiMappings: {
      Query: {
        AnzStressLabelTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1001)]',
        },
      },
    },
    mockData: [
      {
        id: 1299,
        text: 'Agriculture',
      },
      {
        id: 1300,
        text: 'Base Metals',
      },
    ],
  },
  {
    name: 'IndexNameTypeSystem',
    title: 'Grp: COM Index Name',
    query: `
  {
    IndexNameTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery: 'IndexNameTypeSystem: [IndexNameTypeSystemOption]',
    apiMappings: {
      Query: {
        IndexNameTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1004)]',
        },
      },
    },
    mockData: [
      {
        id: 1299,
        text: 'ALUM - FUT LME      ',
      },
      {
        id: 1300,
        text: 'API2 COAL           ',
      },
    ],
  },
  {
    name: 'UnitTypeSystem',
    title: 'Grp: COM Unit',
    query: `
  {
    UnitTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery: 'UnitTypeSystem: [UnitTypeSystemOption]',
    apiMappings: {
      Query: {
        UnitTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1009)]',
        },
      },
    },
    mockData: [
      {
        id: 1299,
        text: 'BBL',
      },
      {
        id: 1300,
        text: 'BU',
      },
    ],
  },
  {
    name: 'DeltaGammaLotConversionTypeSystem',
    title: 'Grp: COM Delta Gamma - Lot Conversation Factor',
    query: `
  {
    DeltaGammaLotConversionTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery:
      'DeltaGammaLotConversionTypeSystem: [DeltaGammaLotConversionTypeSystemOption]',
    apiMappings: {
      Query: {
        DeltaGammaLotConversionTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1003)]',
        },
      },
    },
    mockData: [
      {
        id: 1299,
        text: '0.002',
      },
      {
        id: 1300,
        text: '0.01',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    comment: String
    priceQuotationTypeSystem: InputOptionType
    productSubGroupTypeSystem: InputOptionType
    ANZStressLabelTypeSystem: InputOptionType
    APRAStressLabelTypeSystem: InputOptionType
    indexNameTypeSystem: InputOptionType
    productGroupTypeSystem: InputOptionType
    unitTypeSystem: InputOptionType
    deltaGammaLotConversionTypeSystem: InputOptionType
    description: String 
    agriculturalExpiryMonths: String
    isTenorBucketed: Boolean
    isActive: Boolean
  }
  `;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/commodity-with-attributes',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        comment: '{args.comment}',
        priceQuotationTypeSystem: { id: '{args.priceQuotationTypeSystem.id}' },
        productSubGroupTypeSystem: {
          id: '{args.productSubGroupTypeSystem.id}',
        },
        ANZStressLabelTypeSystem: { id: '{args.ANZStressLabelTypeSystem.id}' },
        APRAStressLabelTypeSystem: {
          id: '{args.APRAStressLabelTypeSystem.id}',
        },
        indexNameTypeSystem: { id: '{args.indexNameTypeSystem.id}' },
        productGroupTypeSystem: { id: '{args.productGroupTypeSystem.id}' },
        unitTypeSystem: { id: '{args.unitTypeSystem.id}' },
        deltaGammaLotConversionTypeSystem: {
          id: '{args.deltaGammaLotConversionTypeSystem.id}',
        },
        description: '{args.description}',
        isTenorBucketed: '{args.isTenorBucketed}',
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'underlyingCode',
    title: 'Underlying - COM',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    defaultSortColumn: true,
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
      isUnique: true,
    },
  },
  {
    field: 'description',
    title: 'COM Long Name',
    filter: 'text',
    typeOf: 'string',
    width: '400px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'productGroupTypeSystem.text',
    title: 'Grp: COM Type',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.ProductGroupTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'productSubGroupTypeSystem.text',
    title: 'Grp: COM Sub-Type',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.ProductSubGroupTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'APRAStressLabelTypeSystem.text',
    title: 'Grp: COM APRA Stress Label',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.ApraStressLabelTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'ANZStressLabelTypeSystem.text',
    title: 'Grp: COM ANZ Stress Group',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.AnzStressLabelTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'indexNameTypeSystem.text',
    title: 'Grp: COM Index Name',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.IndexNameTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'unitTypeSystem.text',
    title: 'Grp: COM Unit',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.UnitTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'deltaGammaLotConversionTypeSystem.text',
    title: 'Grp: COM Delta Gamma - Lot Conversation Factor',
    filter: 'text',
    typeOf: 'string',
    width: '400px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.DeltaGammaLotConversionTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'priceQuotationTypeSystem.text',
    title: 'Grp: COM Price Quotation',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.PriceQuotationTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'agriculturalExpiryMonths.text',
    title: 'Agricultural Expiry Month',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'isTenorBucketed',
    title: 'Is Tenor Bucketed',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '200px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      isOptional: true,
      typeOf: 'boolean',
    },
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

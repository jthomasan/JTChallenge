// Category
const category = "Underlyings";

// Type
const type = "Underlying-EQ";

// GQL Schema
const schemaQuery = "StaticDataUnderlyingEQs: [StaticDataUnderlyingEQType]";
const schemaType = `
  type StaticDataUnderlyingEQType {
    id: ID!
    modified: Boolean!
    ticker: String!
    description: String
    SecurityMarket: SecurityMarketOptions
    EQTypeTypeSystem: EQTypeTypeSystemOptions
    EQRegionTypeSystem: EQRegionTypeSystemOptions
    EQTierTypeSystem: EQTierTypeSystemOptions
    EQSpecificRkWeightTypeSystem: EQSpecificRkWeightTypeSystemOptions
    isIgnore: Boolean
    comment: String
    isActive: Boolean!
    added: Added!
  }
  
  type SecurityMarketOptions {
    id: ID
    text: String
  }

  type EQTypeTypeSystemOptions {
    id: ID
    text: String
  }

  type EQRegionTypeSystemOptions {
    id: ID
    text: String
  }

  type EQTierTypeSystemOptions {
    id: ID
    text: String
  }

  type EQSpecificRkWeightTypeSystemOptions {
    id: ID
    text: String
  }
  `;

// Query
const queryName = "StaticDataUnderlyingEQs";
const query = `
{
  StaticDataUnderlyingEQs {
    id
    modified
    ticker
    description
    SecurityMarket {
      id
      text
    }
    EQTypeTypeSystem {
      id
      text
    }
    EQRegionTypeSystem {
      id
      text
    }
    EQTierTypeSystem {
      id
      text
    }
    EQSpecificRkWeightTypeSystem {
      id
      text
    }
    isIgnore
    comment
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataUnderlyingEQs: {
      url: "reference-data/v1/ticker-with-attributes",
      dataPath: "$",
    },
  },
  StaticDataUnderlyingEQType: {
    modified: false,
  },
  SecurityMarketOptions: {
    text: "$.value",
  },
  EQTypeTypeSystemOptions: {
    text: "$.value",
  },
  EQRegionTypeSystemOptions: {
    text: "$.value",
  },
  EQTierTypeSystemOptions: {
    text: "$.value",
  },
  EQSpecificRkWeightTypeSystemOptions: {
    text: "$.value",
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "ticker",
    title: "Underlying - EQ",
    filter: "text",
    typeOf: "string",
    width: "130px",
    defaultSortColumn: true,
  },
  {
    field: "description",
    title: "Full Name",
    filter: "text",
    typeOf: "string",
    width: "180px",
  },
  {
    field: "SecurityMarket.text",
    title: "Security Market",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "EQTypeTypeSystem.text",
    title: "Grp: EQ Type",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "EQRegionTypeSystem.text",
    title: "Grp: EQ Region",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "EQTierTypeSystem.text",
    title: "Grp: EQ Tier",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "EQSpecificRkWeightTypeSystem.text",
    title: "Grp: EQ Specific Risk Weight",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "isIgnore",
    title: "Excluded from Quarantine",
    filter: "boolean",
    typeOf: "boolean",
    width: "180px",
    cell: "GridCheckboxCell",
  },
  {
    field: "comment",
    title: "Comment",
    filter: "text",
    typeOf: "string",
    width: "180px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    comment: null,
    description: "ISHARES S&P 500",
    isActive: true,
    added: {
      by: "lor",
      time: "2014-05-15T10:19:38.473+0000",
    },
    ticker: "IVV.AX",
    isIgnore: false,
    EQRegionTypeSystem: {
      id: 35,
      text: "Australia",
    },
    EQSpecificRkWeightTypeSystem: {
      id: 1072,
      text: "8%",
    },
    EQTierTypeSystem: {
      id: 1228,
      text: "SP500 Total",
    },
    EQTypeTypeSystem: {
      id: 33,
      text: "Stocks",
    },
    SecurityMarket: {
      id: 26,
      text: "AU ASX",
    },
    id: 1,
  },
  {
    modified: false,
    comment: null,
    description: "SPDR S&P/ASX 200 FUND",
    isActive: true,
    added: {
      by: "lor",
      time: "2014-05-19T08:31:20.837+0000",
    },
    ticker: "STW.AX",
    isIgnore: false,
    EQRegionTypeSystem: {
      id: 35,
      text: "Australia",
    },
    EQSpecificRkWeightTypeSystem: {
      id: 1072,
      text: "8%",
    },
    EQTierTypeSystem: {
      id: 1229,
      text: "ASX Index Total",
    },
    EQTypeTypeSystem: {
      id: 32,
      text: "Indices",
    },
    SecurityMarket: {
      id: 26,
      text: "AU ASX",
    },
    id: 2,
  },
  {
    modified: false,
    comment: null,
    description: "S&P ASX 200",
    isActive: true,
    added: {
      by: "lor",
      time: "2014-05-19T08:31:20.840+0000",
    },
    ticker: "XJO.AX",
    isIgnore: false,
    EQRegionTypeSystem: {
      id: 35,
      text: "Australia",
    },
    EQSpecificRkWeightTypeSystem: {
      id: 1071,
      text: "2%",
    },
    EQTierTypeSystem: {
      id: 1229,
      text: "ASX Index Total",
    },
    EQTypeTypeSystem: {
      id: 32,
      text: "Indices",
    },
    SecurityMarket: {
      id: 26,
      text: "AU ASX",
    },
    id: 3,
  },
  {
    modified: false,
    comment: null,
    description: "S&P ASX 200 Accumulated",
    isActive: true,
    added: {
      by: "lor",
      time: "2014-05-19T08:31:20.840+0000",
    },
    ticker: "XJOA.AX",
    isIgnore: false,
    EQRegionTypeSystem: {
      id: 35,
      text: "Australia",
    },
    EQSpecificRkWeightTypeSystem: {
      id: 1071,
      text: "2%",
    },
    EQTierTypeSystem: {
      id: 1229,
      text: "ASX Index Total",
    },
    EQTypeTypeSystem: {
      id: 32,
      text: "Indices",
    },
    SecurityMarket: {
      id: 26,
      text: "AU ASX",
    },
    id: 4,
  },
  {
    modified: false,
    comment: null,
    description: "Hang Seng China Enterprise Index",
    isActive: true,
    added: {
      by: "brightw",
      time: "2015-11-19T02:49:56.400+0000",
    },
    ticker: "HSCE",
    isIgnore: false,
    EQRegionTypeSystem: {
      id: 34,
      text: "Asia",
    },
    EQSpecificRkWeightTypeSystem: {
      id: 1072,
      text: "8%",
    },
    EQTierTypeSystem: {
      id: 1244,
      text: "HSCE Total",
    },
    EQTypeTypeSystem: {
      id: 32,
      text: "Indices",
    },
    SecurityMarket: {
      id: 32,
      text: "HK HKSE",
    },
    id: 5,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Underlyings';

// Type
const type = 'Grp: STF Geography';

// GQL Schema
const schemaQuery = 'StaticDataGrpSTFGeographies: [StaticDataGrpSTFGeography]';
const schemaType = `
  type StaticDataGrpSTFGeography {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataGrpSTFGeographies';
const query = `
{
  StaticDataGrpSTFGeographies {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataGrpSTFGeographies: {
      url: 'reference-data/v1/type-system-parameters',
      dataPath: '$[?(@.system.id == 1068)]',
    },
  },
  StaticDataGrpSTFGeography: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'value',
    title: 'Value',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    id: 1664,
    modified: false,
    description: null,
    value: 'G11',
    isActive: true,
    added: {
      by: 'System',
      time: '2015-08-01T03:33:16.097+0000',
    },
  },
  {
    id: 1665,
    modified: false,
    description: null,
    value: 'ASIA11',
    isActive: true,
    added: {
      by: 'System',
      time: '2015-08-01T03:33:16.097+0000',
    },
  },
  {
    id: 1666,
    modified: false,
    description: null,
    value: 'Others',
    isActive: true,
    added: {
      by: 'System',
      time: '2015-08-01T03:33:16.097+0000',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

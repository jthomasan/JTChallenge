// Discard all the previous changes which are generated from the generator, when re-running it.

// Category
const category = "Underlyings";

// Type
const type = "Underlying-COM";

// GQL Schema
const schemaQuery = "StaticDataUnderlyingCOMs: [StaticDataUnderlyingCOM]";

// Before adding the new types, make sure it doesnt already exist in the schema
const schemaType = `
  type StaticDataUnderlyingCOM {
    id: ID!
    modified: Boolean!
    comment: String
    priceQuotationTypeSystem: PriceQuotationTypeSystemOptions
    productSubGroupTypeSystem: ProductSubGroupTypeSystemOptions
    unitTypeSystem: UnitTypeSystemOptions
    isTenorBucketed: Boolean
    underlyingCode: String
    ANZStressLabelTypeSystem: ANZStressLabelTypeSystemOptions
    APRAStressLabelTypeSystem: APRAStressLabelTypeSystemOptions
    agriculturalExpiryMonths: String
    indexNameTypeSystem: IndexNameTypeSystemOptions
    productGroupTypeSystem: ProductGroupTypeSystemOptions
    deltaGammaLotConversionTypeSystem: DeltaGammaLotConversionTypeSystemOptions
    description: String
    isActive: Boolean!
    added: Added!
  }
  
  type PriceQuotationTypeSystemOptions {
    id: ID
    text: String
  }

  type ProductSubGroupTypeSystemOptions {
    id: ID
    text: String
  }

  type UnitTypeSystemOptions {
    id: ID
    text: String
  }

  type ANZStressLabelTypeSystemOptions {
    id: ID
    text: String
  }

  type APRAStressLabelTypeSystemOptions {
    id: ID
    text: String
  }

  type IndexNameTypeSystemOptions {
    id: ID
    text: String
  }

  type ProductGroupTypeSystemOptions {
    id: ID
    text: String
  }

  type DeltaGammaLotConversionTypeSystemOptions {
    id: ID
    text: String
  }
`;

// Query
const queryName = "StaticDataUnderlyingCOMs";
const query = `
{
  StaticDataUnderlyingCOMs {
    id
    modified
    comment
    priceQuotationTypeSystem {
      id
      text
    }
    productSubGroupTypeSystem {
      id
      text
    }
    unitTypeSystem {
      id
      text
    }
    isTenorBucketed
    underlyingCode
    ANZStressLabelTypeSystem {
      id
      text
    }
    APRAStressLabelTypeSystem {
      id
      text
    }
    agriculturalExpiryMonths
    indexNameTypeSystem {
      id
      text
    }
    productGroupTypeSystem {
      id
      text
    }
    deltaGammaLotConversionTypeSystem {
      id
      text
    }
    description
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataUnderlyingCOMs: {
      url: "reference-data/commodity-with-attributes",
      dataPath: "$",
    },
  },
  StaticDataUnderlyingCOM: {
    modified: false,
  },
  PriceQuotationTypeSystemOptions: {
    text: "$.value",
  },
  ProductSubGroupTypeSystemOptions: {
    text: "$.value",
  },
  UnitTypeSystemOptions: {
    text: "$.value",
  },
  ANZStressLabelTypeSystemOptions: {
    text: "$.value",
  },
  APRAStressLabelTypeSystemOptions: {
    text: "$.value",
  },
  IndexNameTypeSystemOptions: {
    text: "$.value",
  },
  ProductGroupTypeSystemOptions: {
    text: "$.value",
  },
  DeltaGammaLotConversionTypeSystemOptions: {
    text: "$.value",
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "underlyingCode",
    title: "Underlying - COM",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "description",
    title: "COM Long Name",
    filter: "text",
    typeOf: "string",
    width: "400px",
  },
  {
    field: "productGroupTypeSystem.text",
    title: "Grp: COM Type",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "productSubGroupTypeSystem.text",
    title: "Grp: COM Sub-Type",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "APRAStressLabelTypeSystem.text",
    title: "Grp: COM APRA Stress Label",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "ANZStressLabelTypeSystem.text",
    title: "Grp: COM ANZ Stress Group",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "indexNameTypeSystem.text",
    title: "Grp: COM Index Name",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "unitTypeSystem.text",
    title: "Grp: COM Unit",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "deltaGammaLotConversionTypeSystem.text",
    title: "Grp: COM Delta Gamma - Lot Conversation Factor",
    filter: "text",
    typeOf: "string",
    width: "400px",
  },
  {
    field: "priceQuotationTypeSystem.text",
    title: "Grp: COM Price Quotation",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "agriculturalExpiryMonths.text",
    title: "Agricultural Expiry Month",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "isTenorBucketed",
    title: "Is Tenor Bucketed",
    filter: "boolean",
    typeOf: "boolean",
    width: "200px",
    cell: "GridCheckboxCell",
    extras: {
      typeOf: "boolean",
    },
  },
  {
    field: "comment",
    title: "Comment",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
// Add modified: false for each element on the mock data list.
const mockData = [
  {
    comment: null,
    modified: false,
    id: 1,
    priceQuotationTypeSystem: {
      id: 643,
      text: "AUD",
    },
    productSubGroupTypeSystem: {
      id: 10,
      text: "CANOLA",
    },
    unitTypeSystem: {
      id: 457,
      text: "MT",
    },
    isTenorBucketed: false,
    underlyingCode: "ACM",
    ANZStressLabelTypeSystem: {
      id: 83,
      text: "Agriculture",
    },
    APRAStressLabelTypeSystem: {
      id: 46,
      text: "Canola",
    },
    agriculturalExpiryMonths: "January, May",
    indexNameTypeSystem: {
      id: 371,
      text: "CANLA - FUT ASX     ",
    },
    productGroupTypeSystem: {
      id: 1,
      text: "Agriculture",
    },
    deltaGammaLotConversionTypeSystem: {
      id: 479,
      text: "0.05",
    },
    description: "ASX Canola",
    isActive: true,
    added: {
      by: "foonga",
      time: "2012-04-10T02:56:52.003+0000",
    },
  },
  {
    comment: null,
    modified: false,
    id: 2,
    priceQuotationTypeSystem: {
      id: 643,
      text: "AUD",
    },
    productSubGroupTypeSystem: {
      id: 18,
      text: "FEED BARLEY",
    },
    unitTypeSystem: {
      id: 457,
      text: "MT",
    },
    isTenorBucketed: false,
    underlyingCode: "AFB",
    ANZStressLabelTypeSystem: {
      id: 83,
      text: "Agriculture",
    },
    APRAStressLabelTypeSystem: {
      id: 45,
      text: "Barley",
    },
    agriculturalExpiryMonths: "January, May",
    indexNameTypeSystem: {
      id: 369,
      text: "BARLY - FUT ASX     ",
    },
    productGroupTypeSystem: {
      id: 1,
      text: "Agriculture",
    },
    deltaGammaLotConversionTypeSystem: {
      id: 479,
      text: "0.05",
    },
    description: "ASX Feed Barley",
    isActive: true,
    added: {
      by: "System",
      time: "2012-01-31T13:33:04.993+0000",
    },
  },
  {
    comment: null,
    modified: false,
    id: 3,
    priceQuotationTypeSystem: {
      id: 660,
      text: "USD",
    },
    productSubGroupTypeSystem: {
      id: 11,
      text: "COAL",
    },
    unitTypeSystem: {
      id: 457,
      text: "MT",
    },
    isTenorBucketed: false,
    underlyingCode: "API2 - Monthly",
    ANZStressLabelTypeSystem: {
      id: 85,
      text: "Coal & Iron Ore",
    },
    APRAStressLabelTypeSystem: {
      id: 47,
      text: "Coal",
    },
    agriculturalExpiryMonths: null,
    indexNameTypeSystem: {
      id: 363,
      text: "API2 COAL           ",
    },
    productGroupTypeSystem: {
      id: 3,
      text: "Coal",
    },
    deltaGammaLotConversionTypeSystem: {
      id: 490,
      text: "1",
    },
    description: "Rotterdam Delivery Location (API2) - Monthly",
    isActive: true,
    added: {
      by: "System",
      time: "2012-01-31T13:33:04.993+0000",
    },
  },
  {
    comment: null,
    modified: false,
    id: 4,
    priceQuotationTypeSystem: {
      id: 660,
      text: "USD",
    },
    productSubGroupTypeSystem: {
      id: 11,
      text: "COAL",
    },
    unitTypeSystem: {
      id: 457,
      text: "MT",
    },
    isTenorBucketed: false,
    underlyingCode: "API2 - Quarterly",
    ANZStressLabelTypeSystem: {
      id: 85,
      text: "Coal & Iron Ore",
    },
    APRAStressLabelTypeSystem: {
      id: 47,
      text: "Coal",
    },
    agriculturalExpiryMonths: null,
    indexNameTypeSystem: {
      id: 365,
      text: "API2 COAL Q         ",
    },
    productGroupTypeSystem: {
      id: 3,
      text: "Coal",
    },
    deltaGammaLotConversionTypeSystem: {
      id: 490,
      text: "1",
    },
    description: "Rotterdam Delivery Location (API2) - Quarterly",
    isActive: true,
    added: {
      by: "System",
      time: "2012-01-31T13:33:04.993+0000",
    },
  },
  {
    comment: null,
    modified: false,
    id: 5,
    priceQuotationTypeSystem: {
      id: 660,
      text: "USD",
    },
    productSubGroupTypeSystem: {
      id: 11,
      text: "COAL",
    },
    unitTypeSystem: {
      id: 457,
      text: "MT",
    },
    isTenorBucketed: false,
    underlyingCode: "API2 - Yearly",
    ANZStressLabelTypeSystem: {
      id: 85,
      text: "Coal & Iron Ore",
    },
    APRAStressLabelTypeSystem: {
      id: 47,
      text: "Coal",
    },
    agriculturalExpiryMonths: null,
    indexNameTypeSystem: {
      id: 364,
      text: "API2 COAL C         ",
    },
    productGroupTypeSystem: {
      id: 3,
      text: "Coal",
    },
    deltaGammaLotConversionTypeSystem: {
      id: 490,
      text: "1",
    },
    description: "Rotterdam Delivery Location (API2) - Yearly",
    isActive: true,
    added: {
      by: "System",
      time: "2012-01-31T13:33:04.993+0000",
    },
  },
  {
    comment: null,
    modified: false,
    id: 6,
    priceQuotationTypeSystem: {
      id: 660,
      text: "USD",
    },
    productSubGroupTypeSystem: {
      id: 11,
      text: "COAL",
    },
    unitTypeSystem: {
      id: 457,
      text: "MT",
    },
    isTenorBucketed: false,
    underlyingCode: "API4 - Monthly",
    ANZStressLabelTypeSystem: {
      id: 85,
      text: "Coal & Iron Ore",
    },
    APRAStressLabelTypeSystem: {
      id: 47,
      text: "Coal",
    },
    agriculturalExpiryMonths: null,
    indexNameTypeSystem: {
      id: 366,
      text: "API4 COAL           ",
    },
    productGroupTypeSystem: {
      id: 3,
      text: "Coal",
    },
    deltaGammaLotConversionTypeSystem: {
      id: 490,
      text: "1",
    },
    description: "Richards Bay Delivery location (API4) - Monthly",
    isActive: true,
    added: {
      by: "System",
      time: "2012-01-31T13:33:04.993+0000",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

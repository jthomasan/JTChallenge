// Category
const category = 'Specific Risk';

// Type
const type = 'Specific Risk Capital Charges';

// GQL Schema
const schemaQuery =
  'StaticDataSpecificRiskCapitalCharges: [StaticDataSpecificRiskCapitalCharge]';
const schemaType = `
  type StaticDataSpecificRiskCapitalCharge {
    id: ID!
    modified: Boolean!
    ratingBandTypeSystem: RatingBandTypeSystemOption
    tenor: TenorOption
    sRCapitalCharge: Float
    sRCategory: SRCategoryOption
    isActive: Boolean!
    added: Added!
  }
  
  type TenorOption {
    id: ID
    text: String
  }

  type SRCategoryOption {
    id: ID
    text: String
  }`;

// Query
const queryName = 'StaticDataSpecificRiskCapitalCharges';
const query = `
{
  StaticDataSpecificRiskCapitalCharges {
    id
    modified
    ratingBandTypeSystem {
      id
      text
    }
    tenor {
      id
      text
    }
    sRCapitalCharge
    sRCategory {
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataSpecificRiskCapitalCharges: {
      url: 'reference-data/v1/srircapital-charge',
      dataPath: '$',
    },
  },
  StaticDataSpecificRiskCapitalCharge: {
    modified: false,
    sRCapitalCharge: '$.SRCapitalCharge',
    sRCategory: '$.SRCategory',
  },
  TenorOption: {
    text: '$.value',
  },
  SRCategoryOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'sRCategory.text',
    title: 'Category',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'ratingBandTypeSystem.text',
    title: 'Rating Band',
    filter: 'text',
    typeOf: 'string',
    width: '130px',
  },
  {
    field: 'tenor.text',
    title: 'Tenor',
    filter: 'text',
    typeOf: 'string',
    width: '180px',
  },
  {
    field: 'sRCapitalCharge',
    title: 'Capital Charge (%)',
    filter: 'numeric',
    typeOf: 'number',
    width: '150px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lakshmn2',
      time: '2012-04-02T17:10:30.880+0000',
    },
    ratingBandTypeSystem: {
      id: 753,
      text: 'AAA to AA-',
    },
    sRCapitalCharge: 0,
    id: 3,
    sRCategory: {
      id: 1,
      text: 'Government',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lakshmn2',
      time: '2012-04-02T17:10:30.913+0000',
    },
    ratingBandTypeSystem: {
      id: 754,
      text: 'A+ to BBB-',
    },
    sRCapitalCharge: 0.25,
    id: 4,
    sRCategory: {
      id: 1,
      text: 'Government',
    },
    tenor: {
      id: '73',
      text: '6 months or less',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lakshmn2',
      time: '2012-04-02T17:10:30.923+0000',
    },
    ratingBandTypeSystem: {
      id: 754,
      text: 'A+ to BBB-',
    },
    sRCapitalCharge: 1,
    id: 5,
    sRCategory: {
      id: 1,
      text: 'Government',
    },
    tenor: {
      id: '74',
      text: 'Exceeding 24 months',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lakshmn2',
      time: '2012-04-02T17:10:30.937+0000',
    },
    ratingBandTypeSystem: {
      id: 754,
      text: 'A+ to BBB-',
    },
    sRCapitalCharge: 1.6,
    id: 6,
    sRCategory: {
      id: 1,
      text: 'Government',
    },
    tenor: {
      id: '75',
      text: 'Greater than 6 months and up to and including 24 months',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lakshmn2',
      time: '2012-04-02T17:10:30.943+0000',
    },
    ratingBandTypeSystem: {
      id: 807,
      text: 'BB+ to B-',
    },
    sRCapitalCharge: 8,
    id: 7,
    sRCategory: {
      id: 1,
      text: 'Government',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Credit';

// Type
const type = 'Equity Underlying Specific Risk Map';

// GQL Schema
const schemaQuery =
  'StaticDataEquityUnderlyingSpecificRiskMaps: [StaticDataEquityUnderlyingSpecificRiskMap]';
const schemaType = `
  type StaticDataEquityUnderlyingSpecificRiskMap {
    id: ID!
    modified: Boolean!
    mappedTicker: MappedTickerOption
    ticker: TickerOption
    isActive: Boolean!
    added: Added!
  }
  
  type MappedTickerOption {
    id: ID!
    text: String!
  }
  
  type TickerOption {
    id: ID!
    text: String!
  }`;

// Query
const queryName = 'StaticDataEquityUnderlyingSpecificRiskMaps';
const query = `
{
  StaticDataEquityUnderlyingSpecificRiskMaps {
    id
    modified
    mappedTicker {
      id
      text
    }
    ticker {
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataEquityUnderlyingSpecificRiskMaps: {
      url: 'reference-data/v1/ticker-specific-risk-map',
      dataPath: '$',
    },
  },
  StaticDataEquityUnderlyingSpecificRiskMap: {
    modified: false,
  },
  MappedTickerOption: {
    text: '$.value',
  },
  TickerOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'ticker.text',
    title: 'Underlying - EQ',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'mappedTicker.text',
    title: 'Mapped Underlying EQ',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    id: 1,
    isActive: false,
    added: {
      by: 'foonga',
      time: '2012-07-13T00:00:00.000+0000',
    },
    mappedTicker: {
      id: 4,
      text: 'XJOA.AX',
    },
    ticker: {
      id: 3,
      text: 'XJO.AX',
    },
  },
  {
    modified: false,
    id: 2,
    isActive: false,
    added: {
      by: 'foonga',
      time: '2012-07-13T00:00:00.000+0000',
    },
    mappedTicker: {
      id: 2,
      text: 'STW.AX',
    },
    ticker: {
      id: 3,
      text: 'XJO.AX',
    },
  },
  {
    modified: false,
    id: 3,
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-25T03:38:27.270+0000',
    },
    mappedTicker: {
      id: 3,
      text: 'XJO.AX',
    },
    ticker: {
      id: 4,
      text: 'XJOA.AX',
    },
  },
  {
    modified: false,
    id: 4,
    isActive: false,
    added: {
      by: 'manuelld',
      time: '2012-10-25T03:38:58.303+0000',
    },
    mappedTicker: {
      id: 3,
      text: 'XJO.AX',
    },
    ticker: {
      id: 2,
      text: 'STW.AX',
    },
  },
  {
    modified: false,
    id: 5,
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-25T03:39:36.070+0000',
    },
    mappedTicker: {
      id: 18,
      text: 'BHP.AX',
    },
    ticker: {
      id: 249,
      text: 'BBL.US',
    },
  },
  {
    modified: false,
    id: 6,
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-25T03:40:07.007+0000',
    },
    mappedTicker: {
      id: 11,
      text: 'FTSE',
    },
    ticker: {
      id: 314,
      text: 'FTSET',
    },
  },
  {
    modified: false,
    id: 7,
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-25T03:40:28.333+0000',
    },
    mappedTicker: {
      id: 13,
      text: 'STOXX',
    },
    ticker: {
      id: 313,
      text: 'STOXXT',
    },
  },
  {
    modified: false,
    id: 8,
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-25T03:40:55.673+0000',
    },
    mappedTicker: {
      id: 12,
      text: 'SP500',
    },
    ticker: {
      id: 347,
      text: 'SP500T',
    },
  },
  {
    modified: false,
    id: 9,
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-25T03:42:02.240+0000',
    },
    mappedTicker: {
      id: 18,
      text: 'BHP.AX',
    },
    ticker: {
      id: 149,
      text: 'BHP.US',
    },
  },
  {
    modified: false,
    id: 10,
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-25T03:42:26.897+0000',
    },
    mappedTicker: {
      id: 18,
      text: 'BHP.AX',
    },
    ticker: {
      id: 266,
      text: 'BLT.LN',
    },
  },
  {
    modified: false,
    id: 11,
    isActive: false,
    added: {
      by: 'manuelld',
      time: '2012-10-25T04:00:43.790+0000',
    },
    mappedTicker: {
      id: 590,
      text: 'FCX.US',
    },
    ticker: {
      id: 315,
      text: 'SPXT ',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

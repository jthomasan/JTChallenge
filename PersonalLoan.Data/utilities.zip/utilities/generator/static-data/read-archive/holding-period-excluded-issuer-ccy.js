// Category
const category = "Holding Period";

// Type
const type = "Holding Period Excluded Issuer Ccy";

// GQL Schema
const schemaQuery =
  "StaticDataHoldingPeriodExcludedIssuerCcys: [StaticDataHoldingPeriodExcludedIssuerCcyType]";
const schemaType = `
  type StaticDataHoldingPeriodExcludedIssuerCcyType {
    modified: Boolean!
    issuer: IssuerOption
    ccy: CurrencyOption
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataHoldingPeriodExcludedIssuerCcys";
const query = `
{
  StaticDataHoldingPeriodExcludedIssuerCcys {
    modified
    issuer {
      id
      text
      description
    }
    ccy {
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataHoldingPeriodExcludedIssuerCcys: {
      url: "reference-data/v1/holding-period-excluded-issuer-ccy",
      dataPath: "$",
    },
  },
  StaticDataHoldingPeriodExcludedIssuerCcyType: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "issuer.text",
    title: "Issuer",
    filter: "text",
    typeOf: "string",
    width: "120px",
    defaultSortColumn: true,
  },
  {
    field: "issuer.description",
    title: "Issuer Description",
    filter: "text",
    typeOf: "string",
    width: "240px",
  },
  {
    field: "ccy.text",
    title: "Currency",
    filter: "text",
    typeOf: "string",
    width: "90px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "130px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "110px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    isActive: true,
    added: {
      by: "System",
      time: "2016-07-16T09:53:36.407+0000",
    },
    ccy: {
      id: 1,
      value: "AUD",
    },
    issuer: {
      id: 743,
      value: "ACGB AU",
      description: "COMMONWEALTH OF AUSTRALIA",
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "System",
      time: "2016-07-16T09:53:36.407+0000",
    },
    ccy: {
      id: 25,
      value: "NZD",
    },
    issuer: {
      id: 1051,
      value: "NZGOVT",
      description: "New Zealand",
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "System",
      time: "2016-07-16T09:53:36.407+0000",
    },
    ccy: {
      id: 33,
      value: "USD",
    },
    issuer: {
      id: 1136,
      value: "T US",
      description: "United States of America",
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "System",
      time: "2016-07-16T09:53:36.407+0000",
    },
    ccy: {
      id: 29,
      value: "SGD",
    },
    issuer: {
      id: 1404,
      value: "MAS SG",
      description: "Monetary Authority of Singapore",
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "System",
      time: "2016-07-16T09:53:36.407+0000",
    },
    ccy: {
      id: 2,
      value: "CAD",
    },
    issuer: {
      id: 1417,
      value: "CAN CA",
      description: "Canada",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

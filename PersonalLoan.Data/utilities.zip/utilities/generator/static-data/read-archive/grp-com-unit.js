// Category
const category = "Underlyings";

// Type
const type = "Grp: COM Unit";

// GQL Schema
const schemaQuery = "StaticDataCOMUnits: [StaticDataCOMUnit]";
const schemaType = `
  type StaticDataCOMUnit {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataCOMUnits";
const query = `
{
  StaticDataCOMUnits {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCOMUnits: {
      url: "reference-data/type-system-parameters",
      dataPath: "$[?(@.system.id == 1009)]",
    },
  },
  StaticDataCOMUnit: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "value",
    title: "Value",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    id: 453,
    modified: false,
    description: null,
    value: "BBL",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:45:06.277+0000",
    },
  },
  {
    id: 454,
    modified: false,
    description: null,
    value: "BU",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:45:06.277+0000",
    },
  },
  {
    id: 455,
    modified: false,
    description: null,
    value: "GAL",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:45:06.277+0000",
    },
  },
  {
    id: 456,
    modified: false,
    description: null,
    value: "LB",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:45:06.277+0000",
    },
  },
  {
    id: 457,
    modified: false,
    description: null,
    value: "MT",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:45:06.277+0000",
    },
  },
  {
    id: 458,
    modified: false,
    description: null,
    value: "MWh",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:45:06.277+0000",
    },
  },
  {
    id: 459,
    modified: false,
    description: null,
    value: "ST",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:45:06.277+0000",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

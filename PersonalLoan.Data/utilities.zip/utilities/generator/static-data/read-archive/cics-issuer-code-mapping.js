// Category
const category = "Credit";

// Type
const type = "CICS Issuer Code Mapping";

// GQL Schema
const schemaQuery =
  "StaticDataCICSIssuerCodeMappings: [StaticDataCICSIssuerCodeMappingType]";
const schemaType = `
  type StaticDataCICSIssuerCodeMappingType {
    id: ID!
    modified: Boolean!
    CICSIssuerCode: String
    Issuer: IssuerOptions
    added: Added!
  }`;

// Query
const queryName = "StaticDataCICSIssuerCodeMappings";
const query = `
{
  StaticDataCICSIssuerCodeMappings {
    id
    modified
    CICSIssuerCode
    Issuer {
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCICSIssuerCodeMappings: {
      url: "reference-data/v1/issuer-cicscode",
      dataPath: "$",
    },
  },
  StaticDataCICSIssuerCodeMappingType: {
    modified: false,
    id: "$.IssuerCICSCode",
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "CICSIssuerCode",
    title: "CICS Issuer Code",
    filter: "text",
    typeOf: "string",
    width: "210px",
    defaultSortColumn: true,
  },
  {
    field: "Issuer.text",
    title: "Issuer",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    Issuer: {
      id: 595,
      text: "002860 KS",
    },
    added: {
      by: "System",
      time: "2000-01-01T00:00:00.000+0000",
    },
    CICSIssuerCode: "A",
    IssuerCICSCode: 1,
  },
  {
    modified: false,
    Issuer: {
      id: 760,
      text: "ANZ AU",
    },
    added: {
      by: "System",
      time: "2000-01-01T00:00:00.000+0000",
    },
    CICSIssuerCode: "ANZBG",
    IssuerCICSCode: 2,
  },
  {
    modified: false,
    Issuer: {
      id: 744,
      text: "ACT AU",
    },
    added: {
      by: "System",
      time: "2000-01-01T00:00:00.000+0000",
    },
    CICSIssuerCode: "AUSTCAPTERR",
    IssuerCICSCode: 3,
  },
  {
    modified: false,
    Issuer: {
      id: 851,
      text: "DUMMY2",
    },
    added: {
      by: "System",
      time: "2000-01-01T00:00:00.000+0000",
    },
    CICSIssuerCode: "BENBK",
    IssuerCICSCode: 4,
  },
  {
    modified: false,
    Issuer: {
      id: 3742,
      text: "BCHINA AU",
    },
    added: {
      by: "brightw",
      time: "2014-04-01T01:25:42.340+0000",
    },
    CICSIssuerCode: "BOCHIAUS",
    IssuerCICSCode: 5,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Ungrouped';

// Type
const type = 'Geography';

// GQL Schema
const schemaQuery = 'StaticDataGeographies: [StaticDataGeography]';
const schemaType = `
  type StaticDataGeography {
    id: ID!
    modified: Boolean!
    description: String
    name: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataGeographies';
const query = `
{
  StaticDataGeographies {
    id
    modified
    description
    name
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataGeographies: {
      url: 'reference-data/v1/geography',
      dataPath: '$',
    },
  },
  StaticDataGeography: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    isActive: true,
    modified: false,
    added: {
      by: 'System',
      time: '2012-06-28T15:24:26.337+0000',
    },
    name: 'Australia',
    id: 1,
  },
  {
    isActive: true,
    modified: false,
    added: {
      by: 'System',
      time: '2012-06-28T15:24:34.947+0000',
    },
    name: 'Hong Kong',
    id: 2,
  },
  {
    isActive: true,
    modified: false,
    added: {
      by: 'System',
      time: '2012-06-28T15:24:42.147+0000',
    },
    name: 'NZ',
    id: 3,
  },
  {
    isActive: true,
    modified: false,
    added: {
      by: 'System',
      time: '2012-06-28T15:24:50.007+0000',
    },
    name: 'Singapore',
    id: 4,
  },
  {
    isActive: true,
    modified: false,
    added: {
      by: 'System',
      time: '2012-06-28T15:24:57.337+0000',
    },
    name: 'E&A',
    id: 5,
  },
  {
    isActive: true,
    modified: false,
    added: {
      by: 'System',
      time: '2012-06-28T15:25:04.867+0000',
    },
    name: 'Other',
    id: 6,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

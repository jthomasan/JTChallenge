// Category
const category = "Tenor Buckets";

// Type
const type = "Net Bucketing - XCCY Basis|Basis Gamma";

// GQL Schema
const schemaQuery =
  "StaticDataNetBucketXccyBasisGammas: [StaticDataNetBucketXccyBasisGammaType]";
const schemaType = `
  type StaticDataNetBucketXccyBasisGammaType {
    modified: Boolean!
    net10y: String
    net30yPlus: String
    net20y: String
    net10yPlus: String
    net1y: String
    net3m: String
    term: String!
    termUnit: Int!
    netUnder3m: String
    net5y: String
    net3y: String
  }`;

// Query
const queryName = "StaticDataNetBucketXccyBasisGammas";
const query = `
{
  StaticDataNetBucketXccyBasisGammas {
    modified
    net10y
    net30yPlus
    net20y
    net10yPlus
    net1y
    net3m
    term
    termUnit
    netUnder3m
    net5y
    net3y
  } 
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataNetBucketXccyBasisGammas: {
      url: "reference-data/v1/net-bucket-xccy-basis",
      dataPath: "$",
    },
  },
  StaticDataNetBucketXccyBasisGammaType: {
    modified: false,
    termUnit: {
      dataPath: "$.term",
      decorators: [{ name: "vegaBuckerTermUnit" }],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "termUnit",
    title: "Days to Maturity",
    filter: "text",
    typeOf: "string",
    width: "150px",
    defaultSortColumn: true,
    cell: "GridCustomCell",
    extras: {
      displayField: "term",
    },
  },
  {
    field: "netUnder3m",
    title: "NetUnder3m",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
  },
  {
    field: "net3m",
    title: "Net3m",
    filter: "numeric",
    typeOf: "number",
    width: "140px",
  },
  {
    field: "net1y",
    title: "Net1y",
    filter: "numeric",
    typeOf: "number",
    width: "140px",
  },
  {
    field: "net3y",
    title: "Net3y",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
  },
  {
    field: "net5y",
    title: "Net5y",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
  },
  {
    field: "net10y",
    title: "Net10y",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
  },
  {
    field: "net10yPlus",
    title: "Net10yPlus",
    filter: "numeric",
    typeOf: "number",
    width: "110px",
  },
  {
    field: "net20y",
    title: "Net20y",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
  },
  {
    field: "net30yPlus",
    title: "Net30yPlus",
    filter: "numeric",
    typeOf: "number",
    width: "120x",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net10y: "100",
    net30yPlus: "0",
    net20y: "0",
    net10yPlus: "100",
    net1y: "0",
    net3m: "0",
    term: "10y",
    termUnit: 3650,
    netUnder3m: "0",
    net5y: "0",
    net3y: "0",
  },
  {
    modified: false,
    net10y: "80",
    net30yPlus: "0",
    net20y: "20",
    net10yPlus: "100",
    net1y: "0",
    net3m: "0",
    term: "12y",
    termUnit: 4380,
    netUnder3m: "0",
    net5y: "0",
    net3y: "0",
  },
  {
    modified: false,
    net10y: "50",
    net30yPlus: "0",
    net20y: "50",
    net10yPlus: "100",
    net1y: "0",
    net3m: "0",
    term: "15y",
    termUnit: 5475,
    netUnder3m: "0",
    net5y: "0",
    net3y: "0",
  },
  {
    modified: false,
    net10y: "0",
    net30yPlus: "0",
    net20y: "0",
    net10yPlus: "0",
    net1y: "0",
    net3m: "100",
    term: "1m",
    termUnit: 30,
    netUnder3m: "100",
    net5y: "0",
    net3y: "0",
  },
  {
    modified: false,
    net10y: "0",
    net30yPlus: "0",
    net20y: "0",
    net10yPlus: "0",
    net1y: "100",
    net3m: "0",
    term: "1y",
    termUnit: 365,
    netUnder3m: "0",
    net5y: "0",
    net3y: "0",
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

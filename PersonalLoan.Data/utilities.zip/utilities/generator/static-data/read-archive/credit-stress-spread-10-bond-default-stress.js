// Category
const category = 'Credit Stress';

// Type
const type = 'Credit Stress Spread 10 - Bond Default Stress';

// GQL Schema
const schemaQuery =
  'StaticDataCreditStressSpreadTenBondDefaultStresses: [StaticDataCreditStressSpreadTenBondDefaultStress]';
const schemaType = `
  type StaticDataCreditStressSpreadTenBondDefaultStress {
    modified: Boolean!
    anzRatingTypeSystem: AnzRatingTypeSystemOptions!
    stressFactor: Int!
    isActive: Boolean!
    added: Added
  }
`;

// Query
const queryName = 'StaticDataCreditStressSpreadTenBondDefaultStresses';
const query = `
{
  StaticDataCreditStressSpreadTenBondDefaultStresses {
    modified
    anzRatingTypeSystem {
      id
      text
    }
    stressFactor
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCreditStressSpreadTenBondDefaultStresses: {
      url: 'reference-data/v1/default-credit-stress-factor',
      dataPath: '$',
    },
  },
  StaticDataCreditStressSpreadTenBondDefaultStress: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'anzRatingTypeSystem.text',
    title: 'Rating',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    defaultSortColumn: true,
  },
  {
    field: 'stressFactor',
    title: 'Stress Factor',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    stressFactor: 30,
    anzRatingTypeSystem: {
      id: 739,
      text: 'AAA',
    },
    isActive: true,
    added: {
      by: 'System',
      time: '2015-09-19T04:46:15.270+0000',
    },
  },
  {
    modified: false,
    stressFactor: 65,
    anzRatingTypeSystem: {
      id: 740,
      text: 'AA',
    },
    isActive: true,
    added: {
      by: 'System',
      time: '2015-09-19T04:46:15.270+0000',
    },
  },
  {
    modified: false,
    stressFactor: 100,
    anzRatingTypeSystem: {
      id: 741,
      text: 'A',
    },
    isActive: true,
    added: {
      by: 'System',
      time: '2015-09-19T04:46:15.270+0000',
    },
  },
  {
    modified: false,
    stressFactor: 200,
    anzRatingTypeSystem: {
      id: 742,
      text: 'BBB',
    },
    isActive: true,
    added: {
      by: 'System',
      time: '2015-09-19T04:46:15.270+0000',
    },
  },
  {
    modified: false,
    stressFactor: 500,
    anzRatingTypeSystem: {
      id: 743,
      text: 'BB',
    },
    isActive: true,
    added: {
      by: 'System',
      time: '2015-09-19T04:46:15.270+0000',
    },
  },
  {
    modified: false,
    stressFactor: 1500,
    anzRatingTypeSystem: {
      id: 744,
      text: 'B',
    },
    isActive: true,
    added: {
      by: 'System',
      time: '2015-09-19T04:46:15.270+0000',
    },
  },
  {
    modified: false,
    stressFactor: 2400,
    anzRatingTypeSystem: {
      id: 745,
      text: 'CCC',
    },
    isActive: true,
    added: {
      by: 'System',
      time: '2015-09-19T04:46:15.270+0000',
    },
  },
  {
    modified: false,
    stressFactor: 250,
    anzRatingTypeSystem: {
      id: 746,
      text: 'N/R',
    },
    isActive: true,
    added: {
      by: 'System',
      time: '2015-09-19T04:46:15.270+0000',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

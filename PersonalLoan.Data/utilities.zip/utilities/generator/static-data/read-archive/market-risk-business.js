// Category
const category = 'Ungrouped';

// Type
const type = 'Market Risk Business';

// GQL Schema
const schemaQuery =
  'MarketRiskBusinessMappings: [MarketRiskBusinessMapping]';
const schemaType = `
  type MarketRiskBusinessMapping {
    modified: Boolean!
    id: ID!
    code: String
    marketRiskBusinessDescription: String
    marketRiskBusinessGroup: MarketRiskBusinessGroup
    addedBy: String
    addedTime: String
  }
  
  type MarketRiskBusinessGroup {
    id: ID
    name: String
  }`;

// Query
const queryName = 'MarketRiskBusinessMappings';
const query = `
{
  MarketRiskBusinessMappings {
    modified
    code
    id
    marketRiskBusinessGroup {
      id
      name
    }
    marketRiskBusinessDescription
    addedBy
    addedTime
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    MarketRiskBusinessMappings: {
      url: 'limits/v1/limit-market-risk-business',
      dataPath: '$',
    },
  },
  MarketRiskBusinessMapping: {
    modified: false,
    id: '$.marketRiskBusinessId'
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'code',
    title: 'Code',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'MarketRiskBusinessDescription',
    title: 'marketRiskBusinessDescription',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'marketRiskBusinessGroup.name',
    title: 'Grouping',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'addedBy',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'addedTime',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
};

// Category
const category = "Tenor Buckets";

// Type
const type = "Generic Term Pillars - Petroleum Delta";

// GQL Schema
const schemaQuery =
  "StaticDataGenericTermPillarsPetroleumDeltas: [StaticDataGenericTermPillarsPetroleumDeltaType]";
const schemaType = `
  type StaticDataGenericTermPillarsPetroleumDeltaType {
    modified: Boolean!
    termUnit: Int!
    term: String!
    net0y_5y: String!
    net5y_8y: String!
  }`;

// Query
const queryName = "StaticDataGenericTermPillarsPetroleumDeltas";
const query = `
{
  StaticDataGenericTermPillarsPetroleumDeltas {
    modified
    term
    termUnit
    net5y_8y
    net0y_5y
  } 
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataGenericTermPillarsPetroleumDeltas: {
      url: "reference-data/v1/bucket-gen-pillar-petroleum",
      dataPath: "$",
    },
  },
  StaticDataGenericTermPillarsPetroleumDeltaType: {
    modified: false,
    termUnit: {
      dataPath: "$.term",
      decorators: [{ name: "genericTermPillarsTermUnit" }],
    },
    net0y_5y: {
      dataPath: "$.net0y_5y",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net5y_8y: {
      dataPath: "$.net5y_8y",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "termUnit",
    title: "Days to Maturity",
    filter: "text",
    typeOf: "string",
    width: "150px",
    defaultSortColumn: true,
    cell: "GridCustomCell",
    extras: {
      displayField: "term",
    },
  },
  {
    field: "net0y_5y",
    title: "Net0y_5y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net5y_8y",
    title: "Net5y_8y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net5y_8y: "0",
    net0y_5y: "100",
    term: "c1",
  },
  {
    modified: false,
    net5y_8y: "0",
    net0y_5y: "100",
    term: "c10",
  },
  {
    modified: false,
    net5y_8y: "0",
    net0y_5y: "100",
    term: "c11",
  },
  {
    modified: false,
    net5y_8y: "0",
    net0y_5y: "100",
    term: "c12",
  },
  {
    modified: false,
    net5y_8y: "0",
    net0y_5y: "100",
    term: "c13",
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

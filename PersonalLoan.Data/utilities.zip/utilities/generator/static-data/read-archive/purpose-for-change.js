// Category
const category = 'Limits';

// Type
const type = 'Purpose for Change';

// GQL Schema
const schemaQuery =
  'StaticDataPurposeForChanges: [StaticDataPurposeForChange]';
const schemaType = `
  type StaticDataPurposeForChange {
    id: ID!
    modified: Boolean!
    description: String
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataPurposeForChanges';
const query = `
{
  StaticDataPurposeForChanges {
    id
    modified
    description
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataPurposeForChanges: {
      url: 'limits/v1/limit-purpose-for-change',
      dataPath: '$',
    },
  },
  StaticDataPurposeForChange: {
    modified: false,
    isActive: "$.active",
    id: "$.purposeForChangeId"
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'description',
    title: 'Purpose For Change',
    filter: 'text',
    typeOf: 'string',
    width: '500px',
    defaultSortColumn: true,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

// Mock Data
const mockData = [
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

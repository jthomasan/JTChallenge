// Category
const category = "Other";

// Type
const type = "Volcker Desk";

// GQL Schema
const schemaQuery = "StaticDataVolckerDesk: [StaticDataVolckerDeskType]";
const schemaType = `
  type StaticDataVolckerDeskType {
    id: ID!
    modified: Boolean
    name: String
    description: String
    added: Added!
    isActive: Boolean!
    reportingCategory: ReportingCategoryOption
    GlobalBusinessUnit: GlobalBusinessUnitOption
  }
  
  type ReportingCategoryOption {
    id: ID
    text: String
  }
  
  type GlobalBusinessUnitOption {
    id: ID
    text: String
  }`;

// Query
const queryName = "StaticDataVolckerDesk";
const query = `
{
  StaticDataVolckerDesk {
    id
    modified
    name
    description
    isActive
    reportingCategory {
      id
      text
    }
    GlobalBusinessUnit {
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataVolckerDesk: {
      url: "reference-data/v1/volcker-desk",
      dataPath: "$",
    },
  },
  StaticDataVolckerDeskType: {
    modified: false,
    id: "$.VolckerDesk",
  },
  GlobalBusinessUnitOption: {
    text: "$.value",
  },
  ReportingCategoryOption: {
    text: "$.value",
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "name",
    title: "Name",
    filter: "text",
    typeOf: "string",
    width: "180px",
    defaultSortColumn: true,
  },
  {
    field: "description",
    title: "Description",
    filter: "text",
    typeOf: "string",
    width: "180px",
  },
  {
    field: "GlobalBusinessUnit.text",
    title: "GlobalBusinessUnit",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "reportingCategory.text",
    title: "ReportingCategory",
    filter: "text",
    typeOf: "string",
    width: "160px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    name: "Commodities - Agriculture/Softs",
    description: "Commodities - Agriculture/Softs",
    added: {
      by: "wongl14",
      time: "2017-12-20T04:27:40.140+0000",
    },
    isActive: true,
    CounterPartyGroupMap: null,
    reportingCategory: {
      id: 7,
      text: "Market Making - Non Mature",
    },
    GlobalBusinessUnit: {
      id: 1,
      text: "Commodities",
    },
    RentdPeriod: null,
    id: 47,
  },
  {
    modified: false,
    name: "Commodities - Base Metals",
    description: "Commodities - Base Metals",
    added: {
      by: "wongl14",
      time: "2017-12-20T04:27:40.173+0000",
    },
    isActive: true,
    CounterPartyGroupMap: null,
    reportingCategory: {
      id: 7,
      text: "Market Making - Non Mature",
    },
    GlobalBusinessUnit: {
      id: 1,
      text: "Commodities",
    },
    RentdPeriod: null,
    id: 48,
  },
  {
    modified: false,
    name: "Commodities - Bulks",
    description: "Commodities - Bulks",
    added: {
      by: "wongl14",
      time: "2017-12-20T04:27:40.173+0000",
    },
    isActive: true,
    CounterPartyGroupMap: null,
    reportingCategory: {
      id: 7,
      text: "Market Making - Non Mature",
    },
    GlobalBusinessUnit: {
      id: 1,
      text: "Commodities",
    },
    RentdPeriod: null,
    id: 49,
  },
  {
    modified: false,
    name: "Commodities - Electricity",
    description: "Commodities - Electricity",
    added: {
      by: "wongl14",
      time: "2017-11-08T05:33:28.660+0000",
    },
    isActive: false,
    CounterPartyGroupMap: null,
    reportingCategory: {
      id: 4,
      text: "TOTUS",
    },
    GlobalBusinessUnit: {
      id: 1,
      text: "Commodities",
    },
    RentdPeriod: null,
    id: 50,
  },
  {
    modified: false,
    name: "Commodities - Emissions",
    description: "Commodities - Emissions",
    added: {
      by: "System",
      time: "2015-07-23T06:43:23.460+0000",
    },
    isActive: true,
    CounterPartyGroupMap: null,
    reportingCategory: {
      id: 4,
      text: "TOTUS",
    },
    GlobalBusinessUnit: {
      id: 1,
      text: "Commodities",
    },
    RentdPeriod: null,
    id: 51,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

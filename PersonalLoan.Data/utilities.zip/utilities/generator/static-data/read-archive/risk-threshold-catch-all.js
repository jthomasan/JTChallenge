// Category
const category = 'Ungrouped';

// Type
const type = 'Risk Threshold - Catch All';

// GQL Schema
const schemaQuery =
  'StaticDataRiskThresholdCatchAllList: [StaticDataRiskThresholdCatchAll]';
const schemaType = `
  type StaticDataRiskThresholdCatchAll {
    id: ID!
    modified: Boolean!
    name: String!
    description: String!
    reconThresholdAmt: Int!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataRiskThresholdCatchAllList';
const query = `
{
  StaticDataRiskThresholdCatchAllList {
    id
    modified
    name
    description
    reconThresholdAmt
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataRiskThresholdCatchAllList: {
      url: 'reference-data/v1/risk-type',
      dataPath: '$',
    },
  },
  StaticDataRiskThresholdCatchAll: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'reconThresholdAmt',
    title: 'Recon Threshold Amount',
    filter: 'numeric',
    typeOf: 'number',
    width: '170px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    name: 'Market Value',
    id: 1,
    description: 'Market Value',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.277+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'DV01 Par',
    id: 2,
    description: 'DV01 Par',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.277+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'IR Gamma',
    id: 3,
    description: 'IR Gamma',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.277+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'IR Vega',
    id: 4,
    description: 'IR Vega',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.290+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'CR01 Par',
    id: 5,
    description: 'CR01 Par',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.290+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Delta',
    id: 6,
    description: 'Delta',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.290+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Vega',
    id: 7,
    description: 'Vega',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.290+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Theta',
    id: 8,
    description: 'Theta',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.290+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Div.Sensitivity',
    id: 9,
    description: 'Div.Sensitivity',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.307+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Rho Repo',
    id: 10,
    description: 'Rho Repo',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.307+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Fx.Delta',
    id: 11,
    description: 'Fx.Delta',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.307+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Fx.Vega',
    id: 12,
    description: 'Fx.Vega',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.320+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Com. Delta',
    id: 13,
    description: 'Com. Delta',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.320+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Com. Vega',
    id: 14,
    description: 'Com. Vega',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.320+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Inflation Delta Par',
    id: 15,
    description: 'Inflation Delta Par',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.320+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Inflation Delta cpi',
    id: 16,
    description: 'Inflation Delta cpi',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.320+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'Basis delta par',
    id: 17,
    description: 'Basis delta par',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T13:06:54.337+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'P&L(i)',
    id: 19,
    description: 'P&L(i)',
    isActive: true,
    added: {
      by: 'System',
      time: '2014-07-12T14:38:45.990+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'SCN_NO_RT_FL',
    id: 409523,
    description: 'SCN_NO_RT_FL',
    isActive: true,
    added: {
      by: 'ETL_UVR',
      time: '2019-03-23T14:35:59.073+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'EUR',
    id: 409524,
    description: 'EUR',
    isActive: true,
    added: {
      by: 'ETL_UVR',
      time: '2019-03-23T14:40:35.540+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'EUR/USD',
    id: 409525,
    description: 'EUR/USD',
    isActive: true,
    added: {
      by: 'ETL_UVR',
      time: '2019-03-23T14:42:37.093+0000',
    },
    reconThresholdAmt: 0,
  },
  {
    modified: false,
    name: 'USD',
    id: 409526,
    description: 'USD',
    isActive: true,
    added: {
      by: 'ETL_UVR',
      time: '2019-03-23T14:43:40.883+0000',
    },
    reconThresholdAmt: 0,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

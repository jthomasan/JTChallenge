// Category
const category = 'Limits';

// Type
const type = 'Product Sub Categories';

// GQL Schema
const schemaQuery =
  'ProductSubCategoryMappings: [ProductSubCategoryMapping]';
const schemaType = `
  type ProductSubCategoryMapping {
    id: ID!
    modified: Boolean!
    description: String
    globalProductLine: GlobalProductLine
    isActive: Boolean!
    added: Added!
  }
  
  type GlobalProductLine{
    id: ID
    text: String
  }
  `;

// Query
const queryName = 'ProductSubCategoryMappings';
const query = `
{
  ProductSubCategoryMappings {
    id
    modified
    description
    globalProductLine{
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    ProductSubCategoryMappings: {
      url: 'limits/v1/limit-product-sub-category',
      dataPath: '$',
    },
  },
  ProductSubCategoryMapping: {
    modified: false,
    isActive: "$.active",
    id: "$.productSubCategoryId"
  },
  GlobalProductLine:{
    text:'$.value'
  }
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'description',
    title: 'Product Sub Category',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    defaultSortColumn: true,
  },
  {
    field: 'globalProductLine.text',
    title: 'Global Product Line',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    defaultSortColumn: true,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

// Mock Data
const mockData = [
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Repo';

// Type
const type = 'Haircut Reference';

// GQL Schema
const schemaQuery = 'StaticDataHaircutReferences: [StaticDataHaircutReference]';
const schemaType = `
  type StaticDataHaircutReference {
    id: ID
    modified: Boolean!
    counterpartyCcr: String!
    counterpartySector: String!
    maturityBucket: String!
    haircut: Float!
    tier: String!
    rating: String!
    added: Added
  }
`;

// Query
const queryName = 'StaticDataHaircutReferences';
const query = `
{
  StaticDataHaircutReferences {
    id
    modified
    tier
    counterpartySector
    counterpartyCcr
    rating
    maturityBucket
    haircut
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataHaircutReferences: {
      url: 'reference-data/v1/haircut-reference',
      dataPath: '$',
    },
  },
  StaticDataHaircutReference: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'tier',
    title: 'Tier',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'counterpartySector',
    title: 'Counterparty Sector',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'counterpartyCcr',
    title: 'Counterparty Ccr',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'rating',
    title: 'Rating',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'maturityBucket',
    title: 'MaturityBucket',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'haircut',
    title: 'Haircut',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    id: 1,
    modified: false,
    counterpartyCcr: '0-2',
    counterpartySector: 'Government',
    maturityBucket: '0-5',
    haircut: -0.02,
    tier: 'TIER1',
    added: {
      by: 'modis3',
      time: '2019-10-21T07:54:42.673+0000',
    },
    rating: 'AAA - AA',
  },
  {
    id: 2,
    modified: false,
    counterpartyCcr: '0-2',
    counterpartySector: 'Government',
    maturityBucket: '0-5',
    haircut: -0.02,
    tier: 'TIER1',
    added: {
      by: 'modis3',
      time: '2019-10-21T07:54:42.673+0000',
    },
    rating: 'A',
  },
  {
    id: 3,
    modified: false,
    counterpartyCcr: '0-2',
    counterpartySector: 'Government',
    maturityBucket: '0-5',
    haircut: -0.03,
    tier: 'TIER1',
    added: {
      by: 'modis3',
      time: '2019-10-21T07:54:42.673+0000',
    },
    rating: 'BBB',
  },
  {
    id: 4,
    modified: false,
    counterpartyCcr: '3-5',
    counterpartySector: 'Government',
    maturityBucket: '0-5',
    haircut: -0.02,
    tier: 'TIER1',
    added: {
      by: 'yeungc4',
      time: '2019-10-29T03:22:44.210+0000',
    },
    rating: 'AAA - AA',
  },
  {
    id: 5,
    modified: false,
    counterpartyCcr: '3-5',
    counterpartySector: 'Government',
    maturityBucket: '0-5',
    haircut: -0.03,
    tier: 'TIER1',
    added: {
      by: 'yeungc4',
      time: '2019-10-29T03:22:44.223+0000',
    },
    rating: 'A',
  },
  {
    id: 6,
    modified: false,
    counterpartyCcr: '3-5',
    counterpartySector: 'Government',
    maturityBucket: '0-5',
    haircut: -0.05,
    tier: 'TIER1',
    added: {
      by: 'yeungc4',
      time: '2019-10-29T03:22:44.223+0000',
    },
    rating: 'BBB',
  },
  {
    id: 7,
    modified: false,
    counterpartyCcr: '0-2',
    counterpartySector: 'Corporate',
    maturityBucket: '0-5',
    haircut: -0.04,
    tier: 'TIER1',
    added: {
      by: 'modis3',
      time: '2019-10-21T07:54:42.690+0000',
    },
    rating: 'AAA - AA',
  },
  {
    id: 8,
    modified: false,
    counterpartyCcr: '0-2',
    counterpartySector: 'Corporate',
    maturityBucket: '0-5',
    haircut: -0.04,
    tier: 'TIER1',
    added: {
      by: 'modis3',
      time: '2019-10-21T07:54:42.690+0000',
    },
    rating: 'A',
  },
  {
    id: 9,
    modified: false,
    counterpartyCcr: '0-2',
    counterpartySector: 'Corporate',
    maturityBucket: '0-5',
    haircut: -0.06,
    tier: 'TIER1',
    added: {
      by: 'modis3',
      time: '2019-10-21T07:54:42.690+0000',
    },
    rating: 'BBB',
  },
  {
    id: 10,
    modified: false,
    counterpartyCcr: '3-5',
    counterpartySector: 'Corporate',
    maturityBucket: '0-5',
    haircut: -0.05,
    tier: 'TIER1',
    added: {
      by: 'yeungc4',
      time: '2019-10-29T03:22:44.240+0000',
    },
    rating: 'AAA - AA',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

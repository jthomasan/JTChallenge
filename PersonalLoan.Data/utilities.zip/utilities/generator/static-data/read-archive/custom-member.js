// Category
const category = 'Ungrouped';

// Type
const type = 'Custom Member';

// GQL Schema
const schemaQuery = 'StaticDataCustomMembers: [StaticDataCustomMember]';
const schemaType = `
  type StaticDataCustomMember {
    id: ID!
    modified: Boolean!
    name: String
    underlyingType: String
    operation: String
    nameofUnderlying: String
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataCustomMembers';
const query = `
{
  StaticDataCustomMembers {
    id
    modified
    name
    underlyingType
    operation
    nameofUnderlying
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCustomMembers: {
      url: 'reference-data/v1/custom-members',
      dataPath: '$',
    },
  },
  StaticDataCustomMember: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'operation',
    title: 'Operation',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'underlyingType',
    title: 'Underlying Type',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'nameofUnderlying',
    title: 'Name of Underlying',
    filter: 'text',
    typeOf: 'string',
    width: '250px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    id: 178,
    name: 'CNG',
    underlyingType: 'Underlying-COM',
    operation: 'Combine',
    nameofUnderlying:
      'Newcastle Coal - Monthly,Newcastle Coal - Quarterly,Newcastle Coal - Yearly',
    isActive: true,
    added: {
      by: 'imrek',
      time: '2013-05-16T02:09:07.557+0000',
    },
  },
  {
    modified: false,
    id: 179,
    isActive: true,
    name: 'IOS',
    underlyingType: 'Underlying-COM',
    operation: 'Combine',
    nameofUnderlying: 'IOP,IOS',
    added: {
      by: 'imrek',
      time: '2013-05-16T02:09:07.497+0000',
    },
  },
  {
    modified: false,
    id: 143,
    isActive: true,
    name: 'WTI',
    underlyingType: 'Underlying-COM',
    operation: 'Combine',
    nameofUnderlying: 'ECL,ECM',
    added: {
      by: 'ngoa',
      time: '2012-12-13T23:02:51.850+0000',
    },
  },
  {
    modified: false,
    id: 147,
    isActive: true,
    name: 'US Wheat',
    underlyingType: 'Underlying-COM',
    operation: 'Combine',
    nameofUnderlying: 'CWT,KWT,MWT',
    added: {
      by: 'ngoa',
      time: '2012-12-13T23:54:42.927+0000',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Underlyings';

// Type
const type = 'National Market	';

// GQL Schema
const schemaQuery = 'StaticDataNationalMarkets: [StaticDataNationalMarket]';
const schemaType = `
  type StaticDataNationalMarket {
    id: ID!
    modified: Boolean!
    securityMarket: String!
    nationalMarketTypeSystem: NationalMarketTypeSystemOptions
    comment: String
    added: Added
  }
  
  type NationalMarketTypeSystemOptions {
    id: ID
    text: String
  }
`;

// Query
const queryName = 'StaticDataNationalMarkets';
const query = `
{
  StaticDataNationalMarkets {
    id
    modified
    securityMarket
    nationalMarketTypeSystem {
      id
      text
    }
    comment
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataNationalMarkets: {
      url: 'reference-data/v1/security-market-with-attribute',
      dataPath: '$',
    },
  },
  StaticDataNationalMarket: {
    modified: false,
  },
  NationalMarketTypeSystemOptions: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'securityMarket',
    title: 'Security Market',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'nationalMarketTypeSystem.text',
    title: 'Grp: National Market',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    comment: null,
    modified: false,
    id: 1,
    added: {
      by: 'System',
      time: '2012-02-24T07:05:33.803+0000',
    },
    nationalMarketTypeSystem: {
      id: 88,
      text: 'Australia',
    },
    securityMarket: 'AUD ASX',
  },
  {
    comment: null,
    modified: false,
    id: 2,
    added: {
      by: 'System',
      time: '2012-02-24T07:05:33.803+0000',
    },
    nationalMarketTypeSystem: {
      id: 95,
      text: 'Non Equity',
    },
    securityMarket: 'Default',
  },
  {
    comment: null,
    modified: false,
    id: 3,
    added: {
      by: 'System',
      time: '2012-02-24T07:05:33.803+0000',
    },
    nationalMarketTypeSystem: {
      id: 91,
      text: 'Europe',
    },
    securityMarket: 'EUR EUZ',
  },
  {
    comment: null,
    modified: false,
    id: 4,
    added: {
      by: 'System',
      time: '2012-02-24T07:05:33.803+0000',
    },
    nationalMarketTypeSystem: {
      id: 97,
      text: 'UK',
    },
    securityMarket: 'GBP LSE',
  },
  {
    comment: null,
    modified: false,
    id: 5,
    added: {
      by: 'System',
      time: '2012-02-24T07:05:33.803+0000',
    },
    nationalMarketTypeSystem: {
      id: 92,
      text: 'Hong Kong',
    },
    securityMarket: 'HKD HKE',
  },
  {
    comment: null,
    modified: false,
    id: 6,
    added: {
      by: 'System',
      time: '2012-02-24T07:05:33.803+0000',
    },
    nationalMarketTypeSystem: {
      id: 92,
      text: 'Hong Kong',
    },
    securityMarket: 'HKD HKF',
  },
  {
    comment: null,
    modified: false,
    id: 7,
    added: {
      by: 'System',
      time: '2012-02-24T07:05:33.803+0000',
    },
    nationalMarketTypeSystem: {
      id: 93,
      text: 'Japan',
    },
    securityMarket: 'JPY OSE',
  },
  {
    comment: null,
    modified: false,
    id: 8,
    added: {
      by: 'System',
      time: '2012-02-24T07:05:33.803+0000',
    },
    nationalMarketTypeSystem: {
      id: 93,
      text: 'Japan',
    },
    securityMarket: 'JPY TSE',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

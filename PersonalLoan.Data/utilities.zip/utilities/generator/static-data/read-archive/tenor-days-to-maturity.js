// Category
const category = 'Tenor Buckets';

// Type
const type = 'Tenor & Days to Maturity';

// GQL Schema
const schemaQuery =
  'StaticDataTenorAndDaystoMaturities: [StaticDataStaticDataTenorAndDaystoMaturity]';
const schemaType = `
  type StaticDataStaticDataTenorAndDaystoMaturity {
    id: ID!
    modified: Boolean!
    tenor: String
    daysToMaturity: Int
    bondETOInstrument: String
    isDeliverable: Boolean
    sEFName: String
    tRNGRP: String
    added: Added!
  }`;

// Query
const queryName = 'StaticDataTenorAndDaystoMaturities';
const query = `
{
  StaticDataTenorAndDaystoMaturities {
    id
    modified
    bondETOInstrument
    sEFName
    tRNGRP
    tenor
    daysToMaturity
    isDeliverable
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataTenorAndDaystoMaturities: {
      url: 'reference-data/v1/tenor-eto',
      dataPath: '$',
    },
  },
  StaticDataStaticDataTenorAndDaystoMaturity: {
    modified: false,
    tenor: '$.Tenor',
    sEFName: '$.SEFName',
    tRNGRP: '$.TRNGRP',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'bondETOInstrument',
    title: 'Bond ETO Instrument',
    filter: 'text',
    typeOf: 'string',
    width: '160px',
    defaultSortColumn: true,
  },
  {
    field: 'sEFName',
    title: 'Contract Description',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'tRNGRP',
    title: 'Contract Group',
    filter: 'text',
    typeOf: 'string',
    width: '130px',
  },
  {
    field: 'tenor',
    title: 'Tenor',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
  },
  {
    field: 'daysToMaturity',
    title: 'Days to Maturity',
    filter: 'numeric',
    typeOf: 'number',
    width: '130px',
  },
  {
    field: 'isDeliverable',
    title: 'Is Deliverable',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '120px',
    cell: 'GridCheckboxCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    added: {
      by: 'System',
      time: '2010-01-01T00:00:00.000+0000',
    },
    tenor: '3y',
    daysToMaturity: 1095,
    bondETOInstrument: 'KOF KRW 3Y BOND',
    id: 10,
    isDeliverable: false,
    sEFName: '3 YR KOREAN GOVT BOND FUTURE',
    tRNGRP: 'LFUT',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2010-01-01T00:00:00.000+0000',
    },
    tenor: '5y',
    daysToMaturity: 1825,
    bondETOInstrument: 'KOF KRW 5Y BOND',
    id: 11,
    isDeliverable: false,
    sEFName: '5 YR KOREAN GOVT BOND FUTURE',
    tRNGRP: 'LFUT',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2010-01-01T00:00:00.000+0000',
    },
    tenor: '10y',
    daysToMaturity: 3650,
    bondETOInstrument: 'LIF 10Y JGB',
    id: 12,
    isDeliverable: false,
    sEFName: 'LIFFE 10 YEAR JAP GOVT FUTURE',
    tRNGRP: 'LFUT',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2010-01-01T00:00:00.000+0000',
    },
    tenor: '10y',
    daysToMaturity: 3650,
    bondETOInstrument: 'NZF 10Y BOND',
    id: 14,
    isDeliverable: false,
    sEFName: '10 YR NZ GOVERNMENT STOCK FUTURE',
    tRNGRP: 'LFUT',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2010-01-01T00:00:00.000+0000',
    },
    tenor: '3y',
    daysToMaturity: 1095,
    bondETOInstrument: 'NZF 3Y BOND',
    id: 15,
    isDeliverable: false,
    sEFName: '3 YR NZ GOVERNMENT STOCK FUTURE',
    tRNGRP: 'LFUT',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2010-01-01T00:00:00.000+0000',
    },
    tenor: '10y',
    daysToMaturity: 3650,
    bondETOInstrument: 'SFE 10Y BOND',
    id: 16,
    isDeliverable: false,
    sEFName: '10 YR AUD COMMONWEALTH BOND FUTURE',
    tRNGRP: 'LFUT',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2010-01-01T00:00:00.000+0000',
    },
    tenor: '3y',
    daysToMaturity: 1095,
    bondETOInstrument: 'SFE 3Y BOND',
    id: 17,
    isDeliverable: false,
    sEFName: '3 YR COMMONWEALTH BOND FUTURE',
    tRNGRP: 'LFUT',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2010-01-01T00:00:00.000+0000',
    },
    tenor: '10y',
    daysToMaturity: 3650,
    bondETOInstrument: 'SGX 10Y JGB',
    id: 18,
    isDeliverable: false,
    sEFName: 'SGX 10Y JAP GOVT FUTURE',
    tRNGRP: 'LFUT',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

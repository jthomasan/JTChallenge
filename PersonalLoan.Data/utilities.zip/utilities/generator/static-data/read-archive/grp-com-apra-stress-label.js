// Category
const category = "Underlyings";

// Type
const type = "Grp: COM APRA Stress Label";

// GQL Schema
const schemaQuery =
  "StaticDataCOMAPRAStressLabels: [StaticDataCOMAPRAStressLabel]";
const schemaType = `
  type StaticDataCOMAPRAStressLabel {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataCOMAPRAStressLabels";
const query = `
{
  StaticDataCOMAPRAStressLabels {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCOMAPRAStressLabels: {
      url: "reference-data/type-system-parameters",
      dataPath: "$[?(@.system.id == 1002)]",
    },
  },
  StaticDataCOMAPRAStressLabel: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "value",
    title: "Value",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    id: 1408,
    modified: false,
    description: null,
    value: "Kerosene",
    isActive: true,
    added: {
      by: "brightw",
      time: "2013-08-09T00:06:28.770+0000",
    },
  },
  {
    id: 1409,
    modified: false,
    description: null,
    value: "Oil - BRT",
    isActive: true,
    added: {
      by: "brightw",
      time: "2013-08-09T00:06:28.770+0000",
    },
  },
  {
    id: 1410,
    modified: false,
    description: null,
    value: "Oil - EN590",
    isActive: true,
    added: {
      by: "brightw",
      time: "2013-08-09T00:06:28.773+0000",
    },
  },
  {
    id: 1411,
    modified: false,
    description: null,
    value: "Oil - GO",
    isActive: true,
    added: {
      by: "brightw",
      time: "2013-08-09T00:06:28.773+0000",
    },
  },
  {
    id: 1412,
    modified: false,
    description: null,
    value: "Oil - HSFO180",
    isActive: true,
    added: {
      by: "brightw",
      time: "2013-08-09T00:06:28.773+0000",
    },
  },
  {
    id: 1413,
    modified: false,
    description: null,
    value: "Oil - IPE",
    isActive: true,
    added: {
      by: "brightw",
      time: "2013-08-09T00:06:28.777+0000",
    },
  },
  {
    id: 1414,
    modified: false,
    description: null,
    value: "Oil - JETCIFNWE",
    isActive: true,
    added: {
      by: "brightw",
      time: "2013-08-09T00:06:28.777+0000",
    },
  },
  {
    id: 1415,
    modified: false,
    description: null,
    value: "Oil - SGO",
    isActive: true,
    added: {
      by: "brightw",
      time: "2013-08-09T00:06:28.780+0000",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

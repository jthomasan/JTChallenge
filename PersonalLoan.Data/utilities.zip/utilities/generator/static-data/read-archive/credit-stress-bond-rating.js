// Category
const category = 'Credit Stress';

// Type
const type = 'Credit Stress - Bond Rating';

// GQL Schema
const schemaQuery =
  'StaticDataCreditStressBondRatings: [StaticDataCreditStressBondRating]';
const schemaType = `
  type StaticDataCreditStressBondRating {
    modified: Boolean!
    anzRatingTypeSystem: AnzRatingTypeSystemOptions!
    daysToMaturity: String!
    longStress: Int!
    shortStress: Int!
    Currency: CurrencyOptions!
    isActive: Boolean!
    added: Added
  }
  
  type AnzRatingTypeSystemOptions {
    id: ID
    text: String
  }
  
  type CurrencyOptions {
    id: ID
    text: String
  }
`;

// Query
const queryName = 'StaticDataCreditStressBondRatings';
const query = `
{
  StaticDataCreditStressBondRatings {
    modified
    anzRatingTypeSystem {
      id
      text
    }
    daysToMaturity
    longStress
    shortStress
    Currency {
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCreditStressBondRatings: {
      url: 'reference-data/v1/credit-stress-bond-rating',
      dataPath: '$',
    },
  },
  StaticDataCreditStressBondRating: {
    modified: false,
  },
  AnzRatingTypeSystemOptions: {
    text: '$.value',
  },
  CurrencyOptions: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'anzRatingTypeSystem.text',
    title: 'Rating',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    defaultSortColumn: true,
  },
  {
    field: 'daysToMaturity',
    title: 'Term',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
  },
  {
    field: 'Currency.text',
    title: 'Currency',
    filter: 'text',
    typeOf: 'string',
    width: '110px',
  },
  {
    field: 'longStress',
    title: 'Long Stress',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'shortStress',
    title: 'Short Stress',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:21.040+0000',
    },
    longStress: 27,
    shortStress: 27,
    daysToMaturity: '10Y',
    anzRatingTypeSystem: {
      id: 739,
      text: 'AAA',
    },
    Currency: {
      id: 1,
      text: 'AUD',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'clalith',
      time: '2016-08-18T05:12:35.327+0000',
    },
    longStress: 90,
    shortStress: 90,
    daysToMaturity: '10Y',
    anzRatingTypeSystem: {
      id: 739,
      text: 'AAA',
    },
    Currency: {
      id: 2,
      text: 'CAD',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'clalith',
      time: '2016-08-18T05:12:35.327+0000',
    },
    longStress: 90,
    shortStress: 90,
    daysToMaturity: '10Y',
    anzRatingTypeSystem: {
      id: 739,
      text: 'AAA',
    },
    Currency: {
      id: 5,
      text: 'CNY',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'clalith',
      time: '2016-08-18T05:12:35.327+0000',
    },
    longStress: 36,
    shortStress: 36,
    daysToMaturity: '10Y',
    anzRatingTypeSystem: {
      id: 739,
      text: 'AAA',
    },
    Currency: {
      id: 7,
      text: 'EUR',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'clalith',
      time: '2016-08-18T05:12:35.327+0000',
    },
    longStress: 90,
    shortStress: 90,
    daysToMaturity: '10Y',
    anzRatingTypeSystem: {
      id: 739,
      text: 'AAA',
    },
    Currency: {
      id: 9,
      text: 'GBP',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'clalith',
      time: '2016-08-18T05:12:35.327+0000',
    },
    longStress: 90,
    shortStress: 90,
    daysToMaturity: '10Y',
    anzRatingTypeSystem: {
      id: 739,
      text: 'AAA',
    },
    Currency: {
      id: 13,
      text: 'HKD',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'clalith',
      time: '2016-08-18T05:12:35.327+0000',
    },
    longStress: 90,
    shortStress: 90,
    daysToMaturity: '10Y',
    anzRatingTypeSystem: {
      id: 739,
      text: 'AAA',
    },
    Currency: {
      id: 15,
      text: 'IDR',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'clalith',
      time: '2016-08-18T05:12:35.327+0000',
    },
    longStress: 90,
    shortStress: 90,
    daysToMaturity: '10Y',
    anzRatingTypeSystem: {
      id: 739,
      text: 'AAA',
    },
    Currency: {
      id: 17,
      text: 'INR',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

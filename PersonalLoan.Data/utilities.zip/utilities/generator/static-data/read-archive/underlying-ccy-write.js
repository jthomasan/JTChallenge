// Type
const type = 'Underlying - CCY';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataUnderlyingCCY';
const selectors = [
  {
    name: 'CCYFamilyGroup',
    title: 'CCY Family Group',
    query: `
{
  CCYFamilyGroup {
    id
    text
  }
}
`,
    schemaQuery: 'CCYFamilyGroup: [CCYFamilyFXOTypeSystemOption]',
    apiMappings: {
      Query: {
        CCYFamilyGroup: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1063)]',
        },
      },
    },
    mockData: [
      {
        id: 147,
        text: 'Gold SGE',
      },
      {
        id: 148,
        text: 'JPY',
      },
      {
        id: 149,
        text: 'Other',
      },
    ],
  },
  {
    name: 'CCYGroupType',
    title: 'CCY Group',
    query: `
{
  CCYGroupType {
    id
    text
  }
}
`,
    schemaQuery: 'CCYGroupType: [CCYGroupTypeSystemOption]',
    apiMappings: {
      Query: {
        CCYGroupType: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1064)]',
        },
      },
    },
    mockData: [
      {
        id: 154,
        text: 'ALL CCYs',
      },
      {
        id: 155,
        text: 'Gold CCYs',
      },
    ],
  },
  {
    name: 'CCYCdsDeliverableType',
    title: 'CCY Group',
    query: `
{
  CCYCdsDeliverableType {
    id
    text
  }
}
`,
    schemaQuery: 'CCYCdsDeliverableType: [CCYCdsDeliverableTypeSystemOption]',
    apiMappings: {
      Query: {
        CCYCdsDeliverableType: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1056)]',
        },
      },
    },
    mockData: [
      {
        id: 1283,
        text: 'Domestic',
      },
      {
        id: 1284,
        text: 'Specified',
      },
    ],
  },
  {
    name: 'CurveList',
    title: 'Curve',
    query: `
{
  CurveList {
    id
    text
  }
}
`,
    schemaQuery: 'CurveList: [CurveListOption]',
    apiMappings: {
      Query: {
        CurveList: {
          url: 'reference-data/v1/curve',
          dataPath: '$',
        },
      },
      CurveListOption: {
        id: '$.dimCurveID',
        text: '$.curve',
      },
    },
    mockData: [
      {
        id: 1283,
        text: 'Domestic',
      },
      {
        id: 1284,
        text: 'Specified',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID!
    name: String
    offShore: String
    isMajor: Boolean
    isISO: Boolean
    ccyGroupTypeSystem: InputOptionType
    ccyFamilyFXOTypeSystem: InputOptionType
    ccyCdsDeliverableTypeSystem: InputOptionType
    Curve: InputOptionType
    isActive: Boolean
    description: String
    comment: String
  }
  
  type CurveListOption {
    id: ID
    text: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/currency-with-attributes',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        name: '{args.name}',
        offShore: '{args.offShore}',
        isMajor: '{args.isMajor}',
        isISO: '{args.isISO}',
        ccyGroupTypeSystem: { id: '{args.ccyGroupTypeSystem.id}' },
        ccyFamilyFXOTypeSystem: { id: '{args.ccyFamilyFXOTypeSystem.id}' },
        ccyCdsDeliverableTypeSystem: {
          id: '{args.ccyCdsDeliverableTypeSystem}',
        },
        Curve: { id: '{args.Curve.id}' },
        isActive: '{args.isActive}',
        description: '{args.description}',
        comment: '{args.comment}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'name',
    title: 'Underlying - CCY',
    filter: 'text',
    width: '150px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
      isUnique: true,
    },
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'offShore',
    title: 'OffShore',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'isISO',
    title: 'Is ISO',
    filter: 'boolean',
    width: '100px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'isMajor',
    title: 'Is Major',
    filter: 'boolean',
    width: '100px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'ccyFamilyFXOTypeSystem.text',
    title: 'Grp: CCY family FXO',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CCYFamilyGroup',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'ccyGroupTypeSystem.text',
    title: 'Grp: CCY Group',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CCYGroupType',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'ccyCdsDeliverableTypeSystem.text',
    title: 'Grp: CCY CDS Deliverable',
    filter: 'text',
    width: '180px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CCYCdsDeliverableType',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'Curve.text',
    title: 'Curve',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CurveList',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    width: '180px',
    editable: false,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

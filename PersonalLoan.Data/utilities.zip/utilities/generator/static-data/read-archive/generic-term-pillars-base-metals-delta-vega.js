// Category
const category = 'Tenor Buckets';

// Type
const type = 'Generic Term Pillars - Base Metals Delta & Vega';

// GQL Schema
const schemaQuery =
  'StaticDataGenericTermPillarsBaseMetalsDeltaVegas: [StaticDataGenericTermPillarsBaseMetalsDeltaVega]';
const schemaType = `
  type StaticDataGenericTermPillarsBaseMetalsDeltaVega {
    modified: Boolean!
    termUnit: Int!
    net1y3mPlus: String!
    net2y3mPlus: String!
    net1m: String!
    net10y3m: String!
    net5m: String!
    net3m: String!
    net9m: String!
    net9y3m: String!
    net1y9m: String!
    net5y3m: String!
    net2y: String!
    term: String!
    net7y3m: String!
    net1y3m: String!
    net3y3m: String!
    net2m: String!
    net6m: String!
    net4m: String!
    net1m_1y3m: String!
    net1y4m_2y3m: String!
    net1y: String!
    net6y3m: String!
    net2y3m: String!
    net8y3m: String!
    net1y6m: String!
    net4y3m: String!
  }`;

// Query
const queryName = 'StaticDataGenericTermPillarsBaseMetalsDeltaVegas';
const query = `
{
  StaticDataGenericTermPillarsBaseMetalsDeltaVegas {
    modified
    term
    termUnit
    net1m
    net2m
    net3m
    net4m
    net5m
    net6m
    net9m
    net1y
    net1y3m
    net1y6m
    net1y9m
    net2y
    net2y3m
    net3y3m
    net4y3m
    net5y3m
    net6y3m
    net7y3m
    net8y3m
    net9y3m
    net10y3m
    net1m_1y3m
    net1y3mPlus
    net1y4m_2y3m
    net2y3mPlus
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataGenericTermPillarsBaseMetalsDeltaVegas: {
      url: 'reference-data/v1/bucket-gen-pillar-base-metals',
      dataPath: '$',
    },
  },
  StaticDataGenericTermPillarsBaseMetalsDeltaVega: {
    modified: false,
    termUnit: '$.term',
    net1y3mPlus: {
      dataPath: '$.net1y3mPlus',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net2y3mPlus: {
      dataPath: '$.net2y3mPlus',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1m: {
      dataPath: '$.net1m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net10y3m: {
      dataPath: '$.net10y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net5m: {
      dataPath: '$.net5m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net3m: {
      dataPath: '$.net3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net9m: {
      dataPath: '$.net9m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net9y3m: {
      dataPath: '$.net9y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1y9m: {
      dataPath: '$.net1y9m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net5y3m: {
      dataPath: '$.net5y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net2y: {
      dataPath: '$.net2y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net7y3m: {
      dataPath: '$.net7y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1y3m: {
      dataPath: '$.net1y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net3y3m: {
      dataPath: '$.net3y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net2m: {
      dataPath: '$.net2m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net6m: {
      dataPath: '$.net6m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net4m: {
      dataPath: '$.net4m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1m_1y3m: {
      dataPath: '$.net1m_1y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1y4m_2y3m: {
      dataPath: '$.net1y4m_2y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1y: {
      dataPath: '$.net1y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net6y3m: {
      dataPath: '$.net6y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net2y3m: {
      dataPath: '$.net2y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net8y3m: {
      dataPath: '$.net8y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1y6m: {
      dataPath: '$.net1y6m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net4y3m: {
      dataPath: '$.net4y3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net1m',
    title: 'Net1m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net2m',
    title: 'Net2m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net4m',
    title: 'Net4m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net5m',
    title: 'Net5m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net6m',
    title: 'Net6m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net9m',
    title: 'Net9m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1y',
    title: 'Net1y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1y3m',
    title: 'Net1y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1y6m',
    title: 'Net1y6m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1y9m',
    title: 'Net1y9m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net2y',
    title: 'Net2y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net2y3m',
    title: 'Net2y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3y3m',
    title: 'Net3y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net4y3m',
    title: 'Net4y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net5y3m',
    title: 'Net5y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net6y3m',
    title: 'Net6y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net7y3m',
    title: 'Net7y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net8y3m',
    title: 'Net8y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net9y3m',
    title: 'Net9y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net10y3m',
    title: 'Net10y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1m_1y3m',
    title: 'Net1m_1y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'net1y3mPlus',
    title: 'Net1y3mPlus',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'net1y4m_2y3m',
    title: 'Net1y4m_2y3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'net2y3mPlus',
    title: 'Net2y3mPlus',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net1y3mPlus: '0',
    net2y3mPlus: '0',
    net1m: '100',
    net10y3m: '0',
    net5m: '0',
    net3m: '0',
    net9m: '0',
    net9y3m: '0',
    net1y9m: '0',
    net5y3m: '0',
    net2y: '0',
    termUnit: 1,
    term: 'c1',
    net7y3m: '0',
    net1y3m: '0',
    net3y3m: '0',
    net2m: '0',
    net6m: '0',
    net4m: '0',
    net1m_1y3m: '100',
    net1y4m_2y3m: '0',
    net1y: '0',
    net6y3m: '0',
    net2y3m: '0',
    net8y3m: '0',
    net1y6m: '0',
    net4y3m: '0',
  },
  {
    modified: false,
    net1y3mPlus: '0',
    net2y3mPlus: '0',
    net1m: '0',
    net10y3m: '0',
    net5m: '0',
    net3m: '0',
    net9m: '0',
    net9y3m: '0',
    net1y9m: '0',
    net5y3m: '0',
    net2y: '0',
    termUnit: 10,
    term: 'c10',
    net7y3m: '0',
    net1y3m: '0',
    net3y3m: '0',
    net2m: '0',
    net6m: '0',
    net4m: '0',
    net1m_1y3m: '100',
    net1y4m_2y3m: '0',
    net1y: '100',
    net6y3m: '0',
    net2y3m: '0',
    net8y3m: '0',
    net1y6m: '0',
    net4y3m: '0',
  },
  {
    modified: false,
    net1y3mPlus: '100',
    net2y3mPlus: '100',
    net1m: '0',
    net10y3m: '0',
    net5m: '0',
    net3m: '0',
    net9m: '0',
    net9y3m: '100',
    net1y9m: '0',
    net5y3m: '0',
    net2y: '0',
    termUnit: 100,
    term: 'c100',
    net7y3m: '0',
    net1y3m: '0',
    net3y3m: '0',
    net2m: '0',
    net6m: '0',
    net4m: '0',
    net1m_1y3m: '0',
    net1y4m_2y3m: '0',
    net1y: '0',
    net6y3m: '0',
    net2y3m: '0',
    net8y3m: '0',
    net1y6m: '0',
    net4y3m: '0',
  },
  {
    modified: false,
    net1y3mPlus: '100',
    net2y3mPlus: '100',
    net1m: '0',
    net10y3m: '0',
    net5m: '0',
    net3m: '0',
    net9m: '0',
    net9y3m: '100',
    net1y9m: '0',
    net5y3m: '0',
    net2y: '0',
    termUnit: 101,
    term: 'c101',
    net7y3m: '0',
    net1y3m: '0',
    net3y3m: '0',
    net2m: '0',
    net6m: '0',
    net4m: '0',
    net1m_1y3m: '0',
    net1y4m_2y3m: '0',
    net1y: '0',
    net6y3m: '0',
    net2y3m: '0',
    net8y3m: '0',
    net1y6m: '0',
    net4y3m: '0',
  },
  {
    modified: false,
    net1y3mPlus: '100',
    net2y3mPlus: '100',
    net1m: '0',
    net10y3m: '0',
    net5m: '0',
    net3m: '0',
    net9m: '0',
    net9y3m: '100',
    net1y9m: '0',
    net5y3m: '0',
    net2y: '0',
    termUnit: 102,
    term: 'c102',
    net7y3m: '0',
    net1y3m: '0',
    net3y3m: '0',
    net2m: '0',
    net6m: '0',
    net4m: '0',
    net1m_1y3m: '0',
    net1y4m_2y3m: '0',
    net1y: '0',
    net6y3m: '0',
    net2y3m: '0',
    net8y3m: '0',
    net1y6m: '0',
    net4y3m: '0',
  },
  {
    modified: false,
    net1y3mPlus: '100',
    net2y3mPlus: '100',
    net1m: '0',
    net10y3m: '0',
    net5m: '0',
    net3m: '0',
    net9m: '0',
    net9y3m: '100',
    net1y9m: '0',
    net5y3m: '0',
    net2y: '0',
    termUnit: 103,
    term: 'c103',
    net7y3m: '0',
    net1y3m: '0',
    net3y3m: '0',
    net2m: '0',
    net6m: '0',
    net4m: '0',
    net1m_1y3m: '0',
    net1y4m_2y3m: '0',
    net1y: '0',
    net6y3m: '0',
    net2y3m: '0',
    net8y3m: '0',
    net1y6m: '0',
    net4y3m: '0',
  },
  {
    modified: false,
    net1y3mPlus: '100',
    net2y3mPlus: '100',
    net1m: '0',
    net10y3m: '0',
    net5m: '0',
    net3m: '0',
    net9m: '0',
    net9y3m: '100',
    net1y9m: '0',
    net5y3m: '0',
    net2y: '0',
    termUnit: 104,
    term: 'c104',
    net7y3m: '0',
    net1y3m: '0',
    net3y3m: '0',
    net2m: '0',
    net6m: '0',
    net4m: '0',
    net1m_1y3m: '0',
    net1y4m_2y3m: '0',
    net1y: '0',
    net6y3m: '0',
    net2y3m: '0',
    net8y3m: '0',
    net1y6m: '0',
    net4y3m: '0',
  },
  {
    modified: false,
    net1y3mPlus: '100',
    net2y3mPlus: '100',
    net1m: '0',
    net10y3m: '0',
    net5m: '0',
    net3m: '0',
    net9m: '0',
    net9y3m: '100',
    net1y9m: '0',
    net5y3m: '0',
    net2y: '0',
    termUnit: 105,
    term: 'c105',
    net7y3m: '0',
    net1y3m: '0',
    net3y3m: '0',
    net2m: '0',
    net6m: '0',
    net4m: '0',
    net1m_1y3m: '0',
    net1y4m_2y3m: '0',
    net1y: '0',
    net6y3m: '0',
    net2y3m: '0',
    net8y3m: '0',
    net1y6m: '0',
    net4y3m: '0',
  },
  {
    modified: false,
    net1y3mPlus: '100',
    net2y3mPlus: '100',
    net1m: '0',
    net10y3m: '0',
    net5m: '0',
    net3m: '0',
    net9m: '0',
    net9y3m: '100',
    net1y9m: '0',
    net5y3m: '0',
    net2y: '0',
    termUnit: 106,
    term: 'c106',
    net7y3m: '0',
    net1y3m: '0',
    net3y3m: '0',
    net2m: '0',
    net6m: '0',
    net4m: '0',
    net1m_1y3m: '0',
    net1y4m_2y3m: '0',
    net1y: '0',
    net6y3m: '0',
    net2y3m: '0',
    net8y3m: '0',
    net1y6m: '0',
    net4y3m: '0',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Credit Stress';

// Type
const type = 'Credit Stress - CDS Rating';

// GQL Schema
const schemaQuery =
  'StaticDataCreditStressCDSRatings: [StaticDataCreditStressCDSRating]';
const schemaType = `
  type StaticDataCreditStressCDSRating {
    modified: Boolean!
    anzRatingTypeSystem: AnzRatingTypeSystemOptions!
    longStress: Int!
    shortStress: Int!
    isActive: Boolean!
    added: Added
  }
`;

// Query
const queryName = 'StaticDataCreditStressCDSRatings';
const query = `
{
  StaticDataCreditStressCDSRatings {
    modified
    anzRatingTypeSystem {
      id
      text
    }
    longStress
    shortStress
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCreditStressCDSRatings: {
      url: 'reference-data/v1/credit-stress-cdsratings',
      dataPath: '$',
    },
  },
  StaticDataCreditStressCDSRating: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'anzRatingTypeSystem.text',
    title: 'Rating',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    defaultSortColumn: true,
  },
  {
    field: 'longStress',
    title: 'Long Stress',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'shortStress',
    title: 'Short Stress',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.270+0000',
    },
    longStress: 100,
    shortStress: 100,
    anzRatingTypeSystem: {
      id: 739,
      text: 'AAA',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.270+0000',
    },
    longStress: 100,
    shortStress: 100,
    anzRatingTypeSystem: {
      id: 740,
      text: 'AA',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.270+0000',
    },
    longStress: 200,
    shortStress: 200,
    anzRatingTypeSystem: {
      id: 741,
      text: 'A',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.270+0000',
    },
    longStress: 350,
    shortStress: 350,
    anzRatingTypeSystem: {
      id: 742,
      text: 'BBB',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.270+0000',
    },
    longStress: 350,
    shortStress: 350,
    anzRatingTypeSystem: {
      id: 743,
      text: 'BB',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.270+0000',
    },
    longStress: 800,
    shortStress: 800,
    anzRatingTypeSystem: {
      id: 744,
      text: 'B',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.270+0000',
    },
    longStress: 800,
    shortStress: 800,
    anzRatingTypeSystem: {
      id: 745,
      text: 'CCC',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.270+0000',
    },
    longStress: 800,
    shortStress: 800,
    anzRatingTypeSystem: {
      id: 746,
      text: 'N/R',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Type
const type = 'Haircut Reference';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataHaircutReference';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    rating: String
    counterpartyCcr: String
    counterpartySector: String
    haircut: Float
    maturityBucket: String
    tier: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/haircut-references',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        rating: '{args.rating}',
        counterpartyCcr: '{args.counterpartyCcr}',
        counterpartySector: '{args.counterpartySector}',
        haircut: '{args.haircut}',
        maturityBucket: '{args.maturityBucket}',
        tier: '{args.tier}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = true;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'tier',
    title: 'Tier',
    filter: 'text',
    width: '120px',
    defaultSortColumn: true,
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
    },
  },
  {
    field: 'counterpartySector',
    title: 'Counterparty Sector',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'counterpartyCcr',
    title: 'Counterparty Ccr',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'rating',
    title: 'Rating',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'maturityBucket',
    title: 'MaturityBucket',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'haircut',
    title: 'Haircut',
    filter: 'numeric',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

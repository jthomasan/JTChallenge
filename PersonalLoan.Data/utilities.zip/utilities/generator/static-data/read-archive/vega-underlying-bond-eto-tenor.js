// Category
const category = "Tenor Buckets";

// Type
const type = "Vega Option Expiry Net Buckets - Swaption / ETOs";

// GQL Schema
const schemaQuery =
  "StaticDataVegaOptionExpiryNetBucktsSwaptionEtos: [StaticDataVegaOptionExpiryNetBucktsSwaptionEtoType]";
const schemaType = `
  type StaticDataVegaOptionExpiryNetBucktsSwaptionEtoType {
    modified: Boolean!
    net10y: String!
    net30yPlus: String!
    net20y: String!
    net1y: String!
    net3m: String!
    termUnit: Int!
    term: String!
    net20yPlus: String!
    net3y: String!
  }`;

// Query
const queryName = "StaticDataVegaOptionExpiryNetBucktsSwaptionEtos";
const query = `
{
  StaticDataVegaOptionExpiryNetBucktsSwaptionEtos {
    modified
    net10y
    net30yPlus
    net20y
    net1y
    net3m
    term
    termUnit
    net20yPlus
    net3y
  } 
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataVegaOptionExpiryNetBucktsSwaptionEtos: {
      url: "reference-data/v1/bucket-option-vega-swaption-eto",
      dataPath: "$",
    },
  },
  StaticDataVegaOptionExpiryNetBucktsSwaptionEtoType: {
    modified: false,
    termUnit: "$.term",
    net3m: {
      dataPath: "$.net3m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1y: {
      dataPath: "$.net1y",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net3y: {
      dataPath: "$.net3y",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net10y: {
      dataPath: "$.net10y",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net20y: {
      dataPath: "$.net20y",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net20yPlus: {
      dataPath: "$.net20yPlus",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net30yPlus: {
      dataPath: "$.net30yPlus",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "termUnit",
    title: "Days to Maturity",
    filter: "text",
    typeOf: "string",
    width: "150px",
    defaultSortColumn: true,
    cell: "GridCustomCell",
    extras: {
      displayField: "term",
    },
  },
  {
    field: "net3m",
    title: "Net3m",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net1y",
    title: "Net1y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net3y",
    title: "Net3y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net10y",
    title: "Net10y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net20y",
    title: "Net20y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net20yPlus",
    title: "Net20yPlus",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net30yPlus",
    title: "Net30yPlus",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net10y: "100",
    net30yPlus: "0",
    net20y: "0",
    net1y: "0",
    net3m: "0",
    term: "10y",
    termUnit: 3650,
    net20yPlus: "0",
    net3y: "0",
  },
  {
    modified: false,
    net10y: "50",
    net30yPlus: "0",
    net20y: "50",
    net1y: "0",
    net3m: "0",
    term: "15y",
    termUnit: 5475,
    net20yPlus: "50",
    net3y: "0",
  },
  {
    modified: false,
    net10y: "0",
    net30yPlus: "0",
    net20y: "0",
    net1y: "0",
    net3m: "100",
    term: "1m",
    termUnit: 30,
    net20yPlus: "0",
    net3y: "0",
  },
  {
    modified: false,
    net10y: "0",
    net30yPlus: "0",
    net20y: "0",
    net1y: "100",
    net3m: "0",
    term: "1y",
    termUnit: 365,
    net20yPlus: "0",
    net3y: "0",
  },
  {
    modified: false,
    net10y: "0",
    net30yPlus: "0",
    net20y: "100",
    net1y: "0",
    net3m: "0",
    term: "20y",
    termUnit: 7300,
    net20yPlus: "100",
    net3y: "0",
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Limits';

// Type
const type = 'Dynamic Limit Thresholds';

// GQL Schema
const schemaQuery =
  'StaticDataDynamicLimitThresholds: [StaticDataDynamicLimitThreshold]';
const schemaType = `
  type StaticDataDynamicLimitThreshold {
    id: ID!
    modified: Boolean!
    isin: String!
    percentageLong: String
    percentageShort: String
    expiryDate: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataDynamicLimitThresholds';
const query = `
{
  StaticDataDynamicLimitThresholds {
    id
    modified
    isin
    percentageLong
    percentageShort
    expiryDate
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataDynamicLimitThresholds: {
      url: 'limits/v1/dynamic-limit-threshold',
      dataPath: '$',
    },
  },
  StaticDataDynamicLimitThreshold: {
    modified: false,
    id: "$.dynamicLimitThreshold",
    isActive: "$.active",
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'isin',
    title: 'ISIN',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    defaultSortColumn: true,
  },
  {
    field: 'percentageLong',
    title: 'PercentageLong',
    filter: 'text',
    typeOf: 'string',
    width: '180px',
  },
  {
    field: 'percentageShort',
    title: 'PercentageShort',
    filter: 'text',
    typeOf: 'string',
    width: '180px',
  },
    {
    field: 'expiryDate',
    title: 'Expiry Date',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

// Mock Data
const mockData = [
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

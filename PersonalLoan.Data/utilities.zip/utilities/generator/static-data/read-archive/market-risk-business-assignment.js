// Category
const category = 'Limits';

// Type
const type = 'Market Risk Business Assignment';

// GQL Schema
const schemaQuery =
  'MarketRiskBusinessAssignmentMappings: [MarketRiskBusinessAssignmentMapping]';
const schemaType = `
  type MarketRiskBusinessAssignmentMapping {
    id: ID!
    modified: Boolean!
    marketRiskBusiness: MarketRiskBusiness
    userId: String
    receiveNotifications: Boolean
    isActive: Boolean!
    added: Added!
  }
  
  type MarketRiskBusiness{
    id
    text
  }
  `;

// Query
const queryName = 'MarketRiskBusinessAssignmentMappings';
const query = `
{
  MarketRiskBusinessAssignmentMappings {
    id
    modified
    marketRiskBusiness{
      id
      text
    }
    userId
    receiveNotifications
    isActive
    added{
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    MarketRiskBusinessAssignmentMappings: {
      url: 'limits/v1/limit-market-risk-business-management',
      dataPath: '$',
    },
  },
  MarketRiskBusinessAssignmentMapping: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'marketRiskBusiness.text',
    title: 'Market Risk Business',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'userId',
    title: 'User',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'marketRiskBusiness.text',
    title: 'Receive Notifications',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '150px',
    cell: 'GridCheckboxCell',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

// Mock Data
const mockData = [
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

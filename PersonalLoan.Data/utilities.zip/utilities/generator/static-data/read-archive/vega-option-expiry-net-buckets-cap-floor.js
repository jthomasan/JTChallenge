// Category
const category = 'Tenor Buckets';

// Type
const type = 'Vega Option Expiry Net Buckets - Cap/Floor';

// GQL Schema
const schemaQuery =
  'StaticDataVegaOptionExpiryNetBucketsCapFloorList: [StaticDataVegaOptionExpiryNetBucketsCapFloor]';
const schemaType = `
  type StaticDataVegaOptionExpiryNetBucketsCapFloor {
    modified: Boolean!
    term: ID!
    termUnit: Int!
    net3m: String!
    net1y: String!
    net3y: String!
    net10y: String!
    net20y: String!
  }`;

// Query
const queryName = 'StaticDataVegaOptionExpiryNetBucketsCapFloorList';
const query = `
{
  StaticDataVegaOptionExpiryNetBucketsCapFloorList {
    modified
    term
    termUnit
    net3m
    net1y
    net3y
    net10y
    net20y
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataVegaOptionExpiryNetBucketsCapFloorList: {
      url: 'reference-data/v1/bucket-option-vega-cap-flr',
      dataPath: '$',
    },
  },
  StaticDataVegaOptionExpiryNetBucketsCapFloor: {
    modified: false,
    termUnit: '$.term',
    net3m: {
      dataPath: '$.net3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1y: {
      dataPath: '$.net1y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net3y: {
      dataPath: '$.net3y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net10y: {
      dataPath: '$.net10y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net20y: {
      dataPath: '$.net20y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1y',
    title: 'Net1y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3y',
    title: 'Net3y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net10y',
    title: 'Net10y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net20y',
    title: 'Net20y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net10y: '100',
    net20y: '0',
    net1y: '0',
    net3m: '0',
    term: '10y',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '50',
    net20y: '50',
    net1y: '0',
    net3m: '0',
    term: '15y',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net1y: '0',
    net3m: '100',
    term: '1m',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net1y: '100',
    net3m: '0',
    term: '1y',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net1y: '87.5',
    net3m: '0',
    term: '1y3m',
    net3y: '12.5',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net1y: '75',
    net3m: '0',
    term: '1y6m',
    net3y: '25',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net1y: '62.5',
    net3m: '0',
    term: '1y9m',
    net3y: '37.5',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '100',
    net1y: '0',
    net3m: '0',
    term: '20y',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '100',
    net1y: '0',
    net3m: '0',
    term: '25y',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net1y: '0',
    net3m: '100',
    term: '2d',
    net3y: '0',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

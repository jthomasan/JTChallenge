// Category
const category = 'Credit Ratings';

// Type
const type = 'Short Term Credit Rating';

// GQL Schema
const schemaQuery =
  'StaticDataShortTermCreditRatings: [StaticDataShortTermCreditRating]';
const schemaType = `
  type StaticDataShortTermCreditRating {
    id: ID!
    modified: Boolean!
    rating: String!
    comment: String
    agency: String!
    ratingBandTypeSystem: RatingBandTypeSystemOption!
    added: Added!
  }
  
  type RatingBandTypeSystemOption {
    id: ID
    text: String
  }`;

// Query
const queryName = 'StaticDataShortTermCreditRatings';
const query = `
{
  StaticDataShortTermCreditRatings {
    id
    modified
    rating
    comment
    agency
    ratingBandTypeSystem {
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataShortTermCreditRatings: {
      url: 'reference-data/v1/short-term-credit-rating',
      dataPath: '$',
    },
  },
  StaticDataShortTermCreditRating: {
    modified: false,
  },
  RatingBandTypeSystemOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'rating',
    title: 'Rating',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'agency',
    title: 'Agency',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'ratingBandTypeSystem.text',
    title: 'ST Rating Band',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    comment: 'test',
    added: {
      by: 'foonga',
      time: '2012-05-02T07:09:52.067+0000',
    },
    agency: 'SNP',
    ratingBandTypeSystem: {
      id: 1190,
      text: 'A-1/P-1',
    },
    rating: 'A-1',
    id: 1,
  },
  {
    modified: false,
    comment: null,
    added: {
      by: 'foonga',
      time: '2012-05-02T06:27:08.210+0000',
    },
    agency: 'SNP',
    ratingBandTypeSystem: {
      id: 1191,
      text: 'A-2/P-2',
    },
    rating: 'A-2',
    id: 2,
  },
  {
    modified: false,
    comment: null,
    added: {
      by: 'foonga',
      time: '2012-05-02T06:27:08.210+0000',
    },
    agency: 'SNP',
    ratingBandTypeSystem: {
      id: 1192,
      text: 'A-3/P-3',
    },
    rating: 'A-3',
    id: 3,
  },
  {
    modified: false,
    comment: null,
    added: {
      by: 'foonga',
      time: '2012-05-02T06:27:08.210+0000',
    },
    agency: 'SNP',
    ratingBandTypeSystem: {
      id: 1193,
      text: 'Below A-3/P-3 or unrated',
    },
    rating: 'B',
    id: 4,
  },
  {
    modified: false,
    comment: null,
    added: {
      by: 'foonga',
      time: '2012-05-02T06:27:08.210+0000',
    },
    agency: 'SNP',
    ratingBandTypeSystem: {
      id: 1193,
      text: 'Below A-3/P-3 or unrated',
    },
    rating: 'C',
    id: 5,
  },
  {
    modified: false,
    comment: null,
    added: {
      by: 'foonga',
      time: '2012-05-02T06:27:08.210+0000',
    },
    agency: 'SNP',
    ratingBandTypeSystem: {
      id: 1193,
      text: 'Below A-3/P-3 or unrated',
    },
    rating: 'D',
    id: 6,
  },
  {
    modified: false,
    comment: null,
    added: {
      by: 'foonga',
      time: '2012-05-02T06:27:08.210+0000',
    },
    agency: 'MOODYS',
    ratingBandTypeSystem: {
      id: 1190,
      text: 'A-1/P-1',
    },
    rating: 'P-1',
    id: 7,
  },
  {
    modified: false,
    comment: null,
    added: {
      by: 'foonga',
      time: '2012-05-02T06:27:08.210+0000',
    },
    agency: 'MOODYS',
    ratingBandTypeSystem: {
      id: 1191,
      text: 'A-2/P-2',
    },
    rating: 'P-1/P-2',
    id: 8,
  },
  {
    modified: false,
    comment: null,
    added: {
      by: 'foonga',
      time: '2012-05-02T06:27:08.210+0000',
    },
    agency: 'MOODYS',
    ratingBandTypeSystem: {
      id: 1191,
      text: 'A-2/P-2',
    },
    rating: 'P-2',
    id: 9,
  },
  {
    modified: false,
    comment: null,
    added: {
      by: 'foonga',
      time: '2012-05-02T06:27:08.210+0000',
    },
    agency: 'MOODYS',
    ratingBandTypeSystem: {
      id: 1192,
      text: 'A-3/P-3',
    },
    rating: 'P-2/P-3',
    id: 10,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

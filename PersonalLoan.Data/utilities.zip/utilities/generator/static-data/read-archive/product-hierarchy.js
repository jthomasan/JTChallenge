// Category
const category = 'Ungrouped';

// Type
const type = 'Product Hierarchy';

// GQL Schema
const schemaQuery =
  'StaticDataProductHierarchies: [StaticDataProductHierarchy]';
const schemaType = `
  type StaticDataProductHierarchy {
    id: ID!
    modified: Boolean!
    description: String
    name: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataProductHierarchies';
const query = `
{
  StaticDataProductHierarchies {
    id
    modified
    description
    name
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataProductHierarchies: {
      url: 'reference-data/v1/product',
      dataPath: '$',
    },
  },
  StaticDataProductHierarchy: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    typeOf: 'string',
    width: '220px',
    defaultSortColumn: true,
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    typeOf: 'string',
    width: '300px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    added: {
      by: 'System',
      time: '2012-01-05T13:47:47.56',
    },
    name: 'COM.ASIAN',
    description: 'COM Asian',
    id: '1',
    isActive: true,
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2012-01-05T13:47:47.56',
    },
    name: 'COM.EFS',
    description: 'COM Exchange Future for Swap',
    id: '2',
    isActive: true,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

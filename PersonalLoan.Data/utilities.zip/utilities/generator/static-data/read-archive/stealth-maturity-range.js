// Category
const category = "Stealth";

// Type
const type = "Stealth Maturity Range";

// GQL Schema
const schemaQuery =
  "StaticDataStealthMaturityRanges: [StaticDataStealthMaturityRangeType]";
const schemaType = `
  type StaticDataStealthMaturityRangeType {
    id: ID!
    modified: Boolean!
    name: String!
    rangeFrom: Float!
    rangeTo: Float!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataStealthMaturityRanges";
const query = `
{
  StaticDataStealthMaturityRanges {
    id
    modified
    name
    rangeFrom
    rangeTo
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataStealthMaturityRanges: {
      url: "reference-data/v1/stealth-maturity-ranges",
      dataPath: "$",
    },
  },
  StaticDataStealthMaturityRangeType: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "name",
    title: "Name",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "rangeFrom",
    title: "From",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
    defaultSortColumn: true,
  },
  {
    field: "rangeTo",
    title: "To",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    isActive: true,
    added: {
      by: "mangalar",
      time: "2018-03-17T15:29:33.243+0000",
    },
    rangeFrom: 0,
    rangeTo: 30,
    name: "< 1m",
    id: 1,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "mangalar",
      time: "2018-03-17T15:29:33.243+0000",
    },
    rangeFrom: 31,
    rangeTo: 183,
    name: "1 to 6 months",
    id: 2,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "mangalar",
      time: "2018-03-17T15:29:33.243+0000",
    },
    rangeFrom: 184,
    rangeTo: 999999,
    name: ">6m",
    id: 3,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

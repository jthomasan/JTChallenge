// Category
const category = 'Repo';

// Type
const type = 'Bespoke Haircut';

// GQL Schema
const schemaQuery = 'StaticDataBespokeHaircuts: [StaticDataBespokeHaircut]';
const schemaType = `
  type StaticDataBespokeHaircut {
    id: ID
    modified: Boolean!
    type: String!
    issuerCountry: String!
    issuerName: String!
    variationToGuideline: Float!
    maxRepoTenor: String!
    razorCode: String!
    startDate: String!
    counterpartyName: String!
    minCollateralRating: String!
    approver: String!
    endDate: String!
    added: Added!
  }
`;

// Query
const queryName = 'StaticDataBespokeHaircuts';
const query = `
{
  StaticDataBespokeHaircuts {
    id
    modified
    counterpartyName
    razorCode
    approver
    startDate
    endDate
    minCollateralRating
    issuerCountry
    issuerName
    type
    maxRepoTenor
    variationToGuideline
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataBespokeHaircuts: {
      url: 'reference-data/v1/bespoke-haircut',
      dataPath: '$',
    },
  },
  StaticDataBespokeHaircut: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'razorCode',
    title: 'Razor Code',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'counterpartyName',
    title: 'Counterparty Name',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'approver',
    title: 'Approver',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'startDate',
    title: 'Start Date',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'endDate',
    title: 'End Date',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'minCollateralRating',
    title: 'Min Collateral Rating',
    filter: 'text',
    typeOf: 'string',
    width: '170px',
  },
  {
    field: 'issuerCountry',
    title: 'Issuer Country',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'issuerName',
    title: 'Issuer Name',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'type',
    title: 'Type',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'maxRepoTenor',
    title: 'Max Repo Tenor',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'variationToGuideline',
    title: 'Variation To Guideline',
    filter: 'numeric',
    typeOf: 'number',
    width: '170px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    type: 'Corp',
    id: 1,
    issuerCountry: 'AU',
    issuerName: 'CBA AU',
    variationToGuideline: -0.06,
    maxRepoTenor: '8',
    razorCode: 'SS-14305',
    startDate: '20180702',
    counterpartyName: 'SSB&T Repo 3',
    minCollateralRating: 'AA-',
    approver: 'Susanna Yeung',
    endDate: 'Ongoing',
    added: {
      by: 'bhatiaka',
      time: '2019-10-29T04:15:51.170+0000',
    },
  },
  {
    modified: false,
    type: 'Corp',
    id: 2,
    issuerCountry: 'AU',
    issuerName: 'CBA AU',
    variationToGuideline: -0.06,
    maxRepoTenor: '8',
    razorCode: 'SS-10510',
    startDate: '20180702',
    counterpartyName: 'SSB&T Repo 2',
    minCollateralRating: 'AA-',
    approver: 'Susanna Yeung',
    endDate: 'Ongoing',
    added: {
      by: 'bhatiaka',
      time: '2019-10-29T04:15:51.173+0000',
    },
  },
  {
    modified: false,
    type: 'Corp',
    id: 3,
    issuerCountry: 'AU',
    issuerName: 'CBA AU',
    variationToGuideline: -0.06,
    maxRepoTenor: '8',
    razorCode: 'SS-10608',
    startDate: '20180702',
    counterpartyName: 'SSB&T Repo 1',
    minCollateralRating: 'AA-',
    approver: 'Susanna Yeung',
    endDate: 'Ongoing',
    added: {
      by: 'bhatiaka',
      time: '2019-10-29T04:15:51.173+0000',
    },
  },
  {
    modified: false,
    type: 'Corp',
    id: 4,
    issuerCountry: 'AU',
    issuerName: 'NAB AU',
    variationToGuideline: -0.06,
    maxRepoTenor: '8',
    razorCode: 'SS-14305',
    startDate: '20180702',
    counterpartyName: 'SSB&T Repo 3',
    minCollateralRating: 'AA-',
    approver: 'Susanna Yeung',
    endDate: 'Ongoing',
    added: {
      by: 'yeungc4',
      time: '2019-09-16T01:33:52.987+0000',
    },
  },
  {
    modified: false,
    type: 'Corp',
    id: 5,
    issuerCountry: 'AU',
    issuerName: 'NAB AU',
    variationToGuideline: -0.06,
    maxRepoTenor: '8',
    razorCode: 'SS-10510',
    startDate: '20180702',
    counterpartyName: 'SSB&T Repo 2',
    minCollateralRating: 'AA-',
    approver: 'Susanna Yeung',
    endDate: 'Ongoing',
    added: {
      by: 'yeungc4',
      time: '2019-09-16T01:33:52.987+0000',
    },
  },
  {
    modified: false,
    type: 'Corp',
    id: 6,
    issuerCountry: 'AU',
    issuerName: 'NAB AU',
    variationToGuideline: -0.06,
    maxRepoTenor: '8',
    razorCode: 'SS-10608',
    startDate: '20180702',
    counterpartyName: 'SSB&T Repo 1',
    minCollateralRating: 'AA-',
    approver: 'Susanna Yeung',
    endDate: 'Ongoing',
    added: {
      by: 'yeungc4',
      time: '2019-09-16T01:33:52.987+0000',
    },
  },
  {
    modified: false,
    type: 'Corp',
    id: 7,
    issuerCountry: 'AU',
    issuerName: 'CBA AU',
    variationToGuideline: -0.06,
    maxRepoTenor: '8',
    razorCode: 'SS-14305',
    startDate: '20180702',
    counterpartyName: 'SSB&T Repo 3',
    minCollateralRating: 'AA-',
    approver: 'Susanna Yeung',
    endDate: 'Ongoing',
    added: {
      by: 'yeungc4',
      time: '2019-09-16T01:51:44.960+0000',
    },
  },
  {
    modified: false,
    type: 'Corp',
    id: 8,
    issuerCountry: 'AU',
    issuerName: 'CBA AU',
    variationToGuideline: -0.06,
    maxRepoTenor: '8',
    razorCode: 'SS-10510',
    startDate: '20180702',
    counterpartyName: 'SSB&T Repo 2',
    minCollateralRating: 'AA-',
    approver: 'Susanna Yeung',
    endDate: 'Ongoing',
    added: {
      by: 'yeungc4',
      time: '2019-09-16T01:51:44.960+0000',
    },
  },
  {
    modified: false,
    type: 'Corp',
    id: 9,
    issuerCountry: 'AU',
    issuerName: 'CBA AU',
    variationToGuideline: -0.06,
    maxRepoTenor: '8',
    razorCode: 'SS-10608',
    startDate: '20180702',
    counterpartyName: 'SSB&T Repo 1',
    minCollateralRating: 'AA-',
    approver: 'Susanna Yeung',
    endDate: 'Ongoing',
    added: {
      by: 'yeungc4',
      time: '2019-09-16T01:51:44.960+0000',
    },
  },
  {
    modified: false,
    type: 'Govt',
    id: 10,
    issuerCountry: 'AU',
    issuerName: 'ANY',
    variationToGuideline: -0.02,
    maxRepoTenor: '99',
    razorCode: 'CRINDEXPIRED',
    startDate: '20160106',
    counterpartyName: 'CREDIT INDUSTRIEL ET COMMERCIAL',
    minCollateralRating: 'AA',
    approver: 'Ashraf Hamed',
    endDate: 'Expired',
    added: {
      by: 'bhatiaka',
      time: '2019-10-29T04:15:51.173+0000',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

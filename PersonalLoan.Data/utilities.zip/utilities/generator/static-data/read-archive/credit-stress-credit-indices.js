// Category
const category = 'Credit Stress';

// Type
const type = 'Credit Stress - Credit Indices';

// GQL Schema
const schemaQuery =
  'StaticDataCreditStressCreditIndices: [StaticDataCreditStressCreditIndice]';
const schemaType = `
  type StaticDataCreditStressCreditIndice {
    modified: Boolean!
    cRIndexType: CRIndexTypeOptions!
    longStress: Int!
    shortStress: Int!
    isActive: Boolean!
    added: Added
  }

  type CRIndexTypeOptions {
    id: ID
    text: String
  }
`;

// Query
const queryName = 'StaticDataCreditStressCreditIndices';
const query = `
{
  StaticDataCreditStressCreditIndices {
    modified
    cRIndexType {
      id
      text
    }
    longStress
    shortStress
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCreditStressCreditIndices: {
      url: 'reference-data/v1/credit-stress-credit-indices',
      dataPath: '$',
    },
  },
  StaticDataCreditStressCreditIndice: {
    modified: false,
    cRIndexType: '$.CRIndexType',
  },
  CRIndexTypeOptions: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'cRIndexType.text',
    title: 'CR Index Type',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'longStress',
    title: 'Long Stress',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'shortStress',
    title: 'Short Stress',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    longStress: 35,
    shortStress: 156,
    cRIndexType: {
      id: 1202,
      text: 'ITraxx Asia ex-Japan IG',
    },
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.377+0000',
    },
  },
  {
    modified: false,
    longStress: 25,
    shortStress: 135,
    cRIndexType: {
      id: 1203,
      text: 'iTraxx Australia',
    },
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.377+0000',
    },
  },
  {
    modified: false,
    longStress: 10,
    shortStress: 15,
    cRIndexType: {
      id: 1204,
      text: 'CDX NA IG',
    },
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.377+0000',
    },
  },
  {
    modified: false,
    longStress: 0,
    shortStress: 0,
    cRIndexType: {
      id: 1205,
      text: 'iTraxx Europe HiVol',
    },
    isActive: true,
    added: {
      by: 'System',
      time: '2015-09-19T04:46:14.933+0000',
    },
  },
  {
    modified: false,
    longStress: 13,
    shortStress: 65,
    cRIndexType: {
      id: 1206,
      text: 'iTraxx Europe',
    },
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.377+0000',
    },
  },
  {
    modified: false,
    longStress: 20,
    shortStress: 80,
    cRIndexType: {
      id: 1207,
      text: 'iTraxx EUR Financial (Sub)',
    },
    isActive: true,
    added: {
      by: 'System',
      time: '2015-09-19T04:46:14.933+0000',
    },
  },
  {
    modified: false,
    longStress: 24,
    shortStress: 91,
    cRIndexType: {
      id: 1208,
      text: 'iTraxx EUR Financial (Senior)',
    },
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.377+0000',
    },
  },
  {
    modified: false,
    longStress: 53,
    shortStress: 266,
    cRIndexType: {
      id: 1209,
      text: 'iTraxx Europe Crossover',
    },
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.377+0000',
    },
  },
  {
    modified: false,
    longStress: 20,
    shortStress: 50,
    cRIndexType: {
      id: 1210,
      text: 'ITRAXX SOVX ASIA PACIFIC',
    },
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.377+0000',
    },
  },
  {
    modified: false,
    longStress: 15,
    shortStress: 45,
    cRIndexType: {
      id: 1211,
      text: 'iTraxx SovX WE',
    },
    isActive: true,
    added: {
      by: 'lintonsm',
      time: '2016-10-08T03:05:20.377+0000',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

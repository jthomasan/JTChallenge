// Category
const category = 'UAT Portfolio Configuration';

// Type
const type = 'UAT Portfolio Configuration';

// GQL Schema
const schemaQuery = 'StaticDataPortfolioConfigs: [StaticDataPortfolioConfig]';
const schemaType = `
  type StaticDataPortfolioConfig {
    id: ID!
    modified: Boolean!
    
    portfolio: PortfolioOption
    container: RiskContainerOption
    sources: [SourceSystemOption]
    officialSource: SourceSystemOption

    isActive: Boolean!
    added: Added!
  }

  type PortfolioOption {
    id: ID
    text: String
  }

  type RiskContainerOption {
    id: ID
    text: String
  }

  type SourceSystemOption {
    id: ID
    text: String
  }
`;

// Query
const queryName = 'StaticDataPortfolioConfigs';
const query = `
{
  StaticDataPortfolioConfigs {
    id
    modified
    portfolio {
      id
      text
    }
    container {
      id
      text
    }
    sources {
      id
      text
    }
    officialSource {
      id
      text
    }

    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataPortfolioConfigs: {
      url: 'reference-data/v1/portfolio-configs',
      dataPath: '$',
    },
  },
  StaticDataPortfolioConfig: {
    modified: false,
    officialSource: {
      dataPath: '$.officialSource',
      decorators: [
        {name: 'nullEmptyString'}
      ]
    },
    sources: {
      dataPath: '$.source',
      decorators: [
        {name: 'nullEmptyString'},
        {name: 'split', params: {separator: ','}}
      ]
    }
  },
  PortfolioOption: {
    id: '$.id',
    text: '$.value'
  },
  RiskContainerOption: {
    id: '$.id',
    text: '$.value'
  },
  SourceSystemOption: {
    id: '$',
    text: '$'
  }
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'portfolio.text',
    title: 'Portfolio',
    filter: 'text',
    width: '120px',
    defaultSortColumn: true,
    typeOf: 'string',
  },
  {
    field: 'container.text',
    title: 'Container',
    filter: 'text',
    width: '180px',
    defaultSortColumn: true,
    typeOf: 'string',
  },
  {
    field: 'sources',
    title: 'Source Systems',
    filter: 'text',
    width: '125px',
    typeOf: 'string',
    cell: 'GridMultiSelectCell',
  },
  {
    field: 'officialSource.text',
    title: 'Official Source',
    filter: 'text',
    width: '110px',
    typeOf: 'string',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

// Mock Data
const mockData = [
  {
    id: 1,
    modified: false,
    portfolio: {
      id: 1,
      text: 'A ARR OPT AU'
    },
    container: {
      id: 2,
      text: 'ACCRUED_INTEREST',
    },
    sources: [
      {
        id: 'Murex',
        text: 'Murex',
      },
      {
        id: 'QRM',
        text: 'QRM'
      }
    ],
    officialSource: {
      id: 'Murex',
      text: 'Murex',
    },
    
    isActive: true,
    added: {
      by: "foonga",
      time: "2012-04-10T02:56:52.003+0000",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

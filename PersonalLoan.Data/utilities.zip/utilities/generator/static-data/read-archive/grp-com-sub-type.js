// Category
const category = "Underlyings";

// Type
const type = "Grp:COM Sub-Type";

// GQL Schema
const schemaQuery = "StaticDataCOMSubTypes: [StaticDataCOMSubType]";
const schemaType = `
  type StaticDataCOMSubType {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataCOMSubTypes";
const query = `
{
  StaticDataCOMSubTypes {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCOMSubTypes: {
      url: "reference-data/type-system-parameters",
      dataPath: "$[?(@.system.id == 1008)]",
    },
  },
  StaticDataCOMSubType: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "value",
    title: "Value",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    id: 8,
    modified: false,
    description: null,
    value: "BASE METALS",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 9,
    modified: false,
    description: null,
    value: "Butane",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 10,
    modified: false,
    description: null,
    value: "CANOLA",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 11,
    modified: false,
    description: null,
    value: "COAL",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 12,
    modified: false,
    description: null,
    value: "COCOA",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 13,
    modified: false,
    description: null,
    value: "COFFEE",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 14,
    modified: false,
    description: null,
    value: "CORN",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

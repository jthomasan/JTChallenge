// Category
const category = 'Repo';

// Type
const type = 'Repo Typology Map';

// GQL Schema
const schemaQuery = 'StaticDataRepoTypologyMaps: [StaticDataRepoTypologyMap]';
const schemaType = `
  type StaticDataRepoTypologyMap {
    modified: Boolean!
    typology: String!
    mapValue: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataRepoTypologyMaps';
const query = `
{
  StaticDataRepoTypologyMaps {
    modified
    typology
    mapValue  
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataRepoTypologyMaps: {
      url: 'reference-data/v1/repo-typology-map',
      dataPath: '$',
    },
  },
  StaticDataRepoTypologyMap: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'typology',
    title: 'Typology',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'mapValue',
    title: 'Map Value',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    isActive: true,
    added: {
      by: 'system',
      time: '2015-09-19T04:46:14.380+0000',
    },
    typology: '.Vanilla',
    mapValue: 'Vanilla',
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'system',
      time: '2015-09-19T04:46:14.380+0000',
    },
    typology: '.VN_REPO',
    mapValue: 'Structured',
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'system',
      time: '2015-09-19T04:46:14.380+0000',
    },
    typology: 'z.Multi CC Rev Repo',
    mapValue: 'Structured',
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'system',
      time: '2015-09-19T04:46:14.380+0000',
    },
    typology: 'z.TriParty',
    mapValue: 'Vanilla',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

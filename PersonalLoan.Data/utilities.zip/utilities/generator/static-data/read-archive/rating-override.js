// Category
const category = 'Credit Ratings';

// Type
const type = 'Rating Override';

// GQL Schema
const schemaQuery = 'StaticDataRatingOverrides: [StaticDataRatingOverride]';
const schemaType = `
  type StaticDataRatingOverride {
    id: ID!
    modified: Boolean!
    agency: String!
    issuer: IssuerOption!
    creditRating: CreditRatingOption!
    isActive: Boolean!
    added: Added!
  }
  
  type CreditRatingOption {
    id: ID
    text: String
  }`;

// Query
const queryName = 'StaticDataRatingOverrides';
const query = `
{
  StaticDataRatingOverrides {
    id
    modified
    agency
    issuer {
      id
      text
    }
    creditRating {
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataRatingOverrides: {
      url: 'reference-data/v1/rating-override',
      dataPath: '$',
    },
  },
  StaticDataRatingOverride: {
    modified: false,
    issuer: '$.Issuer',
    creditRating: '$.CreditRating',
  },
  CreditRatingOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'issuer.text',
    title: 'Issuer',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'agency',
    title: 'Agency',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'creditRating.text',
    title: 'Rating',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    id: 1,
    modified: false,
    isActive: false,
    added: {
      by: 'System',
      time: '2015-06-20T03:53:38.237+0000',
    },
    agency: 'SNP',
    issuer: {
      id: 4964,
      text: '000030 KS',
    },
    creditRating: {
      id: 6,
      text: 'A',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

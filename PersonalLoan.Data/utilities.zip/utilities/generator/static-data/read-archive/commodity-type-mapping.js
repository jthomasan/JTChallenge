// Category
const category = 'Underlyings';

// Type
const type = 'Commodity Type Mapping';

// GQL Schema
const schemaQuery = 'StaticDataCommodityTypeMappings: [StaticDataCommodityTypeMapping]';
const schemaType = `
  type StaticDataCommodityTypeMapping {
    id: ID!
    modified: Boolean!
    added: Added!
    MXRkLabel1: String!
    MXRkLabel3: String!
    commodity: CommodityOption
  }
  
  type CommodityOption {
    id: ID
    text: String
  }
  `;

// Query
const queryName = 'StaticDataCommodityTypeMappings';
const query = `
{
  StaticDataCommodityTypeMappings {
    id
    modified
    MXRkLabel1
    MXRkLabel3
    commodity{
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCommodityTypeMappings: {
      url: 'reference-data/v1/commodity-code-map',
      dataPath: '$',
    },
  },
  StaticDataCommodityTypeMappings: {
    modified: false,
  },
  CommodityOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'MXRkLabel1',
    title: 'MX_RiskLabel1',
    filter: 'text',
    typeOf: 'string',
    width: '100px',
  },
  {
    field: 'MXRkLabel3',
    title: 'MX_RiskLabel3',
    filter: 'text',
    typeOf: 'string',
    width: '100px',
  },
  {
    field: 'commodity.text',
    title: 'Commodity Underlying Code',
    filter: 'text',
    typeOf: 'string',
    width: '100px',
    defaultSortColumn: true,
  },
  { 
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    id: 1,
    modified: false,
    added: {
      by: "foonga",
      time: "2012-04-03T07:35:30.447+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 1,
      value: "ACM"
    },
    MXRkLabel1: "56"
  },
  {
    id: 2,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 1,
      value: "ACM"
    },
    MXRkLabel1: "78"
  },
  {
    id: 3,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 15,
      value: "CNL"
    },
    MXRkLabel1: "25"
  },
  {
    id: 4,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 15,
      value: "CNL"
    },
    MXRkLabel1: "28"
  },
  {
    id: 5,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 12,
      value: "CCN"
    },
    MXRkLabel1: "19"
  },
  {
    id: 6,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 12,
      value: "CCN"
    },
    MXRkLabel1: "34"
  },
  {
    id: 7,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 70,
      value: "LCC"
    },
    MXRkLabel1: "9"
  },
  {
    id: 8,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 70,
      value: "LCC"
    },
    MXRkLabel1: "33"
  },
  {
    id: 9,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 67,
      value: "KCN"
    },
    MXRkLabel1: "20"
  },
  {
    id: 10,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 67,
      value: "KCN"
    },
    MXRkLabel1: "18"
  },
  {
    id: 11,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 72,
      value: "LKD"
    },
    MXRkLabel1: "10"
  },
  {
    id: 12,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 72,
      value: "LKD"
    },
    MXRkLabel1: "15"
  },
  {
    id: 13,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 18,
      value: "CRN"
    },
    MXRkLabel1: "1"
  },
  {
    id: 14,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 18,
      value: "CRN"
    },
    MXRkLabel1: "29"
  },
  {
    id: 15,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 16,
      value: "COT"
    },
    MXRkLabel1: "21"
  },
  {
    id: 16,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 16,
      value: "COT"
    },
    MXRkLabel1: "30"
  },
  {
    id: 17,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 2,
      value: "AFB"
    },
    MXRkLabel1: "57"
  },
  {
    id: 18,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 2,
      value: "AFB"
    },
    MXRkLabel1: "79"
  },
  {
    id: 19,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 17,
      value: "CPO"
    },
    MXRkLabel1: "54"
  },
  {
    id: 20,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 17,
      value: "CPO"
    },
    MXRkLabel1: "74"
  },
  {
    id: 21,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 68,
      value: "KPO"
    },
    MXRkLabel1: "53"
  },
  {
    id: 22,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 68,
      value: "KPO"
    },
    MXRkLabel1: "73"
  },
  {
    id: 23,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 86,
      value: "SBO"
    },
    MXRkLabel1: "4"
  },
  {
    id: 24,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 86,
      value: "SBO"
    },
    MXRkLabel1: "11"
  },
  {
    id: 25,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 87,
      value: "SOY"
    },
    MXRkLabel1: "2"
  },
  {
    id: 26,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 87,
      value: "SOY"
    },
    MXRkLabel1: "40"
  },
  {
    id: 27,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 89,
      value: "SSM"
    },
    MXRkLabel1: "3"
  },
  {
    id: 28,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 89,
      value: "SSM"
    },
    MXRkLabel1: "41"
  },
  {
    id: 29,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 64,
      value: "FCL"
    },
    MXRkLabel1: "128"
  },
  {
    id: 30,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 64,
      value: "FCL"
    },
    MXRkLabel1: "92"
  },
  {
    id: 31,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 9,
      value: "ASM"
    },
    MXRkLabel1: "55"
  },
  {
    id: 32,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 9,
      value: "ASM"
    },
    MXRkLabel1: "77"
  },
  {
    id: 33,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 90,
      value: "SU5"
    },
    MXRkLabel1: "11"
  },
  {
    id: 34,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 90,
      value: "SU5"
    },
    MXRkLabel1: "42"
  },
  {
    id: 35,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 91,
      value: "SUG"
    },
    MXRkLabel1: "22"
  },
  {
    id: 36,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 91,
      value: "SUG"
    },
    MXRkLabel1: "26"
  },
  {
    id: 37,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 10,
      value: "AWM"
    },
    MXRkLabel1: "47"
  },
  {
    id: 38,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 10,
      value: "AWM"
    },
    MXRkLabel1: "72"
  },
  {
    id: 39,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 11,
      value: "AWW"
    },
    MXRkLabel1: "95"
  },
  {
    id: 40,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 11,
      value: "AWW"
    },
    MXRkLabel1: "89"
  },
  {
    id: 41,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 19,
      value: "CWT"
    },
    MXRkLabel1: "5"
  },
  {
    id: 42,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 19,
      value: "CWT"
    },
    MXRkLabel1: "44"
  },
  {
    id: 43,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 65,
      value: "FMW"
    },
    MXRkLabel1: "130"
  },
  {
    id: 44,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 65,
      value: "FMW"
    },
    MXRkLabel1: "94"
  },
  {
    id: 45,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 69,
      value: "KWT"
    },
    MXRkLabel1: "8"
  },
  {
    id: 46,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 69,
      value: "KWT"
    },
    MXRkLabel1: "25"
  },
  {
    id: 47,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 71,
      value: "LFW"
    },
    MXRkLabel1: "129"
  },
  {
    id: 48,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 71,
      value: "LFW"
    },
    MXRkLabel1: "93"
  },
  {
    id: 49,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 78,
      value: "MWT"
    },
    MXRkLabel1: "18"
  },
  {
    id: 50,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 78,
      value: "MWT"
    },
    MXRkLabel1: "45"
  },
  {
    id: 51,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 73,
      value: "MAL"
    },
    MXRkLabel1: "12"
  },
  {
    id: 52,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 73,
      value: "MAL"
    },
    MXRkLabel1: "31"
  },
  {
    id: 53,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 73,
      value: "MAL"
    },
    MXRkLabel1: "12"
  },
  {
    id: 54,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 74,
      value: "MCU"
    },
    MXRkLabel1: "13"
  },
  {
    id: 55,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 74,
      value: "MCU"
    },
    MXRkLabel1: "32"
  },
  {
    id: 56,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 74,
      value: "MCU"
    },
    MXRkLabel1: "13"
  },
  {
    id: 57,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 75,
      value: "MNI"
    },
    MXRkLabel1: "15"
  },
  {
    id: 58,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 75,
      value: "MNI"
    },
    MXRkLabel1: "38"
  },
  {
    id: 59,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 75,
      value: "MNI"
    },
    MXRkLabel1: "15"
  },
  {
    id: 60,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 76,
      value: "MPB"
    },
    MXRkLabel1: "14"
  },
  {
    id: 61,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 76,
      value: "MPB"
    },
    MXRkLabel1: "35"
  },
  {
    id: 62,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 76,
      value: "MPB"
    },
    MXRkLabel1: "14"
  },
  {
    id: 63,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 77,
      value: "MSN"
    },
    MXRkLabel1: "16"
  },
  {
    id: 64,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 77,
      value: "MSN"
    },
    MXRkLabel1: "43"
  },
  {
    id: 65,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 77,
      value: "MSN"
    },
    MXRkLabel1: "16"
  },
  {
    id: 66,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 79,
      value: "MZN"
    },
    MXRkLabel1: "17"
  },
  {
    id: 67,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 79,
      value: "MZN"
    },
    MXRkLabel1: "46"
  },
  {
    id: 68,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 79,
      value: "MZN"
    },
    MXRkLabel1: "17"
  },
  {
    id: 69,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 3,
      value: "API2 - Monthly"
    },
    MXRkLabel1: "26"
  },
  {
    id: 70,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 3,
      value: "API2 - Monthly"
    },
    MXRkLabel1: "26"
  },
  {
    id: 71,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 4,
      value: "API2 - Quarterly"
    },
    MXRkLabel1: "132"
  },
  {
    id: 72,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 4,
      value: "API2 - Quarterly"
    },
    MXRkLabel1: "132"
  },
  {
    id: 73,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 5,
      value: "API2 - Yearly"
    },
    MXRkLabel1: "131"
  },
  {
    id: 74,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 5,
      value: "API2 - Yearly"
    },
    MXRkLabel1: "131"
  },
  {
    id: 75,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 6,
      value: "API4 - Monthly"
    },
    MXRkLabel1: "27"
  },
  {
    id: 76,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 6,
      value: "API4 - Monthly"
    },
    MXRkLabel1: "27"
  },
  {
    id: 77,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 7,
      value: "API4 - Quarterly"
    },
    MXRkLabel1: "134"
  },
  {
    id: 78,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 7,
      value: "API4 - Quarterly"
    },
    MXRkLabel1: "134"
  },
  {
    id: 79,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 8,
      value: "API4 - Yearly"
    },
    MXRkLabel1: "133"
  },
  {
    id: 80,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 8,
      value: "API4 - Yearly"
    },
    MXRkLabel1: "133"
  },
  {
    id: 81,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 80,
      value: "Newcastle Coal - Monthly"
    },
    MXRkLabel1: "28"
  },
  {
    id: 82,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 80,
      value: "Newcastle Coal - Monthly"
    },
    MXRkLabel1: "28"
  },
  {
    id: 83,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 81,
      value: "Newcastle Coal - Quarterly"
    },
    MXRkLabel1: "136"
  },
  {
    id: 84,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 81,
      value: "Newcastle Coal - Quarterly"
    },
    MXRkLabel1: "136"
  },
  {
    id: 85,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 82,
      value: "Newcastle Coal - Yearly"
    },
    MXRkLabel1: "135"
  },
  {
    id: 86,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 82,
      value: "Newcastle Coal - Yearly"
    },
    MXRkLabel1: "135"
  },
  {
    id: 87,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 13,
      value: "CER (EUR)"
    },
    MXRkLabel1: "CER EU"
  },
  {
    id: 88,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 13,
      value: "CER (EUR)"
    },
    MXRkLabel1: "ICE EUR CER"
  },
  {
    id: 89,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 92,
      value: "VER"
    },
    MXRkLabel1: "VER AU"
  },
  {
    id: 90,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 83,
      value: "NGAC"
    },
    MXRkLabel1: "NGAC AU"
  },
  {
    id: 91,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 84,
      value: "NZU"
    },
    MXRkLabel1: "NZD NZ"
  },
  {
    id: 92,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 85,
      value: "REC"
    },
    MXRkLabel1: "REC AU"
  },
  {
    id: 93,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 85,
      value: "REC"
    },
    MXRkLabel1: "ASX RECC"
  },
  {
    id: 94,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 88,
      value: "SREC"
    },
    MXRkLabel1: "SREC AU"
  },
  {
    id: 95,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 66,
      value: "IOS"
    },
    MXRkLabel1: "97"
  },
  {
    id: 96,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 56,
      value: "EPA"
    },
    MXRkLabel1: "126"
  },
  {
    id: 97,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 57,
      value: "EPK"
    },
    MXRkLabel1: "127"
  },
  {
    id: 98,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 62,
      value: "ETS"
    },
    MXRkLabel1: "125"
  },
  {
    id: 99,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 20,
      value: "EAB"
    },
    MXRkLabel1: "98"
  },
  {
    id: 100,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 38,
      value: "EJB"
    },
    MXRkLabel1: "99"
  },
  {
    id: 101,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 59,
      value: "ESB"
    },
    MXRkLabel1: "100"
  },
  {
    id: 102,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 25,
      value: "ECL"
    },
    MXRkLabel1: "23"
  },
  {
    id: 103,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 25,
      value: "ECL"
    },
    MXRkLabel1: "23"
  },
  {
    id: 104,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 25,
      value: "ECL"
    },
    MXRkLabel1: "23"
  },
  {
    id: 105,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 26,
      value: "ECM"
    },
    MXRkLabel1: "96"
  },
  {
    id: 106,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 27,
      value: "ECO"
    },
    MXRkLabel1: "91"
  },
  {
    id: 107,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 27,
      value: "ECO"
    },
    MXRkLabel1: "39"
  },
  {
    id: 108,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 27,
      value: "ECO"
    },
    MXRkLabel1: "91"
  },
  {
    id: 109,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 28,
      value: "EDB"
    },
    MXRkLabel1: "29"
  },
  {
    id: 110,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 28,
      value: "EDB"
    },
    MXRkLabel1: "29"
  },
  {
    id: 111,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 29,
      value: "EDO"
    },
    MXRkLabel1: "124"
  },
  {
    id: 112,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 30,
      value: "EDU"
    },
    MXRkLabel1: "90"
  },
  {
    id: 113,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 30,
      value: "EDU"
    },
    MXRkLabel1: "90"
  },
  {
    id: 114,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 36,
      value: "EIC"
    },
    MXRkLabel1: "103"
  },
  {
    id: 115,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 39,
      value: "EJC"
    },
    MXRkLabel1: "104"
  },
  {
    id: 116,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 45,
      value: "EMC"
    },
    MXRkLabel1: "102"
  },
  {
    id: 117,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 55,
      value: "EOC"
    },
    MXRkLabel1: "101"
  },
  {
    id: 118,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 61,
      value: "ETP"
    },
    MXRkLabel1: "30"
  },
  {
    id: 119,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 61,
      value: "ETP"
    },
    MXRkLabel1: "30"
  },
  {
    id: 120,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 21,
      value: "EAF"
    },
    MXRkLabel1: "118"
  },
  {
    id: 121,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 33,
      value: "EH1"
    },
    MXRkLabel1: "33"
  },
  {
    id: 122,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 33,
      value: "EH1"
    },
    MXRkLabel1: "33"
  },
  {
    id: 123,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 34,
      value: "EH2"
    },
    MXRkLabel1: "34"
  },
  {
    id: 124,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 34,
      value: "EH2"
    },
    MXRkLabel1: "34"
  },
  {
    id: 125,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 46,
      value: "EMF"
    },
    MXRkLabel1: "120"
  },
  {
    id: 126,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 49,
      value: "ENF"
    },
    MXRkLabel1: "119"
  },
  {
    id: 127,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 22,
      value: "EAG"
    },
    MXRkLabel1: "106"
  },
  {
    id: 128,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 24,
      value: "EAU"
    },
    MXRkLabel1: "107"
  },
  {
    id: 129,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 31,
      value: "EGG"
    },
    MXRkLabel1: "31"
  },
  {
    id: 130,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 32,
      value: "EGO"
    },
    MXRkLabel1: "82"
  },
  {
    id: 131,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 32,
      value: "EGO"
    },
    MXRkLabel1: "82"
  },
  {
    id: 132,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 35,
      value: "EHO"
    },
    MXRkLabel1: "89"
  },
  {
    id: 133,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 35,
      value: "EHO"
    },
    MXRkLabel1: "86"
  },
  {
    id: 134,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 35,
      value: "EHO"
    },
    MXRkLabel1: "89"
  },
  {
    id: 135,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 37,
      value: "EIG"
    },
    MXRkLabel1: "92"
  },
  {
    id: 136,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 37,
      value: "EIG"
    },
    MXRkLabel1: "85"
  },
  {
    id: 137,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 37,
      value: "EIG"
    },
    MXRkLabel1: "92"
  },
  {
    id: 138,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 47,
      value: "EMU"
    },
    MXRkLabel1: "109"
  },
  {
    id: 139,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 54,
      value: "ENU"
    },
    MXRkLabel1: "108"
  },
  {
    id: 140,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 63,
      value: "EUD"
    },
    MXRkLabel1: "105"
  },
  {
    id: 141,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 43,
      value: "EM2"
    },
    MXRkLabel1: "111"
  },
  {
    id: 142,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 44,
      value: "EM5"
    },
    MXRkLabel1: "112"
  },
  {
    id: 143,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 52,
      value: "ENP"
    },
    MXRkLabel1: "113"
  },
  {
    id: 144,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 58,
      value: "ERB"
    },
    MXRkLabel1: "93"
  },
  {
    id: 145,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 58,
      value: "ERB"
    },
    MXRkLabel1: "87"
  },
  {
    id: 146,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 58,
      value: "ERB"
    },
    MXRkLabel1: "93"
  },
  {
    id: 147,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 42,
      value: "EJS"
    },
    MXRkLabel1: "35"
  },
  {
    id: 148,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 42,
      value: "EJS"
    },
    MXRkLabel1: "35"
  },
  {
    id: 149,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 50,
      value: "ENJ"
    },
    MXRkLabel1: "110"
  },
  {
    id: 150,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 40,
      value: "EJN"
    },
    MXRkLabel1: "115"
  },
  {
    id: 151,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 48,
      value: "ENC"
    },
    MXRkLabel1: "117"
  },
  {
    id: 152,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 51,
      value: "ENN"
    },
    MXRkLabel1: "116"
  },
  {
    id: 153,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 53,
      value: "ENS"
    },
    MXRkLabel1: "114"
  },
  {
    id: 154,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 23,
      value: "EAP"
    },
    MXRkLabel1: "123"
  },
  {
    id: 155,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 41,
      value: "EJP"
    },
    MXRkLabel1: "122"
  },
  {
    id: 156,
    modified: false,
    added: {
      by: "System",
      time: "2011-01-01T00:00:00.000+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 60,
      value: "ESP"
    },
    MXRkLabel1: "121"
  },
  {
    id: 157,
    modified: false,
    added: {
      by: "lakshmn2",
      time: "2012-07-25T07:54:21.660+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 21,
      value: "EAF"
    },
    MXRkLabel1: "118"
  },
  {
    id: 158,
    modified: false,
    added: {
      by: "lakshmn2",
      time: "2012-07-25T07:54:21.663+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 50,
      value: "ENJ"
    },
    MXRkLabel1: "110"
  },
  {
    id: 159,
    modified: false,
    added: {
      by: "foonga",
      time: "2012-08-15T03:41:13.890+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 97,
      value: "EUA"
    },
    MXRkLabel1: "EUA EU"
  },
  {
    id: 160,
    modified: false,
    added: {
      by: "foonga",
      time: "2012-08-15T03:41:13.893+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 93,
      value: "ACU"
    },
    MXRkLabel1: "ACU AU"
  },
  {
    id: 161,
    modified: false,
    added: {
      by: "foonga",
      time: "2012-08-15T03:41:13.893+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 95,
      value: "AEU"
    },
    MXRkLabel1: "AEU AU"
  },
  {
    id: 162,
    modified: false,
    added: {
      by: "foonga",
      time: "2012-08-15T03:41:13.893+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 96,
      value: "ESC"
    },
    MXRkLabel1: "ESC AU"
  },
  {
    id: 163,
    modified: false,
    added: {
      by: "foonga",
      time: "2012-08-15T03:41:13.893+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 98,
      value: "VEC"
    },
    MXRkLabel1: "VEC AU"
  },
  {
    id: 164,
    modified: false,
    added: {
      by: "foonga",
      time: "2012-08-15T03:41:13.893+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 100,
      value: "ERU"
    },
    MXRkLabel1: "ERR EU"
  },
  {
    id: 165,
    modified: false,
    added: {
      by: "foonga",
      time: "2012-08-15T03:41:13.893+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 99,
      value: "IOP"
    },
    MXRkLabel1: "137"
  },
  {
    id: 166,
    modified: false,
    added: {
      by: "imrek",
      time: "2012-09-02T23:33:12.927+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 84,
      value: "NZU"
    },
    MXRkLabel1: "NZU NZ"
  },
  {
    id: 167,
    modified: false,
    added: {
      by: "imrek",
      time: "2012-09-02T23:33:12.927+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 97,
      value: "EUA"
    },
    MXRkLabel1: "ICE EUR EUA"
  },
  {
    id: 168,
    modified: false,
    added: {
      by: "lakshmn2",
      time: "2013-01-29T09:37:25.920+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 31,
      value: "EGG"
    },
    MXRkLabel1: "31"
  },
  {
    id: 169,
    modified: false,
    added: {
      by: "liec",
      time: "2013-03-18T04:15:46.807+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 100,
      value: "ERU"
    },
    MXRkLabel1: "ICE EUR ERR"
  },
  {
    id: 170,
    modified: false,
    added: {
      by: "brightw",
      time: "2014-05-30T03:59:41.727+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 102,
      value: "ELG"
    },
    MXRkLabel1: "140"
  },
  {
    id: 171,
    modified: false,
    added: {
      by: "brightw",
      time: "2014-06-06T06:57:37.553+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 26,
      value: "ECM"
    },
    MXRkLabel1: "90"
  },
  {
    id: 172,
    modified: false,
    added: {
      by: "brightw",
      time: "2014-06-23T06:41:25.273+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 66,
      value: "IOS"
    },
    MXRkLabel1: "97"
  },
  {
    id: 173,
    modified: false,
    added: {
      by: "brightw",
      time: "2014-06-23T06:41:25.280+0000"
    },
    MXRkLabel3: "2",
    Commodity: {
      id: 99,
      value: "IOP"
    },
    MXRkLabel1: "137"
  },
  {
    id: 174,
    modified: false,
    added: {
      by: "System",
      time: "2014-07-17T10:27:10.653+0000"
    },
    MXRkLabel3: "EPX",
    Commodity: {
      id: 103,
      value: "EPX"
    },
    MXRkLabel1: "EPX"
  },
  {
    id: 175,
    modified: false,
    added: {
      by: "wongl14",
      time: "2016-05-31T07:43:18.643+0000"
    },
    MXRkLabel3: "1",
    Commodity: {
      id: 102,
      value: "ELG"
    },
    MXRkLabel1: "96"
  },
  {
    id: 179,
    modified: false,
    added: {
      by: "wongl14",
      time: "2016-11-27T22:51:13.767+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 106,
      value: "AWE"
    },
    MXRkLabel1: "157"
  },
  {
    id: 180,
    modified: false,
    added: {
      by: "wongl14",
      time: "2016-12-01T23:52:17.513+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 105,
      value: "EM7"
    },
    MXRkLabel1: "154"
  },
  {
    id: 181,
    modified: false,
    added: {
      by: "wongl14",
      time: "2017-08-07T01:20:58.903+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 104,
      value: "NGA"
    },
    MXRkLabel1: "24"
  },
  {
    id: 182,
    modified: false,
    added: {
      by: "wongl14",
      time: "2018-07-30T23:32:45.060+0000"
    },
    MXRkLabel3: "N/A",
    Commodity: {
      id: 97,
      value: "EUA"
    },
    MXRkLabel1: "ICE EUR EUA P3"
  },
  {
    id: 183,
    modified: false,
    added: {
      by: "rajagos1",
      time: "2019-05-22T05:04:54.523+0000"
    },
    MXRkLabel3: "0",
    Commodity: {
      id: 109,
      value: "JKM"
    },
    MXRkLabel1: "160"
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Credit';

// Type
const type = 'CRDI Composition';

// GQL Schema
const schemaQuery =
  'StaticDataCRDICompositions (cob: Date): [StaticDataCRDIComposition]';
const schemaType = `
  type StaticDataCRDIComposition {
    id: ID!
    modified: Boolean!
    indexLabel: String!
    date: Int!
    issuer: String!
    Instrument: Int!
    compositionPercentage: Float
    seniority: String!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataCRDICompositions';
const query = ({ cob }) => `
{
  StaticDataCRDICompositions (cob: ${cob}) {
    id
    modified
    indexLabel
    date
    issuer
    Instrument
    compositionPercentage
    seniority
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCRDICompositions: {
      url: 'reference-data/v1/crdindex-compositions?cobDate={args.cob}',
      dataPath: '$',
    },
  },
  StaticDataCRDIComposition: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'date',
    title: 'Date',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'indexLabel',
    title: 'Index Label',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'issuer',
    title: 'Issuer',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'seniority',
    title: 'Seniority',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'compositionPercentage',
    title: 'Composition Percentage',
    filter: 'numeric',
    typeOf: 'number',
    width: '150px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    date: 20160101,
    id: 1,
    issuer: 'ABG SM',
    Instrument: 45083,
    compositionPercentage: 1.36986301369863,
    seniority: 'SNR UNSEC',
    added: {
      by: 'wongl14',
      time: '2016-10-26T03:38:06.653+0000',
    },
    indexLabel: 'EU XR S23 V1',
  },
  {
    modified: false,
    date: 20160101,
    id: 2,
    issuer: 'ABG SM',
    Instrument: 45083,
    compositionPercentage: 1.7241379310344827,
    seniority: 'SNR UNSEC',
    added: {
      by: 'wongl14',
      time: '2016-10-26T03:38:06.653+0000',
    },
    indexLabel: 'EU XR S21 V1',
  },
  {
    modified: false,
    date: 20160101,
    id: 3,
    issuer: 'ABG SM',
    Instrument: 45083,
    compositionPercentage: 1.36986301369863,
    seniority: 'SNR UNSEC',
    added: {
      by: 'wongl14',
      time: '2016-10-26T03:38:06.653+0000',
    },
    indexLabel: 'EU XR S22 V1',
  },
  {
    modified: false,
    date: 20160101,
    id: 4,
    issuer: 'AZN LN',
    Instrument: 45109,
    compositionPercentage: 0.8064516129032258,
    seniority: 'SNR UNSEC',
    added: {
      by: 'wongl14',
      time: '2016-10-26T03:38:06.653+0000',
    },
    indexLabel: 'EU S25 V1',
  },
  {
    modified: false,
    date: 20160101,
    id: 5,
    issuer: 'AZN LN',
    Instrument: 45109,
    compositionPercentage: 0.8064516129032258,
    seniority: 'SNR UNSEC',
    added: {
      by: 'wongl14',
      time: '2016-10-26T03:38:06.653+0000',
    },
    indexLabel: 'EU S22 V1',
  },
  {
    modified: false,
    date: 20160101,
    id: 6,
    issuer: 'AZN LN',
    Instrument: 45109,
    compositionPercentage: 0.8064516129032258,
    seniority: 'SNR UNSEC',
    added: {
      by: 'wongl14',
      time: '2016-10-26T03:38:06.653+0000',
    },
    indexLabel: 'EU S26 V1',
  },
  {
    modified: false,
    date: 20160101,
    id: 7,
    issuer: 'AZN LN',
    Instrument: 45109,
    compositionPercentage: 0.8064516129032258,
    seniority: 'SNR UNSEC',
    added: {
      by: 'wongl14',
      time: '2016-10-26T03:38:06.653+0000',
    },
    indexLabel: 'EU S20 V1',
  },
  {
    modified: false,
    date: 20160101,
    id: 8,
    issuer: 'AZN LN',
    Instrument: 45109,
    compositionPercentage: 0.8064516129032258,
    seniority: 'SNR UNSEC',
    added: {
      by: 'wongl14',
      time: '2016-10-26T03:38:06.653+0000',
    },
    indexLabel: 'EU S21 V1',
  },
  {
    modified: false,
    date: 20160101,
    id: 9,
    issuer: 'AZN LN',
    Instrument: 45109,
    compositionPercentage: 0.8064516129032258,
    seniority: 'SNR UNSEC',
    added: {
      by: 'wongl14',
      time: '2016-10-26T03:38:06.653+0000',
    },
    indexLabel: 'EU S24 V1',
  },
  {
    modified: false,
    date: 20160101,
    id: 10,
    issuer: 'BMY US',
    Instrument: 45124,
    compositionPercentage: 0.8,
    seniority: 'SNR UNSEC',
    added: {
      by: 'wongl14',
      time: '2016-10-26T03:38:06.653+0000',
    },
    indexLabel: 'CDX NAIG S22 V1',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

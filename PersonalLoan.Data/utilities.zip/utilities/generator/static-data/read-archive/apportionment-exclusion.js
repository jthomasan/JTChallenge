// Category
const category = 'Regulatory';

// Type
const type = 'Apportionment Exclusion';

// GQL Schema
const schemaQuery =
  'StaticDataApportionmentExclusions: [StaticDataApportionmentExclusion]';
const schemaType = `
  type StaticDataApportionmentExclusion {
    apportionmentExclusion: ID!
    modified: Boolean!
    node: NodeOption!
    isActive: Boolean!
    added: Added!
  }
  
  type NodeOption {
    id: ID!
    text: String!
  }`;

// Query
const queryName = 'StaticDataApportionmentExclusions';
const query = `
{
  StaticDataApportionmentExclusions {
    modified
    apportionmentExclusion
    node {
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataApportionmentExclusions: {
      url: 'reference-data/v1/apportionment-exclusion',
      dataPath: '$',
    },
  },
  StaticDataApportionmentExclusion: {
    modified: false,
  },
  NodeOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'node.text',
    title: 'Risk Portfolio Hierarchy',
    filter: 'text',
    typeOf: 'string',
    width: '180px',
    defaultSortColumn: true,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    isActive: true,
    added: {
      by: 'barmann',
      time: '2020-09-27T12:10:19.240+0000',
    },
    apportionmentExclusion: 1,
    node: {
      id: 6663,
      text: 'AFS - Indonesia',
    },
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: 'atkinsot',
      time: '2015-06-30T02:42:04.310+0000',
    },
    apportionmentExclusion: 2,
    node: {
      id: 8568,
      text: 'Non Traded Group',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

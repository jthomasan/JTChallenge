// Category
const category = "Underlyings";

// Type
const type = "Grp: COM Type";

// GQL Schema
const schemaQuery = "StaticDataCOMTypes: [StaticDataCOMType]";
const schemaType = `
  type StaticDataCOMType {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataCOMTypes";
const query = `
{
  StaticDataCOMTypes {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCOMTypes: {
      url: "reference-data/type-system-parameters",
      dataPath: "$[?(@.system.id == 1007)]",
    },
  },
  StaticDataCOMType: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "value",
    title: "Value",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    id: 1,
    modified: false,
    description: null,
    value: "Agriculture",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 2,
    modified: false,
    description: null,
    value: "Base Metals",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 3,
    modified: false,
    description: null,
    value: "Coal",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 4,
    modified: false,
    description: null,
    value: "Emission",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 5,
    modified: false,
    description: null,
    value: "Iron Ore",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
  {
    id: 6,
    modified: false,
    description: null,
    value: "Oil",
    isActive: true,
    added: {
      by: "System",
      time: "2012-02-09T18:02:52.273+0000",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Tenor Buckets';

// Type
const type = 'Net Bucketing - All';

// GQL Schema
const schemaQuery =
  'StaticDataVegaNetBucketingAllList: [StaticDataVegaNetBucketingAll]';
const schemaType = `
  type StaticDataVegaNetBucketingAll {
    modified: Boolean!
    term: Int!
    net3m: String!
    net1y: String!
    net3y: String!
    net5y: String!
    net10y: String!
    net20y: String!
    net30yPlus: String!
  }`;

// Query
const queryName = 'StaticDataVegaNetBucketingAllList';
const query = `
{
  StaticDataVegaNetBucketingAllList {
    modified
    term
    net3m
    net1y
    net3y
    net5y
    net10y
    net20y
    net30yPlus
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataVegaNetBucketingAllList: {
      url: 'reference-data/v1/bucket-all',
      dataPath: '$',
    },
  },
  StaticDataVegaNetBucketingAll: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'term',
    title: 'Days to Maturity',
    filter: 'numeric',
    typeOf: 'number',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1y',
    title: 'Net1y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3y',
    title: 'Net3y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net5y',
    title: 'Net5y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net10y',
    title: 'Net10y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net20y',
    title: 'Net20y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net30yPlus',
    title: 'Net30yPlus',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '100',
    term: '1',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '100',
    term: '10',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '3.19634703196',
    net3m: '96.80365296804',
    term: '100',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '13.01369863014',
    net3m: '0',
    term: '1000',
    net5y: '0',
    net3y: '86.98630136986',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '73.97260273973',
    net20y: '26.027397260270003',
    net1y: '0',
    net3m: '0',
    term: '10000',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '74',
    net20y: '26',
    net1y: '0',
    net3m: '0',
    term: '10001',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '74.02739726027',
    net20y: '25.97260273973',
    net1y: '0',
    net3m: '0',
    term: '10002',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '74.05479452055',
    net20y: '25.94520547945',
    net1y: '0',
    net3m: '0',
    term: '10003',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '74.08219178082',
    net20y: '25.91780821918',
    net1y: '0',
    net3m: '0',
    term: '10004',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '74.1095890411',
    net20y: '25.890410958900002',
    net1y: '0',
    net3m: '0',
    term: '10005',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '74.13698630137',
    net20y: '25.86301369863',
    net1y: '0',
    net3m: '0',
    term: '10006',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '74.164383561640008',
    net20y: '25.83561643836',
    net1y: '0',
    net3m: '0',
    term: '10007',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '74.191780821919991',
    net20y: '25.808219178079998',
    net1y: '0',
    net3m: '0',
    term: '10008',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '74.21917808219',
    net20y: '25.780821917809998',
    net1y: '0',
    net3m: '0',
    term: '10009',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '12.876712328770001',
    net3m: '0',
    term: '1001',
    net5y: '0',
    net3y: '87.12328767123',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '74.24657534247',
    net20y: '25.75342465753',
    net1y: '0',
    net3m: '0',
    term: '10010',
    net5y: '0',
    net3y: '0',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Regulatory';

// Type
const type = 'D2A Forms';

// GQL Schema
const schemaQuery = 'StaticDataDTwoAForms: [StaticDataDTwoAForm]';
const schemaType = `
  type StaticDataDTwoAForm {
    id: ID!
    modified: Boolean!
    version: Int
    order: Int
    formCode: String
    returnIdentifier: ReturnIdentifierOption
    formName: String!
    calculateTwoLevels: Boolean
    isActive: Boolean!
    added: Added!
  }
  
  type ReturnIdentifierOption {
    id: ID!
    text: String!
  }`;

// Query
const queryName = 'StaticDataDTwoAForms';
const query = `
{
  StaticDataDTwoAForms {
    id
    modified
    version
    order
    formCode
    returnIdentifier {
      id
      text
    }
    formName
    calculateTwoLevels
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataDTwoAForms: {
      url: 'reference-data/v1/d2aforms',
      dataPath: '$',
    },
  },
  StaticDataDTwoAForm: {
    modified: false,
  },
  ReturnIdentifierOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'formName',
    title: 'Form Name',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'returnIdentifier.text',
    title: 'Return Identifier',
    filter: 'text',
    typeOf: 'string',
    width: '250px',
  },
  {
    field: 'version',
    title: 'Version',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'calculateTwoLevels',
    title: 'Calculate Two Levels',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    cell: 'GridCheckboxCell',
  },
  {
    field: 'order',
    title: 'Order',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    version: 4,
    order: 1,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.557+0000',
    },
    isActive: true,
    id: 1,
    formCode: 'ARF_116_0_SU',
    returnIdentifier: {
      id: '3075',
      text: 'Market Risk Return 1 - Advanced',
    },
    formName: 'Market Risk Summary Table',
    calculateTwoLevels: true,
  },
  {
    modified: false,
    version: 10,
    order: 2,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.557+0000',
    },
    isActive: true,
    id: 2,
    formCode: 'ARF_116_0_1',
    returnIdentifier: {
      id: '3075',
      text: 'Market Risk Return 1 - Advanced',
    },
    formName: 'Market Risk Table 1',
    calculateTwoLevels: true,
  },
  {
    modified: false,
    version: 5,
    order: 3,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.557+0000',
    },
    isActive: false,
    id: 3,
    formCode: 'ARF_116_0_2',
    returnIdentifier: {
      id: '3075',
      text: 'Market Risk Return 1 - Advanced',
    },
    formName: 'Market Risk Table 2',
    calculateTwoLevels: false,
  },
  {
    modified: false,
    version: 5,
    order: 4,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.557+0000',
    },
    isActive: true,
    id: 4,
    formCode: 'ARF_116_0_3',
    returnIdentifier: {
      id: '3075',
      text: 'Market Risk Return 1 - Advanced',
    },
    formName: 'Market Risk Table 3',
    calculateTwoLevels: false,
  },
  {
    modified: false,
    version: 7,
    order: 5,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.557+0000',
    },
    isActive: false,
    id: 5,
    formCode: 'ARF_116_0_4',
    returnIdentifier: {
      id: '3075',
      text: 'Market Risk Return 1 - Advanced',
    },
    formName: 'Market Risk Table 4',
    calculateTwoLevels: false,
  },
  {
    modified: false,
    version: 4,
    order: 6,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.557+0000',
    },
    isActive: true,
    id: 6,
    formCode: 'ARF_116_0_5',
    returnIdentifier: {
      id: '3075',
      text: 'Market Risk Return 1 - Advanced',
    },
    formName: 'Market Risk Table 5',
    calculateTwoLevels: false,
  },
  {
    modified: false,
    version: 4,
    order: 7,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.557+0000',
    },
    isActive: false,
    id: 7,
    formCode: 'ARF_116_0_6',
    returnIdentifier: {
      id: '3075',
      text: 'Market Risk Return 1 - Advanced',
    },
    formName: 'Market Risk Table 6',
    calculateTwoLevels: false,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

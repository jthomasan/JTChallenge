// Category
const category = 'Credit Stress';

// Type
const type = 'Credit Stress - Bond Issuer';

// GQL Schema
const schemaQuery =
  'StaticDataCreditStressBondIssuers: [StaticDataCreditStressBondIssuer]';
const schemaType = `
  type StaticDataCreditStressBondIssuer {
    modified: Boolean
    issuer: IssuerOptions!
    currency: CurrencyOptions!
    isActive: Boolean!
    added: Added!
    longStress: String!
    shortStress: String!
    daysToMaturity: String!
  }`;

// Query
const queryName = 'StaticDataCreditStressBondIssuers';
const query = `
{
  StaticDataCreditStressBondIssuers {
    modified
    issuer {
      id
      text
    }
    currency {
      id
      text
    }
    isActive
    added {
      by
      time
    }
    longStress
    shortStress
    daysToMaturity
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCreditStressBondIssuers: {
      url: 'reference-data/v1/credit-stress-issuer',
      dataPath: '$',
    },
  },
  StaticDataCreditStressBondIssuer: {
    modified: false,
    currency: "$.Currency",
    issuer: "$.Issuer"
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: "issuer.text",
    title: "Issuer",
    filter: "text",
    typeOf: "string",
    width: "150px",
    defaultSortColumn: true,
  },
  {
    field: 'currency.text',
    title: 'Currency',
    filter: 'text',
    typeOf: 'string',
    width: '110px',
  },
  {
    field: 'daysToMaturity',
    title: 'Term',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
  },
  {
    field: 'longStress',
    title: 'Long Stress',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'shortStress',
    title: 'Short Stress',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "10y"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "15y"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "1y"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "20y"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "2y"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "30y"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "3m"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "3y"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "4y"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "5y"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "6m"
  },
  {
    isActive: true,
    added: {
      by: "System",
      time: "2015-09-19T04:46:15.080+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 550,
    shortStress: 275,
    currency: {
      id: 15,
      text: "IDR"
    },
    daysToMaturity: "7y"
  },
  {
    isActive: false,
    added: {
      by: "lintonsm",
      time: "2016-08-26T23:52:07.213+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 400,
    shortStress: 200,
    currency: {
      id: 33,
      text: "USD"
    },
    daysToMaturity: "10y"
  },
  {
    isActive: false,
    added: {
      by: "lintonsm",
      time: "2016-08-26T23:52:07.213+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 400,
    shortStress: 200,
    currency: {
      id: 33,
      text: "USD"
    },
    daysToMaturity: "15y"
  },
  {
    isActive: false,
    added: {
      by: "lintonsm",
      time: "2016-08-26T23:52:07.213+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 400,
    shortStress: 200,
    currency: {
      id: 33,
      text: "USD"
    },
    daysToMaturity: "1y"
  },
  {
    isActive: false,
    added: {
      by: "lintonsm",
      time: "2016-08-26T23:52:07.213+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 400,
    shortStress: 200,
    currency: {
      id: 33,
      text: "USD"
    },
    daysToMaturity: "20y"
  },
  {
    isActive: false,
    added: {
      by: "lintonsm",
      time: "2016-08-26T23:52:07.213+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 400,
    shortStress: 200,
    currency: {
      id: 33,
      text: "USD"
    },
    daysToMaturity: "2y"
  },
  {
    isActive: false,
    added: {
      by: "lintonsm",
      time: "2016-08-26T23:52:07.213+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 400,
    shortStress: 200,
    currency: {
      id: 33,
      text: "USD"
    },
    daysToMaturity: "30y"
  },
  {
    isActive: false,
    added: {
      by: "lintonsm",
      time: "2016-08-26T23:52:07.213+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 400,
    shortStress: 200,
    currency: {
      id: 33,
      text: "USD"
    },
    daysToMaturity: "3m"
  },
  {
    isActive: false,
    added: {
      by: "lintonsm",
      time: "2016-08-26T23:52:07.213+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 400,
    shortStress: 200,
    currency: {
      id: 33,
      text: "USD"
    },
    daysToMaturity: "3y"
  },
  {
    isActive: false,
    added: {
      by: "lintonsm",
      time: "2016-08-26T23:52:07.213+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 400,
    shortStress: 200,
    currency: {
      id: 33,
      text: "USD"
    },
    daysToMaturity: "4y"
  },
  {
    isActive: false,
    added: {
      by: "lintonsm",
      time: "2016-08-26T23:52:07.213+0000"
    },
    issuer: {
      id: 627,
      text: "1133Z IJ"
    },
    longStress: 400,
    shortStress: 200,
    currency: {
      id: 33,
      text: "USD"
    },
    daysToMaturity: "5y"
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = "Tenor Buckets";

// Type
const type = "Pillars - CR01";

// GQL Schema
const schemaQuery = "StaticDataPillarsCr01s: [StaticDataPillarsCr01Type]";
const schemaType = `
  type StaticDataPillarsCr01Type {
    modified: Boolean!
    net15y: String
    net7y: String
    net10y: String
    net30y: String
    net20y: String
    net6m: String
    net3m: String
    net1y: String
    net2y: String
    term: String!
    termUnit: Int!
    net5y: String
    net3y: String
    net4y: String
  }`;

// Query
const queryName = "StaticDataPillarsCr01s";
const query = `
{
  StaticDataPillarsCr01s {
    modified
    net15y
    net7y
    net10y
    net30y
    net20y
    net6m
    net3m
    net1y
    net2y
    term
    termUnit
    net5y
    net3y
    net4y
  } 
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataPillarsCr01s: {
      url: "reference-data/v1/bucket-cr01",
      dataPath: "$",
    },
  },
  StaticDataPillarsCr01Type: {
    modified: false,
    termUnit: {
      dataPath: "$.term",
      decorators: [{ name: "pillarsTermUnit" }],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "termUnit",
    title: "Days to Maturity",
    filter: "text",
    typeOf: "string",
    width: "150px",
    defaultSortColumn: true,
    cell: "GridCustomCell",
    extras: {
      displayField: "term",
    },
  },
  {
    field: "net3m",
    title: "3m",
    filter: "numeric",
    typeOf: "number",
    width: "140px",
  },
  {
    field: "net6m",
    title: "6m",
    filter: "numeric",
    typeOf: "number",
    width: "140px",
  },
  {
    field: "net1y",
    title: "1y",
    filter: "numeric",
    typeOf: "number",
    width: "140px",
  },
  {
    field: "net2y",
    title: "2y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net3y",
    title: "3y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net4y",
    title: "4y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net5y",
    title: "5y",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
  },
  {
    field: "net7y",
    title: "7y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net10y",
    title: "10y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net15y",
    title: "15y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net20y",
    title: "20y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
  {
    field: "net30y",
    title: "30y",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net15y: "0",
    net7y: "0",
    net10y: "0",
    net30y: "0",
    net20y: "0",
    net6m: "0",
    net3m: "100",
    net1y: "0",
    net2y: "0",
    term: "1",
    termUnit: 1,
    net5y: "0",
    net3y: "0",
    net4y: "0",
  },
  {
    modified: false,
    net15y: "0",
    net7y: "0",
    net10y: "0",
    net30y: "0",
    net20y: "0",
    net6m: "0",
    net3m: "100",
    net1y: "0",
    net2y: "0",
    term: "10",
    termUnit: 10,
    net5y: "0",
    net3y: "0",
    net4y: "0",
  },
  {
    modified: false,
    net15y: "0",
    net7y: "0",
    net10y: "0",
    net30y: "0",
    net20y: "0",
    net6m: "9.5890410959",
    net3m: "90.410958904109592",
    net1y: "0",
    net2y: "0",
    term: "100",
    termUnit: 100,
    net5y: "0",
    net3y: "0",
    net4y: "0",
  },
  {
    modified: false,
    net15y: "0",
    net7y: "0",
    net10y: "0",
    net30y: "0",
    net20y: "0",
    net6m: "0",
    net3m: "0",
    net1y: "0",
    net2y: "26.02739726",
    term: "1000",
    termUnit: 1000,
    net5y: "0",
    net3y: "73.97260274",
    net4y: "0",
  },
  {
    modified: false,
    net15y: "0",
    net7y: "0",
    net10y: "0",
    net30y: "73.97260274",
    net20y: "26.02739726",
    net6m: "0",
    net3m: "0",
    net1y: "0",
    net2y: "0",
    term: "10000",
    termUnit: 10000,
    net5y: "0",
    net3y: "0",
    net4y: "0",
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

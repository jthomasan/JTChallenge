// Category
const category = "Tenor Buckets";

// Type
const type = "Generic Term Pillars - Emission";

// GQL Schema
const schemaQuery =
  "StaticDataGenericTermPillarsEmissions: [StaticDataGenericTermPillarsEmissionType]";
const schemaType = `
  type StaticDataGenericTermPillarsEmissionType {
    modified: Boolean!
    net13m_24m: String!
    net19m_30m: String!
    net25m_36m: String!
    net4m_18m: String!
    net4m_12m: String!
    term: String!
    termUnit: Int!
    net0m_3m: String!
    net31m_42m: String!
  }`;

// Query
const queryName = "StaticDataGenericTermPillarsEmissions";
const query = `
{
  StaticDataGenericTermPillarsEmissions {
    modified
    net13m_24m
    net19m_30m
    net25m_36m
    net4m_18m
    net4m_12m
    term
    termUnit
    net0m_3m
    net31m_42m
  } 
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataGenericTermPillarsEmissions: {
      url: "reference-data/v1/bucket-gen-pillar-emission",
      dataPath: "$",
    },
  },
  StaticDataGenericTermPillarsEmissionType: {
    modified: false,
    termUnit: {
      dataPath: "$.term",
      decorators: [{ name: "genericTermPillarsTermUnit" }],
    },
    net13m_24m: {
      dataPath: "$.net13m_24m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net19m_30m: {
      dataPath: "$.net19m_30m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net25m_36m: {
      dataPath: "$.net25m_36m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net4m_18m: {
      dataPath: "$.net4m_18m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net4m_12m: {
      dataPath: "$.net4m_12m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net0m_3m: {
      dataPath: "$.net0m_3m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net31m_42m: {
      dataPath: "$.net31m_42m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "termUnit",
    title: "Days to Maturity",
    filter: "text",
    typeOf: "string",
    width: "150px",
    defaultSortColumn: true,
    cell: "GridCustomCell",
    extras: {
      displayField: "term",
    },
  },
  {
    field: "net0m_3m",
    title: "Net0m_3m",
    filter: "numeric",
    typeOf: "number",
    width: "110px",
  },
  {
    field: "net4m_18m",
    title: "Net4m_18m",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
  },
  {
    field: "net19m_30m",
    title: "Net19m_30m",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
  },
  {
    field: "net31m_42m",
    title: "Net31m_42m",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
  },
  {
    field: "net4m_12m",
    title: "Net4m_12m",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
  },
  {
    field: "net13m_24m",
    title: "Net13m_24m",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
  },
  {
    field: "net25m_36m",
    title: "Net25m_36m",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net13m_24m: "0",
    net19m_30m: "0",
    net25m_36m: "0",
    net4m_18m: "0",
    net4m_12m: "0",
    term: "c1",
    termUnit: 1,
    net0m_3m: "100",
    net31m_42m: "0",
  },
  {
    modified: false,
    net13m_24m: "0",
    net19m_30m: "0",
    net25m_36m: "0",
    net4m_18m: "100",
    net4m_12m: "100",
    term: "c10",
    termUnit: 10,
    net0m_3m: "0",
    net31m_42m: "0",
  },
  {
    modified: false,
    net13m_24m: "0",
    net19m_30m: "0",
    net25m_36m: "0",
    net4m_18m: "100",
    net4m_12m: "100",
    term: "c11",
    termUnit: 11,
    net0m_3m: "0",
    net31m_42m: "0",
  },
  {
    modified: false,
    net13m_24m: "0",
    net19m_30m: "0",
    net25m_36m: "0",
    net4m_18m: "100",
    net4m_12m: "100",
    term: "c12",
    termUnit: 12,
    net0m_3m: "0",
    net31m_42m: "0",
  },
  {
    modified: false,
    net13m_24m: "100",
    net19m_30m: "0",
    net25m_36m: "0",
    net4m_18m: "100",
    net4m_12m: "0",
    term: "c13",
    termUnit: 13,
    net0m_3m: "0",
    net31m_42m: "0",
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

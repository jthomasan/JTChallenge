// Category
const category = 'Limits';

// Type
const type = 'Market Risk Business Group';

// GQL Schema
const schemaQuery =
  'StaticDataMarketRiskBusinessGroups: [StaticDataMarketRiskBusinessGroup]';
const schemaType = `
  type StaticDataMarketRiskBusinessGroup {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataMarketRiskBusinessGroups';
const query = `
{
  StaticDataMarketRiskBusinessGroups {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataMarketRiskBusinessGroups: {
      url: 'limits/v1/limit-market-risk-business-group',
      dataPath: '$',
    },
  },
  StaticDataMarketRiskBusinessGroup: {
    modified: false,
    id: "$.marketRiskBusinessGroupId",
    value: "$.name",
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'value',
    title: 'Value',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    defaultSortColumn: true,
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    typeOf: 'string',
    width: '250px',
    defaultSortColumn: true,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

// Mock Data
const mockData = [
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = "Credit Stress";

// Type
const type = "Credit Stress - Top CDS Issuers";

// GQL Schema
const schemaQuery =
  "StaticDataCreditStressTopCDSIssuers: [StaticDataCreditStressTopCDSIssuer]";
const schemaType = `
  type StaticDataCreditStressTopCDSIssuer {
    modified: Boolean!
    Issuer: IssuerOptions!
    longStress: Int!
    shortStress: Int!
    isActive: Boolean!
    added: Added
  }

  type IssuerOptions {
    id: ID
    text: String
    description: String
  }
`;

// Query
const queryName = "StaticDataCreditStressTopCDSIssuers";
const query = `
{
  StaticDataCreditStressTopCDSIssuers {
    modified
    Issuer {
      id
      text
    }
    longStress
    shortStress
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCreditStressTopCDSIssuers: {
      url: "reference-data/v1/credit-stress-top-cdscompress",
      dataPath: "$",
    },
  },
  StaticDataCreditStressTopCDSIssuer: {
    modified: false,
  },
  IssuerOptions: {
    text: "$.value",
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "Issuer.text",
    title: "Issuer",
    filter: "text",
    typeOf: "string",
    width: "120px",
    defaultSortColumn: true,
  },
  {
    field: "longStress",
    title: "Long Stress",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
  },
  {
    field: "shortStress",
    title: "Short Stress",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.153+0000",
    },
    Issuer: {
      id: 610,
      text: "1054Z NA",
    },
    longStress: 200,
    shortStress: 200,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.153+0000",
    },
    Issuer: {
      id: 627,
      text: "1133Z IJ",
    },
    longStress: 350,
    shortStress: 350,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.150+0000",
    },
    Issuer: {
      id: 641,
      text: "13 HK",
    },
    longStress: 70,
    shortStress: 70,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.153+0000",
    },
    Issuer: {
      id: 659,
      text: "1696Z SW",
    },
    longStress: 350,
    shortStress: 350,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.153+0000",
    },
    Issuer: {
      id: 686,
      text: "2783Z LN",
    },
    longStress: 200,
    shortStress: 200,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.153+0000",
    },
    Issuer: {
      id: 687,
      text: "279379Z PM",
    },
    longStress: 350,
    shortStress: 350,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.153+0000",
    },
    Issuer: {
      id: 740,
      text: "AA US",
    },
    longStress: 350,
    shortStress: 350,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.153+0000",
    },
    Issuer: {
      id: 742,
      text: "ACA FP",
    },
    longStress: 200,
    shortStress: 200,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.153+0000",
    },
    Issuer: {
      id: 743,
      text: "ACGB AU",
    },
    longStress: 100,
    shortStress: 100,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.153+0000",
    },
    Issuer: {
      id: 746,
      text: "AGL AU",
    },
    longStress: 350,
    shortStress: 350,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "lintonsm",
      time: "2016-10-08T03:05:20.153+0000",
    },
    Issuer: {
      id: 753,
      text: "AMC AU",
    },
    longStress: 350,
    shortStress: 350,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = "Tenor Buckets";

// Type
const type = "Generic Term Pillars - Coal & Iron Ore Delta";

// GQL Schema
const schemaQuery =
  "StaticDataGenericTermPillarsCoalIronOreDeltas: [StaticDataGenericTermPillarsCoalIronOreDeltaType]";
const schemaType = `
  type StaticDataGenericTermPillarsCoalIronOreDeltaType {
    modified: Boolean!
    net7m_12m: String!
    net4m_6m: String!
    net2y: String!
    term: String!
    termUnit: Int!
    net0m_3m: String!
    net3y_5y: String!
  }`;

// Query
const queryName = "StaticDataGenericTermPillarsCoalIronOreDeltas";
const query = `
{
  StaticDataGenericTermPillarsCoalIronOreDeltas {
    modified
    net7m_12m
    net4m_6m
    net2y
    term
    termUnit
    net0m_3m
    net3y_5y
  } 
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataGenericTermPillarsCoalIronOreDeltas: {
      url: "reference-data/v1/bucket-gen-pillar-coal-iron-ore",
      dataPath: "$",
    },
  },
  StaticDataGenericTermPillarsCoalIronOreDeltaType: {
    modified: false,
    termUnit: {
      dataPath: "$.term",
      decorators: [{ name: "genericTermPillarsTermUnit" }],
    },
    net7m_12m: {
      dataPath: "$.net7m_12m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net4m_6m: {
      dataPath: "$.net4m_6m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net2y: {
      dataPath: "$.net2y",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net0m_3m: {
      dataPath: "$.net0m_3m",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net3y_5y: {
      dataPath: "$.net3y_5y",
      decorators: [
        {
          name: "roundNumber",
          params: {
            decimalPlaces: 0,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "termUnit",
    title: "Days to Maturity",
    filter: "text",
    typeOf: "string",
    width: "150px",
    defaultSortColumn: true,
    cell: "GridCustomCell",
    extras: {
      displayField: "term",
    },
  },
  {
    field: "net0m_3m",
    title: "Net0m_3m",
    filter: "numeric",
    typeOf: "number",
    width: "110px",
  },
  {
    field: "net4m_6m",
    title: "Net4m_6m",
    filter: "numeric",
    typeOf: "number",
    width: "110px",
  },
  {
    field: "net7m_12m",
    title: "Net7m_12m",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
  },
  {
    field: "net2y",
    title: "Net2y",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
  },
  {
    field: "net3y_5y",
    title: "Net3y_5y",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net7m_12m: "0",
    net4m_6m: "0",
    net2y: "0",
    term: "c1",
    net0m_3m: "100",
    net3y_5y: "0",
  },
  {
    modified: false,
    net7m_12m: "100",
    net4m_6m: "0",
    net2y: "0",
    term: "c10",
    net0m_3m: "0",
    net3y_5y: "0",
  },
  {
    modified: false,
    net7m_12m: "100",
    net4m_6m: "0",
    net2y: "0",
    term: "c11",
    net0m_3m: "0",
    net3y_5y: "0",
  },
  {
    modified: false,
    net7m_12m: "100",
    net4m_6m: "0",
    net2y: "0",
    term: "c12",
    net0m_3m: "0",
    net3y_5y: "0",
  },
  {
    modified: false,
    net7m_12m: "0",
    net4m_6m: "0",
    net2y: "100",
    term: "c13",
    net0m_3m: "0",
    net3y_5y: "0",
  },
  {
    modified: false,
    net7m_12m: "0",
    net4m_6m: "0",
    net2y: "100",
    term: "c14",
    net0m_3m: "0",
    net3y_5y: "0",
  },
  {
    modified: false,
    net7m_12m: "0",
    net4m_6m: "0",
    net2y: "100",
    term: "c15",
    net0m_3m: "0",
    net3y_5y: "0",
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Credit';

// Type
const type = 'Issuer';

// GQL Schema
const schemaQuery = 'StaticDataIssuers: [StaticDataIssuer]';
const schemaType = `
  type StaticDataIssuer {
    id: ID!
    modified: Boolean!
    comment: String
    ratingBandTypeSystem: RatingBandTypeSystemOption
    Country: IssuerCountryOption
    STFSectorTypeSystem: STFSectorTypeSystemOption
    fitchIssueRating: FitchIssueRatingOption
    isDataReview: Boolean
    isIgnore: Boolean
    isUpdatedFromAc: Boolean
    issuerEquityTicker: String
    MOIssueRating: MOIssueRatingOption
    snpIssueRating: SnpIssueRatingOption
    APRAApproved: Boolean
    ackey: String
    amountOutstanding: String
    bbBicsLevel1SectorName: String
    bbBicsLevel2IndustryGroupName: String
    bbBicsLevel3IndustryName: String
    castParentName: String
    commentISS: String
    dvParentEntityName: String
    FTRatingType: String
    fitchIssuer: String
    isAcQuarantine: Boolean
    isExclude: Boolean
    isMurexRiskless: Boolean
    issuerFamilyTypeSystem: IssuerFamilyTypeSystemOption
    issuerGuaranteedTypeSystem: IssuerGuaranteedTypeSystemOption
    issuerNodeAK: String
    issuerTypeTypeSystem: IssuerTypeTypeSystemOption
    issuerUtilisation: String
    issuerCode: String
    MORatingType: String
    mdyIssuer: String
    murexVersions: String
    parentIssuer: ParentIssuer
    parentOwned: String
    parentRelation: String
    SPRatingType: String
    SRCategory: SRCategoryOption
    sector: String
    spIssuer: String
    ultimateParentCompanyName: String
    ultimateParentTickerExchange: String
    CICSIssuerCode: String
    IssuerCICSCode: String
    description: String
    isActive: Boolean
    added: Added
    derivedRating: String
  }
  
  type IssuerCountryOption {
    id: ID!
    value: CountryOptionValue
  }

  type CountryOptionValue {
    name: String
    countryCode: String
  }

  type SnpIssueRatingOption {
    id: ID!
    value: String
  }

  type FitchIssueRatingOption {
    id: ID!
    value: String
  }

  type MOIssueRatingOption {
    id: ID!
    value: String
  }

  type ParentIssuer {
    id: ID!
    value: String
  }

  type IssuerFamilyTypeSystemOption {
    id: ID!
    value: String
  }

  type IssuerGuaranteedTypeSystemOption {
    id: ID!
    value: String
  }

  type IssuerTypeTypeSystemOption {
    id: ID!
    value: String
  }
  `;

// Query
const queryName = 'StaticDataIssuers';
const query = `
{
  StaticDataIssuers {
    id
    modified
    comment
    ratingBandTypeSystem {
      id
      text
    }
    Country {
      id
      value {
        name
        countryCode
      }
    }
    STFSectorTypeSystem {
      id
      text
    }
    fitchIssueRating {
      id
      value
    }
    isDataReview
    isIgnore
    isUpdatedFromAc
    issuerEquityTicker
    MOIssueRating {
      id
      value
    }
    snpIssueRating {
      id
      value
    }
    APRAApproved
    ackey
    amountOutstanding
    bbBicsLevel1SectorName
    bbBicsLevel2IndustryGroupName
    bbBicsLevel3IndustryName
    castParentName
    commentISS
    dvParentEntityName
    FTRatingType
    fitchIssuer
    isAcQuarantine
    isExclude
    isMurexRiskless
    issuerFamilyTypeSystem {
      id
      value
    }
    issuerGuaranteedTypeSystem {
      id
      value
    }
    issuerNodeAK
    issuerTypeTypeSystem {
      id
      value
    }
    issuerUtilisation
    issuerCode
    MORatingType
    mdyIssuer
    murexVersions
    parentIssuer {
      id
      value
    }
    parentOwned
    parentRelation
    SPRatingType
    SRCategory {
      id
      text
    }
    sector
    spIssuer
    ultimateParentCompanyName
    ultimateParentTickerExchange
    CICSIssuerCode
    IssuerCICSCode
    description
    isActive
    added {
      by
      time
    }
    derivedRating
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataIssuers: {
      url: 'reference-data/v1/issuer-with-attribute',
      dataPath: '$',
    },
  },
  StaticDataIssuer: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'issuerCode',
    title: 'Issuer Code',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'isExclude',
    title: 'Exclude',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    cell: 'GridCheckboxCell',
    typeOf: 'boolean',
    width: '90px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'ratingBandTypeSystem',
    title: 'RatingBand TypeSystem',
    cell: 'GridTextboxCell',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'Boolean',
    typeOf: 'Boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    comment: '[20150919][System] Updated STFSectorTypeSystemID_',
    ratingBandTypeSystem: null,
    Country: {
      id: 8,
      value: {
        name: '',
        countryCode: 'AU',
      },
    },
    STFSectorTypeSystem: {
      id: 1667,
      value: 'Corporate',
    },
    fitchIssueRating: {
      id: 78,
      value: 'N/R',
    },
    isDataReview: true,
    isIgnore: true,
    isUpdatedFromAc: false,
    issuerEquityTicker: null,
    MOIssueRating: {
      id: 126,
      value: 'N/R',
    },
    snpIssueRating: {
      id: 26,
      value: 'N/R',
    },
    APRAApproved: false,
    ackey: null,
    amountOutstanding: null,
    bbBicsLevel1SectorName: null,
    bbBicsLevel2IndustryGroupName: null,
    bbBicsLevel3IndustryName: null,
    castParentName: null,
    commentISS: '',
    dvParentEntityName: null,
    FTRatingType: null,
    fitchIssuer: '',
    isAcQuarantine: false,
    isExclude: false,
    isMurexRiskless: false,
    issuerFamilyTypeSystem: null,
    issuerGuaranteedTypeSystem: null,
    issuerNodeAK: null,
    issuerTypeTypeSystem: null,
    issuerUtilisation: null,
    issuerCode: 'WDBYTRST10-1 B',
    MORatingType: null,
    mdyIssuer: '',
    murexVersions: '[MX2.11],[MX3.1]',
    parentIssuer: {
      id: 1430,
      value: 'ALL',
    },
    parentOwned: false,
    parentRelation: null,
    SPRatingType: null,
    SRCategory: null,
    sector: 'DivrsFinancials',
    spIssuer: '',
    ultimateParentCompanyName: null,
    ultimateParentTickerExchange: null,
    CICSIssuerCode: null,
    IssuerCICSCode: null,
    description: 'Perpetual Trustee Co Ltd atf Wide Bay Trust 2010-1 B',
    isActive: true,
    added: {
      by: 'ISS',
      time: '2015-08-20T17:10:30.690+0000',
    },
    id: 3366,
    derivedRating: 'N/R',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

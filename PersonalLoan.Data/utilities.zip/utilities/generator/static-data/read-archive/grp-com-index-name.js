// Category
const category = "Underlyings";

// Type
const type = "Grp: COM Index Name";

// GQL Schema
const schemaQuery = "StaticDataCOMIndexNames: [StaticDataCOMIndexName]";
const schemaType = `
  type StaticDataCOMIndexName {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataCOMIndexNames";
const query = `
{
  StaticDataCOMIndexNames {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCOMIndexNames: {
      url: "reference-data/type-system-parameters",
      dataPath: "$[?(@.system.id == 1004)]",
    },
  },
  StaticDataCOMIndexName: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "value",
    title: "Value",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    id: 1235,
    modified: false,
    description: null,
    value: "ACU AU",
    isActive: true,
    added: {
      by: "imrek",
      time: "2012-08-15T00:03:54.010+0000",
    },
  },
  {
    id: 1236,
    modified: false,
    description: null,
    value: "AEU AU",
    isActive: true,
    added: {
      by: "imrek",
      time: "2012-08-15T00:03:54.013+0000",
    },
  },
  {
    id: 1237,
    modified: false,
    description: null,
    value: "ESC AU",
    isActive: true,
    added: {
      by: "imrek",
      time: "2012-08-15T00:03:54.013+0000",
    },
  },
  {
    id: 1238,
    modified: false,
    description: null,
    value: "EUA EU",
    isActive: true,
    added: {
      by: "imrek",
      time: "2012-08-15T00:03:54.013+0000",
    },
  },
  {
    id: 1239,
    modified: false,
    description: null,
    value: "VEC AU",
    isActive: true,
    added: {
      by: "imrek",
      time: "2012-08-15T00:03:54.017+0000",
    },
  },
  {
    id: 1240,
    modified: false,
    description: null,
    value: "PLATTS IRON ORE",
    isActive: true,
    added: {
      by: "imrek",
      time: "2012-08-15T00:03:54.017+0000",
    },
  },
  {
    id: 1241,
    modified: false,
    description: null,
    value: "ERR EU",
    isActive: true,
    added: {
      by: "imrek",
      time: "2012-08-15T00:03:54.017+0000",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Tenor Buckets';

// Type
const type = 'Pillars - Single CCY Basis';

// GQL Schema
const schemaQuery =
  'StaticDataPillarsSingleCCYBasisList: [StaticDataPillarsSingleCCYBasis]';
const schemaType = `
  type StaticDataPillarsSingleCCYBasis {
    modified: Boolean!
    term: Int!
    net25y: String!
    net15y: String!
    net7y: String!
    net10y: String!
    net1m: String!
    net30y: String!
    net20y: String!
    net6m: String!
    net3m: String!
    net1y: String!
    net2y: String!
    net5y: String!
    net3y: String!
    net4y: String!
  }`;

// Query
const queryName = 'StaticDataPillarsSingleCCYBasisList';
const query = `
{
  StaticDataPillarsSingleCCYBasisList {
    modified
    term
    net1m
    net3m
    net6m
    net1y
    net2y
    net3y
    net4y
    net5y
    net7y
    net10y
    net15y
    net20y
    net25y
    net30y
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataPillarsSingleCCYBasisList: {
      url: 'reference-data/v1/bucket-single-ccy-basis',
      dataPath: '$',
    },
  },
  StaticDataPillarsSingleCCYBasis: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'term',
    title: 'Days to Maturity',
    filter: 'numeric',
    typeOf: 'number',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'net1m',
    title: '1m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3m',
    title: '3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net6m',
    title: '6m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1y',
    title: '1y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net2y',
    title: '2y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3y',
    title: '3y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net4y',
    title: '4y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net5y',
    title: '5y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net7y',
    title: '7y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net10y',
    title: '10y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net15y',
    title: '15y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net20y',
    title: '20y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net25y',
    title: '25y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net30y',
    title: '30y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net25y: '0',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '100',
    net30y: '0',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '1',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '0',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '100',
    net30y: '0',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '0',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '0',
    net20y: '0',
    net6m: '9.5890410959',
    net3m: '90.410958904000012',
    net1y: '0',
    net2y: '0',
    term: '100',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '0',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '0',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '26.02739726',
    term: '1000',
    net5y: '0',
    net3y: '73.97260274',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '52.054794521000005',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '47.945205479',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10000',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '52',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10001',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '51.945205479',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48.054794521',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10002',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '51.890410959',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48.109589041',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10003',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '51.835616437999995',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48.164383562000005',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10004',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '51.780821918',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48.219178082',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10005',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '51.726027396999996',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48.273972603',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10006',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '51.671232876999994',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48.328767123',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10007',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '51.616438356',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48.383561644000004',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10008',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '51.561643836',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48.438356164',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10009',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '0',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '0',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '25.753424658',
    term: '1001',
    net5y: '0',
    net3y: '74.246575342',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '51.506849315000004',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48.493150685',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10010',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net25y: '51.452054795',
    net15y: '0',
    net7y: '0',
    net10y: '0',
    net1m: '0',
    net30y: '48.547945205',
    net20y: '0',
    net6m: '0',
    net3m: '0',
    net1y: '0',
    net2y: '0',
    term: '10011',
    net5y: '0',
    net3y: '0',
    net4y: '0',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

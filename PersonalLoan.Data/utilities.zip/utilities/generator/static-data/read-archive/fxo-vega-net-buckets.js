// Category
const category = 'Tenor Buckets';

// Type
const type = 'FXO Vega Net Buckets';

// GQL Schema
const schemaQuery = 'StaticDataFXOVegaNetBuckets: [StaticDataFXOVegaNetBucket]';
const schemaType = `
  type StaticDataFXOVegaNetBucket {
    modified: Boolean!
    termUnit: Int!
    term: String!
    net1m: String!
    net3m: String!
    net1y: String!
    net3y: String!
    net10y: String!
    net15y: String!
    net1m_1y: String!
    net1yPlus: String!
    net6mPlus: String!
  }`;

// Query
const queryName = 'StaticDataFXOVegaNetBuckets';
const query = `
{
  StaticDataFXOVegaNetBuckets {
    modified
    termUnit
    term
    net1m
    net3m
    net1y
    net3y
    net10y
    net15y
    net1m_1y
    net1yPlus
    net6mPlus
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataFXOVegaNetBuckets: {
      url: 'reference-data/v1/bucket-fxo-vega',
      dataPath: '$',
    },
  },
  StaticDataFXOVegaNetBucket: {
    modified: false,
    termUnit: '$.term',
    net1m: {
      dataPath: '$.net1m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net3m: {
      dataPath: '$.net3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1y: {
      dataPath: '$.net1y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net3y: {
      dataPath: '$.net3y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net10y: {
      dataPath: '$.net10y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net15y: {
      dataPath: '$.net15y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1m_1y: {
      dataPath: '$.net1m_1y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1yPlus: {
      dataPath: '$.net1yPlus',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net6mPlus: {
      dataPath: '$.net6mPlus',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net1m',
    title: 'Net1m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1y',
    title: 'Net1y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3y',
    title: 'Net3y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net10y',
    title: 'Net10y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net15y',
    title: 'Net15y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1m_1y',
    title: 'Net1m_1y',
    filter: 'numeric',
    typeOf: 'number',
    width: '110px',
  },
  {
    field: 'net1yPlus',
    title: 'Net1yPlus',
    filter: 'numeric',
    typeOf: 'number',
    width: '110px',
  },
  {
    field: 'net6mPlus',
    title: 'Net6mPlus',
    filter: 'numeric',
    typeOf: 'number',
    width: '110px',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net1m_1y: '0',
    net15y: '0',
    net1yPlus: '100',
    net6mPlus: '100',
    net10y: '100',
    net1m: '0',
    net1y: '0',
    net3m: '0',
    term: '10y',
    termUnit: '10',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '0',
    net15y: '0',
    net1yPlus: '100',
    net6mPlus: '100',
    net10y: '0',
    net1m: '0',
    net1y: '87.5',
    net3m: '0',
    term: '15m',
    termUnit: '15',
    net3y: '12.5',
  },
  {
    modified: false,
    net1m_1y: '0',
    net15y: '100',
    net1yPlus: '100',
    net6mPlus: '100',
    net10y: '0',
    net1m: '0',
    net1y: '0',
    net3m: '0',
    term: '15y',
    termUnit: '15',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '0',
    net15y: '0',
    net1yPlus: '100',
    net6mPlus: '100',
    net10y: '0',
    net1m: '0',
    net1y: '75',
    net3m: '0',
    term: '18m',
    termUnit: '18',
    net3y: '25',
  },
  {
    modified: false,
    net1m_1y: '100',
    net15y: '0',
    net1yPlus: '0',
    net6mPlus: '0',
    net10y: '0',
    net1m: '100',
    net1y: '0',
    net3m: '100',
    term: '1d',
    termUnit: '1',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '100',
    net15y: '0',
    net1yPlus: '0',
    net6mPlus: '0',
    net10y: '0',
    net1m: '100',
    net1y: '0',
    net3m: '100',
    term: '1m',
    termUnit: '1',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '100',
    net15y: '0',
    net1yPlus: '0',
    net6mPlus: '0',
    net10y: '0',
    net1m: '100',
    net1y: '0',
    net3m: '100',
    term: '1w',
    termUnit: '1',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '100',
    net15y: '0',
    net1yPlus: '0',
    net6mPlus: '100',
    net10y: '0',
    net1m: '0',
    net1y: '100',
    net3m: '0',
    term: '1y',
    termUnit: '1',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '0',
    net15y: '0',
    net1yPlus: '100',
    net6mPlus: '100',
    net10y: '0',
    net1m: '0',
    net1y: '62.5',
    net3m: '0',
    term: '21m',
    termUnit: '21',
    net3y: '37.5',
  },
  {
    modified: false,
    net1m_1y: '100',
    net15y: '0',
    net1yPlus: '0',
    net6mPlus: '0',
    net10y: '0',
    net1m: '0',
    net1y: '0',
    net3m: '100',
    term: '2m',
    termUnit: '2',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '100',
    net15y: '0',
    net1yPlus: '0',
    net6mPlus: '0',
    net10y: '0',
    net1m: '100',
    net1y: '0',
    net3m: '100',
    term: '2w',
    termUnit: '2',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '0',
    net15y: '0',
    net1yPlus: '100',
    net6mPlus: '100',
    net10y: '0',
    net1m: '0',
    net1y: '50',
    net3m: '0',
    term: '2y',
    termUnit: '2',
    net3y: '50',
  },
  {
    modified: false,
    net1m_1y: '100',
    net15y: '0',
    net1yPlus: '0',
    net6mPlus: '0',
    net10y: '0',
    net1m: '0',
    net1y: '0',
    net3m: '100',
    term: '3m',
    termUnit: '3',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '100',
    net15y: '0',
    net1yPlus: '0',
    net6mPlus: '0',
    net10y: '0',
    net1m: '100',
    net1y: '0',
    net3m: '100',
    term: '3w',
    termUnit: '3',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '0',
    net15y: '0',
    net1yPlus: '100',
    net6mPlus: '100',
    net10y: '0',
    net1m: '0',
    net1y: '0',
    net3m: '0',
    term: '3y',
    termUnit: '3',
    net3y: '100',
  },
  {
    modified: false,
    net1m_1y: '0',
    net15y: '0',
    net1yPlus: '100',
    net6mPlus: '100',
    net10y: '14.299999999999999',
    net1m: '0',
    net1y: '0',
    net3m: '0',
    term: '4y',
    termUnit: '4',
    net3y: '85.7',
  },
  {
    modified: false,
    net1m_1y: '0',
    net15y: '0',
    net1yPlus: '100',
    net6mPlus: '100',
    net10y: '28.599999999999998',
    net1m: '0',
    net1y: '0',
    net3m: '0',
    term: '5y',
    termUnit: '5',
    net3y: '71.399999999999991',
  },
  {
    modified: false,
    net1m_1y: '100',
    net15y: '0',
    net1yPlus: '0',
    net6mPlus: '0',
    net10y: '0',
    net1m: '0',
    net1y: '33.300000000000004',
    net3m: '66.7',
    term: '6m',
    termUnit: '6',
    net3y: '0',
  },
  {
    modified: false,
    net1m_1y: '0',
    net15y: '0',
    net1yPlus: '100',
    net6mPlus: '100',
    net10y: '57.099999999999994',
    net1m: '0',
    net1y: '0',
    net3m: '0',
    term: '7y',
    termUnit: '7',
    net3y: '42.9',
  },
  {
    modified: false,
    net1m_1y: '100',
    net15y: '0',
    net1yPlus: '0',
    net6mPlus: '100',
    net10y: '0',
    net1m: '0',
    net1y: '66.7',
    net3m: '33.300000000000004',
    term: '9m',
    termUnit: '9',
    net3y: '0',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

// Category
const category = 'Underlyings';

// Type
const type = 'Grp: EQTier';

// GQL Schema
const schemaQuery = 'StaticDataGrpEQTiers: [StaticDataGrpEQTier]';
const schemaType = `
  type StaticDataGrpEQTier {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataGrpEQTiers';
const query = `
{
  StaticDataGrpEQTiers {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataGrpEQTiers: {
      url: 'reference-data/v1/type-system-parameters',
      dataPath: '$[?(@.system.id == 1033)]',
    },
  },
  StaticDataGrpEQTier: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'value',
    title: 'Value',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    defaultSortColumn: true,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    id: 41,
    modified: false,
    description: null,
    value: 'Asian Stock Tier 1',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-13T14:51:22.193+0000',
    },
  },
  {
    id: 42,
    modified: false,
    description: null,
    value: 'Asian Stock Tier 2',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-13T14:51:22.193+0000',
    },
  },
  {
    id: 43,
    modified: false,
    description: null,
    value: 'Asian Stock Tier 4',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-13T14:51:22.193+0000',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

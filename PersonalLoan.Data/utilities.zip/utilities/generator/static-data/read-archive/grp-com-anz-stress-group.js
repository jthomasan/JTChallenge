// Category
const category = 'Underlyings';

// Type
const type = 'Grp: COM ANZ Stress Group';

// GQL Schema
const schemaQuery =
  'StaticDataCOMANZStressGroups: [StaticDataCOMANZStressGroup]';
const schemaType = `
  type StaticDataCOMANZStressGroup {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataCOMANZStressGroups';
const query = `
{
  StaticDataCOMANZStressGroups {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCOMANZStressGroups: {
      url: 'reference-data/v1/type-system-parameters',
      dataPath: '$[?(@.system.id == 1001)]',
    },
  },
  StaticDataCOMANZStressGroup: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'value',
    title: 'Value',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    defaultSortColumn: true,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    id: 83,
    modified: false,
    description: null,
    value: 'Agriculture',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:27:56.090+0000',
    },
  },
  {
    id: 84,
    modified: false,
    description: null,
    value: 'Base Metals',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:27:56.090+0000',
    },
  },
  {
    id: 85,
    modified: false,
    description: null,
    value: 'Coal & Iron Ore',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:27:56.090+0000',
    },
  },
  {
    id: 86,
    modified: false,
    description: null,
    value: 'Emission',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:27:56.090+0000',
    },
  },
  {
    id: 87,
    modified: false,
    description: null,
    value: 'Oil',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:27:56.090+0000',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

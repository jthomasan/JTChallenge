// Category
const category = 'Tenor Buckets';

// Type
const type = 'Vega Underlying Swap/Bond Maturity Net Buckets';

// GQL Schema
const schemaQuery =
  'StaticDataVegaUnderlyingSwapBondMaturityNetBuckets: [StaticDataVegaUnderlyingSwapBondMaturityNetBucket]';
const schemaType = `
  type StaticDataVegaUnderlyingSwapBondMaturityNetBucket {
    modified: Boolean!
    term: ID!
    termUnit: Int!
    net3m: String!
    net2y: String!
    net5y: String!
    net10y: String!
    net20y: String!
  }`;

// Query
const queryName = 'StaticDataVegaUnderlyingSwapBondMaturityNetBuckets';
const query = `
{
  StaticDataVegaUnderlyingSwapBondMaturityNetBuckets {
    modified
    term
    termUnit
    net3m
    net2y
    net5y
    net10y
    net20y
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataVegaUnderlyingSwapBondMaturityNetBuckets: {
      url: 'reference-data/v1/bucket-vega-swaption-bond-mat',
      dataPath: '$',
    },
  },
  StaticDataVegaUnderlyingSwapBondMaturityNetBucket: {
    modified: false,
    termUnit: {
      dataPath: '$.term',
      decorators: [
        {
          name: 'vegaBuckerTermUnit',
        },
      ],
    },
    net3m: {
      dataPath: '$.net3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net2y: {
      dataPath: '$.net2y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net5y: {
      dataPath: '$.net5y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net10y: {
      dataPath: '$.net10y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net20y: {
      dataPath: '$.net20y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net2y',
    title: 'Net2y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net5y',
    title: 'Net5y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net10y',
    title: 'Net10y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net20y',
    title: 'Net20y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net10y: '100',
    net20y: '0',
    net2y: '0',
    net3m: '0',
    term: '10y',
    net5y: '0',
  },
  {
    modified: false,
    net10y: '50',
    net20y: '50',
    net2y: '0',
    net3m: '0',
    term: '15y',
    net5y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net2y: '100',
    net3m: '0',
    term: '1y',
    net5y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '100',
    net2y: '0',
    net3m: '0',
    term: '20y',
    net5y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '100',
    net2y: '0',
    net3m: '0',
    term: '25y',
    net5y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net2y: '100',
    net3m: '0',
    term: '2y',
    net5y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '100',
    net2y: '0',
    net3m: '0',
    term: '30y',
    net5y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net2y: '0',
    net3m: '100',
    term: '3m',
    net5y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net2y: '67',
    net3m: '0',
    term: '3y',
    net5y: '33',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net2y: '33',
    net3m: '0',
    term: '4y',
    net5y: '67',
  },
  {
    modified: false,
    net10y: '0',
    net20y: '0',
    net2y: '0',
    net3m: '0',
    term: '5y',
    net5y: '100',
  },
  {
    modified: false,
    net10y: '20',
    net20y: '0',
    net2y: '0',
    net3m: '0',
    term: '6y',
    net5y: '80',
  },
  {
    modified: false,
    net10y: '40',
    net20y: '0',
    net2y: '0',
    net3m: '0',
    term: '7y',
    net5y: '60',
  },
  {
    modified: false,
    net10y: '60',
    net20y: '0',
    net2y: '0',
    net3m: '0',
    term: '8y',
    net5y: '40',
  },
  {
    modified: false,
    net10y: '80',
    net20y: '0',
    net2y: '0',
    net3m: '0',
    term: '9y',
    net5y: '20',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

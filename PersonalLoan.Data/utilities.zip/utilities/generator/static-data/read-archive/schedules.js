const category = 'Limits';

// Type
const type = 'Schedules';

// GQL Schema
const schemaQuery =
  'ScheduleMappings: [ScheduleMapping]';
const schemaType = `
  type ScheduleMapping {
    id: ID!
    modified: Boolean!
    name: String
    scheduleLocation: String
    lastIssuedOn: String
    lastIssuedBy: String
    marketRiskBusiness: MarketRiskBusiness
    reviewDate: String
    isActive: Boolean!
    added: Added!
  }
  
  type MarketRiskBusiness{
    id: ID
    text: String
  }
  `;

// Query
const queryName = 'ScheduleMappings';
const query = `
{
  ScheduleMappings {
    id
    modified
    name
    scheduleLocation
    lastIssuedOn
    lastIssuedBy
    marketRiskBusiness{
      id
      text
    }
    reviewDate
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    ScheduleMappings: {
      url: 'limits/v1/limit-schedules',
      dataPath: '$',
    },
  },
  ScheduleMapping: {
    modified: false,
  },
  MarketRiskBusiness: {
    text: '$.value'
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'marketRiskBusiness.text',
    title: 'Market Risk Business',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'name',
    title: 'Market Risk Limit Schedule',
    filter: 'text',
    typeOf: 'string',
    width: '110px',
    defaultSortColumn: true,
  },
  {
    field: 'scheduleLocation',
    title: 'Document Location',
    filter: 'text',
    typeOf: 'string',
    width: '110px',
  },
  {
    field: 'lastIssuedOn',
    title: 'Last Issued On',
    filter: 'text',
    typeOf: 'string',
    width: '110px',
  },
  {
    field: 'reviewDate',
    title: 'Review Date',
    filter: 'text',
    typeOf: 'string',
    width: '110px',
  },
  {
    field: 'lastIssuedBy',
    title: 'Last Issued By',
    filter: 'text',
    typeOf: 'string',
    width: '110px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

// Mock Data
const mockData = [
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};
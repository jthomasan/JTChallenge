// Category
const category = "Underlyings";

// Type
const type = "Underlying-CCY PAIR";

// GQL Schema
const schemaQuery =
  "StaticDataUnderlyingCCYPairs: [StaticDataUnderlyingCCYPair]";
const schemaType = `
  type StaticDataUnderlyingCCYPair {
    id: ID!
    modified: Boolean!
    name: String
    description: String
    isActive: Boolean!
    added: Added!
    comment: String
    foreignCurrency: String
    baseCurrency: String
    stealthTypeTypeSystem: StealthTypeTypeSystemOptions
    ccyPairGroupTypeSystem: CCYPairGroupTypeSystemOptions
    ccyPairFamilyTypeSystem: CCYPairFamilyTypeSystemOptions
  }
  
  type StealthTypeTypeSystemOptions {
    id: ID
    text: String
  }
  
  type CCYPairGroupTypeSystemOptions {
    id: ID
    text: String
  }
  
  type CCYPairFamilyTypeSystemOptions {
    id: ID
    text: String
  }
  `;

// Query
const queryName = "StaticDataUnderlyingCCYPairs";
const query = `
{
  StaticDataUnderlyingCCYPairs {
    id
    modified
    name
    description
    isActive
    comment
    foreignCurrency
    baseCurrency
    stealthTypeTypeSystem {
      id
      text
    }
    ccyPairGroupTypeSystem {
      id
      text
    }
    ccyPairFamilyTypeSystem {
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataUnderlyingCCYPairs: {
      url: "reference-data/currency-pair-with-attributes",
      dataPath: "$",
    },
  },
  StaticDataUnderlyingCCYPair: {
    modified: false,
  },
  StealthTypeTypeSystemOptions: {
    text: "$.value",
  },
  CCYPairGroupTypeSystemOptions: {
    text: "$.value",
  },
  CCYPairFamilyTypeSystemOptions: {
    text: "$.value",
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "name",
    title: "Underlying - CCY Pair",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "description",
    title: "Description",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "baseCurrency",
    title: "BaseCurrency",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "foreignCurrency",
    title: "ForeignCurrency",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "ccyPairFamilyTypeSystem.text",
    title: "Grp: CCY Pair Family",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "ccyPairGroupTypeSystem.text",
    title: "Grp: CCY Pair OnOffShore",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "comment",
    title: "Comment",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    comment: null,
    modified: false,
    name: "AUD/CAD",
    id: 1,
    foreignCurrency: "CAD",
    description: "Unknown",
    isActive: true,
    added: {
      by: "System",
      time: "2012-03-28T13:07:32.727+0000",
    },
    baseCurrency: "AUD",
    stealthTypeTypeSystem: {
      id: 2052,
      text: "Non-Core",
    },
    ccyPairGroupTypeSystem: {
      id: 1428,
      text: "N/A",
    },
    ccyPairFamilyTypeSystem: {
      id: 1216,
      text: "AUD",
    },
  },
  {
    comment: null,
    modified: false,
    name: "AUD/CHF",
    id: 2,
    foreignCurrency: "CHF",
    description: "Unknown",
    isActive: true,
    added: {
      by: "imrek",
      time: "2012-08-30T04:35:03.807+0000",
    },
    baseCurrency: "AUD",
    stealthTypeTypeSystem: {
      id: 2052,
      text: "Non-Core",
    },
    ccyPairGroupTypeSystem: {
      id: 1428,
      text: "N/A",
    },
    ccyPairFamilyTypeSystem: {
      id: 265,
      text: "EUR",
    },
  },
  {
    comment: null,
    modified: false,
    name: "AUD/CN1",
    id: 3,
    foreignCurrency: "CN1",
    description: "Unknown",
    isActive: true,
    added: {
      by: "khorh",
      time: "2013-06-26T05:06:09.247+0000",
    },
    baseCurrency: "AUD",
    stealthTypeTypeSystem: {
      id: 2052,
      text: "Non-Core",
    },
    ccyPairGroupTypeSystem: {
      id: 1429,
      text: "AUD/CN onshore/offshore",
    },
    ccyPairFamilyTypeSystem: {
      id: 1216,
      text: "AUD",
    },
  },
  {
    comment: null,
    modified: false,
    name: "AUD/CNY",
    id: 4,
    foreignCurrency: "CNY",
    description: "Unknown",
    isActive: true,
    added: {
      by: "khorh",
      time: "2013-06-26T05:06:09.303+0000",
    },
    baseCurrency: "AUD",
    stealthTypeTypeSystem: {
      id: 2052,
      text: "Non-Core",
    },
    ccyPairGroupTypeSystem: {
      id: 1429,
      text: "AUD/CN onshore/offshore",
    },
    ccyPairFamilyTypeSystem: {
      id: 1216,
      text: "AUD",
    },
  },
  {
    comment: null,
    modified: false,
    name: "AUD/DKK",
    id: 5,
    foreignCurrency: "DKK",
    description: "Unknown",
    isActive: true,
    added: {
      by: "imrek",
      time: "2012-08-30T04:35:03.817+0000",
    },
    baseCurrency: "AUD",
    stealthTypeTypeSystem: {
      id: 2052,
      text: "Non-Core",
    },
    ccyPairGroupTypeSystem: {
      id: 1428,
      text: "N/A",
    },
    ccyPairFamilyTypeSystem: {
      id: 265,
      text: "EUR",
    },
  },
  {
    comment: null,
    modified: false,
    name: "AUD/EUR",
    id: 6,
    foreignCurrency: "EUR",
    description: "Unknown",
    isActive: true,
    added: {
      by: "System",
      time: "2012-03-14T21:38:57.103+0000",
    },
    baseCurrency: "AUD",
    stealthTypeTypeSystem: {
      id: 2052,
      text: "Non-Core",
    },
    ccyPairGroupTypeSystem: {
      id: 1428,
      text: "N/A",
    },
    ccyPairFamilyTypeSystem: {
      id: 1216,
      text: "AUD",
    },
  },
  {
    comment: null,
    modified: false,
    name: "AUD/FJD",
    id: 7,
    foreignCurrency: "FJD",
    description: "Unknown",
    isActive: true,
    added: {
      by: "System",
      time: "2012-03-14T21:38:57.103+0000",
    },
    baseCurrency: "AUD",
    stealthTypeTypeSystem: {
      id: 2052,
      text: "Non-Core",
    },
    ccyPairGroupTypeSystem: {
      id: 1428,
      text: "N/A",
    },
    ccyPairFamilyTypeSystem: {
      id: 268,
      text: "Other",
    },
  },
  {
    comment: null,
    modified: false,
    name: "AUD/GBP",
    id: 8,
    foreignCurrency: "GBP",
    description: "Unknown",
    isActive: true,
    added: {
      by: "System",
      time: "2012-03-14T21:38:57.103+0000",
    },
    baseCurrency: "AUD",
    stealthTypeTypeSystem: {
      id: 2052,
      text: "Non-Core",
    },
    ccyPairGroupTypeSystem: {
      id: 1428,
      text: "N/A",
    },
    ccyPairFamilyTypeSystem: {
      id: 1216,
      text: "AUD",
    },
  },
  {
    comment: null,
    modified: false,
    name: "AUD/HKD",
    id: 9,
    foreignCurrency: "HKD",
    description: "Unknown",
    isActive: true,
    added: {
      by: "imrek",
      time: "2013-06-08T00:18:09.707+0000",
    },
    baseCurrency: "AUD",
    stealthTypeTypeSystem: {
      id: 2052,
      text: "Non-Core",
    },
    ccyPairGroupTypeSystem: {
      id: 1428,
      text: "N/A",
    },
    ccyPairFamilyTypeSystem: {
      id: 1216,
      text: "AUD",
    },
  },
  {
    comment: null,
    modified: false,
    name: "AUD/ID1",
    id: 10,
    foreignCurrency: "ID1",
    description: "Unknown",
    isActive: true,
    added: {
      by: "imrek",
      time: "2013-06-08T00:18:09.707+0000",
    },
    baseCurrency: "AUD",
    stealthTypeTypeSystem: {
      id: 2052,
      text: "Non-Core",
    },
    ccyPairGroupTypeSystem: {
      id: 1430,
      text: "AUD/ID onshore/offshore",
    },
    ccyPairFamilyTypeSystem: {
      id: 1352,
      text: "Asia Other",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

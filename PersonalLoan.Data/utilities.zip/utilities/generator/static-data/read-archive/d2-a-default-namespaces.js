// Category
const category = 'Regulatory';

// Type
const type = 'D2A Default Namespaces';

// GQL Schema
const schemaQuery =
  'StaticDataD2ADefaultNamespaces: [StaticDataD2ADefaultNamespace]';
const schemaType = `
  type StaticDataD2ADefaultNamespace {
    id: ID!
    modified: Boolean!
    uri: String!
    prefix: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataD2ADefaultNamespaces';
const query = `
{
  StaticDataD2ADefaultNamespaces {
    id
    modified
    uri
    prefix
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataD2ADefaultNamespaces: {
      url: 'reference-data/v1/d2adefault-namespaces',
      dataPath: '$',
    },
  },
  StaticDataD2ADefaultNamespace: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'prefix',
    title: 'Prefix',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'uri',
    title: 'Uri',
    filter: 'text',
    typeOf: 'string',
    width: '300px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    uri: 'http://www.xbrl.org/2003/linkbase',
    prefix: 'xmlns:link',
    id: 1,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.603+0000',
    },
  },
  {
    modified: false,
    uri: 'http://www.w3.org/1999/xlink',
    prefix: 'xmlns:xlink',
    id: 2,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.603+0000',
    },
  },
  {
    modified: false,
    uri: 'http://www.w3.org/2001/XMLSchema',
    prefix: 'xmlns:xs',
    id: 3,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.603+0000',
    },
  },
  {
    modified: false,
    uri: 'http://www.w3.org/2001/XMLSchema',
    prefix: 'xmlns:xsd',
    id: 4,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.603+0000',
    },
  },
  {
    modified: false,
    uri: 'http://www.xbrl.org/2003/iso4217',
    prefix: 'xmlns:iso4217',
    id: 5,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.620+0000',
    },
  },
  {
    modified: false,
    uri: 'http://www.apra.gov.au/reverseMappingFunctions',
    prefix: 'xmlns:apraReverseFuncs',
    id: 6,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.620+0000',
    },
  },
  {
    modified: false,
    uri: 'http://sbr.gov.au/icls/baf/bafot/bafot.02.05.data',
    prefix: 'xmlns:bafot.02.05',
    id: 7,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.620+0000',
    },
  },
  {
    modified: false,
    uri: 'http://sbr.gov.au/icls/py/pyde/pyde.02.00.data',
    prefix: 'xmlns:pyde.02.00',
    id: 8,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.620+0000',
    },
  },
  {
    modified: false,
    uri: 'http://sbr.gov.au/icls/py/pyin/pyin.02.00.data',
    prefix: 'xmlns:pyin.02.00',
    id: 9,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.620+0000',
    },
  },
  {
    modified: false,
    uri: 'http://sbr.gov.au/icls/py/pyin/pyin.02.02.data',
    prefix: 'xmlns:pyin.02.02',
    id: 10,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.620+0000',
    },
  },
  {
    modified: false,
    uri: 'http://sbr.gov.au/icls/py/pyin/pyin.02.09.data',
    prefix: 'xmlns:pyin.02.09',
    id: 11,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.620+0000',
    },
  },
  {
    modified: false,
    uri: 'http://sbr.gov.au/icls/py/pyin/pyin.02.22.data',
    prefix: 'xmlns:pyin.02.22',
    id: 12,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.620+0000',
    },
  },
  {
    modified: false,
    uri: 'http://sbr.gov.au/icls/py/pyin/pyin.02.27.data',
    prefix: 'xmlns:pyin.02.27',
    id: 13,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.637+0000',
    },
  },
  {
    modified: false,
    uri: 'http://sbr.gov.au/rprt/apra/apra.report.02.13.module',
    prefix: 'xmlns:report',
    id: 14,
    isActive: true,
    added: {
      by: 'makaroa',
      time: '2017-08-26T03:26:05.637+0000',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

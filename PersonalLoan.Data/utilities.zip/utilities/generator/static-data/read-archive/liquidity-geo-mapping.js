// Category
const category = 'Ungrouped';

// Type
const type = 'Liquidity Geo Mapping';

// GQL Schema
const schemaQuery =
  'StaticDataLiquidityGeoMappings: [StaticDataLiquidityGeoMapping]';
const schemaType = `
  type StaticDataLiquidityGeoMapping {
    modified: Boolean!
    node: NodeOption
    geographyMapping: GeographyMappingOption
    country: String
    added: Added!
  }
  
  type GeographyMappingOption {
    id: ID
    text: String
  }`;

// Query
const queryName = 'StaticDataLiquidityGeoMappings';
const query = `
{
  StaticDataLiquidityGeoMappings {
    modified
    node {
      id
      text
    }
    geographyMapping {
      id
      text
    }
    country
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataLiquidityGeoMappings: {
      url: 'reference-data/v1/liquidity-geo-mappings',
      dataPath: '$',
    },
  },
  StaticDataLiquidityGeoMapping: {
    modified: false,
  },
  GeographyMappingOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'country',
    title: 'Location',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'geographyMapping.text',
    title: 'Geography',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'node.text',
    title: 'Geography FullPath',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    added: {
      by: 'System',
      time: '2018-09-15T07:42:42.043+0000',
    },
    node: {
      id: 7187,
      text: 'ANZ Group|APEA',
    },
    geographyMapping: {
      id: 1,
      text: 'Australia',
    },
    country: 'APEA',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2018-09-15T07:42:42.043+0000',
    },
    node: {
      id: 7187,
      text: 'ANZ Group|APEA',
    },
    geographyMapping: {
      id: 2,
      text: 'Hong Kong',
    },
    country: 'APEA Level 1',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2018-09-15T07:42:42.043+0000',
    },
    node: {
      id: 7187,
      text: 'ANZ Group|APEA',
    },
    geographyMapping: {
      id: 3,
      text: 'NZ',
    },
    country: 'APEA Level 2',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2018-09-15T07:42:42.043+0000',
    },
    node: {
      id: 7188,
      text: 'ANZ Group|APEA|Asia',
    },
    geographyMapping: {
      id: 4,
      text: 'Singapore',
    },
    country: 'Asia Level 1',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2018-09-15T07:42:42.043+0000',
    },
    node: {
      id: 7188,
      text: 'ANZ Group|APEA|Asia',
    },
    geographyMapping: {
      id: 5,
      text: 'E&A',
    },
    country: 'Asia Level 2',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2018-09-15T07:42:42.043+0000',
    },
    node: {
      id: 7189,
      text: 'ANZ Group|AUST',
    },
    geographyMapping: {
      id: 6,
      text: 'Other',
    },
    country: 'AUS',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2018-09-15T07:42:42.043+0000',
    },
    node: {
      id: 7189,
      text: 'ANZ Group|AUST',
    },
    geographyMapping: null,
    country: 'AUS Level 1',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2018-09-15T07:42:42.043+0000',
    },
    node: {
      id: 7189,
      text: 'ANZ Group|AUST',
    },
    geographyMapping: null,
    country: 'AUS Level 2',
  },
  {
    modified: false,
    added: {
      by: 'System',
      time: '2018-09-15T07:42:42.043+0000',
    },
    node: {
      id: 7189,
      text: 'ANZ Group|AUST',
    },
    geographyMapping: null,
    country: 'AUS Sub',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

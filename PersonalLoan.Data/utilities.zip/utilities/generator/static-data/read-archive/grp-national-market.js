// Category
const category = 'Underlyings';

// Type
const type = 'Grp: NationalMarket';

// GQL Schema
const schemaQuery =
  'StaticDataGrpNationalMarkets: [StaticDataGrpNationalMarket]';
const schemaType = `
  type StaticDataGrpNationalMarket {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataGrpNationalMarkets';
const query = `
{
  StaticDataGrpNationalMarkets {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataGrpNationalMarkets: {
      url: 'reference-data/v1/type-system-parameters',
      dataPath: '$[?(@.system.id == 1031)]',
    },
  },
  StaticDataGrpNationalMarket: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'value',
    title: 'Value',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    id: 88,
    modified: false,
    description: null,
    value: 'Australia',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:53:46.310+0000',
    },
  },
  {
    id: 91,
    modified: false,
    description: null,
    value: 'Europe',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:53:46.310+0000',
    },
  },
  {
    id: 92,
    modified: false,
    description: null,
    value: 'Hong Kong',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:53:46.310+0000',
    },
  },
  {
    id: 93,
    modified: false,
    description: null,
    value: 'Japan',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:53:46.310+0000',
    },
  },
  {
    id: 94,
    modified: false,
    description: null,
    value: 'Korea',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:53:46.310+0000',
    },
  },
  {
    id: 95,
    modified: false,
    description: null,
    value: 'Non Equity',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:53:46.310+0000',
    },
  },
  {
    id: 96,
    modified: false,
    description: null,
    value: 'Singapore',
    isActive: true,
    added: {
      by: 'System',
      time: '2012-02-24T06:53:46.310+0000',
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

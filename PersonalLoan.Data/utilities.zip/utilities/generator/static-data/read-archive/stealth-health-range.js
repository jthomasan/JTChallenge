// Category
const category = "Stealth";

// Type
const type = "Stealth Health Range";

// GQL Schema
const schemaQuery =
  "StaticDataStealthHealthRanges: [StaticDataStealthHealthRangeType]";
const schemaType = `
  type StaticDataStealthHealthRangeType {
    id: ID!
    modified: Boolean!
    name: String!
    rangeFrom: Float!
    rangeTo: Float!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataStealthHealthRanges";
const query = `
{
  StaticDataStealthHealthRanges {
    id
    modified
    name
    rangeFrom
    rangeTo
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataStealthHealthRanges: {
      url: "reference-data/v1/stealth-health-ranges",
      dataPath: "$",
    },
  },
  StaticDataStealthHealthRangeType: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "name",
    title: "Name",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "rangeFrom",
    title: "From",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
    defaultSortColumn: true,
  },
  {
    field: "rangeTo",
    title: "To",
    filter: "numeric",
    typeOf: "number",
    width: "100px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    isActive: true,
    added: {
      by: "mangalar",
      time: "2018-03-17T15:29:33.230+0000",
    },
    rangeFrom: 0,
    rangeTo: 5,
    name: "Within 5%",
    id: 1,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "mangalar",
      time: "2018-03-17T15:29:33.230+0000",
    },
    rangeFrom: 5,
    rangeTo: 10,
    name: "5% to 10%",
    id: 2,
  },
  {
    modified: false,
    isActive: true,
    added: {
      by: "mangalar",
      time: "2018-03-17T15:29:33.230+0000",
    },
    rangeFrom: 10,
    rangeTo: 1000000,
    name: "Outside 10%",
    id: 3,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

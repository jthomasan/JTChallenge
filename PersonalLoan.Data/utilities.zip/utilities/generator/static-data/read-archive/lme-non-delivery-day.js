// Category
const category = 'Ungrouped';

// Type
const type = 'LME Non Delivery Day';

// GQL Schema
const schemaQuery =
  'StaticDataLMENonDeliveryDays: [StaticDataLMENonDeliveryDay]';
const schemaType = `
  type StaticDataLMENonDeliveryDay {
    modified: Boolean!
    date: DateTime!
    isLMENonDelivery: Boolean!
  }`;

// Query
const queryName = 'StaticDataLMENonDeliveryDays';
const query = `
{
  StaticDataLMENonDeliveryDays {
    modified
    date
    isLMENonDelivery
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataLMENonDeliveryDays: {
      url: 'reference-data/v1/lme-non-delivery-day',
      dataPath: '$',
    },
  },
  StaticDataLMENonDeliveryDay: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'date',
    title: 'LME Non - Delivery Days',
    filter: 'date',
    typeOf: 'date',
    width: '180px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
    defaultSortColumn: true,
  },
  {
    field: 'isLMENonDelivery',
    title: 'Is LME Non Delivery Day',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '150px',
    cell: 'GridCheckboxCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    date: '2009-05-25T00:00:00.000+0000',
    isLMENonDelivery: true,
  },
  {
    modified: false,
    date: '2009-08-31T00:00:00.000+0000',
    isLMENonDelivery: true,
  },
  {
    modified: false,
    date: '2009-09-07T00:00:00.000+0000',
    isLMENonDelivery: true,
  },
  {
    modified: false,
    date: '2009-10-12T00:00:00.000+0000',
    isLMENonDelivery: true,
  },
  {
    modified: false,
    date: '2009-11-11T00:00:00.000+0000',
    isLMENonDelivery: true,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

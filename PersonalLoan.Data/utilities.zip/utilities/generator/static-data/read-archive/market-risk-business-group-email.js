// Category
const category = 'Ungrouped';

// Type
const type = 'Market Risk Business Group Email';

// GQL Schema
const schemaQuery =
  'MarketRiskBusinessGroupEmailMappings: [MarketRiskBusinessGroupEmailMapping]';
const schemaType = `
  type MarketRiskBusinessGroupEmailMapping {
    id: ID!
    modified: Boolean!
    snapshot: String
    marketRiskBusinessGroup: MarketRiskBusinessGroup
    emailToList: String
    emailCcList: String
    added: Added!
  }
  
  type MarketRiskBusinessGroup {
    id: ID
    text: String
  }`;

// Query
const queryName = 'MarketRiskBusinessGroupEmailMappings';
const query = `
{
  MarketRiskBusinessGroupEmailMappings {
    id
    modified
    snapshot
    marketRiskBusinessGroup {
      id
      text
    }
    emailToList
    emailCcList
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    MarketRiskBusinessGroupEmailMappings: {
      url: 'limits/v1/limit-market-risk-business-group-email',
      dataPath: '$',
    },
  },
  MarketRiskBusinessGroupEmailMapping: {
    modified: false,
  },
  MarketRiskBusinessGroup: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  
  {
    field: 'marketRiskBusinessGroup.text',
    title: 'MRB Group',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'snapshot',
    title: 'SnapShot',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'emailToList',
    title: 'Email To List',
    filter: 'text',
    typeOf: 'string',
    width: '300px',
  },
  {
    field: 'emailCcList',
    title: 'Email CC List',
    filter: 'text',
    typeOf: 'string',
    width: '300px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];


module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
};

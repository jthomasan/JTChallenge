// Category
const category = 'Specific Risk';

// Type
const type = 'Specific Risk Short Term Issue';

// GQL Schema
const schemaQuery =
  'StaticDataSpecificRiskShortTermIssues: [StaticDataSpecificRiskShortTermIssue]';
const schemaType = `
  type StaticDataSpecificRiskShortTermIssue {
    id: ID!
    modified: Boolean!
    sTRatingBandTypeSystem: STRatingBandTypeSystemOption
    resecuritisationExposures: Float
    securitisationExposures: Float
    added: Added!
  }
  
  type STRatingBandTypeSystemOption {
    id: ID
    text: String
  }`;

// Query
const queryName = 'StaticDataSpecificRiskShortTermIssues';
const query = `
{
  StaticDataSpecificRiskShortTermIssues {
    id
    modified
    sTRatingBandTypeSystem {
      id
      text
    }
    resecuritisationExposures
    securitisationExposures
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataSpecificRiskShortTermIssues: {
      url: 'reference-data/v1/srshort-term-issues',
      dataPath: '$',
    },
  },
  StaticDataSpecificRiskShortTermIssue: {
    modified: false,
    sTRatingBandTypeSystem: '$.STRatingBandTypeSystem',
  },
  STRatingBandTypeSystemOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'sTRatingBandTypeSystem.text',
    title: 'ST Rating Band',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'securitisationExposures',
    title: 'Securitisation Exposures (%)',
    filter: 'numeric',
    typeOf: 'number',
    width: '190px',
  },
  {
    field: 'resecuritisationExposures',
    title: 'Re-Securitisation Exposures (%)',
    filter: 'numeric',
    typeOf: 'number',
    width: '200px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    added: {
      by: 'foonga',
      time: '2012-05-09T00:00:00.000+0000',
    },
    resecuritisationExposures: 3.2,
    securitisationExposures: 1.6,
    sTRatingBandTypeSystem: {
      id: 1190,
      text: 'A-1/P-1',
    },
    id: 1,
  },
  {
    modified: false,
    added: {
      by: 'foonga',
      time: '2012-05-09T00:00:00.000+0000',
    },
    resecuritisationExposures: 8,
    securitisationExposures: 4,
    sTRatingBandTypeSystem: {
      id: 1191,
      text: 'A-2/P-2',
    },
    id: 2,
  },
  {
    modified: false,
    added: {
      by: 'foonga',
      time: '2012-05-09T00:00:00.000+0000',
    },
    resecuritisationExposures: 18,
    securitisationExposures: 8,
    sTRatingBandTypeSystem: {
      id: 1192,
      text: 'A-3/P-3',
    },
    id: 3,
  },
  {
    modified: false,
    added: {
      by: 'foonga',
      time: '2012-05-09T00:00:00.000+0000',
    },
    resecuritisationExposures: 100,
    securitisationExposures: 100,
    sTRatingBandTypeSystem: {
      id: 1193,
      text: 'Below A-3/P-3 or unrated',
    },
    id: 4,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

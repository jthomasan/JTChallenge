// Category
const category = "Holding Period";

// Type
const type = "Holding Period Trade";

// GQL Schema
const schemaQuery =
  "StaticDataHoldingPeriodTrades(cob: Date): [StaticDataHoldingPeriodTradeType]";
const schemaType = `
  type StaticDataHoldingPeriodTradeType {
    modified: Boolean!
    currencyName: String
    family: String
    group: String
    isActive: Boolean
    added: Added!
    issuerName: String
    baseNotional: Float
    instrumentName: String
    isInMRE: Boolean
    isExcludedTrade: Boolean
    isLongDated: Boolean
    isReplacedTrade: Boolean
    isSettlementTrade: Boolean
    maturityDate: Int
    notional: Int
    portfolioName: String
    rank: String
    replaceDate: Int
    replaced: Int
    reportDate: Int!
    nb: Int!
  }`;

// Query
const queryName = "StaticDataHoldingPeriodTrades";
const query = ({ cob }) => `
{
  StaticDataHoldingPeriodTrades (cob: ${cob}) {
    modified
    currencyName
    family
    group
    issuerName
    baseNotional
    instrumentName
    isInMRE
    isExcludedTrade
    isLongDated
    isReplacedTrade
    isSettlementTrade
    maturityDate
    notional
    portfolioName
    rank
    replaceDate
    replaced
    reportDate
    nb
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataHoldingPeriodTrades: {
      url: "reference-data/v1/holding-period-trade?cobDate={args.cob}",
      dataPath: "$",
    },
  },
  StaticDataHoldingPeriodTradeType: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "reportDate",
    title: "Report Date",
    filter: "numeric",
    typeOf: "numeric",
    width: "120px",
  },
  {
    field: "family",
    title: "Family",
    filter: "text",
    typeOf: "string",
    width: "90px",
  },
  {
    field: "group",
    title: "Group",
    filter: "text",
    typeOf: "string",
    width: "90px",
  },
  {
    field: "nb",
    title: "Trade ID",
    filter: "text",
    typeOf: "string",
    width: "110px",
    defaultSortColumn: true,
  },
  {
    field: "isInMRE",
    title: "Status",
    filter: "boolean",
    cell: "GridCheckboxCell",
    typeOf: "boolean",
    width: "90px",
  },
  {
    field: "instrumentName",
    title: "Instrument",
    filter: "text",
    typeOf: "string",
    width: "130px",
  },
  {
    field: "portfolioName",
    title: "Portfolio",
    filter: "text",
    typeOf: "string",
    width: "130px",
  },
  {
    field: "currencyName",
    title: "Currency",
    filter: "text",
    typeOf: "string",
    width: "100px",
  },
  {
    field: "notional",
    title: "Notional",
    filter: "numeric",
    typeOf: "String",
    width: "100px",
  },
  {
    field: "baseNotional",
    title: "Base Notional",
    filter: "numeric",
    typeOf: "numeric",
    width: "130px",
  },
  {
    field: "maturityDate",
    title: "Maturity Date",
    filter: "numeric",
    typeOf: "numeric",
    width: "130px",
  },
  {
    field: "issuerName",
    title: "Issuer",
    filter: "text",
    typeOf: "string",
    width: "110px",
  },
  {
    field: "rank",
    title: "Rank",
    filter: "text",
    typeOf: "string",
    width: "90px",
  },
  {
    field: "isLongDated",
    title: "Is Long Dated",
    filter: "boolean",
    cell: "GridCheckboxCell",
    typeOf: "boolean",
    width: "120px",
  },
  {
    field: "isSettlementTrade",
    title: "Is Settlement Trade",
    filter: "boolean",
    cell: "GridCheckboxCell",
    typeOf: "boolean",
    width: "150px",
  },
  {
    field: "isExcludedTrade",
    title: "Is Excluded Trade",
    filter: "boolean",
    cell: "GridCheckboxCell",
    typeOf: "boolean",
    width: "140px",
  },
  {
    field: "replaceDate",
    title: "Replace Date",
    filter: "numeric",
    typeOf: "numeric",
    width: "120px",
  },
  {
    field: "replaced",
    title: "Replaced ID",
    filter: "numeric",
    typeOf: "numeric",
    width: "110px",
  },
  {
    field: "isReplacedTrade",
    title: "Is Replaced Trade",
    filter: "boolean",
    cell: "GridCheckboxCell",
    typeOf: "boolean",
    width: "140px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    currencyName: "AUD",
    family: "IRD",
    group: "BOND",
    isActive: true,
    added: {
      by: "System",
      time: "2020-05-07T02:26:08.010+0000",
    },
    issuerName: "1002Z NZ",
    issuer: 599,
    baseNotional: -100000,
    currency: 1,
    instrument: 35482,
    instrumentName: "TPNZ0608214.25",
    isExcludedTrade: false,
    isInMRE: false,
    isLongDated: true,
    isReplacedTrade: false,
    isSettlementTrade: false,
    maturityDate: 20210806,
    nb: 21475984,
    notional: -100000,
    portfolio: 274,
    portfolioName: "CRDT CASH AU",
    rank: "SNR",
    replaceDate: 20200504,
    replaced: 0,
    reportDate: 20200505,
    id: -630681439,
  },
  {
    modified: false,
    currencyName: "AUD",
    family: "IRD",
    group: "BOND",
    isActive: true,
    added: {
      by: "System",
      time: "2020-05-07T02:26:08.010+0000",
    },
    issuerName: "1002Z NZ",
    issuer: 599,
    baseNotional: -500000,
    currency: 1,
    instrument: 35482,
    instrumentName: "TPNZ0608214.25",
    isExcludedTrade: false,
    isInMRE: false,
    isLongDated: true,
    isReplacedTrade: false,
    isSettlementTrade: false,
    maturityDate: 20210806,
    nb: 21627135,
    notional: -500000,
    portfolio: 274,
    portfolioName: "CRDT CASH AU",
    rank: "SNR",
    replaceDate: 20200504,
    replaced: 0,
    reportDate: 20200505,
    id: -630650015,
  },
  {
    modified: false,
    currencyName: "AUD",
    family: "IRD",
    group: "BOND",
    isActive: true,
    added: {
      by: "System",
      time: "2020-05-07T02:26:08.010+0000",
    },
    issuerName: "1002Z NZ",
    issuer: 599,
    baseNotional: 600000,
    currency: 1,
    instrument: 35482,
    instrumentName: "TPNZ0608214.25",
    isExcludedTrade: false,
    isInMRE: false,
    isLongDated: true,
    isReplacedTrade: false,
    isSettlementTrade: false,
    maturityDate: 20210806,
    nb: 22002851,
    notional: 600000,
    portfolio: 274,
    portfolioName: "CRDT CASH AU",
    rank: "SNR",
    replaceDate: 20200504,
    replaced: 0,
    reportDate: 20200505,
    id: -630649567,
  },
  {
    modified: false,
    currencyName: "NZD",
    family: "IRD",
    group: "BOND",
    isActive: true,
    added: {
      by: "System",
      time: "2020-05-07T02:26:08.010+0000",
    },
    issuerName: "1003Z NZ",
    issuer: 600,
    baseNotional: -4889988.011912274,
    currency: 25,
    instrument: 60259,
    instrumentName: "ASB090720",
    isExcludedTrade: false,
    isInMRE: false,
    isLongDated: false,
    isReplacedTrade: false,
    isSettlementTrade: false,
    maturityDate: 20200709,
    nb: 21997710,
    notional: -5200000,
    portfolio: 419,
    portfolioName: "D FLT CRED NZ",
    rank: "SNR",
    replaceDate: 20200504,
    replaced: 0,
    reportDate: 20200505,
    id: -630672103,
  },
  {
    modified: false,
    currencyName: "NZD",
    family: "IRD",
    group: "BOND",
    isActive: true,
    added: {
      by: "System",
      time: "2020-05-07T02:26:08.010+0000",
    },
    issuerName: "1003Z NZ",
    issuer: 600,
    baseNotional: 4889988.011912274,
    currency: 25,
    instrument: 60259,
    instrumentName: "ASB090720",
    isExcludedTrade: false,
    isInMRE: false,
    isLongDated: false,
    isReplacedTrade: false,
    isSettlementTrade: false,
    maturityDate: 20200709,
    nb: 21997750,
    notional: 5200000,
    portfolio: 419,
    portfolioName: "D FLT CRED NZ",
    rank: "SNR",
    replaceDate: 20200504,
    replaced: 0,
    reportDate: 20200505,
    id: -630571318,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

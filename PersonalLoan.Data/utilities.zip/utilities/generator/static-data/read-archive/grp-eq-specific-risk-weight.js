// Category
const category = "Underlyings";

// Type
const type = "Grp: EQ Specific Risk Weight";

// GQL Schema
const schemaQuery =
  "StaticDataEQSpecificRiskWeights: [StaticDataEQSpecificRiskWeight]";
const schemaType = `
  type StaticDataEQSpecificRiskWeight {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataEQSpecificRiskWeights";
const query = `
{
  StaticDataEQSpecificRiskWeights {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataEQSpecificRiskWeights: {
      url: "reference-data/type-system-parameters",
      dataPath: "$[?(@.system.id == 1040)]",
    },
  },
  StaticDataEQSpecificRiskWeight: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "value",
    title: "Value",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    id: 1071,
    modified: false,
    description: null,
    value: "2%",
    isActive: true,
    added: {
      by: "System",
      time: "2012-04-20T00:00:00.000+0000",
    },
  },
  {
    id: 1072,
    modified: false,
    description: null,
    value: "8%",
    isActive: true,
    added: {
      by: "System",
      time: "2012-04-20T00:00:00.000+0000",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

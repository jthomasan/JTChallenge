// Category
const category = "Tenor Buckets";

// Type
const type = "Pillars - Repo STF Sensivity";

// GQL Schema
const schemaQuery =
  "StaticDataRepoStfSensivities: [StaticDataRepoStfSensivityType]";
const schemaType = `
  type StaticDataRepoStfSensivityType {
    modified: Boolean!
    net7d: String
    net1y: String
    net3m: String
    net3yPlus: String
    term: String!
    termUnit: Int!
    net9m: String
    net3y: String
  }`;

// Query
const queryName = "StaticDataRepoStfSensivities";
const query = `
{
  StaticDataRepoStfSensivities {
    modified
    net7d
    net1y
    net3m
    net3yPlus
    term
    termUnit
    net9m
    net3y
  } 
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataRepoStfSensivities: {
      url: "reference-data/v1/bucket-stfrepo",
      dataPath: "$",
    },
  },
  StaticDataRepoStfSensivityType: {
    modified: false,
    termUnit: {
      dataPath: "$.term",
      decorators: [{ name: "pillarsTermUnit" }],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "termUnit",
    title: "Days to Maturity",
    filter: "text",
    typeOf: "string",
    width: "150px",
    defaultSortColumn: true,
    cell: "GridCustomCell",
    extras: {
      displayField: "term",
    },
  },
  {
    field: "net7d",
    title: "7d",
    filter: "numeric",
    typeOf: "number",
    width: "80px",
  },
  {
    field: "net3m",
    title: "3m",
    filter: "numeric",
    typeOf: "number",
    width: "80px",
  },
  {
    field: "net9m",
    title: "9m",
    filter: "numeric",
    typeOf: "number",
    width: "80px",
  },
  {
    field: "net1y",
    title: "1y",
    filter: "numeric",
    typeOf: "number",
    width: "80px",
  },
  {
    field: "net3y",
    title: "3y",
    filter: "numeric",
    typeOf: "number",
    width: "80px",
  },
  {
    field: "net3yPlus",
    title: "3yPlus",
    filter: "numeric",
    typeOf: "number",
    width: "90px",
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net7d: "100",
    net1y: "0",
    net3m: "0",
    net3yPlus: "0",
    term: "1",
    termUnit: 1,
    net9m: "0",
    net3y: "0",
  },
  {
    modified: false,
    net7d: "0",
    net1y: "0",
    net3m: "100",
    net3yPlus: "0",
    term: "10",
    termUnit: 10,
    net9m: "0",
    net3y: "0",
  },
  {
    modified: false,
    net7d: "0",
    net1y: "0",
    net3m: "0",
    net3yPlus: "0",
    term: "100",
    termUnit: 100,
    net9m: "100",
    net3y: "0",
  },
  {
    modified: false,
    net7d: "0",
    net1y: "0",
    net3m: "0",
    net3yPlus: "0",
    term: "1000",
    termUnit: 1000,
    net9m: "0",
    net3y: "100",
  },
  {
    modified: false,
    net7d: "0",
    net1y: "0",
    net3m: "0",
    net3yPlus: "100",
    term: "10000",
    termUnit: 10000,
    net9m: "0",
    net3y: "0",
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

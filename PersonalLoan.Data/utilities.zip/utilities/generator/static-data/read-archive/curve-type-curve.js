// Category
const category = "Underlyings";

// Type
const type = "CurveType:Curve";

// GQL Schema
const schemaQuery = "StaticDataCurveTypeCurves: [StaticDataCurveTypeCurve]";
const schemaType = `
  type StaticDataCurveTypeCurve {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataCurveTypeCurves";
const query = `
{
  StaticDataCurveTypeCurves {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCurveTypeCurves: {
      url: "reference-data/type-system-parameters",
      dataPath: "$[?(@.system.id == 1054)]",
    },
  },
  StaticDataCurveTypeCurve: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "value",
    title: "Value",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    id: 1296,
    modified: false,
    description: "Single CCY",
    value: "SCCY",
    isActive: true,
    added: {
      by: "System",
      time: "2012-09-21T00:00:00.000+0000",
    },
  },
  {
    id: 1297,
    modified: false,
    description: "XCCY",
    value: "XCCY",
    isActive: true,
    added: {
      by: "System",
      time: "2012-09-21T00:00:00.000+0000",
    },
  },
  {
    id: 1298,
    modified: false,
    description: "N/A",
    value: "N/A",
    isActive: true,
    added: {
      by: "System",
      time: "2012-09-21T00:00:00.000+0000",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

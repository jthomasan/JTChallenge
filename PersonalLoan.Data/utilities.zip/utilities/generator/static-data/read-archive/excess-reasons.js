// Category
const category = 'Limits';

// Type
const type = 'Excess Reasons';

// GQL Schema
const schemaQuery =
  'StaticDataExcessReasons: [StaticDataExcessReason]';
const schemaType = `
  type StaticDataExcessReason {
    id: ID!
    modified: Boolean!
    description: String
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataExcessReasons';
const query = `
{
  StaticDataExcessReasons {
    id
    modified
    description
    isActive
    added{
      time
      by
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataExcessReasons: {
      url: 'limits/v1/limit-excess-reason',
      dataPath: '$',
    },
  },
  StaticDataExcessReason: {
    modified: false,
    id: "$.excessReasonId",
    isActive: "$.active"
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'description',
    title: 'Reason',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    defaultSortColumn: true,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

// Mock Data
const mockData = [
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

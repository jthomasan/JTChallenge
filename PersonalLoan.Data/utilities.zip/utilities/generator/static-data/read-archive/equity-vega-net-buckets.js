// Category
const category = 'Tenor Buckets';

// Type
const type = 'Equity Vega Net Buckets';

// GQL Schema
const schemaQuery =
  'StaticDataEquityVegaNetBuckets: [StaticDataEquityVegaNetBucket]';
const schemaType = `
  type StaticDataEquityVegaNetBucket {
    modified: Boolean!
    termUnit: Int!
    net1m: String!
    net2m: String!
    net1y: String!
    net2y: String!
    net6m: String!
    net3m: String!
    term: String!
    net3y: String!
    net4y: String!
  }`;

// Query
const queryName = 'StaticDataEquityVegaNetBuckets';
const query = `
{
  StaticDataEquityVegaNetBuckets {
    modified
    term
    termUnit
    net1m
    net2m
    net3m
    net6m
    net1y
    net2y
    net3y
    net4y
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataEquityVegaNetBuckets: {
      url: 'reference-data/v1/bucket-equity-vega',
      dataPath: '$',
    },
  },
  StaticDataEquityVegaNetBucket: {
    modified: false,
    termUnit: '$.term',
    net1m: {
      dataPath: '$.net1m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net2m: {
      dataPath: '$.net2m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net3m: {
      dataPath: '$.net3m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net6m: {
      dataPath: '$.net6m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net1y: {
      dataPath: '$.net1y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net2y: {
      dataPath: '$.net2y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net3y: {
      dataPath: '$.net3y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
    net4y: {
      dataPath: '$.net4y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 1,
            applyToDecimalsOnly: true,
          },
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net1m',
    title: 'Net1m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net2m',
    title: 'Net2m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net6m',
    title: 'Net6m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1y',
    title: 'Net1y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net2y',
    title: 'Net2y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3y',
    title: 'Net3y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net4y',
    title: 'Net4y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net1m: '0',
    net2m: '0',
    net1y: '0',
    net2y: '0',
    net6m: '0',
    net3m: '0',
    termUnit: 10,
    term: '10y',
    net3y: '0',
    net4y: '100',
  },
  {
    modified: false,
    net1m: '100',
    net2m: '0',
    net1y: '0',
    net2y: '0',
    net6m: '0',
    net3m: '0',
    termUnit: 1,
    term: '1m',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net1m: '100',
    net2m: '0',
    net1y: '0',
    net2y: '0',
    net6m: '0',
    net3m: '0',
    termUnit: 1,
    term: '1w',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net1m: '0',
    net2m: '0',
    net1y: '100',
    net2y: '0',
    net6m: '0',
    net3m: '0',
    termUnit: 1,
    term: '1y',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net1m: '0',
    net2m: '100',
    net1y: '0',
    net2y: '0',
    net6m: '0',
    net3m: '0',
    termUnit: 2,
    term: '2m',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net1m: '0',
    net2m: '0',
    net1y: '0',
    net2y: '100',
    net6m: '0',
    net3m: '0',
    termUnit: 2,
    term: '2y',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net1m: '0',
    net2m: '0',
    net1y: '0',
    net2y: '0',
    net6m: '0',
    net3m: '100',
    termUnit: 3,
    term: '3m',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net1m: '0',
    net2m: '0',
    net1y: '0',
    net2y: '0',
    net6m: '0',
    net3m: '0',
    termUnit: 3,
    term: '3y',
    net3y: '100',
    net4y: '0',
  },
  {
    modified: false,
    net1m: '0',
    net2m: '0',
    net1y: '0',
    net2y: '0',
    net6m: '0',
    net3m: '0',
    termUnit: 4,
    term: '4y',
    net3y: '0',
    net4y: '100',
  },
  {
    modified: false,
    net1m: '0',
    net2m: '0',
    net1y: '0',
    net2y: '0',
    net6m: '0',
    net3m: '0',
    termUnit: 5,
    term: '5y',
    net3y: '0',
    net4y: '100',
  },
  {
    modified: false,
    net1m: '0',
    net2m: '0',
    net1y: '0',
    net2y: '0',
    net6m: '100',
    net3m: '0',
    termUnit: 6,
    term: '6m',
    net3y: '0',
    net4y: '0',
  },
  {
    modified: false,
    net1m: '0',
    net2m: '0',
    net1y: '0',
    net2y: '0',
    net6m: '0',
    net3m: '0',
    termUnit: 7,
    term: '7y',
    net3y: '0',
    net4y: '100',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

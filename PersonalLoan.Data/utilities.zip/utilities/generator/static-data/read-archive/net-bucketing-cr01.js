// Category
const category = 'Tenor Buckets';

// Type
const type = 'Net Bucketing - CR01';

// GQL Schema
const schemaQuery =
  'StaticDataNetBucketingCR01List: [StaticDataNetBucketingCR01]';
const schemaType = `
  type StaticDataNetBucketingCR01 {
    modified: Boolean!
    term: String!
    termUnit: Int!
    net10y: String!
    net30yPlus: String!
    net20y: String!
    net1y: String!
    net3m: String!
    net5y: String!
    net3y: String!
  }`;

// Query
const queryName = 'StaticDataNetBucketingCR01List';
const query = `
{
  StaticDataNetBucketingCR01List {
    modified
    term
    termUnit
    net3m
    net1y
    net3y
    net5y
    net10y
    net20y
    net30yPlus
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataNetBucketingCR01List: {
      url: 'reference-data/v1/net-bucket-cr01',
      dataPath: '$',
    },
  },
  StaticDataNetBucketingCR01: {
    modified: false,
    termUnit: {
      dataPath: '$.term',
      decorators: [
        {
          name: 'vegaBuckerTermUnit',
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'numeric',
    typeOf: 'number',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net1y',
    title: 'Net1y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net3y',
    title: 'Net3y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net5y',
    title: 'Net5y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net10y',
    title: 'Net10y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net20y',
    title: 'Net20y',
    filter: 'numeric',
    typeOf: 'number',
    width: '90px',
  },
  {
    field: 'net30yPlus',
    title: 'Net30yPlus',
    filter: 'numeric',
    typeOf: 'number',
    width: '110px',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net10y: '100',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '0',
    term: '10y',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '80',
    net30yPlus: '0',
    net20y: '20',
    net1y: '0',
    net3m: '0',
    term: '12y',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '50',
    net30yPlus: '0',
    net20y: '50',
    net1y: '0',
    net3m: '0',
    term: '15y',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '100',
    net3m: '0',
    term: '1y',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '100',
    net1y: '0',
    net3m: '0',
    term: '20y',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '50',
    net20y: '50',
    net1y: '0',
    net3m: '0',
    term: '25y',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '50',
    net3m: '0',
    term: '2y',
    net5y: '0',
    net3y: '50',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '100',
    net20y: '0',
    net1y: '0',
    net3m: '0',
    term: '30y',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '100',
    term: '3m',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '0',
    term: '3y',
    net5y: '0',
    net3y: '100',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '0',
    term: '4y',
    net5y: '50',
    net3y: '50',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '0',
    term: '5y',
    net5y: '100',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '33.333333333333329',
    net3m: '66.666666666666657',
    term: '6m',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '20',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '0',
    term: '6y',
    net5y: '80',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '40',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '0',
    term: '7y',
    net5y: '60',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '60',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '0',
    term: '8y',
    net5y: '40',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '0',
    net30yPlus: '0',
    net20y: '0',
    net1y: '66.666666667',
    net3m: '33.333333333',
    term: '9m',
    net5y: '0',
    net3y: '0',
  },
  {
    modified: false,
    net10y: '80',
    net30yPlus: '0',
    net20y: '0',
    net1y: '0',
    net3m: '0',
    term: '9y',
    net5y: '20',
    net3y: '0',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

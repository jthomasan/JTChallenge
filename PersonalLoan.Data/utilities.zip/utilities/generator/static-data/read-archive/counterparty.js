// Category
const category = 'Counterparty';

// Type
const type = 'Counterparty';

// GQL Schema
const schemaQuery = 'StaticDataCounterparties: [StaticDataCounterparty]';
const schemaType = `
  type StaticDataCounterparty {
    id: ID!
    modified: Boolean
    comment: String
    razorCode: String
    interdeskDescription: String
    sTFSectorTypeSystem: STFSectorTypeSystemOption
    controlPoint: String
    counterpartyName: String
    country: CountryOption
    sourceKey: SourceKeyOption
    interbank: String
    isInternal: Boolean
    setNo: String
    counterpartyExternalId: String
    cTPYCOUNTRYOFRISK: String
    cOUNTRYOFDOMICILE: String
    cTPYCCR: String
    cTPYRazorName: String
    internalGroupTypeSystem: InternalGroupTypeSystemOption
    added: Added
  }
  
  type STFSectorTypeSystemOption {
    id: ID
    text: String
  }
  
  type CountryOption {
    id: ID
    text: String
  }
  
  type SourceKeyOption {
    id: ID
    text: String
  }
  
  type InternalGroupTypeSystemOption {
    id: ID
    text: String
  }`;

// Query
const queryName = 'StaticDataCounterparties';
const query = `
{
  StaticDataCounterparties {
    id
    modified
    comment
    razorCode
    interdeskDescription
    sTFSectorTypeSystem {
      id
      text
    }
    controlPoint
    counterpartyName
    country {
      id
      text
    }
    sourceKey {
      id
      text
    }
    interbank
    isInternal
    setNo
    counterpartyExternalId
    cTPYCOUNTRYOFRISK
    cOUNTRYOFDOMICILE
    cTPYCCR
    cTPYRazorName
    internalGroupTypeSystem {
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCounterparties: {
      url: 'reference-data/v1/counter-party-with-attribute',
      dataPath: '$',
    },
  },
  StaticDataCounterparty: {
    modified: false,
    sTFSectorTypeSystem: '$.STFSectorTypeSystem',
    country: '$.Country',
    sourceKey: '$.SourceKey',
    cTPYCOUNTRYOFRISK: '$.CTPYCOUNTRYOFRISK',
    cOUNTRYOFDOMICILE: '$.COUNTRYOFDOMICILE',
    cTPYCCR: '$.CTPYCCR',
    cTPYRazorName: '$.CTPYRazorName',
  },
  STFSectorTypeSystemOption: {
    text: '$.value',
  },
  CountryOption: {
    text: '$.value',
  },
  SourceKeyOption: {
    text: '$.value',
  },
  InternalGroupTypeSystemOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'counterpartyExternalId',
    title: 'External ID',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'sourceKey.text',
    title: 'Source',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
  },
  {
    field: 'counterpartyName',
    title: 'Counterparty Name',
    filter: 'text',
    typeOf: 'string',
    width: '300px',
  },
  {
    field: 'country.text',
    title: 'Country',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
  },
  {
    field: 'internalGroupTypeSystem.text',
    title: 'Grp: Internal Counterparty',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'sTFSectorTypeSystem.text',
    title: 'Grp: STF Sector',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'isInternal',
    title: 'Is Internal',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'razorCode',
    title: 'Razor Code',
    filter: 'text',
    typeOf: 'string',
    width: '140px',
  },
  {
    field: 'cTPYCOUNTRYOFRISK',
    title: 'CTPY_COUNTRY_OF_RISK',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'cOUNTRYOFDOMICILE',
    title: 'COUNTRY_OF_DOMICILE',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'interbank',
    title: 'Interbank',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'cTPYCCR',
    title: 'CTPY_CCR',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'setNo',
    title: 'Set No.',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
  },
  {
    field: 'controlPoint',
    title: 'Control Point',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'cTPYRazorName',
    title: 'CTPY_Razor_Name',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'interdeskDescription',
    title: 'Interdesk - Description',
    filter: 'text',
    typeOf: 'string',
    width: '170px',
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    comment:
      '[20150919][System] Updated STFSectorTypeSystemID_20150919 Inserted missing attribute',
    razorCode: null,
    interdeskDescription: null,
    sTFSectorTypeSystem: {
      id: 1667,
      text: 'Corporate',
    },
    controlPoint: null,
    country: null,
    sourceKey: {
      id: 1,
      text: 'MX3.1',
    },
    interbank: null,
    isInternal: true,
    setNo: null,
    counterpartyExternalId: 'JCPABATSTCHCNZ',
    cTPYCOUNTRYOFRISK: null,
    cOUNTRYOFDOMICILE: null,
    cTPYCCR: null,
    cTPYRazorName: null,
    id: 1,
    internalGroupTypeSystem: null,
    added: {
      by: 'varadasr',
      time: '2011-08-23T14:36:23.793+0000',
    },
    counterpartyName: 'TRUSTEES OF THE J C AND P A BAYNES FAMILY TRUST',
  },
  {
    modified: false,
    comment:
      '[20150919][System] Updated STFSectorTypeSystemID_20150919 Inserted missing attribute',
    razorCode: 'NORXM',
    interdeskDescription: null,
    sTFSectorTypeSystem: {
      id: 1667,
      text: 'Corporate',
    },
    controlPoint: null,
    country: null,
    sourceKey: {
      id: 1,
      text: 'MX3.1',
    },
    interbank: null,
    isInternal: true,
    setNo: null,
    counterpartyExternalId: 'PAMSC7204GENCH',
    cTPYCOUNTRYOFRISK: null,
    cOUNTRYOFDOMICILE: null,
    cTPYCCR: null,
    cTPYRazorName: null,
    id: 2,
    internalGroupTypeSystem: null,
    added: {
      by: 'varadasr',
      time: '2011-08-23T14:36:23.793+0000',
    },
    counterpartyName: 'PICTET ASSET MANAGEMENT SA  - C7204',
  },
  {
    modified: false,
    comment:
      '[20150919][System] Updated STFSectorTypeSystemID_20150919 Inserted missing attribute',
    razorCode: null,
    interdeskDescription: null,
    sTFSectorTypeSystem: {
      id: 1667,
      text: 'Corporate',
    },
    controlPoint: null,
    country: null,
    sourceKey: {
      id: 1,
      text: 'MX3.1',
    },
    interbank: null,
    isInternal: true,
    setNo: null,
    counterpartyExternalId: 'SAMSUNGCCSEOKR',
    cTPYCOUNTRYOFRISK: null,
    cOUNTRYOFDOMICILE: null,
    cTPYCCR: null,
    cTPYRazorName: null,
    id: 3,
    internalGroupTypeSystem: null,
    added: {
      by: 'varadasr',
      time: '2011-08-23T14:36:23.793+0000',
    },
    counterpartyName: 'SAMSUNG CARD CO LTD',
  },
  {
    modified: false,
    comment:
      '[20150919][System] Updated STFSectorTypeSystemID_20150919 Inserted missing attribute',
    razorCode: null,
    interdeskDescription: null,
    sTFSectorTypeSystem: {
      id: 1672,
      text: 'Internal',
    },
    controlPoint: null,
    country: null,
    sourceKey: {
      id: 1,
      text: 'MX3.1',
    },
    interbank: null,
    isInternal: true,
    setNo: null,
    counterpartyExternalId: 'X_APOLLO',
    cTPYCOUNTRYOFRISK: null,
    cOUNTRYOFDOMICILE: null,
    cTPYCCR: null,
    cTPYRazorName: null,
    id: 4,
    internalGroupTypeSystem: null,
    added: {
      by: 'varadasr',
      time: '2011-08-23T14:36:23.793+0000',
    },
    counterpartyName: 'X_APOLLO',
  },
  {
    modified: false,
    comment:
      '[20150919][System] Updated STFSectorTypeSystemID_20150919 Inserted missing attribute',
    razorCode: 'NORXM',
    interdeskDescription: null,
    sTFSectorTypeSystem: {
      id: 1667,
      text: 'Corporate',
    },
    controlPoint: null,
    country: null,
    sourceKey: {
      id: 1,
      text: 'MX3.1',
    },
    interbank: null,
    isInternal: true,
    setNo: null,
    counterpartyExternalId: '000270 KS',
    cTPYCOUNTRYOFRISK: null,
    cOUNTRYOFDOMICILE: null,
    cTPYCCR: null,
    cTPYRazorName: null,
    id: 5,
    internalGroupTypeSystem: null,
    added: {
      by: 'varadasr',
      time: '2011-08-23T14:36:23.793+0000',
    },
    counterpartyName: 'Kia Motors Corporation',
  },
  {
    modified: false,
    comment:
      '[20150919][System] Updated STFSectorTypeSystemID_20150919 Inserted missing attribute',
    razorCode: 'NORXM',
    interdeskDescription: null,
    sTFSectorTypeSystem: {
      id: 1667,
      text: 'Corporate',
    },
    controlPoint: null,
    country: null,
    sourceKey: {
      id: 1,
      text: 'MX3.1',
    },
    interbank: null,
    isInternal: true,
    setNo: null,
    counterpartyExternalId: '002860 KS',
    cTPYCOUNTRYOFRISK: null,
    cOUNTRYOFDOMICILE: null,
    cTPYCCR: null,
    cTPYRazorName: null,
    id: 6,
    internalGroupTypeSystem: null,
    added: {
      by: 'varadasr',
      time: '2011-08-23T14:36:23.793+0000',
    },
    counterpartyName: 'HANA BANK',
  },
  {
    modified: false,
    comment:
      '[20150919][System] Updated STFSectorTypeSystemID_20150919 Inserted missing attribute',
    razorCode: 'HYUNDAIMOTOR',
    interdeskDescription: null,
    sTFSectorTypeSystem: {
      id: 1667,
      text: 'Corporate',
    },
    controlPoint: null,
    country: null,
    sourceKey: {
      id: 1,
      text: 'MX3.1',
    },
    interbank: null,
    isInternal: true,
    setNo: null,
    counterpartyExternalId: '005380 KS',
    cTPYCOUNTRYOFRISK: null,
    cOUNTRYOFDOMICILE: null,
    cTPYCCR: null,
    cTPYRazorName: null,
    id: 7,
    internalGroupTypeSystem: null,
    added: {
      by: 'varadasr',
      time: '2011-08-23T14:36:23.793+0000',
    },
    counterpartyName: 'HYUNDAI MOTOR COMPANY',
  },
  {
    modified: false,
    comment:
      '[20150919][System] Updated STFSectorTypeSystemID_20150919 Inserted missing attribute',
    razorCode: 'POSCO-1',
    interdeskDescription: null,
    sTFSectorTypeSystem: {
      id: 1667,
      text: 'Corporate',
    },
    controlPoint: null,
    country: null,
    sourceKey: {
      id: 1,
      text: 'MX3.1',
    },
    interbank: null,
    isInternal: true,
    setNo: null,
    counterpartyExternalId: '005490 KS',
    cTPYCOUNTRYOFRISK: null,
    cOUNTRYOFDOMICILE: null,
    cTPYCCR: null,
    cTPYRazorName: null,
    id: 8,
    internalGroupTypeSystem: null,
    added: {
      by: 'varadasr',
      time: '2011-08-23T14:36:23.793+0000',
    },
    counterpartyName: 'POSCO',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

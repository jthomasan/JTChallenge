// Category
const category = "Underlyings";

// Type
const type = "Grp: COM Delta Gamma - Lot Conversion Factor";

// GQL Schema
const schemaQuery =
  "StaticDataCOMDeltaGammaLotConversionFactors: [StaticDataCOMDeltaGammaLotConversionFactor]";
const schemaType = `
  type StaticDataCOMDeltaGammaLotConversionFactor {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = "StaticDataCOMDeltaGammaLotConversionFactors";
const query = `
{
  StaticDataCOMDeltaGammaLotConversionFactors {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataCOMDeltaGammaLotConversionFactors: {
      url: "reference-data/type-system-parameters",
      dataPath: "$[?(@.system.id == 1003)]",
    },
  },
  StaticDataCOMDeltaGammaLotConversionFactor: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "value",
    title: "Value",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

// Mock Data
const mockData = [
  {
    id: 471,
    modified: false,
    description: null,
    value: "0.0238095238",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:53:31.510+0000",
    },
  },
  {
    id: 473,
    modified: false,
    description: null,
    value: "0.04",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:53:31.510+0000",
    },
  },
  {
    id: 479,
    modified: false,
    description: null,
    value: "0.05",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:53:31.510+0000",
    },
  },
  {
    id: 485,
    modified: false,
    description: null,
    value: "0.1",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:53:31.510+0000",
    },
  },
  {
    id: 488,
    modified: false,
    description: null,
    value: "0.1666666667",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:53:31.510+0000",
    },
  },
  {
    id: 490,
    modified: false,
    description: null,
    value: "1",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:53:31.510+0000",
    },
  },
  {
    id: 523,
    modified: false,
    description: null,
    value: "0.0000166667",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:53:31.510+0000",
    },
  },
  {
    id: 524,
    modified: false,
    description: null,
    value: "10.8",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:53:31.510+0000",
    },
  },
  {
    id: 527,
    modified: false,
    description: null,
    value: "12.4",
    isActive: true,
    added: {
      by: "lakshmn2",
      time: "2012-03-14T22:53:31.510+0000",
    },
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

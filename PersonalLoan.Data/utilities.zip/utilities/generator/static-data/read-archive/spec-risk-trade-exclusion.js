// Category
const category = 'Specific Risk';

// Type
const type = 'Spec Risk Trade Exclusion';

// GQL Schema
const schemaQuery =
  'StaticDataSpecRiskTradeExclusions: [StaticDataSpecRiskTradeExclusion]';
const schemaType = `
  type StaticDataSpecRiskTradeExclusion {
    id: ID!
    modified: Boolean!
    reportName: String!
    tradeNumber: Int!
    comment: String
    isActive: Boolean!
    added: Added!
  }`;

// Query
const queryName = 'StaticDataSpecRiskTradeExclusions';
const query = `
{
  StaticDataSpecRiskTradeExclusions {
    id
    modified
    reportName
    tradeNumber
    comment
    isActive
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataSpecRiskTradeExclusions: {
      url: 'reference-data/v1/trade-exclusion',
      dataPath: '$',
    },
  },
  StaticDataSpecRiskTradeExclusion: {
    modified: false,
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'reportName',
    title: 'Report Type',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'tradeNumber',
    title: 'Trade Number',
    filter: 'numeric',
    typeOf: 'number',
    width: '130px',
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    typeOf: 'string',
    width: '180px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    comment: 'Should be a banking book trade',
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-09-27T08:00:20.453+0000',
    },
    reportName: 'SpecificRiskIR',
    tradeNumber: 2700997,
    id: 1,
  },
  {
    modified: false,
    comment: 'Vietnam - Buy-Sell-Back trade',
    isActive: false,
    added: {
      by: 'brightw',
      time: '2013-03-08T04:52:02.943+0000',
    },
    reportName: 'SpecificRiskIR',
    tradeNumber: 5208273,
    id: 2,
  },
  {
    modified: false,
    comment: 'Vietnam - Buy-Sell-Back trade',
    isActive: false,
    added: {
      by: 'brightw',
      time: '2013-03-08T04:52:02.943+0000',
    },
    reportName: 'SpecificRiskIR',
    tradeNumber: 5517805,
    id: 3,
  },
  {
    modified: false,
    comment: 'As advised by David Manuell',
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-04T14:19:35.747+0000',
    },
    reportName: 'APRACDS',
    tradeNumber: 93534,
    id: 4,
  },
  {
    modified: false,
    comment: 'As advised by David Manuell',
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-04T14:19:35.747+0000',
    },
    reportName: 'APRACDS',
    tradeNumber: 130098,
    id: 5,
  },
  {
    modified: false,
    comment: 'As advised by David Manuell',
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-04T14:19:35.747+0000',
    },
    reportName: 'APRACDS',
    tradeNumber: 797532,
    id: 6,
  },
  {
    modified: false,
    comment: 'As advised by David Manuell',
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-04T14:19:35.747+0000',
    },
    reportName: 'APRACDS',
    tradeNumber: 797533,
    id: 7,
  },
  {
    modified: false,
    comment: 'As advised by David Manuell',
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-04T14:19:35.747+0000',
    },
    reportName: 'APRACDS',
    tradeNumber: 814453,
    id: 8,
  },
  {
    modified: false,
    comment: 'As advised by David Manuell',
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-04T14:19:35.747+0000',
    },
    reportName: 'APRACDS',
    tradeNumber: 814455,
    id: 9,
  },
  {
    modified: false,
    comment: 'As advised by David Manuell',
    isActive: true,
    added: {
      by: 'manuelld',
      time: '2012-10-04T14:19:35.747+0000',
    },
    reportName: 'APRACDS',
    tradeNumber: 814456,
    id: 10,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

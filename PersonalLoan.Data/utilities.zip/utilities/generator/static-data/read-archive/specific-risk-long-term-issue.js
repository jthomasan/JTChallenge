// Category
const category = 'Specific Risk';

// Type
const type = 'Specific Risk Long Term Issue';

// GQL Schema
const schemaQuery =
  'StaticDataSpecificRiskLongTermIssues: [StaticDataSpecificRiskLongTermIssue]';
const schemaType = `
  type StaticDataSpecificRiskLongTermIssue {
    id: ID!
    modified: Boolean!
    ratingBandSecTypeSystem: RatingBandSecTypeSystemOption
    resecuritisationExposures: Float
    securitisationExposures: Float
    added: Added!
  }
  
  type RatingBandSecTypeSystemOption {
    id: ID
    text: String
  }`;

// Query
const queryName = 'StaticDataSpecificRiskLongTermIssues';
const query = `
{
  StaticDataSpecificRiskLongTermIssues {
    id
    modified
    ratingBandSecTypeSystem {
      id
      text
    }
    resecuritisationExposures
    securitisationExposures
    added {
      by
      time
    }
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataSpecificRiskLongTermIssues: {
      url: 'reference-data/v1/srlong-term-issues',
      dataPath: '$',
    },
  },
  StaticDataSpecificRiskLongTermIssue: {
    modified: false,
  },
  RatingBandSecTypeSystemOption: {
    text: '$.value',
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'ratingBandSecTypeSystem.text',
    title: 'Rating Band Sec',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'securitisationExposures',
    title: 'Securitisation Exposures (%)',
    filter: 'numeric',
    typeOf: 'number',
    width: '190px',
  },
  {
    field: 'resecuritisationExposures',
    title: 'Securitisation Exposures (%)',
    filter: 'numeric',
    typeOf: 'number',
    width: '190px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    id: 1,
    added: {
      by: 'foonga',
      time: '2012-05-09T00:00:00.000+0000',
    },
    ratingBandSecTypeSystem: {
      id: 1074,
      text: 'AAA to AA-',
    },
    resecuritisationExposures: 3.2,
    securitisationExposures: 1.6,
  },
  {
    modified: false,
    id: 2,
    added: {
      by: 'foonga',
      time: '2012-05-09T00:00:00.000+0000',
    },
    ratingBandSecTypeSystem: {
      id: 1073,
      text: 'A+ to A-',
    },
    resecuritisationExposures: 8,
    securitisationExposures: 4,
  },
  {
    modified: false,
    id: 3,
    added: {
      by: 'foonga',
      time: '2012-05-09T00:00:00.000+0000',
    },
    ratingBandSecTypeSystem: {
      id: 1076,
      text: 'BBB+ to BBB-',
    },
    resecuritisationExposures: 18,
    securitisationExposures: 8,
  },
  {
    modified: false,
    id: 4,
    added: {
      by: 'foonga',
      time: '2012-05-09T00:00:00.000+0000',
    },
    ratingBandSecTypeSystem: {
      id: 1075,
      text: 'BB+ to BB-',
    },
    resecuritisationExposures: 52,
    securitisationExposures: 28,
  },
  {
    modified: false,
    id: 5,
    added: {
      by: 'foonga',
      time: '2012-05-09T00:00:00.000+0000',
    },
    ratingBandSecTypeSystem: {
      id: 1077,
      text: 'Below BB- or unrated',
    },
    resecuritisationExposures: 100,
    securitisationExposures: 100,
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

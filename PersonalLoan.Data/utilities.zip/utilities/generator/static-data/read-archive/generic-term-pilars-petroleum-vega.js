// Category
const category = 'Tenor Buckets';

// Type
const type = 'Generic Term Pilars - Petroleum Vega';

// GQL Schema
const schemaQuery =
  'StaticDataGenericTermPilarsPetroleumVegas: [StaticDataGenericTermPilarsPetroleumVega]';
const schemaType = `
  type StaticDataGenericTermPilarsPetroleumVega {
    modified: Boolean!
    term: String!
    termUnit: Int!
    net1m_2m: String!
    net3m_5m: String!
    net6m_11m: String!
    net1y_2y: String!
    net2yPlus: String!
  }`;

// Query
const queryName = 'StaticDataGenericTermPilarsPetroleumVegas';
const query = `
{
  StaticDataGenericTermPilarsPetroleumVegas {
    modified
    term
    termUnit
    net1m_2m
    net3m_5m
    net6m_11m
    net1y_2y
    net2yPlus
  }
}
`;

// Api mapping info
const apiMappings = {
  Query: {
    StaticDataGenericTermPilarsPetroleumVegas: {
      url: 'reference-data/v1/bucket-gen-pillar-petroleum-vega',
      dataPath: '$',
    },
  },
  StaticDataGenericTermPilarsPetroleumVega: {
    modified: false,
    termUnit: {
      dataPath: '$.term',
      decorators: [
        {
          name: 'genericTermPillarsTermUnit',
        },
      ],
    },
    net1m_2m: {
      dataPath: '$.net1m_2m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 0,
          },
        },
      ],
    },
    net3m_5m: {
      dataPath: '$.net3m_5m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 0,
          },
        },
      ],
    },
    net6m_11m: {
      dataPath: '$.net6m_11m',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 0,
          },
        },
      ],
    },
    net1y_2y: {
      dataPath: '$.net1y_2y',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 0,
          },
        },
      ],
    },
    net2yPlus: {
      dataPath: '$.net2yPlus',
      decorators: [
        {
          name: 'roundNumber',
          params: {
            decimalPlaces: 0,
          },
        },
      ],
    },
  },
};

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net1m_2m',
    title: 'Net1m_2m',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'net3m_5m',
    title: 'Net3m_5m',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'net6m_11m',
    title: 'Net6m_11m',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'net1y_2y',
    title: 'Net1y_2y',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
  {
    field: 'net2yPlus',
    title: 'Net2yPlus',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
  },
];

// Mock Data
const mockData = [
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '0',
    net3m_5m: '0',
    term: 'c1',
    net2yPlus: '0',
    net1m_2m: '100',
  },
  {
    modified: false,
    net6m_11m: '100',
    net1y_2y: '0',
    net3m_5m: '0',
    term: 'c10',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '100',
    net1y_2y: '0',
    net3m_5m: '0',
    term: 'c11',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c12',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c13',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c14',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c15',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c16',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c17',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c18',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c19',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '0',
    net3m_5m: '0',
    term: 'c2',
    net2yPlus: '0',
    net1m_2m: '100',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c20',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c21',
    net2yPlus: '0',
    net1m_2m: '0',
  },
  {
    modified: false,
    net6m_11m: '0',
    net1y_2y: '100',
    net3m_5m: '0',
    term: 'c22',
    net2yPlus: '0',
    net1m_2m: '0',
  },
];

module.exports = {
  category,
  type,
  queryName,
  query,
  apiMappings,
  fieldInfo,
  mockData,
  schemaQuery,
  schemaType,
};

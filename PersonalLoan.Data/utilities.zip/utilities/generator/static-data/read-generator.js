#!/usr/bin/env node

const fs = require('fs-extra');
const ejs = require('ejs');
const argv = require('yargs-parser')(process.argv.slice(2));
const path = require('path');
const caseChange = require('change-case');
const _ = require('lodash');

const {
  category,
  type,
  apiMappings,
  mockData,
  exportUrl,
  fieldInfo,
  query,
  queryName,
  schemaQuery,
  schemaType,
} = require('./read-config');
const name = caseChange.pascalCase(type);
const namePrefixed = `StaticData${name}`;
const canAddNew = false;
const canBulkUpdate = false;
const rootPath = path.join(__dirname, '../../..');

const readFileAsJSON = (filepath) => JSON.parse(fs.readFileSync(filepath));

const main = () => {
  console.log('Generating template...');
  try {
    const { _: leftovers } = argv;
    const data = {
      name,
      nameCapitalCase: caseChange.capitalCase(caseChange.sentenceCase(name)),
      nameParamCase: caseChange.paramCase(caseChange.sentenceCase(name)),
      namePrefixed,
      namePrefixedCapitalCase: caseChange.capitalCase(namePrefixed),
      namePrefixedCamelCased: caseChange.camelCase(namePrefixed),
      namePrefixedSnakeCase: caseChange.snakeCase(namePrefixed),
      category,
      type,
      apiMappings,
      mockData,
      exportUrl,
      fieldInfo,
      query,
      queryName,
      canAddNew,
      canBulkUpdate,
    };

    if (!name) {
      console.error('--name flag required');
      process.exit(1);
    }

    let dirname = '';

    // Mock
    let filename = path.join(__dirname, './templates/static-data-mock.ejs');
    let pathname = `../../merv-web-ui/mock/gql/mockdata/staticData/${queryName}.js`;

    createFiles(filename, data, pathname);

    // UI Mappings - Columns
    filename = path.join(
      __dirname,
      './templates/static-data-ui-mapping-column.ejs'
    );
    let foldername = caseChange.camelCase(name);
    pathname = `../../merv-web-ui/src/pages/reference-data/static-data/mappings/staticDataSet/${foldername}/column.ts`;

    createFiles(filename, data, pathname);

    // UI Mappings - Query
    filename = path.join(
      __dirname,
      './templates/static-data-ui-mapping-query.ejs'
    );
    pathname = `../../merv-web-ui/src/pages/reference-data/static-data/mappings/staticDataSet/${foldername}/query.ts`;

    createFiles(filename, data, pathname);

    // UI Mappings - Index
    filename = path.join(
      __dirname,
      './templates/static-data-ui-mapping-index.ejs'
    );
    pathname = `../../merv-web-ui/src/pages/reference-data/static-data/mappings/staticDataSet/${foldername}/index.ts`;

    createFiles(filename, data, pathname);

    // Export Mappings
    filename = path.join(
      __dirname,
      './templates/static-data-export-mapping.ejs'
    );
    pathname = `../../merv-web-es/src/mappings/staticData/${foldername}.ts`;

    createFiles(filename, data, pathname);

    // API mapping
    filename = path.join(
      rootPath,
      'merv-web-api/api-mappings/static-data.json'
    );
    const staticDataMapping = readFileAsJSON(filename);
    _.merge(staticDataMapping, apiMappings);

    fs.ensureFileSync(filename);
    fs.outputFileSync(filename, JSON.stringify(staticDataMapping));

    // Mock Server Index
    dirname = path.join(rootPath, 'merv-web-ui/mock/gql/mockdata/staticData');
    filename = path.join(dirname, '/index.js');
    const ls = fs.readdirSync(dirname);
    let content = ls.reduce((acc, curr) => {
      const type = curr.split('.')[0];
      if (type !== 'index') {
        acc = `${acc} export {default as ${type}} from './${type}';`;
      }
      return acc;
    }, '');
    fs.ensureFileSync(filename);
    fs.outputFileSync(filename, content);

    // UI - StaticDataSet
    const newStaticDataSet = caseChange.camelCase(name);
    const importStatment = `import * as ${newStaticDataSet} from './${newStaticDataSet}';`;
    const enumEntry = `${name} = '${newStaticDataSet}',`;
    const exportEntry = `[StaticData.${name}]: ${newStaticDataSet},`;

    filename = path.join(
      rootPath,
      'merv-web-ui/src/pages/reference-data/static-data/mappings/staticDataSet/index.ts'
    );

    content = fs.readFileSync(filename, 'utf8');

    content = insertInStringBeforeMarkerIfNotExist(
      importStatment,
      content,
      '// end import'
    );
    content = insertInStringBeforeMarkerIfNotExist(
      enumEntry,
      content,
      '// end enum'
    );
    content = insertInStringBeforeMarkerIfNotExist(
      exportEntry,
      content,
      '// end export'
    );

    fs.ensureFileSync(filename);
    fs.outputFileSync(filename, content);

    // UI - Static Data Mapping Index
    const listName = caseChange.camelCase(category);
    const categoryEntry = `{
      name: '${category}',
      list: ${listName},
    },`;

    const listEntry = `{
      id: StaticData.${name},
      name: '${type}',
    },`;

    filename = path.join(
      rootPath,
      'merv-web-ui/src/pages/reference-data/static-data/mappings/staticData.ts'
    );

    content = fs.readFileSync(filename, 'utf8');

    content = createOrAddIntoArrayInString(
      categoryEntry,
      content,
      'allCategories: StaticDataCategory[]'
    );
    content = createOrAddIntoArrayInString(
      listEntry,
      content,
      listName,
      '// end listings'
    );

    fs.ensureFileSync(filename);
    fs.outputFileSync(filename, content);

    // Common - schema
    filename = path.join(rootPath, 'merv-web-common/schema/static-data.js');

    content = fs.readFileSync(filename, 'utf8');
    content = createOrAddIntoArrayInString(
      `  ${schemaQuery}\n  `,
      content,
      'Query',
      null,
      true,
      false
    );
    content = insertInStringBeforeMarkerIfNotExist(schemaType, content, '`;');

    fs.ensureFileSync(filename);
    fs.outputFileSync(filename, content);

    // Keep config on archive
    fs.copySync(
      path.resolve(__dirname, './read-config.js'),
      `static-data/read-archive/${caseChange.paramCase(name)}.js`
    );
  } catch (err) {
    console.error(err);
  }
};

function createOrAddIntoArrayInString(
  toAdd,
  string,
  arrayName,
  markerForCreate,
  arrayDelimiterCurly = false,
  expectSemiColonAtEnd = true
) {
  const arrayNameEscaped = _.escapeRegExp(arrayName);
  const delimiterStart = arrayDelimiterCurly ? '{' : '[';
  const delimiterEnd =
    (arrayDelimiterCurly ? '}' : ']') + (expectSemiColonAtEnd ? ';' : '');
  const equalSign = arrayDelimiterCurly ? '' : '= ';
  const regex = new RegExp(
    `${arrayNameEscaped}\\s*${equalSign}\\s*\\${delimiterStart}([\\S\\s]+?)\\${delimiterEnd}`
  );
  const match = string.match(regex);

  let result = string;

  if (match) {
    // add to existing array
    let arrayContent = match[1];
    if (!isExistsInString(toAdd, arrayContent)) {
      arrayContent += toAdd;
    }
    result = result.replace(
      regex,
      `${arrayName} ${equalSign}${delimiterStart}${arrayContent}${delimiterEnd}`
    );
  } else if (markerForCreate) {
    // create new array
    const newListing = `const ${arrayNameEscaped} = [${toAdd}]`;
    result = insertInStringBeforeMarkerIfNotExist(
      newListing,
      result,
      markerForCreate
    );
  }

  return result;
}

function insertInStringBeforeMarkerIfNotExist(
  newData,
  destString,
  marker,
  addNewline = true
) {
  // check if exist
  if (isExistsInString(newData, destString)) return destString;

  let result = destString;
  const markerIndex = destString.indexOf(marker);
  if (markerIndex >= 0) {
    result =
      result.slice(0, markerIndex) +
      (newData || '') +
      (addNewline ? '\n' : '') +
      result.slice(markerIndex);
  }

  return result;
}

function isExistsInString(needle, haystack) {
  const checkString = _.escapeRegExp(needle).replace(/\s+/g, '\\s+');
  const checkRE = new RegExp(checkString);

  return checkRE.test(haystack);
}

function createFiles(filename, data, pathname) {
  const options = {
    rmWhitespace: true,
    beautify: true,
  };

  ejs.renderFile(filename, data, options, (err, str) => {
    const strWithOutSpace = str;
    // .replace(/(\r\n|\n|\r)/gm, "")

    if (err) {
      console.error(err);
    }

    const outputFile = path.join(process.cwd(), pathname);
    fs.ensureFileSync(outputFile);
    fs.outputFileSync(outputFile, strWithOutSpace);
  });
}

main();

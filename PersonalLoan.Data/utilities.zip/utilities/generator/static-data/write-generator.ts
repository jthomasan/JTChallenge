#!/usr/bin/env node

const fs = require('fs-extra');
const ejs = require('ejs');
const argv = require('yargs-parser')(process.argv.slice(2));
import * as path from 'path';
const caseChange = require('change-case');
const _ = require('lodash');

import {
  typeList,
  type as staticDataType,
  apiMappings,
  fieldInfo,
  schemaQuery as schemaQueryName,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
} from './write-config';

const writeGenerator = (params) => {
  let { type, schemaQuery } = params;
  const name = caseChange.pascalCase(type);
  const namePrefixed = `StaticData${name}`;

  const rootPath = path.join(__dirname, '../../..');

  const readFileAsJSON = (filepath) => JSON.parse(fs.readFileSync(filepath));
  const lowerCaseSelector = (value: string): string =>
    value.charAt(0).toLowerCase() + value.slice(1);

  const main = () => {
    console.log('Generating template...');
    try {
      const { _: leftovers } = argv;
      const data = {
        name,
        nameCapitalCase: caseChange.capitalCase(caseChange.sentenceCase(name)),
        nameParamCase: caseChange.paramCase(caseChange.sentenceCase(name)),
        namePrefixed,
        namePrefixedCapitalCase: caseChange.capitalCase(namePrefixed),
        namePrefixedCamelCased: caseChange.camelCase(namePrefixed),
        namePrefixedSnakeCase: caseChange.snakeCase(namePrefixed),
        type,
        apiMappings,
        fieldInfo,
        schemaQuery,
        canAddNew,
        canBulkUpdate,
      };

      if (!name) {
        console.error('--name flag required');
        process.exit(1);
      }

      let filename = '';
      let pathname = '';
      let content = '';

      // Mock
      // filename = path.join(
      //   rootPath,
      //   'merv-web-ui/mock/gql/mockdata/batchAction/index.js'
      // );

      // let content = fs.readFileSync(filename, 'utf8');

      // const addImport = `import add${schemaQuery} from './genericStaticData';`;
      // const replaceImport = `import replace${schemaQuery} from './genericStaticData';`;

      // content = insertInStringBeforeMarkerIfNotExist(
      //   addImport,
      //   content,
      //   '// end import'
      // );
      // content = insertInStringBeforeMarkerIfNotExist(
      //   replaceImport,
      //   content,
      //   '// end import'
      // );
      // content = insertInStringBeforeMarkerIfNotExist(
      //   `add${schemaQuery},`,
      //   content,
      //   '// end export'
      // );
      // content = insertInStringBeforeMarkerIfNotExist(
      //   `replace${schemaQuery},`,
      //   content,
      //   '// end export'
      // );

      // fs.ensureFileSync(filename);
      // fs.outputFileSync(filename, content);

      // UI Mappings - Columns
      filename = path.join(
        __dirname,
        './templates/static-data-ui-mapping-column.ejs'
      );
      let foldername = caseChange.camelCase(name);
      pathname = `../../merv-web-ui/src/pages/reference-data/static-data/mappings/staticDataSet/${foldername}/column.ts`;

      createFiles(filename, data, pathname);

      // UI Mappings - Query
      filename = path.join(
        rootPath,
        `merv-web-ui/src/pages/reference-data/static-data/mappings/staticDataSet/${foldername}/query.ts`
      );

      content = fs.readFileSync(filename, 'utf8');

      const addQueryName = `export const mutationAddAction = 'add${schemaQuery}';`;
      const replaceQueryName = `export const mutationAction = 'replace${schemaQuery}';`;

      content = insertInStringBeforeMarkerIfNotExist(
        addQueryName,
        content,
        'export const exportUrl'
      );
      content = insertInStringBeforeMarkerIfNotExist(
        replaceQueryName,
        content,
        'export const mutationAddAction'
      );

      fs.ensureFileSync(filename);
      fs.outputFileSync(filename, content);

      // UI Mappings - Index
      filename = path.join(
        __dirname,
        './templates/static-data-ui-mapping-index.ejs'
      );
      pathname = `../../merv-web-ui/src/pages/reference-data/static-data/mappings/staticDataSet/${foldername}/index.ts`;

      createFiles(filename, data, pathname);

      // UI Selectors
      if (selectors.length > 0) {
        generateSelectors();
      }

      // API mapping
      filename = path.join(
        rootPath,
        'merv-web-api/api-mappings/mutation-actions/static-data.json'
      );
      const staticDataMapping = readFileAsJSON(filename);
      _.merge(staticDataMapping, apiMappings);

      fs.ensureFileSync(filename);
      fs.outputFileSync(filename, JSON.stringify(staticDataMapping));

      // Common - schema
      filename = path.join(rootPath, 'merv-web-common/schema/static-data.js');

      content = fs.readFileSync(filename, 'utf8');
      content = createOrAddIntoArrayInString(
        `  add${schemaQuery}: Update${schemaQuery}\n  `,
        content,
        'input BatchActions',
        null,
        true,
        false
      );
      content = createOrAddIntoArrayInString(
        `  replace${schemaQuery}: Update${schemaQuery}\n  `,
        content,
        'input BatchActions',
        null,
        true,
        false
      );
      content = insertInStringBeforeMarkerIfNotExist(schemaType, content, '`;');

      fs.ensureFileSync(filename);
      fs.outputFileSync(filename, content);

      // Keep config on archive
      fs.copySync(
        path.resolve(__dirname, './write-config.js'),
        `static-data/write-archive/${caseChange.paramCase(name)}-write.js`
      );
    } catch (err) {
      console.error(err);
    }
  };

  function generateSelectors() {
    selectors.forEach((item) => {
      // Mock
      let filename = path.join(__dirname, './templates/static-data-mock.ejs');
      let pathname = `../../merv-web-ui/mock/gql/mockdata/staticDataOptions/${item.name}.js`;

      createFiles(filename, item, pathname);

      const lowerCaseSelector = (value: string): string =>
        value.charAt(0).toLowerCase() + value.slice(1);

      // Selector Query
      const selectorName = lowerCaseSelector(item.name);

      filename = path.join(
        __dirname,
        './templates/static-data-selector-query.ejs'
      );

      pathname = `../../merv-web-ui/src/pages/reference-data/static-data/mappings/selectors/${selectorName}.ts`;

      createFiles(filename, item, pathname);

      // Selector API mapping
      filename = path.join(
        rootPath,
        'merv-web-api/api-mappings/static-data.json'
      );
      const selectorMappings = readFileAsJSON(filename);
      _.merge(selectorMappings, item.apiMappings);

      fs.ensureFileSync(filename);
      fs.outputFileSync(filename, JSON.stringify(selectorMappings));

      filename = path.join(
        rootPath,
        'merv-web-ui/src/pages/reference-data/static-data/mappings/selectors/index.ts'
      );

      let content = fs.readFileSync(filename, 'utf8');

      const importStatment = `import * as ${selectorName} from './${selectorName}';`;
      const enumEntry = `${item.name} = '${selectorName}',`;
      const exportEntry = `[Selector.${item.name}]: ${selectorName},`;

      content = insertInStringBeforeMarkerIfNotExist(
        importStatment,
        content,
        '// end import'
      );
      content = insertInStringBeforeMarkerIfNotExist(
        enumEntry,
        content,
        '// end enum'
      );
      content = insertInStringBeforeMarkerIfNotExist(
        exportEntry,
        content,
        '// end export'
      );

      fs.ensureFileSync(filename);
      fs.outputFileSync(filename, content);

      // Common - schema
      filename = path.join(rootPath, 'merv-web-common/schema/static-data.js');

      content = fs.readFileSync(filename, 'utf8');
      content = createOrAddIntoArrayInString(
        `  ${item.schemaQuery}\n  `,
        content,
        'Query',
        null,
        true,
        false
      );

      fs.ensureFileSync(filename);
      fs.outputFileSync(filename, content);
    });

    // Mock Server Index
    let dirname = path.join(
      rootPath,
      'merv-web-ui/mock/gql/mockdata/staticDataOptions'
    );
    let filename = path.join(dirname, '/index.js');
    const ls = fs.readdirSync(dirname);
    let content = ls.reduce((acc, curr) => {
      const type = curr.split('.')[0];
      if (type !== 'index') {
        acc = `${acc} export {default as ${type}} from './${type}';`;
      }
      return acc;
    }, '');
    fs.ensureFileSync(filename);
    fs.outputFileSync(filename, content);
  }

  function createOrAddIntoArrayInString(
    toAdd,
    string,
    arrayName,
    markerForCreate,
    arrayDelimiterCurly = false,
    expectSemiColonAtEnd = true
  ) {
    const arrayNameEscaped = _.escapeRegExp(arrayName);
    const delimiterStart = arrayDelimiterCurly ? '{' : '[';
    const delimiterEnd =
      (arrayDelimiterCurly ? '}' : ']') + (expectSemiColonAtEnd ? ';' : '');
    const equalSign = arrayDelimiterCurly ? '' : '= ';
    const regex = new RegExp(
      `${arrayNameEscaped}\\s*${equalSign}\\s*\\${delimiterStart}([\\S\\s]+?)\\${delimiterEnd}`
    );
    const match = string.match(regex);

    let result = string;

    if (match) {
      // add to existing array
      let arrayContent = match[1];
      if (!isExistsInString(toAdd, arrayContent)) {
        arrayContent += toAdd;
      }
      result = result.replace(
        regex,
        `${arrayName} ${equalSign}${delimiterStart}${arrayContent}${delimiterEnd}`
      );
    } else if (markerForCreate) {
      // create new array
      const newListing = `const ${arrayNameEscaped} = [${toAdd}]`;
      result = insertInStringBeforeMarkerIfNotExist(
        newListing,
        result,
        markerForCreate
      );
    }

    return result;
  }

  function insertInStringBeforeMarkerIfNotExist(
    newData,
    destString,
    marker,
    addNewline = true
  ) {
    // check if exist
    if (isExistsInString(newData, destString)) return destString;

    let result = destString;
    const markerIndex = destString.indexOf(marker);
    if (markerIndex >= 0) {
      result =
        result.slice(0, markerIndex) +
        (newData || '') +
        (addNewline ? '\n' : '') +
        result.slice(markerIndex);
    }

    return result;
  }

  function isExistsInString(needle, haystack) {
    const checkString = _.escapeRegExp(needle).replace(/\s+/g, '\\s+');
    const checkRE = new RegExp(checkString);

    return checkRE.test(haystack);
  }

  function createFiles(filename, data, pathname) {
    const options = {
      rmWhitespace: true,
      beautify: true,
    };

    ejs.renderFile(filename, data, options, (err, str) => {
      const strWithOutSpace = str;
      // .replace(/(\r\n|\n|\r)/gm, "")

      if (err) {
        console.error(err);
      }

      const outputFile = path.join(process.cwd(), pathname);
      fs.ensureFileSync(outputFile);
      fs.outputFileSync(outputFile, strWithOutSpace);
    });
  }

  main();
};

if (typeList.length > 0) {
  typeList.forEach((item) => {
    writeGenerator(item);
  });
} else {
  writeGenerator({ type: staticDataType, schemaQuery: schemaQueryName });
}

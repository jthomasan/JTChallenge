const typeList = [];

// Type
const type = "schedules";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "ScheduleMapping";
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    name: String
    scheduleLocation: String
    lastIssuedOn: String
    lastIssuedBy: InputOptionType
    marketRiskBusiness: InputOptionType
    reviewDate: String
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "limits/v1/schedules",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: { $value: "{args.id}", $type: "number" },
        name: "{args.name}",
        scheduleLocation: "{args.scheduleLocation}",
        marketRiskBusiness: {
          id: {
            $value: "{args.marketRiskBusiness.id}",
            $type: "number",
          },
        },
        lastIssuedOn: "{args.lastIssuedOn}",
        reviewDate: "{args.reviewDate}",
        lastIssuedBy: "{args.lastIssuedBy.id}",
        isActive: { $value: "{args.isActive}", $type: "boolean" },
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    width: "90px",
    cell: "GridStateCell",
  },
  {
    field: "marketRiskBusiness.text",
    title: "Market Risk Business",
    filter: "text",
    width: "150px",
    defaultSortColumn: true,
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.MarketRiskBusinessSelectors",
      selectorField: "text",
      typeOf: "string",
    },
  },
  {
    field: "name",
    title: "Market Risk Limit Schedule",
    filter: "text",
    width: "180px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "string",
    },
  },
  {
    field: "scheduleLocation",
    title: "Document Location",
    filter: "text",
    width: "110px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "lastIssuedOn",
    title: "Last Issued On",
    filter: "text",
    width: "110px",
    editable: true,
    cell: "GridDatePickerCell",
    extras: {
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "reviewDate",
    title: "Review Date",
    filter: "text",
    width: "110px",
    editable: true,
    cell: "GridDatePickerCell",
    extras: {
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "lastIssuedBy.text",
    title: "Last Issued By",
    filter: "text",
    width: "110px",
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.UserList",
      selectorField: "text",
      typeOf: "string",
    },
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

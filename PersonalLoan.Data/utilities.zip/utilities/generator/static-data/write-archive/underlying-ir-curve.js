// Type
const type = 'Underlying-IR Curve';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataUnderlyingIRCurve';
const selectors = [
  {
    name: 'SingleCurveType',
    title: 'SingleCurve Type',
    query: `
  {
    SingleCurveType {
      id
      text
    }
  }
`,
    schemaQuery: 'SingleCurveType: [SCCYTypeTypeSystemOption]',
    apiMappings: {
      Query: {
        SingleCurveType: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1055)]',
        },
      },
    },
    mockData: [
      {
        id: 1299,
        text: 'QM',
      },
      {
        id: 1300,
        text: 'QS',
      },
    ],
  },
  {
    name: 'CurveType',
    title: 'Curve Type',
    query: `
  {
    CurveType {
      id
      text
    }
  }
`,
    schemaQuery: 'CurveType: [CurveTypeSystemOption]',
    apiMappings: {
      Query: {
        CurveType: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1054)]',
        },
      },
    },
    mockData: [
      {
        id: 1296,
        text: 'SCCY',
      },
      {
        id: 1297,
        text: 'XCCY',
      },
      {
        id: 1298,
        text: 'N/A',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID!
    curve: String
    isActive: Boolean
    description: String
    tenorLowerDays: String
    tenorUpperDays: String
    SCCYTypeTypeSystem: InputOptionType
    curveTypeSystem: InputOptionType
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/curve-with-attributes',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        Curve: '{args.id}',
        curve: '{args.curve}',
        isActive: '{isActive}',
        description: '{args.description}',
        tenorLowerDays: '{args.tenorLowerDays}',
        tenorUpperDays: '{args.tenorUpperDays}',
        SCCYTypeTypeSystem: { id: '{args.SCCYTypeTypeSystem.id}' },
        curveTypeSystem: { id: '{args.curveTypeSystem.id}' },
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'curve',
    title: 'Curve',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
      isUnique: true,
    },
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'tenorLowerDays',
    title: 'TenorLowerDays',
    filter: 'numeric',
    typeOf: 'number',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'tenorUpperDays',
    title: 'TenorUpperDays',
    filter: 'numeric',
    typeOf: 'number',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'SCCYTypeTypeSystem.text',
    title: 'SingleCurveType',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.SingleCurveType',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'curveTypeSystem.text',
    title: 'CurveType',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CurveType',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

const typeList = [];

// Type
const type = 'Tenor Days To Maturity';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataTenorDaysToMaturity';
const selectors = [
  {
    name: 'TenorList',
    title: 'Tenor',
    query: `
  {
    TenorList {
      id
      text
    }
  }
`,
    schemaQuery: 'TenorList: [TenorListInputOption]',
    apiMappings: {
      Query: {
        TenorList: {
          url: 'reference-data/v1/tenors',
          dataPath: '$',
        },
      },
      TenorListInputOption: { id: '$.pillar', text: '$.pillar' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    tenor: String
    daysToMaturity: Int
    isDeliverable: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/tenor-eto',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        tenor: '{args.tenor}',
        daysToMaturity: '{args.daysToMaturity}',
        isDeliverable: '{args.isDeliverable}',
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'bondETOInstrument',
    title: 'Bond ETO Instrument',
    filter: 'text',
    width: '160px',
    defaultSortColumn: true,
  },
  {
    field: 'sEFName',
    title: 'Contract Description',
    filter: 'text',
    width: '200px',
  },
  {
    field: 'tRNGRP',
    title: 'Contract Group',
    filter: 'text',
    width: '130px',
  },
  {
    field: 'tenor',
    title: 'Tenor',
    filter: 'text',
    width: '90px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.TenorList',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'daysToMaturity',
    title: 'Days to Maturity',
    filter: 'numeric',
    width: '130px',
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
    },
  },
  {
    field: 'isDeliverable',
    title: 'Is Deliverable',
    filter: 'boolean',
    width: '120px',
    cell: 'GridCheckboxCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

//Type list
const typeList = [];

// Type
const type = 'Net Bucketing Dv01SrIrgCpiDv01';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataNetBucketingDv01SrIrgCpiDv01';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    term: ID
    sp_id: Int
    net3mCom: Float
    net1yPlus: Float
    net10y: Float
    net4yFXO: Float
    net20y: Float
    net1mFXO: Float
    net3m: Float
    net10yCom: Float
    net1yCom: Float
    net6mPlus: Float
    net30yPlus: Float
    net3yFXO: Float
    net2yFXO: Float
    net2mFXO: Float
    net7yFXO: Float
    nFA10y: Float
    net2m_3m: Float
    net6mFXO: Float
    nFA2y: Float
    nFA30y: Float
    nFA5y: Float
    net10yPlus: Float
    net10yFXO: Float
    net1yFXO: Float
    net5yCom: Float
    net2yPlus: Float
    net3mFXO: Float
    net3yCom: Float
    netLess1yCom: Float
    net5yFXO: Float
    net1y: Float
    net5y: Float
    net20yPlus: Float
    net3y: Float
    net3y: String
    net3mRAT: String
    net1yRAT: String
    net2yRAT: String
    net3yRAT: String
    net5yRAT: String
    net7yRAT: String
    net10yRAT: String
    net15yRAT: String
    net20yRAT: String
    net25yRAT: String
    net30yPlusRAT: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/update-tenor-bucket',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: [
        {
          term: '{args.term}',
          sp_id: { $value: '{args.sp_id}', $type: 'number' },
          net3mCom: { $value: '{args.net3mCom}', $type: 'number' },
          net1yPlus: { $value: '{args.net1yPlus}', $type: 'number' },
          net10y: { $value: '{args.net10y}', $type: 'number' },
          net4yFXO: { $value: '{args.net4yFXO}', $type: 'number' },
          net20y: { $value: '{args.net20y}', $type: 'number' },
          net1mFXO: { $value: '{args.net1mFXO}', $type: 'number' },
          net3m: { $value: '{args.net3m}', $type: 'number' },
          net10yCom: { $value: '{args.net10yCom}', $type: 'number' },
          net1yCom: { $value: '{args.net1yCom}', $type: 'number' },
          net6mPlus: { $value: '{args.net6mPlus}', $type: 'number' },
          net30yPlus: { $value: '{args.net30yPlus}', $type: 'number' },
          net3yFXO: { $value: '{args.net3yFXO}', $type: 'number' },
          net2yFXO: { $value: '{args.net2yFXO}', $type: 'number' },
          net2mFXO: { $value: '{args.net2mFXO}', $type: 'number' },
          net7yFXO: { $value: '{args.net7yFXO}', $type: 'number' },
          nFA10y: { $value: '{args.nFA10y}', $type: 'number' },
          net2m_3m: { $value: '{args.net2m_3m}', $type: 'number' },
          net6mFXO: { $value: '{args.net6mFXO}', $type: 'number' },
          nFA2y: { $value: '{args.nFA2y}', $type: 'number' },
          nFA30y: { $value: '{args.nFA30y}', $type: 'number' },
          nFA5y: { $value: '{args.nFA5y}', $type: 'number' },
          net10yPlus: { $value: '{args.net10yPlus}', $type: 'number' },
          net10yFXO: { $value: '{args.net10yFXO}', $type: 'number' },
          net1yFXO: { $value: '{args.net1yFXO}', $type: 'number' },
          net5yCom: { $value: '{args.net5yCom}', $type: 'number' },
          net2yPlus: { $value: '{args.net2yPlus}', $type: 'number' },
          net3mFXO: { $value: '{args.net3mFXO}', $type: 'number' },
          net3yCom: { $value: '{args.net3yCom}', $type: 'number' },
          netLess1yCom: { $value: '{args.netLess1yCom}', $type: 'number' },
          net5yFXO: { $value: '{args.net5yFXO}', $type: 'number' },
          net1y: { $value: '{args.net1y}', $type: 'number' },
          net5y: { $value: '{args.net5y}', $type: 'number' },
          net20yPlus: { $value: '{args.net20yPlus}', $type: 'number' },
          net3y: { $value: '{args.net3y}', $type: 'number' },
          net3mRAT: { $value: '{args.net3mRAT}', $type: 'number' },
          net1yRAT: { $value: '{args.net1yRAT}', $type: 'number' },
          net2yRAT: { $value: '{args.net2yRAT}', $type: 'number' },
          net5yRAT: { $value: '{args.net5yRAT}', $type: 'number' },
          net5yRAT: { $value: '{args.net5yRAT}', $type: 'number' },
          net7yRAT: { $value: '{args.net7yRAT}', $type: 'number' },
          net10yRAT: { $value: '{args.net10yRAT}', $type: 'number' },
          net20yRAT: { $value: '{args.net20yRAT}', $type: 'number' },
          net25yRAT: { $value: '{args.net25yRAT}', $type: 'number' },
          net30yPlusRAT: { $value: '{args.net30yPlusRAT}', $type: 'number' },
        },
      ],
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net2m_3m',
    title: 'Net2m_3m',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1y',
    title: 'Net1y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3y',
    title: 'Net3y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net5y',
    title: 'Net5y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net10y',
    title: 'Net10y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net10yPlus',
    title: 'Net10yPlus',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net20y',
    title: 'Net20y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net20yPlus',
    title: 'Net20yPlus',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net30yPlus',
    title: 'Net30yPlus',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1yPlus',
    title: 'Net1yPlus',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3mCom',
    title: 'Net3mCom',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'netLess1yCom',
    title: 'NetLess1yCom',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1yCom',
    title: 'Net1yCom',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3yCom',
    title: 'Net3yCom',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net5yCom',
    title: 'Net5yCom',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net10yCom',
    title: 'Net10yCom',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'nFA2y',
    title: 'NFA2y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'nFA5y',
    title: 'NFA5y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'nFA10y',
    title: 'NFA10y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'nFA30y',
    title: 'NFA30y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1mFXO',
    title: 'Net1mFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net2mFXO',
    title: 'Net2mFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3mFXO',
    title: 'Net3mFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net6mFXO',
    title: 'Net6mFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1yFXO',
    title: 'Net1yFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net2yFXO',
    title: 'Net2yFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3yFXO',
    title: 'Net3yFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net4yFXO',
    title: 'Net4yFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net5yFXO',
    title: 'Net5yFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net7yFXO',
    title: 'Net7yFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net10yFXO',
    title: 'Net10yFXO',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net6mPlus',
    title: 'Net6mPlus',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net2yPlus',
    title: 'Net2yPlus',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3mRAT',
    title: 'Net3mRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1yRAT',
    title: 'Net1yRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },

  {
    field: 'net2yRAT',
    title: 'Net2yRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3yRAT',
    title: 'Net3yRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net5yRAT',
    title: 'Net5yRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net7yRAT',
    title: 'Net7yRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net10yRAT',
    title: 'Net10yRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },

  {
    field: 'net15yRAT',
    title: 'Net15yRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net20yRAT',
    title: 'Net20yRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net25yRAT',
    title: 'Net25yRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net30yPlusRAT',
    title: 'Net30yPlusRAT',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },

];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

const typeList = [];

// Type
const type = 'longTermCreditRating';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataLongTermCreditRating';
const selectors = [
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    ranking: Int
    comment: String
  }
`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/credit-rating-with-attribute',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        ranking: '{args.ranking}',
        comment: '{args.comment}',
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'rating',
    title: 'Grp: CR Rating',
    filter: 'text',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'agency',
    title: 'Grp: CR Agency',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'isIssuer',
    title: 'Is Issuer',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'isIssue',
    title: 'Is Issue',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'ranking',
    title: 'Ranking',
    filter: 'numeric',
    width: '100px',
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number'
    } 
  },
  {
    field: 'anzRatingTypeSystem.text',
    title: 'Grp: CR Rating - Generic',
    filter: 'text',
    width: '180px',
  },
  {
    field: 'investmentGradeTypeSystem.text',
    title: 'Grp: CR Investment Grade',
    filter: 'text',
    width: '180px',
  },
  {
    field: 'ratingBandTypeSystem.text',
    title: 'Grp: CR Rating Band - LT',
    filter: 'text',
    width: '180px',
  },
  {
    field: 'ratingBandOtherTypeSystem.text',
    title: 'Grp: CR Rating Band - Other',
    filter: 'text',
    width: '180px',
  },
  {
    field: 'ratingBandSecTypeSystem.text',
    title: 'Grp: CR Rating Band - Sec',
    filter: 'text',
    width: '180px',
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    width: '180px',
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string'
    } 
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

const typeList = [];

// Type
const type = "Country";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataCountry";
const selectors = [
  {
    name: "BaseCurrency",
    title: "Base Currency",
    query: `
  {
    BaseCurrency {
      id
      text
    }
  }
`,
    schemaQuery: "BaseCurrency: [BaseCurrencyInputOption]",
    apiMappings: {
      Query: {
        BaseCurrency: {
          url: "reference-data/v1/currency-with-attributes",
          dataPath: "$",
        },
      },
      BaseCurrencyInputOption: { text: "$.name" },
    },
    mockData: [
      {
        text: "AUD",
        id: 1,
      },
      {
        text: "KYD",
        id: 2,
      },
    ],
  },
  {
    name: "Geography",
    title: "Geography",
    query: `
  {
    Geography {
      id
      text
    }
  }
`,
    schemaQuery: "Geography: [GeographyInputOption]",
    apiMappings: {
      Query: {
        Geography: {
          url: "reference-data/v1/geography",
          dataPath: "$",
        },
      },
      GeographyInputOption: { text: "$.name" },
    },
    mockData: [
      {
        id: 1218,
        text: "	Australia",
      },
      {
        id: 1219,
        text: "Other",
      },
    ],
  },
  {
    name: "STFGeographyTypeSystem",
    title: "STF Geography",
    query: `
  {
    STFGeographyTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery: "STFGeographyTypeSystem: [STFGeographyTypeSystemOption]",
    apiMappings: {
      Query: {
        STFGeographyTypeSystem: {
          url: "reference-data/v1/type-system-parameters",
          dataPath: "$[?(@.system.id == 1068)]",
        },
      },
    },
    mockData: [
      {
        id: 1218,
        text: "Tier1",
      },
      {
        id: 1219,
        text: "Tier2",
      },
    ],
  },
  {
    name: "FRTBGeographyTypeSystem",
    title: "FRTB Geography",
    query: `
  {
    FRTBGeographyTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery: "FRTBGeographyTypeSystem: [FRTBGeographyTypeSystemOption]",
    apiMappings: {
      Query: {
        FRTBGeographyTypeSystem: {
          url: "reference-data/v1/type-system-parameters",
          dataPath: "$[?(@.system.id == 1080)]",
        },
      },
    },
    mockData: [
      {
        id: 1218,
        text: "Asian",
      },
      {
        id: 1219,
        text: "Others",
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    countryCode: String
    name: String
    baseCurrency: InputOptionType
    geography: InputOptionType
    OECDIndicator: Boolean
    isCMRC: Boolean
    STFGeographyTypeSystem: InputOptionType
    FRTBGeographyTypeSystem: InputOptionType
    isActive: Boolean
  }
  
  type BaseCurrencyInputOption {
    id: ID
    text: String
  }
  
  type GeographyInputOption {
    id: ID
    text: String
  }
  `;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "reference-data/v1/country",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: "{args.id}",
        countryCode: "{args.countryCode}",
        name: "{args.name}",
        baseCurrency: { id: "{args.baseCurrency.id}" },
        geography: { id: "{args.geography.id}" },
        OECDIndicator: "{args.OECDIndicator}",
        isCMRC: "{args.isCMRC}",
        STFGeographyTypeSystem: { id: "{args.STFGeographyTypeSystem.id}" },
        FRTBGeographyTypeSystem: { id: "{args.FRTBGeographyTypeSystem.id}" },
        isActive: "{args.isActive}",
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "countryCode",
    title: "Country Code",
    filter: "text",
    width: "110px",
    onlyEditableOnNew: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "string",
      isPrimaryField: true,
      isUnique: true,
    },
  },
  {
    field: "name",
    title: "Name",
    filter: "text",
    width: "150px",
    defaultSortColumn: true,
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "string",
    },
  },
  {
    field: "baseCurrency.text",
    title: "Base Currency",
    filter: "text",
    width: "120px",
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.BaseCurrency",
      selectorField: "text",
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "geography.text",
    title: "Geography",
    filter: "text",
    width: "120px",
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.Geography",
      selectorField: "text",
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "STFGeographyTypeSystem.text",
    title: "STF Geography",
    filter: "text",
    width: "120px",
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.STFGeographyTypeSystem",
      selectorField: "text",
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "FRTBGeographyTypeSystem.text",
    title: "FRTB Geography",
    filter: "text",
    width: "120px",
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.FRTBGeographyTypeSystem",
      selectorField: "text",
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "isCMRC",
    title: "Is CMRC",
    filter: "boolean",
    width: "120px",
    cell: "GridCheckboxCell",
    editable: true,
    extras: {
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "OECDIndicator",
    title: "OECD Indicator",
    filter: "boolean",
    width: "120px",
    cell: "GridCheckboxCell",
    editable: true,
    extras: {
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

//Type list
const typeList = [];

// Type
const type = 'FXO Vega Net Buckets';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataFXOVegaNetBuckets';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    term: ID
    sp_id: Int
    net1m: Float
    net3m: Float
    net1y: Float
    net3y: Float
    net10y: Float
    net15y: Float
    net1m_1y: Float
    net1yPlus: Float
    net6mPlus: Float
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/update-tenor-bucket',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: [
        {
          term: '{args.term}',
          sp_id: { $value: '{args.sp_id}', $type: 'number' },
          net1m: { $value: '{args.net1m}', $type: 'number' },
          net3m: { $value: '{args.net3m}', $type: 'number' },
          net1y: { $value: '{args.net1y}', $type: 'number' },
          net3y: { $value: '{args.net3y}', $type: 'number' },
          net10y: { $value: '{args.net10y}', $type: 'number' },
          net15y: { $value: '{args.net15y}', $type: 'number' },
          net1m_1y: { $value: '{args.net1m_1y}', $type: 'number' },
          net1yPlus: { $value: '{args.net1yPlus}', $type: 'number' },
          net6mPlus: { $value: '{args.net6mPlus}', $type: 'number' },
        },
      ],
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net1m',
    title: 'Net1m',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1y',
    title: 'Net1y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3y',
    title: 'Net3y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net10y',
    title: 'Net10y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net15y',
    title: 'Net15y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1m_1y',
    title: 'Net1m_1y',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1yPlus',
    title: 'Net1yPlus',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net6mPlus',
    title: 'Net6mPlus',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

const typeList = [];

// Type
const type = 'Portfolio Config';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataPortfolioConfig';
const selectors = [
  {
    name: 'Portfolio',
    title: 'Portfolio',
    query: `
  {
    Portfolio {
      id
      text
    }
  }
`,
    schemaQuery: 'Portfolio: [PortfolioInputOption]',
    apiMappings: {
      Query: {
        Portfolio: {
          url: 'reference-data/v1/portfolios',
          dataPath: '$',
        },
      },
      PortfolioInputOption: { text: '$.name' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'SourceSystems',
    title: 'Source Systems',
    query: `
  {
    SourceSystems {
      id
      text
    }
  }
`,
    schemaQuery: 'SourceSystems: [SourceSystemsInputOption]',
    apiMappings: {
      Query: {},
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    portfolio: InputOptionType
    sources: [InputOptionType]
    officialSource: InputOptionType
    isActive: Boolean
  }
  
  type PortfolioInputOption {
    id: ID
    text: String
  }

  type SourceSystemsInputOption {
    id: ID
    text: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/portfolio-configs',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        portfolio: { id: '{args.portfolio.id}' },
        sources: { id: '{args.sources.id}' },
        officialSource: { id: '{args.officialSource.id}' },
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'portfolio.text',
    title: 'Portfolio',
    filter: 'text',
    width: '120px',
    defaultSortColumn: true,
    onlyEditableOnNew: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.Portfolio',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'container.text',
    title: 'Container',
    filter: 'text',
    width: '180px',
  },
  {
    field: 'sources',
    title: 'Source Systems',
    filter: 'text',
    width: '125px',
    editable: true,
    cell: 'GridMultiSelectCell',
    extras: {
      selector: 'Selector.SourceSystems',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'officialSource.text',
    title: 'Official Source',
    filter: 'text',
    width: '110px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.SourceSystems',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

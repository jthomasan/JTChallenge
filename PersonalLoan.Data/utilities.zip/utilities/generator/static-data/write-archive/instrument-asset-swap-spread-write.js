const typeList = [];

// Type
const type = "instrumentAssetSwapSpread";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataInstrumentAssetSwapSpread";
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    ISIN: String
    spread: Float
    cob: String!
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "reference-data/v1/update-asset-swap-spread",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        instrument: { $value: "{args.id}", $type: "number" },
        ISIN: "{args.ISIN}",
        spread: { $value: "{args.spread}", $type: "number" },
        cobDate: { $value: "{args.cob}", $type: "number" },
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    width: "80px",
    cell: "GridStateCell",
  },
  {
    field: "name",
    title: "Instrument",
    filter: "text",
    width: "150px",
    defaultSortColumn: true,
  },
  {
    field: "ISIN",
    title: "ISIN",
    filter: "text",
    width: "150px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "spread",
    title: "Spread",
    filter: "text",
    width: "120px",
    editable: true,
    cell: "GridTextboxCell",
    typeOf: "number",
    extras: {
      typeOf: "number",
      isOptional: true,
    },
  },
  {
    field: "isLive",
    title: "Is Live",
    filter: "boolean",
    width: "100px",
    cell: "GridCheckboxCell",
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

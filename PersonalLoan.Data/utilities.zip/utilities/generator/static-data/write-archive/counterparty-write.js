const typeList = [];

// Type
const type = 'Counterparty';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataCounterparty';
const selectors = [
  {
    name: 'Country',
    title: 'Country',
    query: `
  {
    Country {
      id
      text
    }
  }
`,
    schemaQuery: 'Country: [CountryInputOption]',
    apiMappings: {
      Query: {
        Country: {
          url: 'reference-data/v1/country',
          dataPath: '$',
        },
      },
      CountryInputOption: { text: '$.name' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'Country',
    title: 'Country',
    query: `
  {
    Country {
      id
      text
    }
  }
`,
    schemaQuery: 'Country: [CountryInputOption]',
    apiMappings: {
      Query: {
        Country: {
          url: 'reference-data/v1/country',
          dataPath: '$',
        },
      },
      CountryInputOption: { text: '$.name' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'InternalCounterparty',
    title: 'InternalCounterparty',
    query: `
  {
    InternalCounterparty {
      id
      text
    }
  }
`,
    schemaQuery: 'InternalCounterparty: [InternalCounterpartyInputOption]',
    apiMappings: {
      Query: {
        InternalCounterparty: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1010)]',
        },
      },
      InternalCounterpartyInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'STFSector',
    title: 'STFSector',
    query: `
  {
    STFSector {
      id
      text
    }
  }
`,
    schemaQuery: 'STFSector: [STFSectorInputOption]',
    apiMappings: {
      Query: {
        STFSector: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: "$[?(@.system.name == 'STFSector')]",
        },
      },
      STFSectorInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    counterpartyName: String
    Country: InputOptionType
    internalGroupTypeSystem: InputOptionType
    STFSectorTypeSystem: InputOptionType
    isInternal: Boolean
    razorCode: String
    CTPYCOUNTRYOFRISK: String
    COUNTRYOFDOMICILE: String
    interbank: String
    CTPYCCR: String
    setNo: String
    controlPoint: String
    CTPYRazorName: String
    interdeskDescription: String
    comment: String
  }

  type CountryInputOption {
    id: ID
    text: String
  }
  
  type InternalCounterpartyInputOption {
    id: ID
    text: String
  }

  `;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/counter-party-with-attribute',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        counterpartyName: '{args.counterpartyName}',
        Country: { id: '{args.Country.id}' },
        internalGroupTypeSystem: { id: '{args.internalGroupTypeSystem.id}' },
        STFSectorTypeSystem: { id: '{args.STFSectorTypeSystem.id}' },
        isInternal: '{args.isInternal}',
        razorCode: '{args.razorCode}',
        CTPYCOUNTRYOFRISK: '{args.CTPYCOUNTRYOFRISK}',
        COUNTRYOFDOMICILE: '{args.COUNTRYOFDOMICILE}',
        interbank: '{args.interbank}',
        CTPYCCR: '{args.CTPYCCR}',
        setNo: '{args.setNo}',
        controlPoint: '{args.controlPoint}',
        CTPYRazorName: '{args.CTPYRazorName}',
        interdeskDescription: '{args.interdeskDescription}',
        comment: '{args.comment}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'counterpartyExternalId',
    title: 'External ID',
    filter: 'text',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'SourceKey.text',
    title: 'Source',
    filter: 'text',
    width: '90px',
  },
  {
    field: 'counterpartyName',
    title: 'Counterparty Name',
    filter: 'text',
    width: '300px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'Country.text',
    title: 'Country',
    filter: 'text',
    width: '90px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.Country',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'internalGroupTypeSystem.text',
    title: 'Grp: Internal Counterparty',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.InternalCounterparty',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'STFSectorTypeSystem.text',
    title: 'Grp: STF Sector',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.STFSector',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'isInternal',
    title: 'Is Internal',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'razorCode',
    title: 'RazorCode',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'CTPYCOUNTRYOFRISK',
    title: 'CTPY_COUNTRY_OF_RISK',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'COUNTRYOFDOMICILE',
    title: 'COUNTRY_OF_DOMICILE',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'interbank',
    title: 'Interbank',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'CTPYCCR',
    title: 'CTPY_CCR',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'setNo',
    title: 'Set No.',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'controlPoint',
    title: 'Control Point',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'CTPYRazorName',
    title: 'CTPY_Razor_Name',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'interdeskDescription',
    title: 'Interdesk - Description',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  type,
  typeList,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

const typeList = [];

// Type
const type = "marketRiskBusinessAssignment";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "MarketRiskBusinessAssignmentMapping";
const selectors = [
  {
    name: "MarketRiskBusinessSelectors",
    title: "Market Risk Business",
    query: `
{
  MarketRiskBusinessSelectors {
    id
    text
  }
}
`,
    schemaQuery: "MarketRiskBusinessSelectors: [MarketRiskBusinessOption]",
    apiMappings: {
      Query: {
        MarketRiskBusinessSelectors: {
          url: "limits/v1/market-risk-business",
          dataPath: "$",
        },
      },
      MarketRiskBusinessOption: {
        text: "$.code",
      },
    },
    mockData: [
      {
        id: 1,
        text: "China",
      },
      {
        id: 2,
        text: "Commodities",
      },
      {
        id: 3,
        text: "Credit",
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    marketRiskBusiness: InputOptionType
    user: InputOptionType
    receiveNotifications: Boolean
    isActive: Boolean
  }
  
  type MarketRiskBusinessOption {
    id: ID
    text: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "limits/v1/market-risk-business-management",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        marketRiskBusiness: {
          id: { $value: "{args.marketRiskBusiness.id}", $type: "number" },
        },
        userId: "{args.user.id}",
        receiveNotifications: {
          $value: "{args.receiveNotifications}",
          $type: "boolean",
        },
        isActive: { $value: "{args.isActive}", $type: "boolean" },
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    width: "90px",
    cell: "GridStateCell",
  },
  {
    field: "marketRiskBusiness.text",
    title: "Market Risk Business",
    filter: "text",
    width: "150px",
    onlyEditableOnNew: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.MarketRiskBusinessSelectors",
      selectorField: "text",
      typeOf: "string",
    },
  },
  {
    field: "user.text",
    title: "User",
    filter: "text",
    width: "150px",
    defaultSortColumn: true,
    onlyEditableOnNew: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.UserList",
      selectorField: "text",
      typeOf: "string",
    },
  },
  {
    field: "receiveNotifications",
    title: "Receive Notifications",
    filter: "boolean",
    width: "150px",
    cell: "GridCheckboxCell",
    editable: true,
    extras: {
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

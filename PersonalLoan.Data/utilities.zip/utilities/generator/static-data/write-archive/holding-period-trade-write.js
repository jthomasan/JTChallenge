// Type
const type = "Holding Period Trade";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataHoldingPeriodTrade";
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    cobDate: String!
    baseNotional: Float
    notional: String
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "/reference-data/v1/currency-with-attributes?cobDate={args.cobDate}",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: "{args.id}",
        curve: "{args.curve}",
        description: "{args.description}",
        tenorLowerDays: "{args.tenorLowerDays}",
        tenorUpperDays: "{args.tenorUpperDays}",
        SCCYTypeTypeSystem: { id: "{args.SCCYTypeTypeSystem.id}" },
        curveTypeSystem: { id: "{args.curveTypeSystem.id}" },
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "reportDate",
    title: "Report Date",
    filter: "numeric",
    typeOf: "numeric",
    width: "120px",
  },
  {
    field: "family",
    title: "Family",
    filter: "text",
    typeOf: "string",
    width: "90px",
  },
  {
    field: "group",
    title: "Group",
    filter: "text",
    typeOf: "string",
    width: "90px",
  },
  {
    field: "nb",
    title: "Trade ID",
    filter: "text",
    typeOf: "string",
    width: "110px",
    defaultSortColumn: true,
    extras: {
      isPrimaryField: true,
      typeOf: "string",
      isUnique: true,
    },
  },
  {
    field: "isInMRE",
    title: "Status",
    filter: "boolean",
    cell: "GridCheckboxCell",
    typeOf: "boolean",
    width: "90px",
  },
  {
    field: "instrumentName",
    title: "Instrument",
    filter: "text",
    typeOf: "string",
    width: "130px",
  },
  {
    field: "portfolioName",
    title: "Portfolio",
    filter: "text",
    typeOf: "string",
    width: "130px",
  },
  {
    field: "currencyName",
    title: "Currency",
    filter: "text",
    typeOf: "string",
    width: "100px",
  },
  {
    field: "notional",
    title: "Notional",
    filter: "numeric",
    typeOf: "String",
    width: "100px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "numeric",
      isOptional: true,
    },
  },
  {
    field: "baseNotional",
    title: "Base Notional",
    filter: "numeric",
    typeOf: "numeric",
    width: "130px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "numeric",
      isOptional: true,
    },
  },
  {
    field: "maturityDate",
    title: "Maturity Date",
    filter: "numeric",
    typeOf: "numeric",
    width: "130px",
  },
  {
    field: "issuerName",
    title: "Issuer",
    filter: "text",
    typeOf: "string",
    width: "110px",
  },
  {
    field: "rank",
    title: "Rank",
    filter: "text",
    typeOf: "string",
    width: "90px",
  },
  {
    field: "isLongDated",
    title: "Is Long Dated",
    filter: "boolean",
    cell: "GridCheckboxCell",
    typeOf: "boolean",
    width: "120px",
  },
  {
    field: "isSettlementTrade",
    title: "Is Settlement Trade",
    filter: "boolean",
    cell: "GridCheckboxCell",
    typeOf: "boolean",
    width: "150px",
  },
  {
    field: "isExcludedTrade",
    title: "Is Excluded Trade",
    filter: "boolean",
    cell: "GridCheckboxCell",
    typeOf: "boolean",
    width: "140px",
  },
  {
    field: "replaceDate",
    title: "Replace Date",
    filter: "numeric",
    typeOf: "numeric",
    width: "120px",
  },
  {
    field: "replaced",
    title: "Replaced ID",
    filter: "numeric",
    typeOf: "numeric",
    width: "110px",
  },
  {
    field: "isReplacedTrade",
    title: "Is Replaced Trade",
    filter: "boolean",
    cell: "GridCheckboxCell",
    typeOf: "boolean",
    width: "140px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

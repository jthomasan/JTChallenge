const typeList = [];

// Type
const type = "D2A Forms";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataD2AForms";
const selectors = [
  {
    name: "ReturnIdentifiers",
    title: "Return Identifier",
    query: `
  {
    ReturnIdentifiers {
      id
      text
    }
  }
`,
    schemaQuery: "ReturnIdentifiers: [ReturnIdentifierOption]",
    mockData: [
      {
        id: "3075",
        text: "Market Risk Return 1 - Advanced",
      },
      {
        id: "3076",
        text: "Market Risk Return 2 - Internal Model - Advanced",
      },
      {
        id: "3077",
        text: "Market Risk Return 3 - Stress Testing - Advanced",
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    version: Int
    order: Int
    formCode: String
    returnIdentifier: InputOptionType
    formName: String
    calculateTwoLevels: Boolean
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "reference-data/v1/d2aforms",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: "{args.id}",
        version: "{args.version}",
        order: "{args.order}",
        formCode: "{args.formCode}",
        formName: "{args.formName}",
        returnIdentifier: { id: "{args.returnIdentifier.id}" },
        calculateTwoLevels: "{args.calculateTwoLevels}",
        isActive: "{args.isActive}",
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "formName",
    title: "Form Name",
    filter: "numeric",
    width: "150px",
    defaultSortColumn: true,
    cell: "GridTextboxCell",
    editable: true,
    onlyEditableOnNew: true,
    extras: {
      isPrimaryField: true,
      typeOf: "string",
      isUnique: true,
    },
  },
  {
    field: "formCode",
    title: "Form Code",
    filter: "text",
    width: "120px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "string",
    },
  },
  {
    field: "returnIdentifier.text",
    title: "Return Identifier",
    filter: "text",
    typeOf: "string",
    width: "250px",
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.ReturnIdentifiers",
      selectorField: "text",
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "version",
    title: "Version",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "number",
      isOptional: true,
    },
  },
  {
    field: "calculateTwoLevels",
    title: "Calculate Two Levels",
    filter: "text",
    typeOf: "string",
    width: "150px",
    editable: true,
    cell: "GridCheckboxCell",
    extras: {
      typeOf: "boolean",
      isOptional: true,
    },
  },
  {
    field: "order",
    title: "Order",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "number",
      isOptional: true,
    },
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

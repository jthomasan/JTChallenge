const typeList = [];

// Type
const type = 'Vega Option Expiry Net Buckets CapFloor';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataEquityVegaOptionExpiryNetBucketsCapFloor';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    term: ID
    net3m: String
    net1y: String
    net3y: String
    net10y: String
    net20y: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/update-tenor-bucket',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        term: '{args.term}',
        net3m: '{args.net3m}',
        net1y: '{args.net1y}',
        net3y: '{args.net3y}',
        net10y: '{args.net10y}',
        net20y: '{args.net20y}',
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1y',
    title: 'Net1y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3y',
    title: 'Net3y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net10y',
    title: 'Net10y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net20y',
    title: 'Net20y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
];

module.exports = {
  type,
  typeList,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

//Type list
const typeList = [];

// Type
const type = 'Market Risk Business';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'MarketRiskBusinessMapping';
const selectors = [
  {
    name: 'MRBusinessGrouping',
    title: 'Grouping',
    query: `
  {
    MRBusinessGrouping {
      id
      text
    }
  }
`,
    schemaQuery: 'MRBusinessGrouping: [MarketRiskBusinessGroupingInputOption]',
    apiMappings: {
      Query: {
        MRBusinessGrouping: {
          url: 'limits/v1/limit-market-risk-business-group',
          dataPath: '$',
        },
      },
      MarketRiskBusinessGroupingInputOption: { text: '$.value', id:'$.marketRiskBusinessGroupId' },
    },
    mockData: [
      {
        text: 'Traded Group',
        id: 1,
      },
      {
        text: 'Non Traded Group',
        id: 2,
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    code: String
    marketRiskBusinessDescription: String
    marketRiskBusinessGroup: InputOptionType
  }
  
  type MarketRiskBusinessGroupingInputOption {
    id: ID
    text: String
  }
  `;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/limits/v1/update-market-risk-business',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        code: '{args.code}',
        marketRiskBusinessDescription: '{args.marketRiskBusinessDescription}',
        marketRiskBusinessGroup: { id: '{args.marketRiskBusinessGroup.id}'},
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'code',
    title: 'Code',
    filter: 'text',
    width: '120px',
    defaultSortColumn: true,
    editable: true,
    cell: 'GridTextboxCell',
  },  
  {
    field: 'marketRiskBusinessDescription',
    title: 'MarketRiskBusinessDescription',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
  },
  {
    field: 'marketRiskBusinessGroup.text',
    title: 'Grouping',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.MRBusinessGrouping',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

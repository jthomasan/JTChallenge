const typeList = [];

// Type
const type = 'Custom Member';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataCustomMember';
const selectors = [
  {
    name: 'Operation',
    title: 'Operation',
    query: `
{
  Operation {
    id
    text
  }
}
`,
    schemaQuery: 'Operation: [OperationTypeOption]',
    apiMappings: {
      Query: {
        Operation: {
          url: 'reference-data/v1/custom-member-operations',
          dataPath: '$',
        },
      },
      OperationTypeOption: {
        text: '$.name',
      },
    },
    mockData: [
      {
        id: 147,
        text: 'Gold SGE',
      },
      {
        id: 148,
        text: 'JPY',
      },
      {
        id: 149,
        text: 'Other',
      },
    ],
  },
  {
    name: 'UnderlyingType',
    title: 'Underlying Type',
    query: `
{
  UnderlyingType {
    id
    text
  }
}
`,
    schemaQuery: 'UnderlyingType: [UnderlyingTypeOption]',
    apiMappings: {
      Query: {
        UnderlyingType: {
          url: 'reference-data/v1/type-system',
          dataPath: '$',
        },
      },
      UnderlyingTypeOption: {
        text: '$.displayName',
      },
    },
    mockData: [
      {
        id: 147,
        text: 'Gold SGE',
      },
      {
        id: 148,
        text: 'JPY',
      },
      {
        id: 149,
        text: 'Other',
      },
    ],
  },
  {
    name: 'UnderlyingNameList',
    title: 'Name of Underlying',
    query: `
{
  UnderlyingNameList {
    id
    text
  }
}
`,
    schemaQuery: 'UnderlyingNameList: [UnderlyingNameListOption]',
    apiMappings: {
      Query: {
        UnderlyingNameList: {
          url: 'reference-data/v1/type-system',
          dataPath: '$',
        },
      },
      UnderlyingNameListOption: {
        text: '$.displayName',
      },
    },
    mockData: [
      {
        id: 147,
        text: 'Gold SGE',
      },
      {
        id: 148,
        text: 'JPY',
      },
      {
        id: 149,
        text: 'Other',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    name: String
    underlyingType: String
    operation: String
    nameofUnderlying: String
    isActive: Boolean
  }
  
  type OperationTypeOption {
    id: ID
    text: String
  }
  
  type UnderlyingTypeOption {
    id: ID
    text: String
  }
  
  type UnderlyingNameListOption {
    id: ID
    text: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/custom-members',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        name: '{args.name}',
        underlyingType: { id: '{args.underlyingType.id}' },
        operation: { id: '{args.operation.id}' },
        nameofUnderlying: { id: '{args.nameofUnderlying.id}' },
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    width: '150px',
    defaultSortColumn: true,
    onlyEditableOnNew: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isPrimaryField: true,
    },
  },
  {
    field: 'operation',
    title: 'Operation',
    filter: 'text',
    width: '120px',
    onlyEditableOnNew: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.Operation',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'underlyingType',
    title: 'Underlying Type',
    filter: 'text',
    width: '150px',
    onlyEditableOnNew: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.UnderlyingType',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'nameofUnderlying',
    title: 'Name of Underlying',
    filter: 'text',
    width: '250px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.UnderlyingNameList',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

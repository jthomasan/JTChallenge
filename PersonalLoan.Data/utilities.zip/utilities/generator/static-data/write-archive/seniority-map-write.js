// Bulk Type
const typeList = [];

// Type
const type = 'Seniority Map';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataSeniorityMap';
const selectors = [
  {
    name: 'GenericSeniority',
    title: 'Generic Seniority',
    query: `
  {
    GenericSeniority {
      id
      text
    }
  }
`,
    schemaQuery: 'GenericSeniority: [GenericSeniorityInputOption]',
    apiMappings: {
      Query: {
        GenericSeniority: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.name == 1053)]',
        },
      },
      GenericSeniorityInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    seniority: String
    genericSeniorityTypeSystem: InputOptionType
    isActive: Boolean
  }
  
  type GenericSeniorityInputOption {
    id: ID
    text: String
  }
  `;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/seniority-map',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        Seniority: '{args.id}',
        seniority: '{args.seniority}',
        genericSeniorityTypeSystem: {
          id: '{args.genericSeniorityTypeSystem.id}',
        },
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'seniority',
    title: 'Seniority',
    filter: 'text',
    width: '180px',
    defaultSortColumn: true,
    onlyEditableOnNew: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isPrimaryField: true,
      isUnique: true,
    },
  },
  {
    field: 'genericSeniorityTypeSystem.text',
    title: 'Generic Seniority',
    filter: 'text',
    width: '180px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.GenericSeniority',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '180px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

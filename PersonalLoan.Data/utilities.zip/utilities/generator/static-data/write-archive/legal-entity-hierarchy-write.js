// Type
const type = 'Legal Entity Hierarchy';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataLegalEntityHierarchy';
const selectors = [
  {
    name: 'LegalEntityHierarchy',
    title: 'Legal Entity Hierarchy',
    query: `
  {
    LegalEntityHierarchy {
      id
      title
      fullPath
      parent
      children
    }
  }
`,
    schemaQuery: 'LegalEntityHierarchy: [LegalEntityHierarchyType]',
    apiMappings: {
      Query: {
        LegalEntityHierarchy: {
          url: 'hierarchy/v1/hierarchies/9/nodes',
          dataPath: '$',
        },
      },
    },
    mockData: [],
  },
];

// Scheme
const schemaType = `
  type LegalEntityHierarchyType {
    id: ID!
    title: String!
    fullPath: String
    parent: ID
    children: [ID]
  }

  input Update${schemaQuery} {
    id: ID!
    name: String
    hierarchy: HierarchyInput
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/legal-entity',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        name: '{args.name}',
        hierarchy: { id: '{args.hierarchy.id}' },
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    width: '150px',
    defaultSortColumn: true,
    onlyEditableOnNew: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
      isUnique: true,
    },
  },
  {
    field: 'hierarchy.value',
    title: 'Legal Entity Hierarchy',
    filter: 'text',
    width: '180px',
    cell: 'GridTreeSelectCell',
    editable: true,
    extras: {
      selector: 'Selector.LegalEntityHierarchy',
      selectorField: 'title',
      typeOf: 'string',
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

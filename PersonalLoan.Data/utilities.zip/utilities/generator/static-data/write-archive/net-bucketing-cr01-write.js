//Type list
const typeList = [];

// Type
const type = 'Net Bucketing Cr01';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataNetBucketingCr01';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    term: ID
    sp_id: Int
    net10y: Float
    net30yPlus: Float
    net20y: Float
    net1y: Float
    net3m: Float
    net5y: Float
    net3y: Float
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/update-tenor-bucket',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: [
        {
          term: '{args.term}',
          sp_id: { $value: '{args.sp_id}', $type: 'number' },
          net10y: { $value: '{args.net10y}', $type: 'number' },
          net30yPlus: { $value: '{args.net30yPlus}', $type: 'number' },
          net20y: { $value: '{args.net20y}', $type: 'number' },
          net1y: { $value: '{args.net1y}', $type: 'number' },
          net3m: { $value: '{args.net3m}', $type: 'number' },
          net5y: { $value: '{args.net5y}', $type: 'number' },
          net3y: { $value: '{args.net3y}', $type: 'number' },
        },
      ],
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net1y',
    title: 'Net1y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net3y',
    title: 'Net3y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net5y',
    title: 'Net5y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net10y',
    title: 'Net10y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net20y',
    title: 'Net20y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net30yPlus',
    title: 'Net30yPlus',
    filter: 'numeric',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

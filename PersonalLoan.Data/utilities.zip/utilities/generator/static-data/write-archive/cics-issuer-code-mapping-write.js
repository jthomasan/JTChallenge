const typeList = [];

// Type
const type = "cicsIssuerCodeMapping";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataCICSIssuerCodeMappingType";
const selectors = [
  {
    name: "CICSIssuer",
    title: "Issuer",
    query: `
  {
    CICSIssuer {
      id
      text
    }
  }
`,
    schemaQuery: "CICSIssuer: [IssuerInputOption]",
    apiMappings: {
      Query: {
        CICSIssuer: {
          url: "reference-data/v1/issuer-with-attribute",
          dataPath: "$",
        },
      },
      IssuerInputOption: { text: "$.issuerCode" },
    },
    mockData: [
      {
        text: "AUD",
        id: 1,
      },
      {
        text: "KYD",
        id: 2,
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    Issuer: InputOptionType
  }
  
  type IssuerInputOption {
    id: ID
    text: String
  }
  `;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "reference-data/v1/issuer-cicscode",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        IssuerCICSCode: "{args.id}",
        Issuer: { id: "{args.Issuer.id}" },
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "CICSIssuerCode",
    title: "CICS Issuer Code",
    filter: "text",
    typeOf: "string",
    width: "210px",
    defaultSortColumn: true,
  },
  {
    field: "Issuer.text",
    title: "Issuer",
    filter: "text",
    typeOf: "string",
    width: "150px",
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.CICSIssuer",
      selectorField: "text",
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

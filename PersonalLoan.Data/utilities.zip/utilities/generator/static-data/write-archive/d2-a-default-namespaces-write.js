// Type
const type = "D2A Default Namespaces";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataD2ADefaultNamespace";
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    uri: String
    prefix: String
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "reference-data/v1/d2adefault-namespaces",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: "{args.id}",
        uri: "{args.uri}",
        prefix: "{args.prefix}",
        isActive: "{args.isActive}",
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "prefix",
    title: "Prefix",
    filter: "text",
    typeOf: "string",
    width: "150px",
    defaultSortColumn: true,
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "uri",
    title: "Uri",
    filter: "text",
    typeOf: "string",
    width: "300px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
      defaultToTrueWhenAddNew: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

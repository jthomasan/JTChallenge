const typeList = [];

// Type
const type = "productSubCategories";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "ProductSubCategoryMapping";
const selectors = [
  {
    name: "GlobalProductLine",
    title: "Global Product Line",
    query: `
  {
    GlobalProductLine {
      id
      text
    }
  }
`,
    schemaQuery: "GlobalProductLine: [GlobalProductLineInputOption]",
    apiMappings: {
      Query: {
        GlobalProductLine: {
          url: "limits/v1/global-product-lines",
          dataPath: "$",
        },
      },
      GlobalProductLineInputOption: { text: "$.description" },
    },
    mockData: [
      {
        text: "Fixed Income",
        id: 1,
      },
      {
        text: "Balance Sheet",
        id: 2,
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    description: String
    globalProductLine: InputOptionType
    isActive: Boolean
  }
  
  type GlobalProductLineInputOption {
    id: ID
    text: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "limits/v1/product-sub-category",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: { $value: "{args.id}", $type: "number" },
        description: "{args.description}",
        globalProductLine: {
          id: {
            $value: "{args.globalProductLine.id}",
            $type: "number",
          },
        },
        isActive: { $value: "{args.isActive}", $type: "boolean" },
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "description",
    title: "Product Sub Category",
    filter: "text",
    typeOf: "string",
    width: "180px",
    defaultSortColumn: true,
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "string",
      isPrimaryField: true,
    },
  },
  {
    field: "globalProductLine.text",
    title: "Global Product Line",
    filter: "text",
    typeOf: "string",
    width: "180px",
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.GlobalProductLine",
      selectorField: "text",
      typeOf: "string",
    },
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

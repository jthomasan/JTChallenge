const typeList = [];

// Type
const type = 'ratingOverride';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataRatingOverride';
const selectors = [
  {
    name: 'StaticDataLongTermCreditRatings',
    title: 'Rating',
    query: `
      query($agency: String!) {
        StaticDataLongTermCreditRatings(agency: [$agency]) {
          id
          text: rating
        }
      }
    `,
    mockData: [
      {
        rating: 'A',
        id: 1
      },
      {
        rating: 'B',
        id: 2
      }
    ]
  },

  {
    name: 'Agency',
    title: 'Agency',
    query: `
      {
        Agency {
          id
          text
        }
      }
    `,
    schemaQuery: 'Agency: [AgencyOption]',
    apiMappings: {
      Query: {
        Agency: [
          {id: 'SNP', text: 'SNP'},
          {id: 'MOODYS', text: 'MOODYS'},
          {id: 'FITCH', text: 'FITCH'},
        ]
      }
    },
    mockData: [
      {id: 'SNP', text: 'SNP'},
      {id: 'MOODYS', text: 'MOODYS'},
      {id: 'FITCH', text: 'FITCH'},
    ]
  },
];

// Scheme
const schemaType = `
  type AgencyOption {
    id: ID!
    text: String!
  }

  input Update${schemaQuery} {
    id: ID
    issuer: InputOptionType
    agency: InputOptionType
    creditRating: InputOptionType
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/rating-override',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        Issuer: { id: '{args.issuer.id}' },
        CreditRating: { id: '{args.creditRating.id}' },
        agency: '{args.agency.id}',
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'issuer.text',
    title: 'Issuer',
    filter: 'text',
    width: '120px',
    defaultSortColumn: true,
    onlyEditableOnNew: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.CICSIssuer",
      selectorField: "text",
      isOptional: true,
      typeOf: "string",
    }
  },
  {
    field: 'agency.text',
    title: 'Agency',
    filter: 'text',
    width: '120px',
    onlyEditableOnNew: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.Agency",
      selectorField: 'text',
      typeOf: "string",
    }
  },
  {
    field: 'creditRating.text',
    title: 'Rating',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.StaticDataLongTermCreditRatings",
      selectorField: "text",
      selectorVariables: {
        agency: 'agency.text',
      },
      isOptional: true,
      typeOf: "string",
    }
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  type,
  typeList,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

// Type
const type = 'Commodity Type Mapping';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataCommodityTypeMapping';
const selectors = [
  {
    name: 'CommodityUnderlyingCode',
    title: 'Commodity Underlying Code',
    query: `
  {
    CommodityUnderlyingCode {
      id
      text
    }
  }
`,
    schemaQuery: 'CommodityUnderlyingCode: [CommodityUnderlyingCodeOption]',
    apiMappings: {
      Query: {
        CommodityUnderlyingCode: {
          url: 'reference-data/v1/commodity',
          dataPath: '$',
        },
      },
      CommodityUnderlyingCodeOption: {
        text: '$.underlyingCode',
      },
    },
    mockData: [
      {
        id: 1299,
        text: 'QM',
      },
      {
        id: 1300,
        text: 'QS',
      },
    ],
  },
];

// Scheme
const schemaType = `
  type CommodityUnderlyingCodeOption {
    id: ID
    text: String
  }

  input Update${schemaQuery} {
    id: ID
    commodity: InputOptionType
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/commodity-code-map',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        commodity: { id: '{args.commodity.id}' },
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'MXRkLabel1',
    title: 'MX_RiskLabel1',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'MXRkLabel3',
    title: 'MX_RiskLabel3',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'commodity.text',
    title: 'Commodity Underlying Code',
    filter: 'text',
    width: '200px',
    defaultSortColumn: true,
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CommodityUnderlyingCode',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

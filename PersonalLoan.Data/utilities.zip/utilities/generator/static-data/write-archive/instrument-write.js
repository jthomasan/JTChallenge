const typeList = [];

// Type
const type = 'Instrument';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataInstrument';
const selectors = [
  {
    name: 'Basel3DesignationOverrideSystem',
    title: 'Basel III Designation Override',
    query: `
{
  Basel3DesignationOverrideSystem {
    id
    text
  }
}
`,
    schemaQuery:
      'Basel3DesignationOverrideSystem: [Basel3DesignationOverrideSystemTypeOption]',
    apiMappings: {
      Query: {
        Basel3DesignationOverrideSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1086)]',
        },
      },
      Basel3DesignationOverrideSystemTypeOption: {
        text: '$.value',
      },
    },
    mockData: [
      {
        id: 147,
        text: 'Gold SGE',
      },
      {
        id: 148,
        text: 'JPY',
      },
      {
        id: 149,
        text: 'Other',
      },
    ],
  },
  {
    name: 'DerivedRating',
    title: 'Derived Rating',
    query: `
{
  DerivedRating {
    id
    text
  }
}
`,
    schemaQuery: 'DerivedRating: [DerivedRatingTypeOption]',
    apiMappings: {
      Query: {
        DerivedRating: {
          url: 'reference-data/v1/credit-rating-with-attribute',
          dataPath: "$[?(@.agency == 'DERIVED')]",
        },
      },
      DerivedRatingTypeOption: {
        text: '$.rating',
      },
    },
    mockData: [
      {
        id: 147,
        text: 'Gold SGE',
      },
      {
        id: 148,
        text: 'JPY',
      },
      {
        id: 149,
        text: 'Other',
      },
    ],
  },
  {
    name: 'EquityMarketCapTypeSystem',
    title: 'Equity Market Cap Type',
    query: `
{
  EquityMarketCapTypeSystem {
    id
    text
  }
}
`,
    schemaQuery:
      'EquityMarketCapTypeSystem: [EquityMarketCapTypeSystemTypeOption]',
    apiMappings: {
      Query: {
        EquityMarketCapTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1081)]',
        },
      },
      EquityMarketCapTypeSystemTypeOption: {
        text: '$.rating',
      },
    },
    mockData: [
      {
        id: 147,
        text: 'Gold SGE',
      },
      {
        id: 148,
        text: 'JPY',
      },
      {
        id: 149,
        text: 'Other',
      },
    ],
  },
  {
    name: 'APRARankTypeSystem',
    title: 'Equity Market Cap Type',
    query: `
{
  APRARankTypeSystem {
    id
    text
  }
}
`,
    schemaQuery: 'APRARankTypeSystem: [APRARankTypeSystemTypeOption]',
    apiMappings: {
      Query: {
        APRARankTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1039)]',
        },
      },
      APRARankTypeSystemTypeOption: {
        text: '$.rating',
      },
    },
    mockData: [
      {
        id: 147,
        text: 'Gold SGE',
      },
      {
        id: 148,
        text: 'JPY',
      },
      {
        id: 149,
        text: 'Other',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    name: String
    ISIN: String
    description: String
    bloombergSeniority: String
    called: String
    bailInStatus: String
    instrumentDebtTicker: String
    issuerEquityTicker: String
    keepwellAgreement: String
    guarantorEquityTicker: String
    SBLCEntity: String
    apraDerivedRating: String
    derivedRatingOverrideComment: String
    entityOfRiskComment: String
    countryOfRisk: String
    countryOfRiskOverrideComment: String
    BICSLevel1: String
    BICSLevel2: String
    BICSLevel3: String
    capitalTriggerType: String
    capitalTriggerLevel: String
    leadManager: String
    useOfProceeds: String
    domesticSUKUK: String
    internationalSUKUK: String
    descriptionNotes: String
    marketIssue: String
    acKey: String
    basel3Designation: String
    countryOfDomicile: String
    industrySector: String
    industryGroup: String
    marketSectorDescription: String
    redemptionCurrency: String
    couponFrequencyDescription: String
    couponType: String
    floaterFormula: String
    floaterSpread: String
    makeWholeCallSpread: String
    makeWholeIndicator: String
    entityOfRiskSP: String
    entityOfRiskMoody: String
    entityOfRiskFitch: String
    entityOfRiskSPOverride: String
    entityOfRiskMoodyOverride: String
    entityOfRiskFitchOverride: String
    marketRiskRatingComment: String
    stepUp: String
    riskComment: String
    typeOfBond: String
    creditCurveLabel: String
    countryOfRiskOverride: Float
    issueOutstandingAmount: Float
    instrumentUtilisation: Float
    Currency: InputOptionType
    genericSeniorityTypeSystem: InputOptionType
    perpetual: InputOptionType
    snpIssueRating: InputOptionType
    MOIssueRating: InputOptionType
    fitchIssueRating: InputOptionType
    Issuer: InputOptionType
    guaranteeIssuer: InputOptionType
    derivedRatingOverride: InputOptionType
    limitEntityIssuer: InputOptionType
    entityOfRiskIssuer: InputOptionType
    overrideSRCatSec: InputOptionType
    creditIndexTypeTypeSystem: InputOptionType
    issuanceCountry: InputOptionType
    equityMarketCapTypeSystem: InputOptionType
    apraRankTypeSystem: InputOptionType
    basel3DesignationOverrideSystem: InputOptionType
    ACSPResultantRating: InputOptionType
    ACMoodyResultantRating: InputOptionType
    ACFitchResultantRating: InputOptionType
    ACApraDerivedRating: InputOptionType
    curveAssignmentRatingOverride: InputOptionType
    curveAssignmentRating: InputOptionType
    callableFlag: Boolean
    isGuaranteed: Boolean
    isOECD: Boolean
    isGoodISIN: Boolean
    isDueDilligence: Boolean
    isDataReview: Boolean
    isIgnore: Boolean
    isCollateralised: Boolean
    isApraApproved: Boolean
    isTier1Tier2: Boolean
    flag144A: Boolean
    isRegS: Boolean
    isActive: Boolean
  }
  
  type Basel3DesignationOverrideSystemTypeOption {
    id: ID
    text: String
  }
  
  type DerivedRatingTypeOption {
    id: ID
    text: String
  } 
  
  type EquityMarketCapTypeSystemTypeOption {
    id: ID
    text: String
  }
  
  type APRARankTypeSystem {
    id: ID
    text: String
  }
  `;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/custom-members',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        name: '{args.name}',
        ISIN: '{args.ISIN}',
        description: '{args.description}',
        bloombergSeniority: '{args.bloombergSeniority}',
        called: '{args.called}',
        bailInStatus: '{args.bailInStatus}',
        instrumentDebtTicker: '{args.instrumentDebtTicker}',
        issuerEquityTicker: '{args.issuerEquityTicker}',
        keepwellAgreement: '{args.keepwellAgreement}',
        guarantorEquityTicker: '{args.guarantorEquityTicker}',
        SBLCEntity: '{args.SBLCEntity}',
        apraDerivedRating: '{args.apraDerivedRating}',
        derivedRatingOverrideComment: '{args.derivedRatingOverrideComment}',
        entityOfRiskComment: '{args.entityOfRiskComment}',
        countryOfRisk: '{args.countryOfRisk}',
        countryOfRiskOverrideComment: '{args.countryOfRiskOverrideComment}',
        BICSLevel1: '{args.BICSLevel1}',
        BICSLevel2: '{args.BICSLevel2}',
        BICSLevel3: '{args.BICSLevel3}',
        capitalTriggerType: '{args.capitalTriggerType}',
        capitalTriggerLevel: '{args.capitalTriggerLevel}',
        leadManager: '{args.leadManager}',
        useOfProceeds: '{args.useOfProceeds}',
        domesticSUKUK: '{args.domesticSUKUK}',
        internationalSUKUK: '{args.internationalSUKUK}',
        descriptionNotes: '{args.descriptionNotes}',
        marketIssue: '{args.marketIssue}',
        acKey: '{args.acKey}',
        basel3Designation: '{args.basel3Designation}',
        countryOfDomicile: '{args.countryOfDomicile}',
        industrySector: '{args.industrySector}',
        industryGroup: '{args.industryGroup}',
        marketSectorDescription: '{args.marketSectorDescription}',
        redemptionCurrency: '{args.redemptionCurrency}',
        couponFrequencyDescription: '{args.couponFrequencyDescription}',
        couponType: '{args.couponType}',
        floaterFormula: '{args.floaterFormula}',
        floaterSpread: '{args.floaterSpread}',
        makeWholeCallSpread: '{args.makeWholeCallSpread}',
        makeWholeIndicator: '{args.makeWholeIndicator}',
        entityOfRiskSP: '{args.entityOfRiskSP}',
        entityOfRiskMoody: '{args.entityOfRiskMoody}',
        entityOfRiskFitch: '{args.entityOfRiskFitch}',
        entityOfRiskSPOverride: '{args.entityOfRiskSPOverride}',
        entityOfRiskMoodyOverride: '{args.entityOfRiskMoodyOverride}',
        entityOfRiskFitchOverride: '{args.entityOfRiskFitchOverride}',
        marketRiskRatingComment: '{args.marketRiskRatingComment}',
        stepUp: '{args.stepUp}',
        riskComment: '{args.riskComment}',
        typeOfBond: '{args.typeOfBond}',
        creditCurveLabel: '{args.creditCurveLabel}',
        countryOfRiskOverride: '{args.countryOfRiskOverride}',
        issueOutstandingAmount: '{args.issueOutstandingAmount}',
        instrumentUtilisation: '{args.instrumentUtilisation}',
        Currency: { id: '{args.Currency.id}' },
        genericSeniorityTypeSystem: {
          id: '{args.genericSeniorityTypeSystem.id}',
        },
        perpetual: { id: '{args.perpetual.id}' },
        snpIssueRating: { id: '{args.snpIssueRating.id}' },
        MOIssueRating: { id: '{args.MOIssueRating.id}' },
        fitchIssueRating: { id: '{args.fitchIssueRating.id}' },
        Issuer: { id: '{args.Issuer.id}' },
        guaranteeIssuer: { id: '{args.guaranteeIssuer.id}' },
        derivedRatingOverride: { id: '{args.derivedRatingOverride.id}' },
        limitEntityIssuer: { id: '{args.limitEntityIssuer.id}' },
        entityOfRiskIssuer: { id: '{args.entityOfRiskIssuer.id}' },
        overrideSRCatSec: { id: '{args.overrideSRCatSec.id}' },
        creditIndexTypeTypeSystem: {
          id: '{args.creditIndexTypeTypeSystem.id}',
        },
        issuanceCountry: { id: '{args.issuanceCountry.id}' },
        equityMarketCapTypeSystem: {
          id: '{args.equityMarketCapTypeSystem.id}',
        },
        apraRankTypeSystem: { id: '{args.apraRankTypeSystem.id}' },
        basel3DesignationOverrideSystem: {
          id: '{args.basel3DesignationOverrideSystem.id}',
        },
        ACSPResultantRating: { id: '{args.ACSPResultantRating.id}' },
        ACMoodyResultantRating: { id: '{args.ACMoodyResultantRating.id}' },
        ACFitchResultantRating: { id: '{args.ACFitchResultantRating.id}' },
        ACApraDerivedRating: { id: '{args.ACApraDerivedRating.id}' },
        curveAssignmentRatingOverride: {
          id: '{args.curveAssignmentRatingOverride.id}',
        },
        curveAssignmentRating: { id: '{args.curveAssignmentRating.id}' },
        callableFlag: '{args.callableFlag}',
        isGuaranteed: '{args.isGuaranteed}',
        isOECD: '{args.isOECD}',
        isGoodISIN: '{args.isGoodISIN}',
        isDueDilligence: '{args.isDueDilligence}',
        isDataReview: '{args.isDataReview}',
        isIgnore: '{args.isIgnore}',
        isCollateralised: '{args.isCollateralised}',
        isApraApproved: '{args.isApraApproved}',
        isTier1Tier2: '{args.isTier1Tier2}',
        flag144A: '{args.flag144A}',
        isRegS: '{args.isRegS}',
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'isUpdatedFromAc',
    title: 'Is Updated from Ac',
    filter: 'text',
    width: '130px',
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'isAcQuarantine',
    title: 'Is in Ac Quarantine',
    filter: 'text',
    width: '130px',
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'ISIN',
    title: 'ISIN',
    filter: 'text',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    width: '200px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
    },
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    width: '250px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'Currency.text',
    title: 'Security Currency',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.Currency',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'genericSeniorityTypeSystem.text',
    title: 'Seniority',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.GenericSeniority',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'bloombergSeniority',
    title: 'Bloomberg Seniority',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'maturityDate',
    title: 'Maturity Date',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridDatePickerCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'isMatured',
    title: 'Is Matured',
    filter: 'boolean',
    width: '120px',
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'callableFlag',
    title: 'Callable Flag',
    filter: 'boolean',
    width: '130px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'nextCallDate',
    title: 'Next Call Date',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridDatePickerCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'called',
    title: 'Called',
    filter: 'text',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'bailInStatus',
    title: 'Bail In Status',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'perpetual',
    title: 'Perpetual Flag',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'snpIssueRating.text',
    title: 'SP Rating',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.SnpIssueRatingTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'MOIssueRating.text',
    title: 'MO Rating',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.MOIssueRatingTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'fitchIssueRating.text',
    title: 'Fitch Rating',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.FitchIssueRatingTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'instrumentDebtTicker',
    title: 'Instrument Debt Ticker',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'Issuer.text',
    title: 'Issuer',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CICSIssuer',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'issuerEquityTicker',
    title: 'Issuer Equity Ticker',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
      hideByDefault: true,
    },
  },
  {
    field: 'keepwellAgreement',
    title: 'Keepwell Agreement',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'issuerDescription',
    title: 'Issuer Description',
    filter: 'text',
    width: '300px',
  },
  {
    field: 'issuerCountry',
    title: 'Issuer Country',
    filter: 'text',
    width: '130px',
  },
  {
    field: 'isGuaranteed',
    title: 'Guaranteed',
    filter: 'boolean',
    width: '120px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'guaranteeIssuer.text',
    title: 'Guarantor Issuer',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CICSIssuer',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'guarantorEquityTicker',
    title: 'Guarantor Equity Ticker',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'guarantorIssuerDescription',
    title: 'Guarantor Issuer Description',
    filter: 'text',
    width: '200px',
  },
  {
    field: 'guarantorIssuerCountry',
    title: 'Guarantor Issuer Country',
    filter: 'text',
    width: '200px',
    extras: {
      hideByDefault: true,
    },
  },
  {
    field: 'isOECD',
    title: 'OECD Indicator',
    filter: 'boolean',
    width: '130px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'SBLCEntity',
    title: 'SBLC Entity',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'SPResultantRating.text',
    title: 'SP Resultant Rating',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'MOResultantRating.text',
    title: 'MO Resultant Rating',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'FitchResultantRating.text',
    title: 'Fitch Resultant Rating',
    filter: 'text',
    width: '170px',
  },
  {
    field: 'apraDerivedRating',
    title: 'APRA Derived Rating',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'derivedRatingOverride.text',
    title: 'APRA Derived Rating Override',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.DerivedRating',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'derivedRatingOverrideComment',
    title: 'APRA Derived Rating Override Comment',
    filter: 'text',
    width: '250px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'limitEntityIssuer.text',
    title: 'Limit Entity',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CICSIssuer',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'entityOfRiskIssuer.text',
    title: 'Entity of Risk',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CICSIssuer',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'entityOfRiskComment',
    title: 'Entity of Risk Comment',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'countryOfRisk',
    title: 'Country of Risk',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
      hideByDefault: true,
    },
  },
  {
    field: 'countryOfRiskOverride',
    title: 'Country of Risk Override',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
      hideByDefault: true,
    },
  },
  {
    field: 'countryOfRiskOverrideComment',
    title: 'Country of Risk Override Comment',
    filter: 'text',
    width: '220px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
      hideByDefault: true,
    },
  },
  {
    field: 'BICSLevel1',
    title: 'BICS Level 1',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'BICSLevel2',
    title: 'BICS Level 2',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'BICSLevel3',
    title: 'BICS Level 3',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'capitalTriggerType',
    title: 'Capital Trigger Type',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'capitalTriggerLevel',
    title: 'Capital Trigger Level',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'leadManager',
    title: 'Lead Manager',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'issueOutstandingAmount',
    title: 'Issue Outstanding Amount',
    filter: 'text',
    width: '180px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'dateOfIssue',
    title: 'Date Of Issue',
    filter: 'text',
    width: '130px',
  },
  {
    field: 'instrumentUtilisation',
    title: 'Instrument Utilisation',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'overrideSRCatSec.text',
    title: 'Override Category',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.SrCategory',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'overrideRatingBandSec.text',
    title: 'Override Rating Band',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'useOfProceeds',
    title: 'Use Of Proceeds',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'domesticSUKUK',
    title: 'Domestic SUKUK',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'internationalSUKUK',
    title: 'International SUKUK',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'descriptionNotes',
    title: 'Description Notes',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'marketIssue',
    title: 'Market Issue',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'isGoodISIN',
    title: 'Is Good ISIN',
    filter: 'boolean',
    width: '130px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
      hideByDefault: true,
    },
  },
  {
    field: 'holdingPeriodStatusTypeSystem.text',
    title: 'Grp: Holding Period Status',
    filter: 'text',
    width: '180px',
    extras: {
      hideByDefault: true,
    },
  },
  {
    field: 'isDueDilligence',
    title: 'Is Due Dilligence',
    filter: 'boolean',
    width: '130px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
      hideByDefault: true,
    },
  },
  {
    field: 'dueDilligenceDate',
    title: 'Due Dilligence Date',
    filter: 'text',
    width: '150px',
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
      hideByDefault: true,
    },
  },
  {
    field: 'daysToReview',
    title: 'Days to Review',
    filter: 'text',
    width: '140px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'nnumber',
      isOptional: true,
      hideByDefault: true,
    },
  },
  {
    field: 'creditIndexTypeTypeSystem.text',
    title: 'Grp: CR Index Type',
    filter: 'text',
    width: '140px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CRIndexType',
      selectorField: 'text',
      typeOf: 'string',
      hideByDefault: true,
      isOptional: true,
    },
  },
  {
    field: 'secFstAccDate',
    title: 'Sec_FstAccDate',
    filter: 'text',
    width: '140px',
    extras: {
      hideByDefault: true,
    },
  },
  {
    field: 'issuanceCountry.text',
    title: 'Issuance Country',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.Country',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'relatedProduct',
    title: 'Related Product',
    filter: 'text',
    width: '140px',
    extras: {
      hideByDefault: true,
    },
  },
  {
    field: 'creditTick',
    title: 'Credit Tick',
    filter: 'text',
    width: '140px',
    extras: {
      hideByDefault: true,
    },
  },
  {
    field: 'isDataReview',
    title: 'Is Data Reviewed',
    filter: 'boolean',
    width: '130px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'isIgnore',
    title: 'Is Additional Data',
    filter: 'boolean',
    width: '150px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'acKey',
    title: 'AC Key',
    filter: 'text',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'equityMarketCapTypeSystem.text',
    title: 'Equity Market Cap Type',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.EquityMarketCapTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      hideByDefault: true,
      isOptional: true,
    },
  },
  {
    field: 'apraRankTypeSystem.text',
    title: 'APRA Rank',
    filter: 'text',
    width: '140px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.APRARankTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      hideByDefault: true,
      isOptional: true,
    },
  },
  {
    field: 'isCollateralised',
    title: 'Collateralised',
    filter: 'boolean',
    width: '140px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
      hideByDefault: true,
    },
  },
  {
    field: 'collatSecurityInstrument.text',
    title: 'Collateral Security',
    filter: 'text',
    width: '150px',
    extras: {
      hideByDefault: true,
    },
  },
  {
    field: 'isApraApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    width: '130px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
      hideByDefault: true,
    },
  },
  {
    field: 'overrideTenor',
    title: 'Override Tenor Maturity',
    filter: 'text',
    width: '170px',
    extras: {
      hideByDefault: true,
    },
  },
  {
    field: 'isTier1Tier2',
    title: 'Is Tier1/Tier2',
    filter: 'boolean',
    width: '130px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
      hideByDefault: true,
    },
  },
  {
    field: 'basel3Designation',
    title: 'Basel III Designation',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'basel3DesignationOverrideSystem.text',
    title: 'Basel III Designation Override',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.Basel3DesignationOverrideSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'apraStressSecTypeSystem.text',
    title: 'ApraStressSecuritisation',
    filter: 'text',
    width: '180px',
    extras: {
      hideByDefault: true,
    },
  },
  {
    field: 'countryOfDomicile',
    title: 'Country Of Domicile',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'industrySector',
    title: 'Industry Sector',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'industryGroup',
    title: 'Industry Group',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'marketSectorDescription',
    title: 'Market Sector Description',
    filter: 'text',
    width: '180px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'redemptionCurrency',
    title: 'Redemption Currency',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'couponFrequencyDescription',
    title: 'Coupon Frequency Description',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'couponType',
    title: 'Coupon Type',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'floaterFormula',
    title: 'Floater Formula',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'floaterSpread',
    title: 'Floater Spread',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'makeWholeCallSpread',
    title: 'Make-Whole Call Spread',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'makeWholeIndicator',
    title: 'Make-Whole Indicator',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'entityOfRiskSP',
    title: 'Entity Of Risk S&P',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'entityOfRiskMoody',
    title: 'Entity Of Risk Moody',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'entityOfRiskFitch',
    title: 'Entity Of Risk Fitch',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'entityOfRiskSPOverride',
    title: 'Entity Of Risk SP Override',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'entityOfRiskMoodyOverride',
    title: 'Entity Of Risk Moody Override',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'entityOfRiskFitchOverride',
    title: 'Entity Of Risk Fitch Override',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'ACSPResultantRating.text',
    title: 'AC SP Resultant Rating',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.SnpIssueRatingTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'ACMoodyResultantRating.text',
    title: 'AC Moody Resultant Rating',
    filter: 'text',
    width: '190px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.MOIssueRatingTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'ACFitchResultantRating.text',
    title: 'AC Fitch Resultant Rating',
    filter: 'text',
    width: '180px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.FitchIssueRatingTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'ACApraDerivedRating.text',
    title: 'AC APRA Derived Rating',
    filter: 'text',
    width: '170px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.APRARankTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'curveAssignmentRatingOverride.text',
    title: 'Curve Assignment Rating Override',
    filter: 'text',
    width: '220px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.DerivedRating',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'curveAssignmentRating.text',
    title: 'Curve Assignment Rating',
    filter: 'text',
    width: '180px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.DerivedRating',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'marketRiskRatingComment',
    title: 'Market Risk Rating Comment',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'stepUp',
    title: 'Step Up',
    filter: 'text',
    width: '110px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'riskComment',
    title: 'Risk Comment',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'typeOfBond',
    title: 'Type Of Bond',
    filter: 'text',
    width: '130px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'flag144A',
    title: '144A Flag',
    filter: 'boolean',
    width: '120px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'isRegS',
    title: 'Is Reg S',
    filter: 'boolean',
    width: '120px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'creditCurveLabel',
    title: 'Credit Curve Label',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'comment',
    title: 'comment',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

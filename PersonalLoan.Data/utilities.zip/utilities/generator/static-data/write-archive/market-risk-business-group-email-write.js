//Type list
const typeList = [
];

// Type
const type = 'Market Risk Business Group Email';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'MarketRiskBusinessGroupEmailMapping';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    emailToList: String
    emailCcList: String
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'limits/v1/market-risk-business-group-email',
    method: 'post',
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: "{args.id}",
        emailToList: "{args.emailToList}",
        emailCcList: "{args.emailCcList}",
        isActive: "{args.isActive}",
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;


// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },  
  {
    field: 'marketRiskBusinessGroup.text',
    title: 'MRB Group',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'snapshot',
    title: 'SnapShot',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'emailToList',
    title: 'Email To List',
    filter: 'text',
    typeOf: 'string',
    width: '300px',
    cell: 'GridTextboxCell',
    editable: true,
  },
  {
    field: 'emailCcList',
    title: 'Email CC List',
    filter: 'text',
    typeOf: 'string',
    width: '300px',
    cell: 'GridTextboxCell',
    editable: true,
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

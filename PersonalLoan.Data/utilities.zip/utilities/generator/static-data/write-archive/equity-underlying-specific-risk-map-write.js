const typeList = [];

// Type
const type = 'Equity Underlying Specific Risk Map';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataEquityUnderlyingSpecificRiskMap';
const selectors = [
  {
    name: 'UnderlyingEQList',
    title: 'Underlying EQ',
    query: `
  {
    UnderlyingEQList {
      id
      text
    }
  }
`,
    schemaQuery: 'UnderlyingEQList: [UnderlyingEQListOption]',
    apiMappings: {
      Query: {
        UnderlyingEQList: {
          url: 'reference-data/v1/ticker-with-attributes',
          dataPath: '$',
        },
      },
      UnderlyingEQListOption: {
        text: '$.ticker',
      },
    },
    mockData: [
      {
        id: 1275,
        text: 'SNR UNSEC',
      },
      {
        id: 1276,
        text: 'SNR SEC',
      },
      {
        id: 1277,
        text: 'SUB SEC',
      },
      {
        id: 1278,
        text: 'SUB UNSEC',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    mappedTicker: InputOptionType
    ticker: InputOptionType
    isActive: Boolean
  }
  
  type UnderlyingEQListOption {
    id: ID
    text: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/ticker-specific-risk-map',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        mappedTicker: { id: '{args.mappedTicker.id}' },
        ticker: { id: '{args.ticker.id}' },
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'ticker.text',
    title: 'Underlying - EQ',
    filter: 'text',
    width: '150px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.UnderlyingEQList',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'mappedTicker.text',
    title: 'Mapped Underlying EQ',
    filter: 'text',
    width: '150px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.UnderlyingEQList',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  type,
  typeList,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

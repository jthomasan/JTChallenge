const typeList = [];

// Type
const type = 'Credit Stress Bond Rating';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataCreditStressBondRating';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    anzRatingTypeSystem: InputOptionType
    daysToMaturity: String
    Currency: InputOptionType
    longStress: Int
    shortStress: Int
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/credit-stress-bond-rating',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        anzRatingTypeSystem: { id: '{args.anzRatingTypeSystem.id}' },
        daysToMaturity: { id: '{args.daysToMaturity.id}' },
        Currency: { id: '{args.Currency.id}' },
        longStress: '{args.longStress}',
        shortStress: '{args.shortStress}',
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'anzRatingTypeSystem.text',
    title: 'Rating',
    filter: 'text',
    width: '90px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.ANZRatingBand',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'daysToMaturity',
    title: 'Term',
    filter: 'text',
    width: '90px',
    onlyEditableOnNew: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.NetBucketCR01',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'currency.text',
    title: 'Currency',
    filter: 'text',
    width: '110px',
    onlyEditableOnNew: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.Currency',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'longStress',
    title: 'Long Stress',
    filter: 'numeric',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      decimalPlaces: 0,
    },
  },
  {
    field: 'shortStress',
    title: 'Short Stress',
    filter: 'numeric',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      decimalPlaces: 0,
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

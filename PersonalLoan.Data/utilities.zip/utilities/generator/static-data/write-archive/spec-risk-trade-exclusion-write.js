const typeList = [];

// Type
const type = 'Spec Risk Trade Exclusion';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataSpecRiskTradeExclusion';
const selectors = [
  {
    name: 'ReportType',
    title: 'Report Type',
    query: `
  {
    ReportType {
      id
      text
    }
  }
`,
    schemaQuery: 'ReportType: [ReportTypeType]',
    apiMappings: {},
    mockData: [
      {
        id: 1275,
        text: 'SNR UNSEC',
      },
      {
        id: 1276,
        text: 'SNR SEC',
      },
      {
        id: 1277,
        text: 'SUB SEC',
      },
      {
        id: 1278,
        text: 'SUB UNSEC',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    reportName: InputOptionType
    tradeNumber: Int
    comment: String
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/trade-exclusion',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        reportName: '{args.reportName.id}',
        tradeNumber: '{args.tradeNumber}',
        comment: '{args.comment}',
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'reportName.text',
    title: 'Report Type',
    filter: 'text',
    width: '120px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.ReportType',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'tradeNumber',
    title: 'Trade Number',
    filter: 'numeric',
    width: '130px',
    onlyEditableOnNew: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    width: '180px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  type,
  typeList,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

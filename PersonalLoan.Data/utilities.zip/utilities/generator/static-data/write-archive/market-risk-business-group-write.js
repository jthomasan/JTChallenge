const typeList = [];

// Type
const type = "Market Risk Business Group";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataMarketRiskBusinessGroup";
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    description: String
    value: String
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "limits/v1/limit-market-risk-business-group",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: "{args.id}",
        description: "{args.description}",
        value: "{args.value}",
        isActive: "{args.isActive}"
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '90px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'value',
    title: 'Name',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    defaultSortColumn: true,
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    typeOf: 'string',
    width: '250px',
    cell: 'GridTextboxCell',
    editable: true,
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    typeOf: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '200px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

//Type list
const typeList = [];

// Type
const type = 'Credit Stress Credit Indices';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataCreditStressCreditIndices';
const selectors = [
  {
    name: 'CRIndexType',
    title: 'Term',
    query: `
  {
    CRIndexType {
      id
      text
    }
  }
`,
    schemaQuery: 'CRIndexType: [CRIndexTypeOption]',
    apiMappings: {
      Query: {
        CRIndexType: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1045)]',
        },
      },
      CRIndexTypeOption: {
        text: '$.value',
      },
    },
    mockData: [
      {
        id: 1275,
        text: 'SNR UNSEC',
      },
      {
        id: 1276,
        text: 'SNR SEC',
      },
      {
        id: 1277,
        text: 'SUB SEC',
      },
      {
        id: 1278,
        text: 'SUB UNSEC',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    CRIndexType: InputOptionType
    longStress: Int
    shortStress: Int
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/credit-stress-credit-indices',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        CRIndexType: { id: '{args.CRIndexType.id}' },
        longStress: '{args.longStress}',
        shortStress: '{args.shortStress}',
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'CRIndexType.text',
    title: 'CR Index Type',
    filter: 'text',
    width: '150px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CRIndexType',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'longStress',
    title: 'Long Stress',
    filter: 'numeric',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      decimalPlaces: 0,
    },
  },
  {
    field: 'shortStress',
    title: 'Short Stress',
    filter: 'numeric',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      decimalPlaces: 0,
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

//Type list
const typeList = [];

// Type
const type = 'Vega Underlying Swap Bond Maturity Net Buckets';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataVegaUnderlyingSwapBondMaturityNetBuckets';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    term: ID
    sp_id: Int
    net3m: Float
    net2y: Float
    net5y: Float
    net10y: Float
    net20y: Float
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/update-tenor-bucket',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: [
        {
          term: '{args.term}',
          sp_id: { $value: '{args.sp_id}', $type: 'number' },
          net3m: { $value: '{args.net3m}', $type: 'number' },
          net2y: { $value: '{args.net2y}', $type: 'number' },
          net5y: { $value: '{args.net5y}', $type: 'number' },
          net10y: { $value: '{args.net10y}', $type: 'number' },
          net20y: { $value: '{args.net20y}', $type: 'number' },
        },
      ],
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'termUnit',
    title: 'Days to Maturity',
    filter: 'text',
    width: '150px',
    defaultSortColumn: true,
    cell: 'GridCustomCell',
    extras: {
      displayField: 'term',
    },
  },
  {
    field: 'net3m',
    title: 'Net3m',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net2y',
    title: 'Net2y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net5y',
    title: 'Net5y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net10y',
    title: 'Net10y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'net20y',
    title: 'Net20y',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

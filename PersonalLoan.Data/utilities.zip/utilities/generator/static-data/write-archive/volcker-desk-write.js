const typeList = [];

// Type
const type = 'Volcker Desk';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataVolckerDesk';
const selectors = [
  {
    name: 'GlobalBusinessUnit',
    title: 'Global Business Unit',
    query: `
  {
    GlobalBusinessUnit {
      id
      text
    }
  }
`,
    schemaQuery: 'GlobalBusinessUnit: [GlobalBusinessUnitType]',
    apiMappings: {
      Query: {
        GlobalBusinessUnit: {
          url: 'reference-data/v1/global-business-unit',
          dataPath: '$',
        },
      },
      GlobalBusinessUnitType: {
        id: '$.dimGlobalBusinessUnitID',
        text: '$.name',
      },
    },
    mockData: [
      {
        id: 1275,
        text: 'SNR UNSEC',
      },
      {
        id: 1276,
        text: 'SNR SEC',
      },
      {
        id: 1277,
        text: 'SUB SEC',
      },
      {
        id: 1278,
        text: 'SUB UNSEC',
      },
    ],
  },
  {
    name: 'ReportingCategory',
    title: 'Reporting Category',
    query: `
  {
    ReportingCategory {
      id
      text
    }
  }
`,
    schemaQuery: 'ReportingCategory: [ReportingCategoryType]',
    apiMappings: {
      Query: {
        ReportingCategory: {
          url: 'reference-data/v1/volcker-reporting-category',
          dataPath: '$',
        },
      },
      ReportingCategoryType: {
        text: '$.name',
      },
    },
    mockData: [
      {
        id: 1275,
        text: 'SNR UNSEC',
      },
      {
        id: 1276,
        text: 'SNR SEC',
      },
      {
        id: 1277,
        text: 'SUB SEC',
      },
      {
        id: 1278,
        text: 'SUB UNSEC',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    name: String
    description: String
    reportingCategory: InputOptionType
    GlobalBusinessUnit: InputOptionType
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/volcker-desk',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        VolckerDesk: '{args.id}',
        name: '{args.name}',
        description: '{args.description}',
        reportingCategory: { id: '{args.reportingCategory.id}' },
        GlobalBusinessUnit: { id: '{args.GlobalBusinessUnit.id}' },
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    width: '180px',
    editable: true,
    defaultSortColumn: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    width: '180px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'GlobalBusinessUnit.text',
    title: 'GlobalBusinessUnit',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.GlobalBusinessUnit',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'reportingCategory.text',
    title: 'ReportingCategory',
    filter: 'text',
    width: '160px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.ReportingCategory',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  type,
  typeList,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

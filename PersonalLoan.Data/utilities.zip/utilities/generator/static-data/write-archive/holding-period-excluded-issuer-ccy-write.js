const typeList = [];

// Type
const type = 'Holding Period Excluded Issuer Ccy';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataHoldingPeriodExcludedIssuerCcy';
const selectors = [
  {
    name: 'Currency',
    title: 'Currency',
    query: `
  {
    Currency {
      id
      text
    }
  }
`,
    schemaQuery: 'Currency: [CurrencyOption]',
    apiMappings: {
      Query: {
        Currency: {
          url: 'reference-data/v1/currency-with-attributes',
          dataPath: '$',
        },
      },
      CurrencyOption: {
        text: '$.name',
      },
    },
    mockData: [
      {
        id: 1275,
        text: 'SNR UNSEC',
      },
      {
        id: 1276,
        text: 'SNR SEC',
      },
      {
        id: 1277,
        text: 'SUB SEC',
      },
      {
        id: 1278,
        text: 'SUB UNSEC',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    issuer: InputOptionType
    ccy: InputOptionType
    isActive: Boolean
  }
`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/holding-period-excluded-issuer-ccy',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        issuer: { id: '{args.issuer.id}' },
        ccy: { id: '{args.ccy.id}' },
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'issuer.text',
    title: 'Issuer',
    filter: 'text',
    width: '120px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.Currency',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'issuer.description',
    title: 'Issuer Description',
    filter: 'text',
    width: '240px',
  },
  {
    field: 'ccy.text',
    title: 'Currency',
    filter: 'text',
    width: '90px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CICSIssuer',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '110px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '130px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '110px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

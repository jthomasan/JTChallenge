// Type
const type = 'Underlying-CCY PAIR';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataUnderlyingCCYPAIR';
const selectors = [
  {
    name: 'CCYPairFamily',
    title: 'CCY Pair Family',
    query: `
  {
    CCYPairFamily {
      id
      text
    }
  }
`,
    schemaQuery: 'CCYPairFamily: [CCYPairFamilyTypeSystemOption]',
    apiMappings: {
      Query: {
        CCYPairFamily: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1023)]',
        },
      },
    },
    mockData: [
      {
        id: 1218,
        text: 'Asian CCY',
      },
      {
        id: 1219,
        text: 'Eastern European',
      },
    ],
  },
  {
    name: 'CCYPairOnOffShore',
    title: 'CCY Pair OnOffShore',
    query: `
  {
    CCYPairOnOffShore {
      id
      text
    }
  }
`,
    schemaQuery: 'CCYPairOnOffShore: [CCYPairFamilyTypeSystemOption]',
    apiMappings: {
      Query: {
        CCYPairOnOffShore: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1066)]',
        },
      },
    },
    mockData: [
      {
        id: 1430,
        text: 'AUD/ID onshore/offshore',
      },
      {
        id: 1431,
        text: 'AUD/IN onshore/offshore',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID!
    name: String
    description: String
    isActive: Boolean
    comment: String
    foreignCurrency: String
    baseCurrency: String
    ccyPairGroupTypeSystem: InputOptionType
    ccyPairFamilyTypeSystem: InputOptionType
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/currency-pair-with-attributes',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        name: '{args.name}',
        description: '{args.description}',
        isActive: '{args.isActive}',
        comment: '{args.comment}',
        foreignCurrency: '{args.foreignCurrency}',
        baseCurrency: '{args.baseCurrency}',
        ccyPairGroupTypeSystem: { id: '{args.ccyPairGroupTypeSystem.id}' },
        ccyPairFamilyTypeSystem: { id: '{args.ccyPairFamilyTypeSystem.id}' },
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'name',
    title: 'Underlying - CCY Pair',
    filter: 'text',
    width: '170px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
      isUnique: true,
    },
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'baseCurrency',
    title: 'BaseCurrency',
    filter: 'text',
    width: '130px',
    onlyEditableOnNew: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'foreignCurrency',
    title: 'ForeignCurrency',
    filter: 'text',
    width: '150px',
    onlyEditableOnNew: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'ccyPairFamilyTypeSystem.text',
    title: 'Grp: CCY Pair Family',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CCYPairFamily',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'ccyPairGroupTypeSystem.text',
    title: 'Grp: CCY Pair OnOffShore',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CCYPairOnOffShore',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

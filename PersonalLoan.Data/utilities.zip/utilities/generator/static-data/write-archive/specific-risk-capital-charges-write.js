// Type
const type = "Specific Risk Capital Charges";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataSpecificRiskCapitalCharge";
const selectors = [
  {
    name: "SrCategory",
    title: "Category",
    query: `
  {
    SrCategory {
      id
      text
    }
  }
`,
    schemaQuery: "SrCategory: [SRCategoryInputOption]",
    apiMappings: {
      Query: {
        SrCategory: {
          url: "reference-data/v1/srcategory",
          dataPath: "$",
        },
      },
      SRCategoryInputOption: {
        text: "$.name",
      },
    },
    mockData: [
      {
        text: "Government",
        id: 1,
      },
      {
        text: "Qualifying",
        id: 2,
      },
    ],
  },
  {
    name: "SrTenor",
    title: "Tenor Maturity",
    query: `
  {
    SrTenor {
      id
      text
    }
  }
`,
    schemaQuery: "SrTenor: [TenorInputOption]",
    apiMappings: {
      Query: {
        SrTenor: {
          url: "reference-data/v1/srir-capital-charge-tenors",
          dataPath: "$",
        },
      },
      TenorInputOption: {
        text: "$.description",
      },
    },
    mockData: [
      {
        text: "6 months or less",
        id: "73",
      },
      {
        text: "Greater than 6 months and up to and including 24 months",
        id: "74",
      },
    ],
  },
  {
    name: "RatingBandTypeSystem",
    title: "Rating Band",
    query: `
  {
    RatingBandTypeSystem {
      id
      text
      typeSystemId
    }
  }
`,
    schemaQuery: "RatingBandTypeSystem: [SrRatingBandTypeSystemOption]",
    apiMappings: {
      Query: {
        RatingBandTypeSystem: {
          url: "reference-data/v1/type-system-parameters",
          dataPath: "$[?(@.system.id == 1013 || @.system.id == 1014)]",
        },
      },
      SrRatingBandTypeSystemOption: {
        text: "$.value",
        typeSystemId: "$.system.id",
      },
    },
    mockData: [
      {
        id: 1299,
        text: "AAA to AA-",
      },
      {
        id: 1300,
        text: "BB+ to BB-",
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    sRCategory: InputOptionType
    tenor: InputOptionType
    ratingBandTypeSystem: InputOptionType
    sRCapitalCharge: Float
    isActive: Boolean
  }
  
  type SRCategoryInputOption {
    id: ID
    text: String
  }

  type TenorInputOption {
    id: ID
    text: String
  }

  type SrRatingBandTypeSystemOption {
    id: ID
    text: String
    typeSystemId: String
  }
  `;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "/reference-data/v1/srircapital-charge",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: "{args.id}",
        SRCategory: { id: "{args.sRCategory.id}" },
        ratingBandTypeSystem: { id: "{args.ratingBandTypeSystem.id}" },
        tenor: { id: "{args.tenor.id}" },
        SRCapitalCharge: "{args.sRCapitalCharge}",
        isActive: "{args.isActive}",
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "sRCategory.text",
    title: "Category",
    filter: "text",
    typeOf: "string",
    width: "120px",
    defaultSortColumn: true,
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.SrCategory",
      selectorField: "text",
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "ratingBandTypeSystem.text",
    title: "Rating Band",
    filter: "text",
    typeOf: "string",
    width: "130px",
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.RatingBandTypeSystem",
      selectorField: "text",
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "tenor.text",
    title: "Tenor Maturity",
    filter: "text",
    typeOf: "string",
    width: "180px",
    editable: true,
    cell: "GridDropdownCell",
    extras: {
      selector: "Selector.SrTenor",
      selectorField: "text",
      typeOf: "string",
      isOptional: true,
    },
  },
  {
    field: "sRCapitalCharge",
    title: "Capital Charge (%)",
    filter: "numeric",
    typeOf: "number",
    width: "150px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "number",
      isOptional: true,
    },
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

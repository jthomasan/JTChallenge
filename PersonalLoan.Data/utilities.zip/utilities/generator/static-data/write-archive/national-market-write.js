const typeList = [];

// Type
const type = 'National Market';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataNationalMarket';
const selectors = [
  {
    name: 'NationalMarketType',
    title: 'National Market Type',
    query: `
  {
    NationalMarketType {
      id
      text
    }
  }
`,
    schemaQuery: 'NationalMarketType: [NationalMarketTypeSystem]',
    apiMappings: {
      Query: {
        NationalMarketType: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1031)]',
        },
      },
    },
    mockData: [
      {
        id: 1275,
        text: 'SNR UNSEC',
      },
      {
        id: 1276,
        text: 'SNR SEC',
      },
      {
        id: 1277,
        text: 'SUB SEC',
      },
      {
        id: 1278,
        text: 'SUB UNSEC',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    nationalMarketTypeSystem: InputOptionType
    comment: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/security-market-with-attribute',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        nationalMarketTypeSystem: {
          id: '{args.nationalMarketTypeSystem.id}',
        },
        comment: '{args.comment}',
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'securityMarket',
    title: 'Security Market',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'nationalMarketTypeSystem.text',
    title: 'Grp: National Market',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.NationalMarketType',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

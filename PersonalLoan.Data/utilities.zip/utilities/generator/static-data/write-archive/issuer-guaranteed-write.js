//Type list
const typeList = [
  // {
  //   type: "InstrumentAPRARanks",
  //   schemaQuery: "StaticDataInstrumentAPRARank",
  // },
  // {
  //   type: "InternalCounterparty",
  //   schemaQuery: "StaticDataInternalCounterParty",
  // },
  // {
  //   type: "Grp: COM ANZ Stress Group",
  //   schemaQuery: "StaticDataCOMANZStressGroup",
  // },
];

// Type
const type = "issuerGuaranteed";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataIssuerGuaranteed";
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "/reference-data/v1/type-system-parameters",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: "{args.id}",
        value: "{args.value}",
        system: { id: "{args.system.id}" },
        isActive: "{args.isActive}",
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "value",
    title: "Value",
    filter: "text",
    typeOf: "string",
    width: "150px",
    editable: true,
    defaultSortColumn: true,
    cell: "GridTextboxCell",
    extras: {
      isPrimaryField: true,
      typeOf: "string",
      isUnique: true,
    },
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridDateTimeCell",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

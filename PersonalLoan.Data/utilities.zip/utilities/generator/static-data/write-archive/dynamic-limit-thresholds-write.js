const typeList = [];

// Type
const type = "dynamicLimitThresholds";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataDynamicLimitThreshold";
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    percentageLong: Float
    percentageShort: Float
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "limits/v1/dynamic-limit-threshold",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: { $value: "{args.id}", $type: "number" },
        percentageLong: { $value: "{args.percentageLong}", $type: "number" },
        percentageShort: { $value: "{args.percentageShort}", $type: "number" },
        isActive: { $value: "{args.isActive}", $type: "boolean" },
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "90px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "isin",
    title: "ISIN",
    filter: "text",
    typeOf: "string",
    width: "200px",
    defaultSortColumn: true,
  },
  {
    field: "percentageLong",
    title: "PercentageLong",
    filter: "text",
    typeOf: "string",
    width: "180px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "number",
      isOptional: true,
    },
  },
  {
    field: "percentageShort",
    title: "PercentageShort",
    filter: "text",
    typeOf: "string",
    width: "180px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "number",
      isOptional: true,
    },
  },
  {
    field: "expiryDate",
    title: "Expiry Date",
    filter: "text",
    typeOf: "string",
    width: "120px",
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "110px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "200px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "200px",
    format: "DATE_FORMATS.DATE_TIME",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

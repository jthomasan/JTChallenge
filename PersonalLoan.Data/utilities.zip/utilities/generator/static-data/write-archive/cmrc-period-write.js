const typeList = [];

// Type
const type = "cmrcPeriod";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "CMRCPeriod";
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    cmrcPeriodDate: DateTime
    isActive: Boolean
    isCmrcReported: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "limits/v1/cmrc-period",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        id: { $value: "{args.id}", $type: "number" },
        cmrcPeriodDate: "{args.cmrcPeriodDate}",
        isCmrcReported: { $value: "{args.isCmrcReported}", $type: "boolean" },
        isActive: { $value: "{args.isActive}", $type: "boolean" },
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    width: "80px",
    cell: "GridStateCell",
  },
  {
    field: "cmrcPeriodDate",
    title: "Cmrc Period",
    filter: "date",
    width: "120px",
    defaultSortColumn: true,
    cell: "GridDatePickerCell",
    onlyEditableOnNew: true,
    extras: {
      isPrimaryField: true,
      typeOf: "string",
    },
  },
  {
    field: "isCmrcReported",
    title: "Cmrc Reported",
    filter: "boolean",
    width: "120px",
    cell: "GridCheckboxCell",
    editable: true,
    extras: {
      typeOf: "boolean",
      isOptional: true,
    },
  },
  {
    field: "isActive",
    title: "Is Active",
    cell: "GridBooleanCell",
    filter: "boolean",
    width: "120px",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

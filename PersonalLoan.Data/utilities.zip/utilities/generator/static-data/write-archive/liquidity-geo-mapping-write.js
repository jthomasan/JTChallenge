// Bulk Type
const typeList = [];

// Type
const type = 'Liquidity Geo Mapping';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataLiquidityGeoMapping';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    geographyHierarchy: InputOptionType
  }

  `;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/liquidity-geo-mappings',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        country: '{args.id}',
        geographyHierarchy: { id: '{args.geographyHierarchy.id}' },
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'country',
    title: 'Location',
    filter: 'text',
    width: '120px',
    defaultSortColumn: true,
  },
  {
    field: 'geographyHierarchy.value',
    title: 'Geography',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.GeographyHierarchy',
      selectorField: 'title',
      typeOf: 'string',
      fullPath: true,
    },
  },
  {
    field: 'geographyHierarchy.fullPath',
    title: 'Geography FullPath',
    filter: 'text',
    width: '200px',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

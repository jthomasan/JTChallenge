// Type
const type = 'Bespoke Haircut';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataBespokeHaircut';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID!
    type: String
    issuerCountry: String
    issuerName: String
    variationToGuideline: Float
    maxRepoTenor: String
    razorCode: String
    startDate: String
    counterpartyName: String
    minCollateralRating: String
    approver: String
    endDate: String
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/bespoke-haircut',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        type: '{args.type}',
        issuerCountry: '{args.issuerCountry}',
        issuerName: '{args.issuerName}',
        variationToGuideline: '{args.variationToGuideline}',
        maxRepoTenor: '{args.maxRepoTenor}',
        razorCode: '{args.razorCode}',
        startDate: '{args.startDate}',
        counterpartyName: '{args.counterpartyName}',
        minCollateralRating: '{args.minCollateralRating}',
        approver: '{args.approver}',
        endDate: '{args.endDate}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    typeOf: 'string',
    width: '80px',
    cell: 'GridStateCell',
    ignoreForExport: true,
  },
  {
    field: 'razorCode',
    title: 'Razor Code',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    defaultSortColumn: true,
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
      isUnique: true,
    },
  },
  {
    field: 'counterpartyName',
    title: 'Counterparty Name',
    filter: 'text',
    typeOf: 'string',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'approver',
    title: 'Approver',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'startDate',
    title: 'Start Date',
    filter: 'numeric',
    typeOf: 'number',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
    },
  },
  {
    field: 'endDate',
    title: 'End Date',
    filter: 'text',
    typeOf: 'string',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'minCollateralRating',
    title: 'Min Collateral Rating',
    filter: 'text',
    typeOf: 'string',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'issuerCountry',
    title: 'Issuer Country',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'issuerName',
    title: 'Issuer Name',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'type',
    title: 'Type',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'maxRepoTenor',
    title: 'Max Repo Tenor',
    filter: 'numeric',
    typeOf: 'number',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
    },
  },
  {
    field: 'variationToGuideline',
    title: 'Variation To Guideline',
    filter: 'numeric',
    typeOf: 'number',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    typeOf: 'string',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    typeOf: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

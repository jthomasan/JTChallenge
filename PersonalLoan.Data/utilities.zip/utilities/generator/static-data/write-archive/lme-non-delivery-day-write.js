const typeList = [];

// Type
const type = "lmeNonDeliveryDay";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataLMENonDeliveryDay";
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    date: DateTime
    isLMENonDelivery: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "reference-data/v1/lme-non-delivery-day",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        date: "{args.date}",
        isLMENonDelivery: "{args.isLMENonDelivery}",
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "date",
    title: "LME Non - Delivery Days",
    filter: "date",
    typeOf: "date",
    width: "180px",
    format: "DATE_FORMATS.DATE_TIME",
    cell: "GridTextboxCell",
    defaultSortColumn: true,
    onlyEditableOnNew: true,
    extras: {
      isPrimaryField: true,
      typeOf: "string",
    },
  },
  {
    field: "isLMENonDelivery",
    title: "Is LME Non Delivery Day",
    filter: "boolean",
    typeOf: "boolean",
    width: "150px",
    cell: "GridCheckboxCell",
    editable: true,
    extras: {
      typeOf: "boolean",
    },
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

const typeList = [];

// Type
const type = 'UnderlyingEq';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataUnderlyingEq';
const selectors = [
  {
    name: 'SecurityMarket',
    title: 'Security Market',
    query: `
  {
    SecurityMarket {
      id
      text
    }
  }
`,
    schemaQuery: 'SecurityMarket: [SecurityMarketOption]',
    apiMappings: {
      Query: {
        SecurityMarket: {
          url: 'reference-data/v1/security-market-with-attribute',
          dataPath: '$',
        },
      },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'EQType',
    title: 'EQ Type',
    query: `
  {
    EQType {
      id
      text
    }
  }
`,
    schemaQuery: 'EQType: [EQTypeTypeSystemOption]',
    apiMappings: {
      Query: {
        EQType: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1034)]',
        },
      },
    },
    mockData: [
      {
        id: 1218,
        text: 'Tier1',
      },
      {
        id: 1219,
        text: 'Tier2',
      },
    ],
  },
  {
    name: 'EQRegion',
    title: 'EQ Region',
    query: `
  {
    EQRegion {
      id
      text
    }
  }
`,
    schemaQuery: 'EQRegion: [EQRegionTypeSystemOption]',
    apiMappings: {
      Query: {
        EQRegion: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1032)]',
        },
      },
    },
    mockData: [
      {
        id: 1218,
        text: 'Asian',
      },
      {
        id: 1219,
        text: 'Others',
      },
    ],
  },
  {
    name: 'EQTier',
    title: 'EQ Tier',
    query: `
  {
    EQTier {
      id
      text
    }
  }
`,
    schemaQuery: 'EQTier: [EQTierTypeSystemOption]',
    apiMappings: {
      Query: {
        EQTier: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1033)]',
        },
      },
    },
    mockData: [
      {
        id: 1218,
        text: 'Asian',
      },
      {
        id: 1219,
        text: 'Others',
      },
    ],
  },
  {
    name: 'EQSpecificRiskWeight',
    title: 'EQ Specific Risk Weight',
    query: `
  {
    EQSpecificRiskWeight {
      id
      text
    }
  }
`,
    schemaQuery: 'EQSpecificRiskWeight: [EQSpecificRkWeightTypeSystemOption]',
    apiMappings: {
      Query: {
        EQSpecificRiskWeight: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: '$[?(@.system.id == 1040)]',
        },
      },
    },
    mockData: [
      {
        id: 1218,
        text: 'Asian',
      },
      {
        id: 1219,
        text: 'Others',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    ticker: String
    description: String
    SecurityMarket: InputOptionType
    EQTypeTypeSystem: InputOptionType
    EQRegionTypeSystem: InputOptionType
    EQTierTypeSystem: InputOptionType
    EQSpecificRkWeightTypeSystem: InputOptionType
    isIgnore: Boolean
    comment: String
    isActive: Boolean
  }
`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/ticker-with-attributes',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        ticker: '{args.ticker}',
        description: '{args.description}',
        SecurityMarket: { id: '{args.SecurityMarket.id}' },
        EQTypeTypeSystem: { id: '{args.EQTypeTypeSystem.id}' },
        EQRegionTypeSystem: { id: '{args.EQRegionTypeSystem.id}' },
        EQTierTypeSystem: { id: '{args.EQTierTypeSystem.id}' },
        EQSpecificRkWeightTypeSystem: {
          id: '{args.EQSpecificRkWeightTypeSystem.id}',
        },
        isIgnore: '{args.isIgnore}',
        comment: '{args.comment}',
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'ticker',
    title: 'Underlying - EQ',
    filter: 'text',
    width: '130px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
      isUnique: true,
    },
  },
  {
    field: 'description',
    title: 'Full Name',
    filter: 'text',
    width: '180px',
    onlyEditableOnNew: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
      isUnique: true,
    },
  },
  {
    field: 'SecurityMarket.text',
    title: 'Security Market',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.SecurityMarket',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'EQTypeTypeSystem.text',
    title: 'Grp: EQ Type',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.EQType',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'EQRegionTypeSystem.text',
    title: 'Grp: EQ Region',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.EQRegion',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'EQTierTypeSystem.text',
    title: 'Grp: EQ Tier',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.EQTier',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'EQSpecificRkWeightTypeSystem.text',
    title: 'Grp: EQ Specific Risk Weight',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.EQSpecificRkWeight',
      selectorField: 'text',
      typeOf: 'string',
    },
  },
  {
    field: 'isIgnore',
    title: 'Excluded from Quarantine',
    filter: 'boolean',
    width: '180px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    width: '180px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
      isUnique: true,
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

const typeList = [];

// Type
const type = 'RiskThresholdCatchAll';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataRiskThresholdCatchAll';
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    reconThresholdAmt: Number
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/risk-type',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        reconThresholdAmt: '{args.reconThresholdAmt}',
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'reconThresholdAmt',
    title: 'Recon Threshold Amount',
    filter: 'numeric',
    width: '170px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  type,
  typeList,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

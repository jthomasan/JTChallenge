const typeList = [];

// Type
const type = 'Issuer';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataIssuer';
const selectors = [
  {
    name: 'Country',
    title: 'Country',
    query: `
  {
    Country {
      id
      text
      countryCode
    }
  }
`,
    schemaQuery: 'Country: [CountryInputOption]',
    apiMappings: {
      Query: {
        Country: {
          url: 'reference-data/v1/country',
          dataPath: '$',
        },
      },
      CountryInputOption: { text: '$.name' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'IssuerType',
    title: 'Issuer Type',
    query: `
  {
    IssuerType {
      id
      text
    }
  }
`,
    schemaQuery: 'IssuerType: [IssuerTypeInputOption]',
    apiMappings: {
      Query: {
        IssuerType: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: "$[?(@.system.name == 'Issuer_IssuerType')]",
        },
      },
      IssuerTypeInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'RatingBandOverrideTypeSystem',
    title: 'Issuer Type',
    query: `
  {
    RatingBandOverrideTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery:
      'RatingBandOverrideTypeSystem: [RatingBandOverrideTypeSystemInputOption]',
    apiMappings: {
      Query: {
        RatingBandOverrideTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath:
            '$[?(@.system.id == 1041 || @.system.id == 1013 || @.system.id == 1014 || @.system.id == 1015)]',
        },
      },
      RatingBandOverrideTypeSystemInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'IssuerFamilyType',
    title: 'Issuer Type',
    query: `
  {
    IssuerFamilyType {
      id
      text
    }
  }
`,
    schemaQuery: 'IssuerFamilyType: [IssuerFamilyTypeInputOption]',
    apiMappings: {
      Query: {
        IssuerFamilyType: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: "$[?(@.system.name == 'Issuer_IssuerFamily')]",
        },
      },
      IssuerFamilyTypeInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'IssuerGuaranteedTypeSystem',
    title: 'Issuer Guaranteed Type',
    query: `
  {
    IssuerGuaranteedTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery:
      'IssuerGuaranteedTypeSystem: [IssuerGuaranteedTypeSystemInputOption]',
    apiMappings: {
      Query: {
        IssuerGuaranteedTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: "$[?(@.system.name == 'Issuer_IssuerGuaranteed')]",
        },
      },
      IssuerGuaranteedTypeSystemInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'SnpIssueRatingTypeSystem',
    title: 'SNP Rating',
    query: `
  {
    SnpIssueRatingTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery:
      'SnpIssueRatingTypeSystem: [SnpIssueRatingTypeSystemInputOption]',
    apiMappings: {
      Query: {
        SnpIssueRatingTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: "$[?(@.system.agency == 'SNP')]",
        },
      },
      SnpIssueRatingTypeSystemInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'MOIssueRatingTypeSystem',
    title: 'MO Rating',
    query: `
  {
    MOIssueRatingTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery:
      'MOIssueRatingTypeSystem: [MOIssueRatingTypeSystemInputOption]',
    apiMappings: {
      Query: {
        MOIssueRatingTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: "$[?(@.system.agency == 'MOODYS')]",
        },
      },
      MOIssueRatingTypeSystemInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'FitchIssueRatingTypeSystem',
    title: 'MO Rating',
    query: `
  {
    FitchIssueRatingTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery:
      'FitchIssueRatingTypeSystem: [FitchIssueRatingTypeSystemInputOption]',
    apiMappings: {
      Query: {
        FitchIssueRatingTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: "$[?(@.system.agency == 'FITCH')]",
        },
      },
      FitchIssueRatingTypeSystemInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
  {
    name: 'StfSectorTypeSystem',
    title: 'STF Sector',
    query: `
  {
    StfSectorTypeSystem {
      id
      text
    }
  }
`,
    schemaQuery: 'StfSectorTypeSystem: [StfSectorTypeSystemInputOption]',
    apiMappings: {
      Query: {
        StfSectorTypeSystem: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: "$[?(@.system.name == 'STFSector')]",
        },
      },
      StfSectorTypeSystemInputOption: { text: '$.value' },
    },
    mockData: [
      {
        text: 'AUD',
        id: 1,
      },
      {
        text: 'KYD',
        id: 2,
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    countryCode: String
    name: String
    baseCurrency: InputOptionType
    geography: InputOptionType
    OECDIndicator: Boolean
    isCMRC: Boolean
    STFGeographyTypeSystem: InputOptionType
    FRTBGeographyTypeSystem: InputOptionType
    isActive: Boolean
  }
  
  type CountryInputOption {
    id: ID
    text: String
    countryCode: String
  }
  
  type IssuerTypeInputOption {
    id: ID
    text: String
  }
  
  type RatingBandOverrideTypeSystemInputOption {
    id: ID
    text: String
  }
  
  type IssuerFamilyTypeInputOption {
    id: ID
    text: String
  }
  
  type IssuerGuaranteedTypeSystemInputOption {
    id: ID
    text: String
  }
  
  type SnpIssueRatingTypeSystemInputOption {
    id: ID
    text: String
  }
  
  type MOIssueRatingTypeSystemInputOption {
    id: ID
    text: String
  }
  
  type FitchIssueRatingTypeSystemInputOption {
    id: ID
    text: String
  }
  
  type StfSectorTypeSystemInputOption {
    id: ID
    text: String
  }
  `;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: 'reference-data/v1/issuer-with-attribute',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        issuerCode: '{args.issuerCode}',
        description: '{args.description}',
        ackey: '{args.ackey}',
        issuerEquityTicker: '{args.issuerEquityTicker}',
        parentIssuer: { id: '{args.parentIssuer.id}' },
        issuerTypeTypeSystem: { id: '{args.issuerTypeTypeSystem.id}' },
        APRAApproved: '{args.APRAApproved}',
        isExclude: '{args.isExclude}',
        SRCategory: { id: '{args.SRCategory.id}' },
        ratingBandTypeSystem: { id: '{args.ratingBandTypeSystem.id}' },
        commentISS: '{args.commentISS}',
        issuerFamilyTypeSystem: { id: '{args.issuerFamilyTypeSystem.id}' },
        issuerGuaranteedTypeSystem: {
          id: '{args.issuerGuaranteedTypeSystem.id}',
        },
        parentOwned: '{args.parentOwned}',
        snpIssueRating: { id: '{args.snpIssueRating.id}' },
        MOIssueRating: { id: '{args.MOIssueRating.id}' },
        fitchIssueRating: { id: '{args.fitchIssueRating.id}' },
        sector: '{args.sector}',
        STFSectorTypeSystem: { id: '{args.STFSectorTypeSystem.id}' },
        amountOutstanding: '{args.amountOutstanding}',
        isDataReview: '{args.isDataReview}',
        isIgnore: '{args.isIgnore}',
        murexVersions: '{args.murexVersions}',
        isMurexRiskless: '{args.isMurexRiskless}',
        countryOfDomicile: '{args.countryOfDomicile}',
        industrySector: '{args.industrySector}',
        industryGroup: '{args.industryGroup}',
        marketSectorDescription: '{args.marketSectorDescription}',
        comment: '{args.comment}',
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'issuerCode',
    title: 'Issuer Code',
    filter: 'text',
    width: '120px',
    onlyEditableOnNew: true,
    defaultSortColumn: true,
    cell: 'GridTextboxCell',
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
      isUnique: true,
    },
  },
  {
    field: 'isUpdatedFromAc',
    title: 'Is Updated from AC',
    filter: 'boolean',
    width: '150px',
    cell: 'GridCheckboxCell',
  },
  {
    field: 'isAcQuarantine',
    title: 'Is in AC Quarantine',
    filter: 'boolean',
    width: '150px',
    cell: 'GridCheckboxCell',
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: 'ultimateParentCompanyName',
    title: 'BB Ultimate Parent Name',
    filter: 'text',
    width: '180px',
  },
  {
    field: 'ultimateParentTickerExchange',
    title: 'BB Ultimate Parent Equity Ticker',
    filter: 'text',
    width: '200px',
  },
  {
    field: 'parentRelation',
    title: 'Parent/Issuer Relation',
    filter: 'text',
    width: '170px',
  },
  {
    field: 'bbBicsLevel1SectorName',
    title: 'BICS Level 1',
    filter: 'text',
    width: '120px',
  },
  {
    field: 'bbBicsLevel2IndustryGroupName',
    title: 'BICS Level 2',
    filter: 'text',
    width: '120px',
  },
  {
    field: 'bbBicsLevel3IndustryName',
    title: 'BICS Level 3',
    filter: 'text',
    width: '120px',
  },
  {
    field: 'castParentName',
    title: 'BB Parent Name',
    filter: 'text',
    width: '140px',
  },
  {
    field: 'dvParentEntityName',
    title: 'BB One up Parent',
    filter: 'text',
    width: '140px',
  },
  {
    field: 'ackey',
    title: 'AC Key',
    filter: 'text',
    width: '90px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'issuerEquityTicker',
    title: 'Issuer Equity Ticker',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'Country.value.countryCode',
    title: 'Country',
    filter: 'text',
    width: '90px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.Country',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'countryDescription',
    title: 'Country Description',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'countryCurrency',
    title: 'Country Currency',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'isOECD',
    title: 'OECD Flag',
    filter: 'boolean',
    width: '120px',
    cell: 'GridCheckboxCell',
  },
  {
    field: 'parentIssuer.text',
    title: 'Parent Issuer',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.CICSIssuer',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'parentIssuerDescription',
    title: 'Parent Issuer Description',
    filter: 'text',
    width: '170px',
  },
  {
    field: 'issuerTypeTypeSystem.text',
    title: 'Issuer Type',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.IssuerTypeInputOption',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'APRAApproved',
    title: 'APRA Approved',
    filter: 'boolean',
    width: '120px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'CICSIssuerCode',
    title: 'CICS Issuer Code',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'isExclude',
    title: 'Exclude',
    filter: 'boolean',
    width: '120px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'SRCategory.text',
    title: 'Cat_Override_Iss',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.SrCategory',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'ratingBandTypeSystem.text',
    title: 'RatBnd_Override_Iss',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.RatingBandOverrideTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'commentISS',
    title: 'Comment ISS',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'issuerFamilyTypeSystem.text',
    title: 'Issuer Family',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.IssuerFamilyType',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'issuerGuaranteedTypeSystem.text',
    title: 'Issuer Guaranteed',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.IssuerGuaranteedTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'parentOwned',
    title: '100% Parent Owned',
    filter: 'boolean',
    width: '150px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'snpIssueRating.text',
    title: 'SNP Rating',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.SnpIssueRatingTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'MOIssueRating.text',
    title: 'MO Rating',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.MOIssueRatingTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'fitchIssueRating.text',
    title: 'Fitch Rating',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.FitchIssueRatingTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'derivedRating',
    title: 'Derived Rating',
    filter: 'text',
    width: '120px',
  },
  {
    field: 'SPRatingType',
    title: 'S&P Rating Type',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'mdyIssuer',
    title: 'Moodys Rating Type',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'FTRatingType',
    title: 'Fitch Rating Type',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'sector',
    title: 'Sector',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'STFSectorTypeSystem.text',
    title: 'STF Sector',
    filter: 'text',
    width: '120px',
    editable: true,
    cell: 'GridDropdownCell',
    extras: {
      selector: 'Selector.StfSectorTypeSystem',
      selectorField: 'text',
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'amountOutstanding',
    title: 'Amount Outstanding',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'issuerUtilisation',
    title: 'Issuer Utilisation',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'isDataReview',
    title: 'Is Date Reviewed',
    filter: 'boolean',
    width: '150px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'isIgnore',
    title: 'Is Additional Data',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'murexVersions',
    title: 'Murex Versions',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'isMurexRiskless',
    title: 'Credit Riskless',
    filter: 'boolean',
    width: '150px',
    editable: true,
    cell: 'GridCheckboxCell',
    extras: {
      typeOf: 'boolean',
    },
  },
  {
    field: 'countryOfDomicile',
    title: 'Country Of Domicile',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'industrySector',
    title: 'Industry Sector',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'industryGroup',
    title: 'Industry Group',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'marketSectorDescription',
    title: 'Market Sector Description',
    filter: 'text',
    width: '200px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'comment',
    title: 'Comment',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: 'GridTextboxCell',
    extras: {
      typeOf: 'string',
      isOptional: true,
    },
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

// Type
const type = 'Seniority Map';

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = 'StaticDataSeniorityMap';
const selectors = [
  {
    name: 'GenericSeniorityType',
    title: 'Generic Seniority Type',
    query: `
  {
    GenericSeniorityType {
      id
      text
    }
  }
`,
    schemaQuery: 'GenericSeniorityType: [GenericSeniorityTypeSystem]',
    apiMappings: {
      Query: {
        GenericSeniorityType: {
          url: 'reference-data/v1/type-system-parameters',
          dataPath: "$[?(@.system.name == 'SeniorityMap_GenericSeniority')]",
        },
      },
    },
    mockData: [
      {
        id: 1275,
        text: 'SNR UNSEC',
      },
      {
        id: 1276,
        text: 'SNR SEC',
      },
      {
        id: 1277,
        text: 'SUB SEC',
      },
      {
        id: 1278,
        text: 'SUB UNSEC',
      },
    ],
  },
];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    seniority: ID
    genericSeniorityTypeSystem: InputOptionType
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: '/reference-data/v1/seniority-map',
    method: 'post',
    body: {
      op: '{args.op}',
      path: '/',
      value: {
        Seniority: '{args.id}',
        seniority: '{args.seniority}',
        genericSeniorityTypeSystem: {
          id: '{args.genericSeniorityTypeSystem.id}',
        },
        isActive: '{args.isActive}',
      },
    },
  },
};

const canAddNew = true;
const canBulkUpdate = true;

// Column and export csv headers
const fieldInfo = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: 'GridStateCell',
  },
  {
    field: 'seniority',
    title: 'Seniority',
    filter: 'text',
    width: '180px',
    defaultSortColumn: true,
  },
  {
    field: 'genericSeniorityTypeSystem.text',
    title: 'Generic Seniority',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: 'GridBooleanCell',
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: 'DATE_FORMATS.DATE_TIME',
    cell: 'GridDateTimeCell',
  },
];

module.exports = {
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

//Type list
const typeList = [];

// Type
const type = "creditStressSpread_10BondDefaultStress";

// GQL Schema for write endpoint - DONT ADD PREFIX like ADD or REPLACE
const schemaQuery = "StaticDataCreditStressSpreadTenBondDefaultStress";
const selectors = [];

// Scheme
const schemaType = `
  input Update${schemaQuery} {
    id: ID
    stressFactor: Int
    isActive: Boolean
  }`;

// Api mapping info
const apiMappings = {
  [schemaQuery]: {
    ignore: false,
    uri: "reference-data/v1/default-credit-stress-factor",
    method: "post",
    body: {
      op: "{args.op}",
      path: "/",
      value: {
        anzRatingTypeSystem: { id: "{args.id}" },
        stressFactor: "{args.stressFactor}",
        isActive: "{args.isActive}",
      },
    },
  },
};

const canAddNew = false;
const canBulkUpdate = false;

// Column and export csv headers
const fieldInfo = [
  {
    field: "modified",
    title: "State",
    filter: "text",
    typeOf: "string",
    width: "80px",
    cell: "GridStateCell",
    ignoreForExport: true,
  },
  {
    field: "anzRatingTypeSystem.text",
    title: "Rating",
    filter: "text",
    typeOf: "string",
    width: "90px",
    defaultSortColumn: true,
  },
  {
    field: "stressFactor",
    title: "Stress Factor",
    filter: "numeric",
    typeOf: "number",
    width: "120px",
    editable: true,
    cell: "GridTextboxCell",
    extras: {
      typeOf: "number",
      decimalPlaces: 0,
    },
  },
  {
    field: "isActive",
    title: "Is Active",
    filter: "boolean",
    typeOf: "boolean",
    width: "90px",
    cell: "GridBooleanCell",
    extras: {
      typeOf: "boolean",
      canActivate: true,
    },
  },
  {
    field: "added.by",
    title: "Added By",
    filter: "text",
    typeOf: "string",
    width: "150px",
  },
  {
    field: "added.time",
    title: "Added Time",
    filter: "date",
    typeOf: "date",
    width: "150px",
    format: "DATE_FORMATS.DATE_TIME",
  },
];

module.exports = {
  typeList,
  type,
  apiMappings,
  fieldInfo,
  schemaQuery,
  schemaType,
  selectors,
  canAddNew,
  canBulkUpdate,
};

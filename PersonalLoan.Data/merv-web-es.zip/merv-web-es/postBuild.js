const fs = require('fs');

fs.copyFile('package.json', 'dist/package.json', (err) => {
  if (err) throw err;
});

export default (err, req, res, next) => {
  req.logger.error(err);
};

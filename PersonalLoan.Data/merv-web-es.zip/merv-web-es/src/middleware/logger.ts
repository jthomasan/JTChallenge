import * as bunyan from 'bunyan';
import * as uuid from 'uuid-random';

export const logger = bunyan.createLogger({ name: 'merv-web-es' });

export const loggerMiddleware = (req, res, next) => {
  const reqId = req.headers['X-Request-ID'] || uuid();
  const childLogger = logger.child({ req_id: reqId });
  req.logger = childLogger;
  req.reqId = reqId;
  next();
};

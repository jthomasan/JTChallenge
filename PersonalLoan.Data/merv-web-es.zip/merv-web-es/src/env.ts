// Initialize environment variables.
require('dotenv').config();

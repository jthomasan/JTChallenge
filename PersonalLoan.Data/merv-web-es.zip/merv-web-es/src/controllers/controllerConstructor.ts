/* eslint-disable no-async-promise-executor */
import { Request, Response } from 'express';
import * as moment from 'moment';

import { DocumentNode, print } from 'graphql';
import { get, isFunction } from 'lodash';
import { InterceptedRequest } from '../routes/types';
import { DataSource, EndPointInfo, Parameter } from '../models/api.model';
import { DataSourceService } from '../services/dataSourceService';
import { streamDataToClient } from '../helpers/streamService';
import { Processor } from '../processors';
import { replaceStringTemplate } from '../helpers/stringUtils';


/** Class representing a controller for handling http requests and response. */
export class ControllerConstructor {
  private readonly params: Parameter[];

  private readonly filename: EndPointInfo['filename'];

  private readonly query: DataSource['query'];

  private readonly queryVariables: DataSource['queryVariables'];

  private readonly returnDataName: DataSource['returnDataName'];

  private readonly dataSourceService: DataSourceService;

  private readonly processor: (data: any) => Processor;

  /**
   * Create a controller.
   * @param {string} name - name which represents the functions.
   * @param {Parameter[]} params - required params from request.
   * @param {string} filename.
   * @param {string} returnDataName - response name from data source.
   */
  constructor(
    params: Parameter[],
    filename: EndPointInfo['filename'],
    query: DataSource['query'],
    queryVariables: DataSource['queryVariables'],
    returnDataName: DataSource['returnDataName'],
    processor: (data: any) => Processor,
  ) {
    this.dataSourceService = new DataSourceService();
    this.params = params;
    this.filename = filename;
    this.query = query;
    this.queryVariables = queryVariables;
    this.returnDataName = returnDataName;
    this.processor = processor;
  }

  /**
   * Retrieve params from requested url based on params provided in spec.
   *
   * @param  {Request}  req
   */
  private getQueryParams(req: Request) {
    const { query } = req;
    const paramsMap = new Map();

    this.params.forEach((param) => {
      let queryParamValue = query[param.name];
      if (param.type === 'object') {
        const decodedValue = decodeURI(queryParamValue.toString());
        queryParamValue = decodedValue ? JSON.parse(decodedValue) : decodedValue;
      }
      // If query doesnt exist set the default value
      paramsMap.set(param.name, queryParamValue ?? param.default);
    });

    return Object.fromEntries(paramsMap);
  }

  private getQuery(queryParams: Record<string, any>) {
    let query: string | DocumentNode;

    if(isFunction(this.query)) {
      query = this.query(queryParams);
    } else {
      query = this.query;
    }

    if(typeof query === 'string') {
      return query;
    }

    return print(query);
  }

  /**
   * Resolve http requests and stream the csv to client.
   *
   * @param  {Object}  queryParams
   * @param  {Function}  postProcessFunc
   * @param  {Function}  streamData
   */
  private async fetchAndStreamData(
    { req, res }: { req: InterceptedRequest; res: Response },
    postProcessFunc: Function,
    streamData: (data: string) => void,
  ) {
    if (typeof postProcessFunc === 'function') {
      let keepAliveInterval: NodeJS.Timeout;
      try {
        const queryParams = this.resolveDataTypes(this.getQueryParams(req));
        const { setHeader, setContents } = postProcessFunc(streamData);
        // Push the header in the initial stream
        setHeader();

        // keep sending nothing to the stream at an interval to maintain connection
        keepAliveInterval = setInterval(() => res.write(''), 5000);

        const data = await this.dataSourceService.getDataFromSource(
          req,
          req.headers,
          this.getQuery(queryParams),
          this.queryVariables ? this.queryVariables(queryParams) : undefined,
        );

        clearInterval(keepAliveInterval);
        setContents(get(data, this.returnDataName), data);
      } catch (err) {
        clearInterval(keepAliveInterval);
        streamData('Unknown error has occurred');
        streamData(null);
        throw err;
      }
    } else {
      streamData(null);
    }
  }

  /**
   * Resolve http requests and stream the csv to client.
   *
   * @param  {Request}  req - request from http
   * @param  {Response}  res
   * @param  {NextFunction}  next
   */
  public async fetchData(req: InterceptedRequest, res: Response) {
    let filename: string;
    if (typeof this.filename === 'string') {
      filename = replaceStringTemplate(this.filename, null, req.query);
    } else {
      filename = this.filename(req);
    }

    filename = `${filename}_${moment().format('YYYYMMDD')}`;
    res.setHeader('Content-Disposition', `attachment; filename="${filename}.csv"`);

    // Attach response param for streaming data
    return streamDataToClient(
      res,
      this.fetchAndStreamData.bind(this, { req, res }, this.processor),
    );
  }

  private resolveDataTypes(params: { [key: string]: string | string[] | boolean | number }) {
    return Object.entries(params).reduce((acc, [key, value]) => {
      if (value == null) {
        return acc;
      }

      const variableInfo = this.params.find((i) => i.name === key);
      let newData: string | string[] | boolean | number;

      switch (variableInfo.type) {
        case 'boolean':
          newData = value === 'true';
          break;

        case 'number':
          newData = Number(value);
          break;

        default:
          newData = value;
          break;
      }

      return {
        ...acc,
        [key]: newData,
      };
    }, {});
  }
}

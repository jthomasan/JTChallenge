import { PassThrough } from 'stream';
import { Parameter } from '../models/api.model';
import { ControllerConstructor } from './controllerConstructor';
import nodesProcessor from '../processors/hierarchy/nodesProcessor';
import { nodes } from '../processors/__mocks__/nodes';

jest.mock('../services/dataSourceService', () => {
  return {
    DataSourceService: jest.fn().mockImplementation(() => {
      return {
        getDataFromSource: jest.fn().mockReturnValue(new Promise((res) => res(nodes.data))),
      };
    }),
  };
});

const mockNext = jest.fn();

describe('Nodes Controller Tests', () => {
  let params: Parameter[] = [];
  let filename = '';
  let returnDataName = '';

  afterEach(() => {
    mockNext.mockReset();
  });

  it('should return nodes list in csv when request for nodes', async () => {
    params = [
      { name: 'id', type: 'string', in: 'query', required: true, default: undefined },
      { name: 'typeId', type: 'string', in: 'query', required: true, default: '' },
    ];
    filename = 'Nodes_';
    returnDataName = 'Nodes';

    const controllerConstructor = new ControllerConstructor(
      params,
      filename,
      () => '',
      null,
      returnDataName,
      nodesProcessor,
    );

    // Create mock stream for receiving streams from the function
    const mockStreamResponse: any = new PassThrough();

    // controllerConstructor.getDataFromSource = jest.fn(() => Promise.resolve(nodes.data.Nodes));

    const req: any = {
      query: { typeId: '1' },
    };
    let streamedResponse = '';

    // Listen the data from stream
    mockStreamResponse.on('data', (data) => {
      streamedResponse += data.toString();
    });

    mockStreamResponse.setHeader = jest.fn();

    await controllerConstructor.fetchData(req, mockStreamResponse);

    expect(mockStreamResponse.setHeader).toHaveBeenCalledTimes(1);
    expect(streamedResponse).toMatchSnapshot();
  });
});

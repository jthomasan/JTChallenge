import { Router } from 'express';
import { APIMappingEntities, Field } from '../models/api.model';

const normalizeField = (field: Field) => ({
  name: field.name,
  field: field.field,
  type: field.typeOf,
});

export function buildFieldsRoute(exportMappings: APIMappingEntities) {
  const router = Router();

  Object.entries(exportMappings).forEach(([exportEndpoint, mapping]) => {
    if (!exportEndpoint.endsWith('/csv')) {
      throw new Error(`${exportEndpoint} - does not end in /csv`);
    }

    if (!mapping?.get?.exportInfo?.fields) {
      // No fields set
      return;
    }

    const fieldsEndpoint = `${exportEndpoint.slice(0, exportEndpoint.length - 4)}/fields`;

    router.get(fieldsEndpoint, (_, res) => {
      res.contentType('json');
      res.send(JSON.stringify(mapping.get.exportInfo.fields.map(normalizeField)));
    });
  });

  return router;
}

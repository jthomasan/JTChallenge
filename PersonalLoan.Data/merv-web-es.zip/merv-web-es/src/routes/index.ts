import { Router, Response, NextFunction } from 'express';
import * as swaggerUi from 'swagger-ui-express';

import swaggerSpec from '../helpers/swaggerSpec';
import { RouteConstructor } from './routerConstructor';
import apiMappings from '../mappings';
import { InterceptedRequest } from './types';
import d2aGenerateXBRLHandler from './d2aGenerateXBRLHandler';
import { buildFieldsRoute } from './fields';

const router = Router();

// Swagger spec
(swaggerSpec as any).paths = { ...apiMappings };

router.use('/swagger', swaggerUi.serve);
router.get('/swagger', swaggerUi.setup(swaggerSpec));

// export route for Apra D2A
router.use(logRequest);
router.get('/XBRL/zip', d2aGenerateXBRLHandler);
router.use(RouteConstructor.constructCSVExportRoutes(apiMappings));
router.use(buildFieldsRoute(apiMappings));

export default router;

function logRequest(req: InterceptedRequest, res: Response, next: NextFunction) {
  req.logger.info({ hostname: req.hostname, method: req.method, url: req.url });
  next();
}

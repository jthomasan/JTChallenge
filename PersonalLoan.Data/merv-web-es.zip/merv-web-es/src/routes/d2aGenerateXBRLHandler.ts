import { Response } from 'express';
import * as moment from 'moment';
import axios from 'axios';

import { InterceptedRequest } from './types';

export default async (req: InterceptedRequest, res: Response) => {
  try {
    const { logger, reqId, cookies, query } = req;

    const outgoingHeaders: Record<string, any> = {
      Authorization: `Bearer ${cookies.auth_token}`,
      'X-Request-ID': reqId,
    };

    const outgoingUrl = `${process.env.MERV_API_URL}/apra-d2a/v1/xbrl-files`;

    const uninterceptedAxiosInstance = axios.create();

    logger.info(`POST ${outgoingUrl}`);
    const response = await uninterceptedAxiosInstance.post(
      outgoingUrl,
      {},
      {
        headers: outgoingHeaders,
        responseType: 'stream',
      },
    );
    logger.info({ method: 'POST', url: outgoingUrl }, 'successful response');

    res.header('Content-Type', 'application/zip');
    res.header('Content-Disposition', `attachment; filename="${query.filename || 'XBRL'}.zip"`);
    response.data.pipe(res);
  } catch (err) {
    req.logger.error(err);
    res.header('Content-Type', 'text/plain');
    res.send(`File Export Error: ${err.message}`);
  }
};

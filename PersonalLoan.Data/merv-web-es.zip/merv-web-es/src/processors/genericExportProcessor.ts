import * as moment from 'moment';
import { Field } from 'src/models/api.model';
import { sortBy } from '../helpers/dataQuery';
import { Processor, ProcessorInfo } from '.';

const formatDateTime = (value: string) =>
  (value && moment(value).format('DD/MM/YYYY hh:mm:ss A')) || '';

const formatDate = (value: string) => (value && moment(value).format('DD/MM/YYYY')) || '';

const formatBoolean = (value: boolean) => value?.toString().toUpperCase() || 'FALSE';

const handleStringFormat = (value: string) => {
  // eslint-disable-next-line no-restricted-globals
  if (isNaN(Number(value))) {
    return value.replace(/"/g, '""');
  }

  return `=""${value}""`;
};

export const formatStrings: Record<Field['typeOf'], (value: any) => string> = {
  string: handleStringFormat,
  number: (value: string) => (value != null ? value : ''),
  boolean: (value: boolean) => formatBoolean(value),
  dateTime: (value: string) => formatDateTime(value),
  date: (value: string) => formatDate(value),
};

export const generateHeaders = (processorInfo: ProcessorInfo[]): string => {
  // Adding BOM to handle special unicode characters in utf-8 encoded CSVs.
  const BOM = '\uFEFF';
  const headers = processorInfo.reduce((acc, curr) => `${acc}"${curr.name}",`, '');
  return `${BOM}${headers.slice(0, headers.length - 1)}\n`;
};

export const mapDataToField = (
  field: string,
  typeOf: string,
  data: any,
  displayRenderer?: (params: any) => string,
) =>
  field.split('.').reduce((acc, curr) => {
    if (acc?.[curr] && typeOf === 'array') {
      return displayRenderer && displayRenderer(acc?.[curr]);
    }

    if (acc?.[curr] && typeof acc?.[curr] === 'string') {
      if (!formatStrings[typeOf]) {
        throw new Error(`type of field ${field} (${typeOf}) has no formatter`);
      }

      return formatStrings[typeOf](acc[curr]);
    }

    return acc?.[curr] != null ? acc?.[curr] : '';
  }, data);

export const generateContents = (processorInfo: ProcessorInfo[], data: any): string => {
  const contents = processorInfo.reduce(
    (acc, curr) =>
      `${acc}"${mapDataToField(curr.field, curr.typeOf, data, curr.displayRenderer)}",`,
    '',
  );
  return `${contents.slice(0, contents.length - 1)}\n`;
};

export function generateProcessor(processorInfo: ProcessorInfo[], sortField = null, sortOrder) {
  return (streamData: (data: string) => void): Processor => {
    const setHeader = () => {
      streamData(generateHeaders(processorInfo));
    };

    const setContents = (list: any[]) => {
      const sortingColumnInfo = processorInfo.find((item) => item.sorting);
      const sortingColumn = sortField || sortingColumnInfo.field;
      const dataItems = sortBy(list, [sortingColumn], sortOrder);

      if (dataItems.length === 0) {
        streamData(`"No results found"\n`);
        streamData(null);
      } else {
        dataItems.forEach((data) => {
          streamData(generateContents(processorInfo, data));
        });

        streamData(null);
      }
    };

    return { setHeader, setContents };
  };
}

import * as moment from 'moment';
import { keyBy } from 'lodash';
import { Portfolio } from '../../models/hierarchyModel';
import { Processor } from '../index';

export default (streamData: (data: string) => void): Processor => {
  // Set csv headers
  const setHeader = () => {
    streamData(`"Name","IsActive","FullPath","AddedTime","SourceDescription"\n`);
  };

  const setContents = (portfolios: Portfolio[], response?: any) => {
    const nodeObj = keyBy(response.Nodes, 'id');

    if (portfolios.length === 0) {
      streamData(`"No results found"\n`);
      streamData(null);
    } else {
      portfolios.forEach((portfolio) => {
        const createdData = moment(portfolio.createdOn).format('DD/MM/YYYY hh:mm:ss A');
        const isActive = portfolio.isActive.toString().toUpperCase();
        const { fullPath } = nodeObj[portfolio.parent.nodeId];

        // Push the data to the stream
        streamData(
          `"${portfolio.title}","${isActive}","${fullPath}","${createdData}","${portfolio.source}"\n`,
        );
      });

      streamData(null);
    }
  };

  return { setHeader, setContents };
};

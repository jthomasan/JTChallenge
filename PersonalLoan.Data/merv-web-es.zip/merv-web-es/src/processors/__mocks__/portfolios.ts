export const portfolios = {
  data: {
    Portfolios: [
      {
        id: 1,
        title: 'AU CORP BKG',
        isActive: false,
        parent: {
          nodeId: '11844',
          fullPath: 'ROOT|ANZ Group|Monitored Portfolios|MP - CAPM',
        },
        createdOn: '2012-02-01 00:00:00',
        source: 'MX2.11',
      },
      {
        id: 2,
        title: 'GSF AU',
        isActive: false,
        parent: {
          nodeId: '11844',
          fullPath: 'ROOT|ANZ Group|Monitored Portfolios|MP - CAPM',
        },
        createdOn: '2012-02-01 00:00:00',
        source: 'MX2.11',
      },
      {
        id: 3,
        title: 'IPM FG CCY SG',
        isActive: false,
        parent: {
          nodeId: '11844',
          fullPath: 'ROOT|ANZ Group|Monitored Portfolios|MP - CAPM',
        },
        createdOn: '2012-02-01 00:00:00',
        source: 'MX2.11',
      },
      {
        id: 4,
        title: 'IPM FG DBU SG',
        isActive: false,
        parent: {
          nodeId: '11844',
          fullPath: 'ROOT|ANZ Group|Monitored Portfolios|MP - CAPM',
        },
        createdOn: '2012-02-01 00:00:00',
        source: 'MX2.11',
      },
      {
        id: 5,
        title: 'IPM FG HK',
        isActive: false,
        parent: {
          nodeId: '11844',
          fullPath: 'ROOT|ANZ Group|Monitored Portfolios|MP - CAPM',
        },
        createdOn: '2012-02-01 00:00:00',
        source: 'MX2.11',
      },
      {
        id: 6,
        title: 'IPM FG LDN',
        isActive: false,
        parent: {
          nodeId: '11844',
          fullPath: 'ROOT|ANZ Group|Monitored Portfolios|MP - CAPM',
        },
        createdOn: '2012-02-01 00:00:00',
        source: 'MX2.11',
      },
      {
        id: 7,
        title: 'IPM FG NY',
        isActive: false,
        parent: {
          nodeId: '11844',
          fullPath: 'ROOT|ANZ Group|Monitored Portfolios|MP - CAPM',
        },
        createdOn: '2012-02-01 00:00:00',
        source: 'MX2.11',
      },
      {
        id: 8,
        title: 'IPM FG NZ',
        isActive: false,
        parent: {
          nodeId: '11844',
          fullPath: 'ROOT|ANZ Group|Monitored Portfolios|MP - CAPM',
        },
        createdOn: '2012-02-08 00:00:00',
        source: 'MX2.11',
      },
      {
        id: 9,
        title: 'IPM FG TOKYO',
        isActive: true,
        parent: {
          nodeId: '11844',
          fullPath: 'ROOT|ANZ Group|Monitored Portfolios|MP - CAPM',
        },
        createdOn: '2017-01-24 00:00:00',
        source: 'MX2.11',
      },
    ],
    Nodes: [
      {
        id: 11844,
        fullPath: 'ROOT|ANZ Group|Monitored Portfolios|MP - CAPM',
      },
    ],
  },
};

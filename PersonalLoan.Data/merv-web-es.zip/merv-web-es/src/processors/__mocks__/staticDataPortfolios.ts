export const staticDataPortfolios = {
  data: {
    StaticDataPortfolios: [
      {
        id: '1',
        modified: false,
        name: 'EQHK BR ISSFX - 1',
        comment: 'Testing 1, 2, 3...',
        isActive: false,
        isEaR: true,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '2',
          text: 'AFS',
        },
        assetTypeSystem: {
          id: '1',
          text: 'COMMODITY',
        },
        capitalHierarchy: {
          id: '8',
          text: 'CHINA',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '2',
          text: 'Banking - Credit',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '13850',
          value: 'Treasury - Taiwan Ltd - ARM NT Offset',
          fullPath:
            'ROOT|ANZ Group|Non Traded Group|Non Traded Treasury|Treasury - APEA|Treasury - Asia|Treasury - Taiwan|Treasury - Taiwan Ltd|Treasury - Taiwan Ltd - ARM NT Offset',
        },
        financeHierarchy: {
          id: '11855',
          value: 'MP - Finance - LM',
        },
        geographyHierarchy: {
          id: '13728',
          value: 'Markets - ANZ Securities Inc',
        },
        hyperionUnit: {
          id: '3',
          text: 'B28388',
        },
        added: {
          by: 'kothiyar',
          time: '2020-07-02',
        },
        exclusion: {
          by: '',
          reason: '',
        },
        isLEGroupSubset: true,
        mxLegalEntityCode: 'ANZBG MELB',
        quarantine: {},
        reviewDate: '2020-09-16',
        reviewer: {
          id: '1',
          text: 'bortolol',
        },
        source: {
          id: '6',
          text: 'Finance',
        },
        syntheticPortfolio: {
          id: '2',
          text: 'B28388',
        },
        isReviewed: false,
      },
      {
        id: '2',
        modified: false,
        name: 'S MKT MYKRIND - 2',
        comment: 'Test',
        isActive: true,
        isEaR: true,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '3',
          text: 'FVTPL',
        },
        assetTypeSystem: {
          id: '6',
          text: 'INTEREST_RATE',
        },
        capitalHierarchy: {
          id: '6',
          text: 'TONGA',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '6',
          text: 'Trading - Structure Credit',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '12053',
          value: 'LM - Singapore LB',
          fullPath:
            'ROOT|ANZ Group|TradedCAPM|Combined Trading|Traded|LM Trading|LM - Singapore|LM - Singapore LB',
        },
        financeHierarchy: {
          id: '7136',
          value: 'Spot - NZ - Spot',
        },
        geographyHierarchy: {
          id: '8527',
          value: 'LM - Laos',
        },
        hyperionUnit: {
          id: '5',
          text: 'B65037',
        },
        added: {},
        exclusion: {
          by: 'wongl14',
          reason: 'FGTP trades used to book CRI deals. excluded from VaR',
        },
        isLEGroupSubset: true,
        mxLegalEntityCode: 'ANZBG MELB',
        quarantine: {},
        source: {
          id: '2',
          text: 'Active Pivot',
        },
        syntheticPortfolio: {
          id: '4',
          text: 'WSS TWOLMK MM',
        },
        isReviewed: false,
      },
      {
        id: '3',
        modified: false,
        name: 'CNSLMK_NHS - 3',
        comment: 'Testing 1, 2, 3...',
        isActive: false,
        isEaR: true,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '2',
          text: 'AFS',
        },
        assetTypeSystem: {
          id: '2',
          text: 'CREDIT',
        },
        capitalHierarchy: {
          id: '18',
          text: 'LAOS',
        },
        bookTypeSystem: {
          id: '1',
          text: 'Banking Book',
        },
        creditBookTypeSystem: {
          id: '2',
          text: 'Banking - Credit',
        },        
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '11823',
          value: 'MP - NT - Asia - TRS',
          fullPath:
            'ROOT|ANZ Group|Monitored Portfolios|MP - NT|MP - NT - Asia|MP - NT - Asia - TRS',
        },
        financeHierarchy: {
          id: '11231',
          value: 'Mismatch - PNG',
        },
        geographyHierarchy: {
          id: '11249',
          value: 'Mismatch Murex - Thailand',
        },
        hyperionUnit: {
          id: '5',
          text: 'B65037',
        },
        added: {
          by: 'System',
          time: '2020-07-14',
        },
        exclusion: {
          by: '',
          reason: '',
        },
        isLEGroupSubset: true,
        mxLegalEntityCode: 'ANZ PANIN',
        quarantine: {
          isQuarantined: false,
          date: '',
        },
        reviewDate: '2020-10-01',
        reviewer: {
          id: '1',
          text: 'chenp14',
        },
        source: {
          id: '10',
          text: 'SKY',
        },
        syntheticPortfolio: {
          id: '5',
          text: 'FUNDING CENTER VALUE',
        },
        isReviewed: true,
      },
      {
        id: '4',
        modified: false,
        name: 'AU CORP APM - 4',
        comment: '',
        isActive: true,
        isEaR: true,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '3',
          text: 'FVTPL',
        },
        assetTypeSystem: {
          id: '6',
          text: 'INTEREST_RATE',
        },
        capitalHierarchy: {
          id: '10',
          text: 'INDONESIA',
        },
        bookTypeSystem: {
          id: '1',
          text: 'Banking Book',
        },
        creditBookTypeSystem: {
          id: '5',
          text: 'Trading - Credit',
        },        
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '11225',
          value: 'Mismatch - Laos',
          fullPath:
            'ROOT|ANZ Group|Non Traded Group|Non Traded Markets|Markets - APEA|Markets - Asia|Markets - Laos|Mismatch - Laos',
        },
        financeHierarchy: {
          id: '12938',
          value: 'CVA and Simulated FVA',
        },
        geographyHierarchy: {
          id: '10045',
          value: 'Repo - Monitor - Aus',
        },
        hyperionUnit: {
          id: '5',
          text: 'B65037',
        },
        added: {
          by: 'System',
          time: '2020-07-14',
        },
        exclusion: {
          by: '',
          reason: '',
        },
        isLEGroupSubset: true,
        mxLegalEntityCode: 'ANZ PANIN',
        quarantine: {
          isQuarantined: true,
          date: '2020-07-14',
        },
        reviewDate: '2020-09-16',
        reviewer: {
          id: '1',
          text: 'bortolol',
        },
        source: {
          id: '4',
          text: 'UI',
        },
        syntheticPortfolio: {
          id: '2',
          text: 'B28388',
        },
        isReviewed: true,
      },
      {
        id: '5',
        modified: false,
        name: 'IPM FG NZ - 5',
        comment: 'Testing 1, 2, 3...',
        isActive: false,
        isEaR: false,
        isFinance: true,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '4',
          text: 'Other',
        },
        assetTypeSystem: {
          id: '3',
          text: 'EQUITY',
        },
        capitalHierarchy: {
          id: '2',
          text: 'EXCLUDED',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '1',
          text: 'Banking - AFS',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '6852',
          value: 'FXO Asia KR',
          fullPath:
            'ROOT|ANZ Group|TradedCAPM|Combined Trading|Traded|FXO - Global Options|FXO Asia|FXO Asia Onshore|FXO Asia KR',
        },
        financeHierarchy: {
          id: '7044',
          value: 'NT - NZ - Subordinated Debt',
        },
        geographyHierarchy: {
          id: '13945',
          value: 'STF - FVA - AUS - Underlying P2',
        },
        hyperionUnit: {
          id: '2',
          text: 'B28345',
        },
        added: {
          by: 'System',
          time: '2020-07-14',
        },
        exclusion: {
          by: 'wongl14',
          reason: 'FGTP trades used to book CRI deals. excluded from VaR',
        },
        isLEGroupSubset: false,
        mxLegalEntityCode: 'ANZ PANIN',
        quarantine: {},
        reviewDate: '2020-10-01',
        reviewer: {
          id: '1',
          text: 'chenp14',
        },
        source: {
          id: '1',
          text: 'MX3.1',
        },
        syntheticPortfolio: {
          id: '1',
          text: 'B28345',
        },
        isReviewed: false,
      },
      {
        id: '6',
        modified: false,
        name: 'EQHK BR ISSFX - 6',
        comment: 'Testing 1, 2, 3...',
        isActive: false,
        isEaR: false,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '3',
          text: 'FVTPL',
        },
        assetTypeSystem: {
          id: '4',
          text: 'EXCLUDED',
        },
        capitalHierarchy: {
          id: '13',
          text: 'DIVERSIFIED',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '1',
          text: 'Banking - AFS',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '13910',
          value: 'ARM NT Vietnam',
          fullPath:
            'ROOT|ANZ Group|Non Traded Group|Non Traded Markets|Markets - APEA|Markets - Asia|Markets - Vietnam|Mismatch - Vietnam|ARM NT Vietnam',
        },
        financeHierarchy: {
          id: '7014',
          value: 'Non Traded - Aust - PAR - Bid/Offer',
        },
        geographyHierarchy: {
          id: '6874',
          value: 'GFX - Hong Kong',
        },
        hyperionUnit: {
          id: '4',
          text: 'B78172',
        },
        added: {
          by: 'kothiyar',
          time: '2020-07-02',
        },
        exclusion: {
          by: 'wongl14',
          reason: 'FGTP trades used to book CRI deals. excluded from VaR',
        },
        isLEGroupSubset: false,
        mxLegalEntityCode: 'ANZBG MELB',
        quarantine: {
          isQuarantined: true,
          date: '2020-07-14',
        },
        reviewDate: '2020-10-01',
        reviewer: {
          id: '1',
          text: 'chenp14',
        },
        source: {
          id: '8',
          text: 'QRM',
        },
        syntheticPortfolio: {
          id: '1',
          text: 'B28345',
        },
        isReviewed: true,
      },
      {
        id: '7',
        modified: false,
        name: 'AU CORP APM - 7',
        comment: 'Test',
        isActive: true,
        isEaR: false,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '4',
          text: 'Other',
        },
        assetTypeSystem: {
          id: '5',
          text: 'FOREX',
        },
        capitalHierarchy: {
          id: '15',
          text: 'CL1_MULTIPLIER3',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '1',
          text: 'Banking - AFS',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '6749',
          value: 'Currency - China',
          fullPath:
            'ROOT|ANZ Group|TradedCAPM|Combined Trading|Traded|LM Trading|LM - Greater China|LM - China|Currency - China',
        },
        financeHierarchy: {
          id: '6904',
          value: 'IRO - EUR',
        },
        geographyHierarchy: {
          id: '13874',
          value: 'ARM NT Fiji',
        },
        hyperionUnit: {
          id: '3',
          text: 'B28388',
        },
        added: {
          by: 'kothiyar',
          time: '2020-07-02',
        },
        exclusion: {
          by: 'wongl14',
          reason: 'FGTP trades used to book CRI deals. excluded from VaR',
        },
        isLEGroupSubset: true,
        mxLegalEntityCode: 'ANZ PANIN',
        quarantine: {
          isQuarantined: true,
          date: '2020-07-14',
        },
        reviewDate: '2020-10-01',
        reviewer: {
          id: '1',
          text: 'chenp14',
        },
        source: {
          id: '8',
          text: 'QRM',
        },
        syntheticPortfolio: {
          id: '3',
          text: 'WSS SGDIVS STP',
        },
        isReviewed: true,
      },
      {
        id: '8',
        modified: false,
        name: 'EQHK BR ISSFX - 8',
        comment: '',
        isActive: false,
        isEaR: true,
        isFinance: true,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '3',
          text: 'FVTPL',
        },
        assetTypeSystem: {
          id: '2',
          text: 'CREDIT',
        },
        capitalHierarchy: {
          id: '12',
          text: 'VANUATU',
        },
        bookTypeSystem: {
          id: '1',
          text: 'Banking Book',
        },
        creditBookTypeSystem: {
          id: '1',
          text: 'Banking - AFS',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '13839',
          value: 'Treasury - Kiribati - ARM NT Offset',
          fullPath:
            'ROOT|ANZ Group|Non Traded Group|Non Traded Treasury|Treasury - APEA|Treasury - Pacific|Treasury - Kiribati|Treasury - Kiribati - ARM NT Offset',
        },
        financeHierarchy: {
          id: '7167',
          value: 'Structured Credit Bal Sheet',
        },
        geographyHierarchy: {
          id: '7077',
          value: 'PM Other',
        },
        hyperionUnit: {
          id: '6',
          text: '63690',
        },
        added: {
          by: 'kothiyar',
          time: '2020-07-02',
        },
        exclusion: {
          by: 'wongl14',
          reason: 'FGTP trades used to book CRI deals. excluded from VaR',
        },
        isLEGroupSubset: false,
        mxLegalEntityCode: 'ANZBG MELB',
        quarantine: {},
        reviewDate: '2020-09-16',
        reviewer: {
          id: '1',
          text: 'bortolol',
        },
        source: {
          id: '8',
          text: 'QRM',
        },
        syntheticPortfolio: {
          id: '4',
          text: 'WSS TWOLMK MM',
        },
        isReviewed: false,
      },
      {
        id: '9',
        modified: false,
        name: 'EQHK BR ISSFX - 9',
        comment: 'Test',
        isActive: false,
        isEaR: true,
        isFinance: true,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '2',
          text: 'AFS',
        },
        assetTypeSystem: {
          id: '2',
          text: 'CREDIT',
        },
        capitalHierarchy: {
          id: '3',
          text: 'ECONOMIC_CAPITAL',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '5',
          text: 'Trading - Credit',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '6880',
          value: 'GFX - Vietnam BGL',
          fullPath:
            'ROOT|ANZ Group|TradedCAPM|Combined Trading|Traded|LM Trading|LM - Vietnam|LM - Vietnam BGL|Currency - Vietnam BGL|GFX - Vietnam BGL',
        },
        financeHierarchy: {
          id: '9529',
          value: 'Mismatch - Cambodia',
        },
        geographyHierarchy: {
          id: '6911',
          value: 'IRO - JPY',
        },
        hyperionUnit: {
          id: '1',
          text: 'Excluded',
        },
        added: {
          by: 'kothiyar',
          time: '2020-07-02',
        },
        exclusion: {
          by: '',
          reason: '',
        },
        isLEGroupSubset: false,
        mxLegalEntityCode: 'ANZ PANIN',
        quarantine: {
          isQuarantined: true,
          date: '2020-07-14',
        },
        reviewDate: '2020-10-01',
        reviewer: {
          id: '1',
          text: 'chenp14',
        },
        source: {
          id: '1',
          text: 'MX3.1',
        },
        syntheticPortfolio: {
          id: '3',
          text: 'WSS SGDIVS STP',
        },
        isReviewed: false,
      },
      {
        id: '10',
        modified: false,
        name: 'CNSLMK_NHS - 10',
        comment: 'Test',
        isActive: false,
        isEaR: true,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '1',
          text: 'Accrual',
        },
        assetTypeSystem: {
          id: '2',
          text: 'CREDIT',
        },
        capitalHierarchy: {
          id: '7',
          text: 'INDIA',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '4',
          text: 'Banking - Structure Credit',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '13634',
          value: 'CVA',
          fullPath: 'ROOT|ANZ Group|TradedCAPM|Combined Trading|CVA and Simulated FVA|CVA',
        },
        financeHierarchy: {
          id: '13877',
          value: 'ARM NT Guam',
        },
        geographyHierarchy: {
          id: '7134',
          value: 'Spot - Lon - Spot',
        },
        hyperionUnit: {
          id: '2',
          text: 'B28345',
        },
        added: {
          by: 'kothiyar',
          time: '2020-07-02',
        },
        exclusion: {
          by: '',
          reason: '',
        },
        isLEGroupSubset: true,
        mxLegalEntityCode: 'ANZBG MELB',
        quarantine: {},
        reviewDate: '2020-09-16',
        reviewer: {
          id: '1',
          text: 'bortolol',
        },
        source: {
          id: '4',
          text: 'UI',
        },
        syntheticPortfolio: {
          id: '2',
          text: 'B28388',
        },
        isReviewed: true,
      },
      {
        id: '11',
        modified: false,
        name: 'CNSLMK_NHS - 11',
        comment: 'Test',
        isActive: false,
        isEaR: true,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '3',
          text: 'FVTPL',
        },
        assetTypeSystem: {
          id: '3',
          text: 'EQUITY',
        },
        capitalHierarchy: {
          id: '9',
          text: 'AMERICAN_SAMOA',
        },
        bookTypeSystem: {
          id: '1',
          text: 'Banking Book',
        },
        creditBookTypeSystem: {
          id: '1',
          text: 'Banking - AFS',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '10086',
          value: 'STF',
          fullPath: 'ROOT|ANZ Group|TradedCAPM|Combined Trading|Traded|STF',
        },
        financeHierarchy: {
          id: '6901',
          value: 'IRO - CNY',
        },
        geographyHierarchy: {
          id: '12206',
          value: 'MGS',
        },
        hyperionUnit: {
          id: '6',
          text: '63690',
        },
        added: {
          by: 'System',
          time: '2020-07-14',
        },
        exclusion: {
          by: 'wongl14',
          reason: 'FGTP trades used to book CRI deals. excluded from VaR',
        },
        isLEGroupSubset: false,
        mxLegalEntityCode: 'ANZ PANIN',
        quarantine: {
          isQuarantined: false,
          date: '',
        },
        reviewDate: '2020-10-01',
        reviewer: {
          id: '1',
          text: 'chenp14',
        },
        source: {
          id: '3',
          text: 'Calculated Measure From RDW Data',
        },
        syntheticPortfolio: {
          id: '1',
          text: 'B28345',
        },
        isReviewed: false,
      },
      {
        id: '12',
        modified: false,
        name: 'S MKT MYKRIND - 12',
        comment: '',
        isActive: true,
        isEaR: false,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '1',
          text: 'Accrual',
        },
        assetTypeSystem: {
          id: '6',
          text: 'INTEREST_RATE',
        },
        capitalHierarchy: {
          id: '16',
          text: 'CL2_MULTIPLIER3',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '4',
          text: 'Banking - Structure Credit',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '11215',
          value: 'Mismatch - American Samoa',
          fullPath:
            'ROOT|ANZ Group|Non Traded Group|Non Traded Markets|Markets - APEA|Markets - Pacific|Markets - American Samoa|Mismatch - American Samoa',
        },
        financeHierarchy: {
          id: '6734',
          value: 'Corp Debt - D/E Hybrids',
        },
        geographyHierarchy: {
          id: '11308',
          value: 'Treasury - Taiwan Branch - QRM Offset',
        },
        hyperionUnit: {
          id: '5',
          text: 'B65037',
        },
        added: {
          by: 'System',
          time: '2020-07-14',
        },
        exclusion: {
          by: '',
          reason: '',
        },
        isLEGroupSubset: false,
        mxLegalEntityCode: 'ANZBG MELB',
        quarantine: {
          isQuarantined: true,
          date: '2020-07-14',
        },
        reviewDate: '2020-10-01',
        reviewer: {
          id: '1',
          text: 'chenp14',
        },
        source: {
          id: '10',
          text: 'SKY',
        },
        syntheticPortfolio: {
          id: '3',
          text: 'WSS SGDIVS STP',
        },
        isReviewed: false,
      },
      {
        id: '13',
        modified: false,
        name: 'AU CORP APM - 13',
        comment: '',
        isActive: false,
        isEaR: true,
        isFinance: true,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '1',
          text: 'Accrual',
        },
        assetTypeSystem: {
          id: '4',
          text: 'EXCLUDED',
        },
        capitalHierarchy: {
          id: '1',
          text: 'MULTIPLIER5',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '5',
          text: 'Trading - Credit',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '6991',
          value: 'MxCcy - China',
          fullPath:
            'ROOT|ANZ Group|TradedCAPM|Combined Trading|Traded|LM Trading|LM - Greater China|LM - China|Currency - China|MxCcy - China',
        },
        financeHierarchy: {
          id: '6815',
          value: 'Fwd - NZ - Fwds - Mantec',
        },
        geographyHierarchy: {
          id: '11559',
          value: 'WSS LM TWBGL',
        },
        hyperionUnit: {
          id: '2',
          text: 'B28345',
        },
        added: {
          by: 'System',
          time: '2020-07-14',
        },
        exclusion: {
          by: '',
          reason: '',
        },
        isLEGroupSubset: false,
        mxLegalEntityCode: 'ANZBG MELB',
        quarantine: {
          isQuarantined: false,
          date: '',
        },
        reviewDate: '2020-10-01',
        reviewer: {
          id: '1',
          text: 'chenp14',
        },
        source: {
          id: '9',
          text: 'Depreciated',
        },
        syntheticPortfolio: {
          id: '4',
          text: 'WSS TWOLMK MM',
        },
        isReviewed: false,
      },
      {
        id: '14',
        modified: false,
        name: 'CNSLMK_NHS - 14',
        comment: '',
        isActive: true,
        isEaR: false,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '4',
          text: 'Other',
        },
        assetTypeSystem: {
          id: '3',
          text: 'EQUITY',
        },
        capitalHierarchy: {
          id: '6',
          text: 'TONGA',
        },
        bookTypeSystem: {
          id: '1',
          text: 'Banking Book',
        },
        creditBookTypeSystem: {
          id: '1',
          text: 'Banking - AFS',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '12250',
          value: 'STF - CVA - AU - Underlying',
          fullPath:
            'ROOT|ANZ Group|TradedCAPM|Combined Trading|Traded|STF|STF - CVA|STF - CVA - AU|STF - CVA - AU - Underlying',
        },
        financeHierarchy: {
          id: '6754',
          value: 'Currency - Lon',
        },
        geographyHierarchy: {
          id: '6687',
          value: 'CAPM',
        },
        hyperionUnit: {
          id: '6',
          text: '63690',
        },
        added: {
          by: 'kothiyar',
          time: '2020-07-02',
        },
        exclusion: {
          by: 'wongl14',
          reason: 'FGTP trades used to book CRI deals. excluded from VaR',
        },
        isLEGroupSubset: false,
        mxLegalEntityCode: 'ANZ PANIN',
        quarantine: {
          isQuarantined: true,
          date: '2020-07-14',
        },
        reviewDate: '2020-09-16',
        reviewer: {
          id: '1',
          text: 'bortolol',
        },
        source: {
          id: '6',
          text: 'Finance',
        },
        syntheticPortfolio: {
          id: '2',
          text: 'B28388',
        },
        isReviewed: false,
      },
      {
        id: '15',
        modified: false,
        name: 'IPM FG NZ - 15',
        comment: 'Testing 1, 2, 3...',
        isActive: true,
        isEaR: true,
        isFinance: false,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '2',
          text: 'AFS',
        },
        assetTypeSystem: {
          id: '6',
          text: 'INTEREST_RATE',
        },
        capitalHierarchy: {
          id: '2',
          text: 'EXCLUDED',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '4',
          text: 'Banking - Structure Credit',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '8574',
          value: 'Markets - Europe',
          fullPath:
            'ROOT|ANZ Group|Non Traded Group|Non Traded Markets|Markets - APEA|Markets - E&A|Markets - Europe',
        },
        financeHierarchy: {
          id: '6929',
          value: 'IRO - USD',
        },
        geographyHierarchy: {
          id: '11199',
          value: 'Liquidity - Thailand',
        },
        hyperionUnit: {
          id: '1',
          text: 'Excluded',
        },
        added: {
          by: 'System',
          time: '2020-07-14',
        },
        exclusion: {
          by: '',
          reason: '',
        },
        isLEGroupSubset: false,
        mxLegalEntityCode: 'ANZBG MELB',
        quarantine: {
          isQuarantined: true,
          date: '2020-07-14',
        },
        reviewDate: '2020-09-16',
        reviewer: {
          id: '1',
          text: 'bortolol',
        },
        source: {
          id: '8',
          text: 'QRM',
        },
        syntheticPortfolio: {
          id: '2',
          text: 'B28388',
        },
        isReviewed: false,
      },
      {
        id: '16',
        modified: false,
        name: 'S MKT MYKRIND - 16',
        comment: '',
        isActive: false,
        isEaR: true,
        isFinance: true,
        reportRunList: 'Sample Data',
        volckerDeskName: 'Sample Data',
        accountingTypeSystem: {
          id: '4',
          text: 'Other',
        },
        assetTypeSystem: {
          id: '6',
          text: 'INTEREST_RATE',
        },
        capitalHierarchy: {
          id: '7',
          text: 'INDIA',
        },
        bookTypeSystem: {
          id: '2',
          text: 'Trading Book',
        },
        creditBookTypeSystem: {
          id: '4',
          text: 'Banking - Structure Credit',
        },
        tradeBookingSystem: {
          id: '2',
          text: 'WSS',
        },
        aggregateTradeCubeFlag: true,
        riskHierarchy: {
          id: '6700',
          value: 'CCIRS - China',
          fullPath:
            'ROOT|ANZ Group|TradedCAPM|Combined Trading|Traded|LM Trading|LM - Greater China|LM - China|Rates - China|MX - China|CCIRS - China',
        },
        financeHierarchy: {
          id: '11299',
          value: 'Treasury - Singapore',
        },
        geographyHierarchy: {
          id: '7040',
          value: 'NT - NZ - Other Funding',
        },
        hyperionUnit: {
          id: '2',
          text: 'B28345',
        },
        added: {
          by: 'kothiyar',
          time: '2020-07-02',
        },
        exclusion: {
          by: 'wongl14',
          reason: 'FGTP trades used to book CRI deals. excluded from VaR',
        },
        isLEGroupSubset: false,
        mxLegalEntityCode: 'ANZBG MELB',
        quarantine: {},
        reviewDate: '2020-10-01',
        reviewer: {
          id: '1',
          text: 'Phil',
        },
        source: {
          id: '7',
          text: 'Electricity',
        },
        syntheticPortfolio: {
          id: '5',
          text: 'FUNDING CENTER VALUE',
        },
        isReviewed: false,
      },
    ],
  },
};

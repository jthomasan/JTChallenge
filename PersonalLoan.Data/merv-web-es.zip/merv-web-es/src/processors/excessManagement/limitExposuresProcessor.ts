import { Processor } from '../index';


interface LimitHierarchy {
  type: String
  value: String
}
interface LimitExposure {
  id: number
  limitId: number
  breachType: String
  marketRiskControl: String
  marketRiskBusiness: String
  limitSchedule: String
  riskMeasure: String
  scenarioValue: String
  hierarchy: [LimitHierarchy]
  underlying: String
  tradePortfolioAttributes: [String]
  customMembers: [String]
  exposureAmount: String
  unit: String
  limitAmount: String
  isMonitored: Boolean
  exposureUnderlying: String
}


export default (streamData: (data: string) => void): Processor => {
  // Set csv headers
  const setHeader = () => {
    streamData(
      `"Limit Id","Market Risk Control","Market Risk Business","Schedule","Risk Measure","Scenario Value","Hierarchy","Name of Underlying","Trade Portfolio Attributes","Custom Members","Exposure Amount","Unit","Limit Amount","Monitored","Exposure Underlying"\n`,
    );
  };

  const setContents = (list: LimitExposure[]) => {
    if (!list?.length) {
      streamData(`"No results found"\n`);
      streamData(null);
    } else {
      list.forEach((item) => {
        streamData(
          `"${item.limitId}","${item.marketRiskControl}","${item.marketRiskBusiness}","${item.limitSchedule}","${item.riskMeasure}","${item.scenarioValue}","${item.hierarchy?.map((node) => `${node.type}=${node.value}`).join(';')}","${
            item.underlying
          }","${item.tradePortfolioAttributes?.join(';')}","${item.customMembers?.join(';')}","${item.exposureAmount}","${
            item.unit
          }","${item.limitAmount}","${item.isMonitored}","${item.exposureUnderlying}"\n`,
        );
      });
      streamData(null);
    }
  };

  return { setHeader, setContents };
};

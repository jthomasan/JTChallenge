import haircutReferenceProcessor from './haircutReferenceProcessor';
import { staticDataHaircutReference } from '../__mocks__/staticDataHaircutReference';

describe('Static Data haircut reference post processor Tests', () => {
  it('should push the data to stream function', () => {
    let csvStrings = '';

    const callbackFunc = (data: string) => {
      csvStrings += data;
    };

    const { setHeader, setContents } = haircutReferenceProcessor(callbackFunc);
    setHeader();
    setContents(staticDataHaircutReference.data.StaticDataHaircutReferences);

    expect(csvStrings).toMatchSnapshot();
  });

  it('should return message and close the stream when static data haircut reference are empty', () => {
    let csvStrings = '';

    const callbackFunc = (data: string) => {
      csvStrings += data;
    };

    const { setHeader, setContents } = haircutReferenceProcessor(callbackFunc);
    setHeader();
    setContents([]);

    expect(csvStrings).toMatchSnapshot();
  });
});

import * as moment from 'moment';
import { sortBy } from 'lodash';
import { Processor } from '../index';

const formatDate = (value: string) =>
  (value && moment(value).format('DD/MM/YYYY hh:mm:ss A')) || '';

export default (streamData: (data: string) => void): Processor => {
  // Set csv headers
  const setHeader = () => {
    streamData(
      `"Tier","Counterparty Sector","Counterparty Ccr","Rating","MaturityBucket","Haircut","Added By","Added Time"\n`,
    );
  };

  const setContents = (list: any[]) => {
    if (list.length === 0) {
      streamData(`"No results found"\n`);
      streamData(null);
    } else {
      const data = sortBy(list, ['tier']);
      data.forEach((item) => {
        const addedDate = formatDate(item.added.time);

        streamData(
          `"${item.tier}","${item.counterpartySector}","=""${item.counterpartyCcr}""","${item.rating}","=""${item.maturityBucket}""","=""${item.haircut}""","${item.added.by}","${addedDate}"\n`,
        );
      });
      streamData(null);
    }
  };

  return { setHeader, setContents };
};

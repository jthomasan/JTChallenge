import { Readable } from 'stream';
import { Response } from 'express';

/**
 * Stream data to client.
 *
 * @param  {Response}  res
 * @param  {Function}  callback function
 * @returns {Promise}  Promise gets returned when stream succeed
 */
export const streamDataToClient = (
  res: Response,
  callback: (callback: (data: string) => void) => any,
): Promise<any> => {
  // eslint-disable-next-line no-async-promise-executor
  return new Promise(async (resolve, reject) => {
    const readableStream = new Readable({
      read() {},
    });

    readableStream.setEncoding('utf8');
    // Set http response as writable stream
    readableStream.pipe(res);

    const streamData = (data: string) => {
      // Push the data in the stream
      readableStream.push(data);
    };

    // Expose callback function for feed data back to stream
    if (callback) {
      await callback(streamData).catch((err) => reject(err));
    }

    readableStream.on('end', () => {
      readableStream.unpipe(res);
      res.end();
      resolve();
    });

    readableStream.on('error', (error) => {
      reject(error);
    });
  });
};

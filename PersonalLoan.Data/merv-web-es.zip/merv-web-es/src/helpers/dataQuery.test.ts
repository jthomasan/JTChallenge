import { sortBy } from './dataQuery';

describe('dataQuery', () => {
  const data = [
    { name: 'market risk 10' },
    { name: 'market risk 11' },
    { name: 'market risk 21' },
    { name: 'market risk 22' },
    { name: 'market risk 23' },
    { name: 'market risk 31' },
    { name: 'market risk 1' },
    { name: 'market risk 2' },
    { name: 'market risk 3' },
    { name: 'market risk 4' },
    { name: 'market risk 5' },
    { name: 'market risk 6' },
    { name: 'market risk 7' },
  ];
  it('should sortBy sort array in asc order', () => {
    const filters = ['name'];

    const sorted = sortBy(data, filters);

    expect(data).toStrictEqual(data);
    expect(sorted).toStrictEqual([
      { name: 'market risk 1' },
      { name: 'market risk 2' },
      { name: 'market risk 3' },
      { name: 'market risk 4' },
      { name: 'market risk 5' },
      { name: 'market risk 6' },
      { name: 'market risk 7' },
      { name: 'market risk 10' },
      { name: 'market risk 11' },
      { name: 'market risk 21' },
      { name: 'market risk 22' },
      { name: 'market risk 23' },
      { name: 'market risk 31' },
    ]);
  });
});

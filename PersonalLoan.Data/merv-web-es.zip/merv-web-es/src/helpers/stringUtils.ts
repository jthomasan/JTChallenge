import { JSONPath } from 'jsonpath-plus';

export const getConfigParamValue = (paramString, entity, args) => {
  if (paramString.match(/{.*?}/g)) {
    const param = paramString.substring(1, paramString.length - 1);
    const argsArry = param.split('.');
    if (param.startsWith('$') && entity) {
      const [content] = JSONPath({ path: param, json: entity });
      return content;
    }

    if (argsArry[0] === 'args' && args && argsArry[1]) {
      return args[argsArry[1]];
    }
  }
  return null;
};

export const replaceStringTemplate = (stringTemplate, parentEntity, args) => {
  return stringTemplate.replace(
    /{.*?}/g,
    (matchString) => getConfigParamValue(matchString, parentEntity, args) || '',
  );
};

export const mapArrayItemsToString = <T>(
  data: T[],
  mapFn: (params: T) => string,
  separator: string,
): string => {
  if (Array.isArray(data)) {
    return data?.reduce((acc, curr, index) => `${acc}${index ? separator : ''}${mapFn(curr)}`, '');
  }

  return '';
};

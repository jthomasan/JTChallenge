import { get } from 'lodash';

/**
 * Creates an array of elements, sorted in ascending order by the results of
 * running each element in a collection through each iteratee. This method
 * performs a stable sort, that is, it preserves the original sort order of
 * equal elements. The iteratees are invoked with one argument: (value).
 */
export const sortBy = (data: any[], fields: string[], sortOrder: string = 'asc') => {
  const copyData = [...data];
  const collator = new Intl.Collator(undefined, {
    numeric: true,
    sensitivity: 'base',
  });
  const sortMultiplier = sortOrder?.toUpperCase() === 'DESC' ? -1 : 1;
  const compareByType = (a: any, b: any, field: string) => {
    const valueA = get(a, field);
    const valueB = get(b, field);
    return typeof valueA === 'string' || typeof valueB === 'string'
      ? (sortMultiplier * collator.compare(valueA || '', valueB || ''))
      : (sortMultiplier * (valueA || null) - (valueB || null));
  };

  return copyData.sort((a, b) =>
    fields.reduce((acc, sortDescriptor) => acc || compareByType(a, b, sortDescriptor), 0),
  );
};

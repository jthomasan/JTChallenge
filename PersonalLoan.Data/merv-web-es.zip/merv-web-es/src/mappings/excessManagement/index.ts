import { APIMappingEntities } from '../../models/api.model';
import generateExcessMonitors from './generateExcessMonitors';
import limitExposures from './limitExposures';

export default {
  ...generateExcessMonitors,
  ...limitExposures,
} as APIMappingEntities;

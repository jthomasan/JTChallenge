import { APIMappingEntities } from '../../models/api.model';

interface Request {
  fromBusinessDate: string;
  toBusinessDate: string;
}

const feedLogMessagesQuery = () => `
  query getExcessMonitors($fromBusinessDate: Date, $toBusinessDate: Date) {
    ExcessMonitors(fromDate: $fromBusinessDate, toDate: $toBusinessDate) {
      id
      businessDate
      exposureType
      exposureField
      snapshotName
      marketRiskBusinessGroup {
        id
        text
      }
      containerName
      status
      exposureStartTime
      exposureCompletedTime
      excessStartTime
      excessEndTime
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/excess-management/excess-generation/generate-excess-monitors/csv': {
    get: {
      name: 'excessMonitors',
      summary: 'Export csv',
      description: 'Returns all data in csv file',
      filename: 'excess_generation_monitors',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Excess Management' }],
      parameters: [
        {
          name: 'fromBusinessDate',
          in: 'query',
          description: 'Search by from Date',
          required: true,
          type: 'string',
        },
        {
          name: 'toBusinessDate',
          in: 'query',
          description: 'Search by to Date',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: feedLogMessagesQuery,
        queryVariables: (params: Request) => params,
        returnDataName: 'ExcessMonitors',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'businessDate',
        sortOrder: 'desc',
        fields: [
          {
            field: 'businessDate',
            name: 'Business Date',
            typeOf: 'date',
          },
          {
            field: 'snapshotName',
            name: 'Snapshot',
            typeOf: 'string',
          },
          {
            field: 'exposureType',
            name: 'Exposure Type',
            typeOf: 'string',
          },
          {
            field: 'exposureField',
            name: 'Exposure Field',
            typeOf: 'string',
          },
          {
            field: 'marketRiskBusinessGroup.text',
            name: 'Market Risk Business Group',
            typeOf: 'string',
          },
          {
            field: 'containerName',
            name: 'Container',
            typeOf: 'string',
          },
          {
            field: 'status',
            name: 'Status',
            typeOf: 'string',
          },
          {
            field: 'exposureStartTime',
            name: 'Exposure Start',
            typeOf: 'date',
          },
          {
            field: 'exposureCompletedTime',
            name: 'Exposure Complete',
            typeOf: 'date',
          },
          {
            field: 'excessStartTime',
            name: 'Excess Start',
            typeOf: 'date',
          },
          {
            field: 'excessEndTime',
            name: 'Excess Complete',
            typeOf: 'date',
          },
          {
            field: 'added.by',
            name: 'Requested By',
            typeOf: 'string',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Excess Monitors',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

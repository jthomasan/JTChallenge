import limitExposuresProcessor from '../../processors/excessManagement/limitExposuresProcessor';
import { APIMappingEntities } from '../../models/api.model';

interface Request {
  excessMonitorId: string;
  breachTypes: string;
  isIntraDay: boolean;
  marketRiskBusinessIds: string[];
  limitScheduleIds: string[];
  riskMeasureIds: string[];
  riskNodeIds: string[];
  customMemberIds: string[];
}

const getExposuresQuery = () => `
  query getExposures(
    $excessMonitorId: String
    $breachTypes: [String]
    $isIntraDay: Boolean
    $marketRiskBusinessIds: [ID]
    $limitScheduleIds: [ID]
    $riskMeasureIds: [ID]
    $riskNodeIds: [ID]
    $customMemberIds: [ID]
  ) {
    LimitExposures(
      excessMonitorId: $excessMonitorId
      breachTypes: $breachTypes
      isIntraDay: $isIntraDay
      marketRiskBusinessIds: $marketRiskBusinessIds
      limitScheduleIds: $limitScheduleIds
      riskMeasureIds: $riskMeasureIds
      riskNodeIds: $riskNodeIds
      customMemberIds: $customMemberIds
    ) {
      id
      limitId
      breachType
      marketRiskControl
      marketRiskBusiness
      limitSchedule
      riskMeasure
      scenarioValue
      hierarchy {
        type
        value
      }
      underlying
      tradePortfolioAttributes
      customMembers
      exposureAmount
      unit
      limitAmount
      isMonitored
      exposureUnderlying
    }
  }
`;

export default {
  '/excess-management/excess-generation/limit-exposures/csv': {
    get: {
      name: 'limitExposures',
      summary: 'Export csv',
      description: 'Returns all data in csv file',
      filename: ({query}) =>{
        const exposureType = (query.exposureType as string) ?? '';
        return `exposures_${exposureType.toLowerCase()}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Excess Management' }],
      parameters: [
        {
          name: 'excessMonitorId',
          in: 'query',
          description: 'Search by excessMonitorId',
          required: true,
          type: 'string',
        },
        {
          name: 'breachTypes',
          in: 'query',
          description: 'Search by breachTypes',
          required: true,
          type: 'array',
        },
        {
          name: 'isIntraDay',
          in: 'query',
          description: 'Search by isIntraDay',
          required: true,
          type: 'boolean',
        },
        {
          name: 'marketRiskBusinessIds',
          in: 'query',
          description: 'Search by marketRiskBusinessIds',
          required: true,
          type: 'array',
        },
        {
          name: 'limitScheduleIds',
          in: 'query',
          description: 'Search by limitScheduleIds',
          required: true,
          type: 'array',
        },
        {
          name: 'riskMeasureIds',
          in: 'query',
          description: 'Search by riskMeasureIds',
          required: true,
          type: 'array',
        },
        {
          name: 'riskNodeIds',
          in: 'query',
          description: 'Search by riskNodeIds',
          required: true,
          type: 'array',
        },
        {
          name: 'customMemberIds',
          in: 'query',
          description: 'Search by customMemberIds',
          required: true,
          type: 'array',
        },
      ],
      dataSource: {
        query: getExposuresQuery,
        queryVariables: (params: Request) => {
          const repopulateIfEmpty = {
            ...params,
            marketRiskBusinessIds: params.marketRiskBusinessIds ? params.marketRiskBusinessIds:[],
            limitScheduleIds: params.limitScheduleIds ? params.limitScheduleIds:[],
            riskMeasureIds: params.riskMeasureIds ? params.riskMeasureIds:[],
            riskNodeIds: params.riskNodeIds ? params.riskNodeIds:[],
            customMemberIds: params.customMemberIds ? params.customMemberIds:[],  
          };
          return repopulateIfEmpty;
        },
        returnDataName: 'LimitExposures',
      },
      exportInfo: {
        customProcessor: limitExposuresProcessor,
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Limit Exposures',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

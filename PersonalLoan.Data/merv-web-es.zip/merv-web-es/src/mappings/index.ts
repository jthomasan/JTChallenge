import { APIMappingEntities } from '../models/api.model';
import hierarchyMappings from './hierarchy';
import staticDataMappings from './staticData';
import refDataConfigMappings from './refDataConfig';
import riskData from './riskData';
import feedMonitorConfigMappings from './feedMonitorConfig';
import userRequests from './userRequests';
import reconReports from './reconReports';
import backTesting from './backTesting';
import feedMonitorStatus from './feedMonitorStatus';
import excessManagement from './excessManagement';

export const getArgs = (params: any) =>
  Object.keys(params).reduce((acc, curr) => {
    const value = params[curr];
    if (value != null) {
      if (typeof value === 'string') {
        return `${acc} ${curr}: "${value}",`;
      }

      return `${acc} ${curr}: ${value},`;
    }

    return acc;
  }, '');

export default {
  ...hierarchyMappings,
  ...staticDataMappings,
  ...refDataConfigMappings,
  ...riskData,
  ...feedMonitorConfigMappings,
  ...userRequests,
  ...reconReports,
  ...backTesting,
  ...feedMonitorStatus,
  ...excessManagement,
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';
import referenceDataConfigurationProcessor from '../../processors/refDataConfig/referenceDataConfigurationProcessor';

const ctdMappingQuery = () => `
{  
  CTDMappings {
    id
    modified
    parent
    title
    fullPath
    isCTD
    added {
      by
      time
    }
  }
}
`;

const customProcessorExportFields = [
  {
    field: 'title',
    name: 'Node Name',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'fullPath',
    name: 'Full Path',
    typeOf: 'string',
  },
  {
    field: 'isCTD',
    name: 'Is CTD?',
    typeOf: 'boolean',
  },
  {
    field: 'added.by',
    name: 'Last Edited By',
    typeOf: 'string',
  },
  {
    field: 'added.time',
    name: 'Last Edited Time',
    typeOf: 'dateTime',
  },
];

export default {
  '/reference-data/configuration/ctd-mapping/csv': {
    get: {
      name: 'refDataConfigurationCTDMapping',
      summary: 'Export Ref data Configuration Ref Data Mapping csv',
      description: 'Returns all data in csv file',
      filename: 'ref_data_configuration_ctd_mapping',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Ref Data Configuration' }],
      parameters: [],
      dataSource: {
        query: ctdMappingQuery,
        returnDataName: 'CTDMappings',
      },
      exportInfo: {
        customProcessor: referenceDataConfigurationProcessor.bind(
          null,
          customProcessorExportFields,
        ),
        sortField: 'title',
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Ref Data Configuration CTD Mapping',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';
import portfolioRunList from './portfolioRunList';
import volckerDeskMapping from './volckerDeskMapping';
import holdingPeriodNode from './holdingPeriodNode';
import ctdMapping from './ctdMapping';

export default {
  ...portfolioRunList,
  ...volckerDeskMapping,
  ...holdingPeriodNode,
  ...ctdMapping,
} as APIMappingEntities;

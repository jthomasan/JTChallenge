import { APIMappingEntities } from '../../models/api.model';

const staticDataD2ADefaultNamespacesQuery = () => `
{
  StaticDataD2ADefaultNamespaces {
    id
    modified
    uri
    prefix
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/d2-a-default-namespaces/csv': {
    get: {
      name: 'staticDataD2ADefaultNamespaces',
      summary: 'Export static data D2 A Default Namespaces csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_d2_a_default_namespaces',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataD2ADefaultNamespacesQuery,
        returnDataName: 'StaticDataD2ADefaultNamespaces',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'prefix',
        fields: [
          {
            field: 'prefix',
            name: 'Prefix',
            typeOf: 'string',
          },
          {
            field: 'uri',
            name: 'Uri',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data D2 A Default Namespaces',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

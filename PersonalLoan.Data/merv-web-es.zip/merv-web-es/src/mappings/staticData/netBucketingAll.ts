import { APIMappingEntities } from '../../models/api.model';

const staticDataNetBucketingAllQuery = () => `
{
  StaticDataVegaNetBucketingAllList {
    modified
    term
    net3m
    net1y
    net3y
    net5y
    net10y
    net20y
    net30yPlus
  }
}
`;

export default {
  '/reference-data/static-data/net-bucketing-all/csv': {
    get: {
      name: 'staticDataNetBucketingAll',
      summary: 'Export static data Net Bucketing All csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_net_bucketing_all',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataNetBucketingAllQuery,
        returnDataName: 'StaticDataVegaNetBucketingAllList',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'term',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: 'Net3m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: 'Net1y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: 'Net3y',
            typeOf: 'number',
          },
          {
            field: 'net5y',
            name: 'Net5y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: 'Net10y',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: 'Net20y',
            typeOf: 'number',
          },
          {
            field: 'net30yPlus',
            name: 'Net30yPlus',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Net Bucketing All',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataShortTermCreditRatingQuery = () => `
{
  StaticDataShortTermCreditRatings {
    id
    modified
    rating
    comment
    agency
    ratingBandTypeSystem {
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/short-term-credit-rating/csv': {
    get: {
      name: 'staticDataShortTermCreditRating',
      summary: 'Export static data Short Term Credit Rating csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_short_term_credit_rating',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataShortTermCreditRatingQuery,
        returnDataName: 'StaticDataShortTermCreditRatings',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'rating',
        fields: [
          {
            field: 'rating',
            name: 'Rating',
            typeOf: 'string',
          },
          {
            field: 'agency',
            name: 'Agency',
            typeOf: 'string',
          },
          {
            field: 'ratingBandTypeSystem.text',
            name: 'ST Rating Band',
            typeOf: 'string',
          },
          {
            field: 'comment',
            name: 'Comment',
            typeOf: 'string',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Short Term Credit Rating',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

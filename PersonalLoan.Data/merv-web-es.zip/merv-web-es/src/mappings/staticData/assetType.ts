import { APIMappingEntities } from '../../models/api.model';

const staticDataAssetTypeQuery = () => `
  {
    StaticDataAssetTypes {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/asset-type/csv': {
    get: {
      name: 'staticDataAssetType',
      summary: 'Export static data asset type csv',
      description: 'Returns all static data asset types in csv file',
      filename: 'Static_Data_Asset_Type',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataAssetTypeQuery,
        returnDataName: 'StaticDataAssetTypes',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Value',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Asset Type',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

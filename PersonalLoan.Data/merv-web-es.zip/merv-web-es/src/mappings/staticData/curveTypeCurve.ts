import { APIMappingEntities } from '../../models/api.model';

const staticDataCurveTypeCurveQuery = () => `
{
  StaticDataCurveTypeCurves {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/curve-type-curve/csv': {
    get: {
      name: 'staticDataCurveTypeCurve',
      summary: 'Export static data Curve Type Curve csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_curve_type_curve',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCurveTypeCurveQuery,
        returnDataName: 'StaticDataCurveTypeCurves',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'value',
            name: 'Value',
            typeOf: 'string',
            sorting: 'true',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
        responses: {
          '200': {
            description: 'An array of strings',
            schema: {
              title: 'Static Data Curve Type Curve',
              type: 'array',
              items: {
                type: 'string',
              },
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

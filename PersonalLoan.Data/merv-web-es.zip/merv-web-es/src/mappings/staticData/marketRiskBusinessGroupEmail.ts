import { APIMappingEntities } from '../../models/api.model';

const staticDataMarketRiskBusinessGroupEmailQuery = () => `
{
  MarketRiskBusinessGroupEmailMappings {
    id
    modified
    snapshot
    marketRiskBusinessGroup {
      id
      text
    }
    emailToList
    emailCcList
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/market-risk-business-group-email/csv': {
    get: {
      name: 'staticDataMarketRiskBusinessGroupEmail',
      summary: 'Export static data Market Risk Business Group Email csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_market_risk_business_group_email',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataMarketRiskBusinessGroupEmailQuery,
        returnDataName: 'MarketRiskBusinessGroupEmailMappings',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'snapshot',
        fields: [
          {
            field: 'marketRiskBusinessGroup.text',
            name: 'MRB Group',
            typeOf: 'string',
          },
          {
            field: 'snapshot',
            name: 'SnapShot',
            typeOf: 'string',
          },
          {
            field: 'emailToList',
            name: 'Email To List',
            typeOf: 'string',
          },
          {
            field: 'emailCcList',
            name: 'Email CC List',
            typeOf: 'string',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Market Risk Business Group Email',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

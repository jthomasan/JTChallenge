import { APIMappingEntities } from '../../models/api.model';

const staticDataRiskThresholdCatchAllQuery = () => `
{
  StaticDataRiskThresholdCatchAllList {
    id
    modified
    name
    description
    reconThresholdAmt
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/risk-threshold-catch-all/csv': {
    get: {
      name: 'staticDataRiskThresholdCatchAll',
      summary: 'Export static data Risk Threshold Catch All csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_risk_threshold_catch_all',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataRiskThresholdCatchAllQuery,
        returnDataName: 'StaticDataRiskThresholdCatchAllList',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'name',
        fields: [
          {
            field: 'name',
            name: 'Name',
            typeOf: 'string',
          },
          {
            field: 'description',
            name: 'Description',
            typeOf: 'string',
          },
          {
            field: 'reconThresholdAmt',
            name: 'Recon Threshold Amount',
            typeOf: 'number',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Risk Threshold Catch All',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataRevenueCodesQuery = () => `
  {
    StaticDataRevenueCodes {
      id
      isActive
      name
      isClean
      hierarchy {
        id
        value
      }
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/revenue-codes/csv': {
    get: {
      name: 'staticDataRevenueCodes',
      summary: 'Export static data revenue codes csv',
      description: 'Returns all static data revenue codes in csv file',
      filename: 'Static_Data_Revenue_Codes',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataRevenueCodesQuery,
        returnDataName: 'StaticDataRevenueCodes',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Revenue Code',
            typeOf: 'string',
            field: 'name',
            sorting: true,
          },
          {
            name: 'Is Clean',
            typeOf: 'boolean',
            field: 'isClean',
          },
          {
            name: 'Revenue Hierarchy',
            typeOf: 'string',
            field: 'hierarchy.value',
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Revenue Codes',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

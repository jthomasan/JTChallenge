import { APIMappingEntities } from '../../models/api.model';

const staticDataBespokeHaircutQuery = () => `
{
  StaticDataBespokeHaircuts {
    id
    modified
    counterpartyName
    razorCode
    approver
    startDate
    endDate
    minCollateralRating
    issuerCountry
    issuerName
    type
    maxRepoTenor
    variationToGuideline
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/bespoke-haircut/csv': {
    get: {
      name: 'staticDataBespokeHaircut',
      summary: 'Export static data Bespoke Haircut csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_bespoke_haircut',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataBespokeHaircutQuery,
        returnDataName: 'StaticDataBespokeHaircuts',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'razorCode',
        fields: [
          {
            field: 'razorCode',
            name: 'Razor Code',
            typeOf: 'string',
          },
          {
            field: 'counterpartyName',
            name: 'External ID',
            typeOf: 'string',
          },
          {
            field: 'approver',
            name: 'Approver',
            typeOf: 'string',
          },
          {
            field: 'startDate',
            name: 'Start Date',
            typeOf: 'string',
          },
          {
            field: 'endDate',
            name: 'End Date',
            typeOf: 'string',
          },
          {
            field: 'minCollateralRating',
            name: 'Min Collateral Rating',
            typeOf: 'string',
          },
          {
            field: 'issuerCountry',
            name: 'Issuer Country',
            typeOf: 'string',
          },
          {
            field: 'issuerName',
            name: 'Issuer Name',
            typeOf: 'string',
          },
          {
            field: 'type',
            name: 'Type',
            typeOf: 'string',
          },
          {
            field: 'maxRepoTenor',
            name: 'Max Repo Tenor',
            typeOf: 'string',
          },
          {
            field: 'variationToGuideline',
            name: 'Variation To Guideline',
            typeOf: 'number',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Bespoke Haircut',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

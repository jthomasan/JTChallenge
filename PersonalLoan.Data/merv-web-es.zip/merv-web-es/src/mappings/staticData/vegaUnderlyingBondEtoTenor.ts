import { APIMappingEntities } from '../../models/api.model';

const staticDataVegaUnderlyingBondEtoTenorQuery = () => `
{
  StaticDataEquityVegaUnderlyingBondETOTenors {
    modified
    term
    net2y
    net3y
    net5y
    net10y
    net30y
  }
}
`;

export default {
  '/reference-data/static-data/vega-underlying-bond-eto-tenor/csv': {
    get: {
      name: 'staticDataVegaUnderlyingBondEtoTenor',
      summary: 'Export static data Vega Underlying Bond Eto Tenor csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_vega_underlying_bond_eto_tenor',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataVegaUnderlyingBondEtoTenorQuery,
        returnDataName: 'StaticDataEquityVegaUnderlyingBondETOTenors',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'term',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net2y',
            name: '2y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: '3y',
            typeOf: 'number',
          },
          {
            field: 'net5y',
            name: '5y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: '10y',
            typeOf: 'number',
          },
          {
            field: 'net30y',
            name: '30y',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Vega Underlying Bond Eto Tenor',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

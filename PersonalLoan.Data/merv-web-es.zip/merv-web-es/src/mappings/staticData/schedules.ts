import { APIMappingEntities } from '../../models/api.model';

const staticDataSchedulesQuery = () => `
{
  ScheduleMappings {
    id
    modified
    name
    scheduleLocation
    lastIssuedOn
    lastIssuedBy
    marketRiskBusiness{
      id
      text
    }
    reviewDate
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/schedules/csv': {
    get: {
      name: 'staticDataSchedules',
      summary: 'Export static data Schedules csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_schedules',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataSchedulesQuery,
        returnDataName: 'ScheduleMappings',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'name',
        fields: [
          {
            field: 'marketRiskBusiness.text',
            name: 'Market Risk Business',
            typeOf: 'string',
          },
          {
            field: 'name',
            name: 'Market Risk Limit Schedule',
            typeOf: 'string',
          },
          {
            field: 'scheduleLocation',
            name: 'Document Location',
            typeOf: 'string',
          },
          {
            field: 'lastIssuedOn',
            name: 'Last Issued On',
            typeOf: 'string',
          },
          {
            field: 'reviewDate',
            name: 'Review Date',
            typeOf: 'string',
          },
          {
            field: 'lastIssuedBy',
            name: 'Last Issued By',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Schedules',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

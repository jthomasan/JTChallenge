import { APIMappingEntities } from '../../models/api.model';

const staticDataCCYFamilyFXOQuery = () => `
  {
    StaticDataCCYFamilyFXOs {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/ccy-family-fxo/csv': {
    get: {
      name: 'staticDataCCYFamilyFXO',
      summary: 'Export static data CCY Family FXO csv',
      description: 'Returns all static data CCY Family FXOs in csv file',
      filename: 'Static_Data_CCY_Family_FXO',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCCYFamilyFXOQuery,
        returnDataName: 'StaticDataCCYFamilyFXOs',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Value',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data CCY Family FXO',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataFxoVegaNetBucketsQuery = () => `
{
  StaticDataFXOVegaNetBuckets {
    modified
    termUnit
    term
    net1m
    net3m
    net1y
    net3y
    net10y
    net15y
    net1m_1y
    net1yPlus
    net6mPlus
  }
}
`;

export default {
  '/reference-data/static-data/fxo-vega-net-buckets/csv': {
    get: {
      name: 'staticDataFxoVegaNetBuckets',
      summary: 'Export static data Fxo Vega Net Buckets csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_fxo_vega_net_buckets',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataFxoVegaNetBucketsQuery,
        returnDataName: 'StaticDataFXOVegaNetBuckets',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net1m',
            name: 'Net1m',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: 'Net3m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: 'Net1y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: 'Net3y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: 'Net10y',
            typeOf: 'number',
          },
          {
            field: 'net15y',
            name: 'Net15y',
            typeOf: 'number',
          },
          {
            field: 'net1m_1y',
            name: 'Net1m_1y',
            typeOf: 'number',
          },
          {
            field: 'net1yPlus',
            name: 'Net1yPlus',
            typeOf: 'number',
          },
          {
            field: 'net6mPlus',
            name: 'Net6mPlus',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Fxo Vega Net Buckets',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

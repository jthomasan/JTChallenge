import { APIMappingEntities } from '../../models/api.model';

const staticDataDynamicLimitThresholdsQuery = () => `
{
  StaticDataDynamicLimitThresholds {
    id
    modified
    isin
    percentageLong
    percentageShort
    expiryDate
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/dynamic-limit-thresholds/csv': {
    get: {
      name: 'staticDataDynamicLimitThresholds',
      summary: 'Export static data Dynamic Limit Thresholds csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_dynamic_limit_thresholds',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataDynamicLimitThresholdsQuery,
        returnDataName: 'StaticDataDynamicLimitThresholds',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'isin',
        fields: [
          {
            field: 'isin',
            name: 'ISIN',
            typeOf: 'string',
          },
          {
            field: 'percentageLong',
            name: 'PercentageLong',
            typeOf: 'string',
          },
          {
            field: 'percentageShort',
            name: 'PercentageShort',
            typeOf: 'string',
          },
          {
            field: 'expiryDate',
            name: 'Expiry Date',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Dynamic Limit Thresholds',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataGrpComPriceQuotationQuery = () => `
{
  StaticDataCOMPriceQuotations {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/grp-com-price-quotation/csv': {
    get: {
      name: 'staticDataGrpComPriceQuotation',
      summary: 'Export static data Grp Com Price Quotation csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_grp_com_price_quotation',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGrpComPriceQuotationQuery,
        returnDataName: 'StaticDataCOMPriceQuotations',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'value',
            name: 'Value',
            typeOf: 'string',
            sorting: 'true',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
        responses: {
          '200': {
            description: 'An array of strings',
            schema: {
              title: 'Static Data Grp Com Price Quotation',
              type: 'array',
              items: {
                type: 'string',
              },
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

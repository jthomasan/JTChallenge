import { APIMappingEntities } from '../../models/api.model';

const staticDataGeographyQuery = () => `
{
  StaticDataGeographies {
    id
    modified
    description
    name
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/geography/csv': {
    get: {
      name: 'staticDataGeography',
      summary: 'Export static data Geography csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_geography',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGeographyQuery,
        returnDataName: 'StaticDataGeographies',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'name',
            name: 'Name',
            typeOf: 'string',
            sorting: 'true',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Geography',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

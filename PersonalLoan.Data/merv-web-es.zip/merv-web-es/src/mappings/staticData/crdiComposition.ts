import { APIMappingEntities } from '../../models/api.model';

const staticDataCrdiCompositionQuery = ({ cob }) => `
{
  StaticDataCRDICompositions (cob: ${cob}) {
    id
    modified
    indexLabel
    date
    issuer
    Instrument
    compositionPercentage
    seniority
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/crdi-composition/csv': {
    get: {
      name: 'staticDataCrdiComposition',
      summary: 'Export static data Crdi Composition csv',
      description: 'Returns all data in csv file',
      filename: ({ query }) => {
        const date = (query.cob as string) ?? '';

        return `static_data_crdi_composition_${date.replace(/\-/g, '')}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [
        {
          name: 'cob',
          in: 'query',
          description: 'Search by cob date',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: staticDataCrdiCompositionQuery,
        returnDataName: 'StaticDataCRDICompositions',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'indexLabel',
        fields: [
          {
            field: 'date',
            name: 'Date',
            typeOf: 'string',
          },
          {
            field: 'indexLabel',
            name: 'Index Label',
            typeOf: 'string',
          },
          {
            field: 'issuer',
            name: 'Issuer',
            typeOf: 'string',
          },
          {
            field: 'seniority',
            name: 'Seniority',
            typeOf: 'string',
          },
          {
            field: 'compositionPercentage',
            name: 'Composition Percentage',
            typeOf: 'number',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Crdi Composition',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

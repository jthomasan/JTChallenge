import { APIMappingEntities } from '../../models/api.model';

const staticDataPurposeForChangeQuery = () => `
{
  StaticDataPurposeForChanges {
    id
    modified
    description
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/purpose-for-change/csv': {
    get: {
      name: 'staticDataPurposeForChange',
      summary: 'Export static data Purpose For Change csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_purpose_for_change',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataPurposeForChangeQuery,
        returnDataName: 'StaticDataPurposeForChanges',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'description',
        fields: [
          {
            field: 'description',
            name: 'Purpose For Change',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Purpose For Change',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

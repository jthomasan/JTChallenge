import { APIMappingEntities } from '../../models/api.model';

const staticDataUnderlyingEqQuery = () => `
{
  StaticDataUnderlyingEQs {
    id
    modified
    ticker
    description
    SecurityMarket {
      id
      text
    }
    EQTypeTypeSystem {
      id
      text
    }
    EQRegionTypeSystem {
      id
      text
    }
    EQTierTypeSystem {
      id
      text
    }
    EQSpecificRiskWeightTypeSystem {
      id
      text
    }
    isIgnore
    comment
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/underlying-eq/csv': {
    get: {
      name: 'staticDataUnderlyingEq',
      summary: 'Export static data Underlying Eq csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_underlying_eq',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataUnderlyingEqQuery,
        returnDataName: 'StaticDataUnderlyingEQs',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'ticker',
        fields: [
          {
            field: 'ticker',
            name: 'Underlying - EQ',
            typeOf: 'string',
          },
          {
            field: 'description',
            name: 'Full Name',
            typeOf: 'string',
          },
          {
            field: 'SecurityMarket.text',
            name: 'Security Market',
            typeOf: 'string',
          },
          {
            field: 'EQTypeTypeSystem.text',
            name: 'Grp: EQ Type',
            typeOf: 'string',
          },
          {
            field: 'EQRegionTypeSystem.text',
            name: 'Grp: EQ Region',
            typeOf: 'string',
          },
          {
            field: 'EQTierTypeSystem.text',
            name: 'Grp: EQ Tier',
            typeOf: 'string',
          },
          {
            field: 'EQSpecificRiskWeightTypeSystem.text',
            name: 'Grp: EQ Specific Risk Weight',
            typeOf: 'string',
          },
          {
            field: 'isIgnore',
            name: 'Excluded from Quarantine',
            typeOf: 'boolean',
          },
          {
            field: 'comment',
            name: 'Comment',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Underlying Eq',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

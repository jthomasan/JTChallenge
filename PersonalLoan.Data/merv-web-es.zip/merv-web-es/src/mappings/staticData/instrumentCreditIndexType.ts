import { APIMappingEntities } from '../../models/api.model';

const staticDataInstrumentCreditIndexTypesQuery = () => `
  {
    StaticDataInstrumentCreditIndexTypes {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/instrument-credit-index-type/csv': {
    get: {
      name: 'staticDataInstrumentCreditIndexTypes',
      summary: 'Export static data instrument credit index type csv',
      description: 'Returns all static data instrument credit index types in csv file',
      filename: 'Static_Data_Instrument_Credit_Index_Types',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataInstrumentCreditIndexTypesQuery,
        returnDataName: 'StaticDataInstrumentCreditIndexTypes',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Value',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Credit Index Type',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

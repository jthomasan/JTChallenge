import { APIMappingEntities } from '../../models/api.model';

const staticDataLiquidityGeoMappingQuery = () => `
{
  StaticDataLiquidityGeoMappings {
    modified
    geographyHierarchy {
      id
      value
      fullPath
    }
    geographyMapping {
      id
      text
    }
    country
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/liquidity-geo-mapping/csv': {
    get: {
      name: 'staticDataLiquidityGeoMapping',
      summary: 'Export static data Liquidity Geo Mapping csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_liquidity_geo_mapping',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataLiquidityGeoMappingQuery,
        returnDataName: 'StaticDataLiquidityGeoMappings',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'country',
        fields: [
          {
            field: 'country',
            name: 'Location',
            typeOf: 'string',
          },
          {
            field: 'geographyHierarchy.value',
            name: 'Geography',
            typeOf: 'string',
          },
          {
            field: 'geographyHierarchy.fullPath',
            name: 'Geography FullPath',
            typeOf: 'string',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Liquidity Geo Mapping',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

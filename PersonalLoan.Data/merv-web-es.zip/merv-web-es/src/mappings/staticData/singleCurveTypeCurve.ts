import { APIMappingEntities } from '../../models/api.model';

const staticDataSingleCurveTypeCurveQuery = () => `
{
  StaticDataSingleCurveTypeCurves {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/single-curve-type-curve/csv': {
    get: {
      name: 'staticDataSingleCurveTypeCurve',
      summary: 'Export static data Single Curve Type Curve csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_single_curve_type_curve',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataSingleCurveTypeCurveQuery,
        returnDataName: 'StaticDataSingleCurveTypeCurves',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'value',
            name: 'Value',
            typeOf: 'string',
            sorting: 'true',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
        responses: {
          '200': {
            description: 'An array of strings',
            schema: {
              title: 'Static Data Single Curve Type Curve',
              type: 'array',
              items: {
                type: 'string',
              },
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

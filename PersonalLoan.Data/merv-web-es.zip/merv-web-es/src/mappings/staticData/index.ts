import * as requireDir from 'require-dir';
import { APIMappingEntities } from '../../models/api.model';

const requires = requireDir('./', {
  extensions: ['.js', '.ts'],
});

export default Object.values(requires).reduce((acc: any, curr: any) => {
  return {
    ...acc,
    ...curr.default,
  };
}, {}) as APIMappingEntities;

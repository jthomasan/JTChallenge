import { APIMappingEntities } from '../../models/api.model';

const staticDataUnderlyingCcyPairQuery = () => `
{
  StaticDataUnderlyingCCYPairs {
    id
    modified
    name
    description
    isActive
    comment
    foreignCurrency
    baseCurrency
    ccyPairGroupTypeSystem {
      id
      text
    }
    ccyPairFamilyTypeSystem {
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/underlying-ccy-pair/csv': {
    get: {
      name: 'staticDataUnderlyingCcyPair',
      summary: 'Export static data Underlying Ccy Pair csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_underlying_ccy_pair',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataUnderlyingCcyPairQuery,
        returnDataName: 'StaticDataUnderlyingCCYPairs',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'name',
            name: 'Underlying - CCY Pair',
            typeOf: 'string',
            sorting: 'true',
          },
          {
            field: 'description',
            name: 'Description',
            typeOf: 'string',
          },
          {
            field: 'baseCurrency',
            name: 'BaseCurrency',
            typeOf: 'string',
          },
          {
            field: 'foreignCurrency',
            name: 'ForeignCurrency',
            typeOf: 'string',
          },
          {
            field: 'ccyPairFamilyTypeSystem.text',
            name: 'Grp: CCY Pair Family',
            typeOf: 'string',
          },
          {
            field: 'ccyPairGroupTypeSystem.text',
            name: 'Grp: CCY Pair OnOffShore',
            typeOf: 'string',
          },
          {
            field: 'comment',
            name: 'Comment',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
        responses: {
          '200': {
            description: 'An array of strings',
            schema: {
              title: 'Static Data Underlying Ccy Pair',
              type: 'array',
              items: {
                type: 'string',
              },
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataPillarsRepoStfSensitivityQuery = () => `
{
  StaticDataRepoStfSensitivities {
    modified
    net7d
    net1y
    net3m
    net3yPlus
    term
    termUnit
    net9m
    net3y
  } 
}
`;

export default {
  '/reference-data/static-data/pillars-repo-stf-sensitivity/csv': {
    get: {
      name: 'staticDataPillarsRepoStfSensitivity',
      summary: 'Export static data Pillars Repo Stf Sensitivity csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_pillars_repo_stf_sensitivity',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataPillarsRepoStfSensitivityQuery,
        returnDataName: 'StaticDataRepoStfSensitivities',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net7d',
            name: '7d',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: '3m',
            typeOf: 'number',
          },
          {
            field: 'net9m',
            name: '9m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: '1y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: '3y',
            typeOf: 'number',
          },
          {
            field: 'net3yPlus',
            name: '3yPlus',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Pillars Repo Stf Sensitivity',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

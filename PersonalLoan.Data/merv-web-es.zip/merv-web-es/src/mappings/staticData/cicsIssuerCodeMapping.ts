import { APIMappingEntities } from '../../models/api.model';

const staticDataCicsIssuerCodeMappingQuery = () => `
{
  StaticDataCICSIssuerCodeMappings {
    id
    modified
    CICSIssuerCode
    Issuer {
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/cics-issuer-code-mapping/csv': {
    get: {
      name: 'staticDataCicsIssuerCodeMapping',
      summary: 'Export static data Cics Issuer Code Mapping csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_cics_issuer_code_mapping',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCicsIssuerCodeMappingQuery,
        returnDataName: 'StaticDataCICSIssuerCodeMappings',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'CICSIssuerCode',
        fields: [
          {
            field: 'CICSIssuerCode',
            name: 'CICS Issuer Code',
            typeOf: 'string',
          },
          {
            field: 'Issuer.text',
            name: 'Issuer',
            typeOf: 'string',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Cics Issuer Code Mapping',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataCreditExtraOrdinaryStressQuery = () => `
{
    StaticDataCreditExtraOrdinaryStress {
      id
      modified
      key
      genericRating
      dealCurrency
      financialMarketCrash
      usEconomicCrash
      globalInflationaryCrisis
      asianCrisis
      chinaHardLanding
      sustainedDeflation
      sovereignDowngradeAust
      cnyAndHkdFreeFloat
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/credit-extraordinary-stress/csv': {
    get: {
      name: 'staticDataCreditExtraOrdinaryStress',
      summary: 'Export static data credit extraordinary stress csv',
      description: 'Returns all static data credit extraordinary stresses in csv file',
      filename: 'Static_Data_Credit_Extraordinary_Stress',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCreditExtraOrdinaryStressQuery,
        returnDataName: 'StaticDataCreditExtraOrdinaryStress',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'key',
            name: 'Key',
            typeOf: 'string',
            sorting: true,
          },
          {
            field: 'genericRating',
            name: 'Generic Rating',
            typeOf: 'string',
          },
          {
            field: 'dealCurrency',
            name: 'Deal Currency',
            typeOf: 'string',
          },
          {
            field: 'financialMarketCrash',
            name: 'Financial Market Crash',
            typeOf: 'number',
          },
          {
            field: 'usEconomicCrash',
            name: 'US Economic Crash',
            typeOf: 'number',
          },
          {
            field: 'globalInflationaryCrisis',
            name: 'Global Inflationary Crisis',
            typeOf: 'number',
          },
          {
            field: 'asianCrisis',
            name: 'Asian Crisis',
            typeOf: 'number',
          },
          {
            field: 'chinaHardLanding',
            name: 'China Hard Landing',
            typeOf: 'number',
          },
          {
            field: 'sustainedDeflation',
            name: 'Sustained Deflation',
            typeOf: 'number',
          },
          {
            field: 'sovereignDowngradeAust',
            name: 'Sovereign Downgrade-Aust',
            typeOf: 'number',
          },
          {
            field: 'cnyAndHkdFreeFloat',
            name: 'CNY and HKD Free Float',
            typeOf: 'number',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'string',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            name: 'Static Data Credit Extraordinary Stress',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

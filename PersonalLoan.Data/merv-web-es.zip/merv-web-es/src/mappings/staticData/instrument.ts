import { APIMappingEntities } from '../../models/api.model';

const staticDataInstrumentQuery = ({ type }: any) => `
{
  StaticDataInstruments (type: "${type}")
}
`;

export default {
  '/reference-data/static-data/instrument/csv': {
    get: {
      name: 'staticDataInstrument',
      summary: 'Export static data Instrument csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_instrument',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [
        {
          name: 'type',
          in: 'query',
          description: 'Search by type',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: staticDataInstrumentQuery,
        returnDataName: 'StaticDataInstruments',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'name',
        fields: [
          {
            name: 'Is Updated from Ac',
            typeOf: 'string',
            field: 'isUpdatedFromAc',
          },
          {
            name: 'Is in Ac Quarantine',
            typeOf: 'string',
            field: 'isAcQuarantine',
          },
          {
            name: 'ISIN',
            typeOf: 'string',
            field: 'ISIN',
          },
          {
            name: 'Name',
            typeOf: 'string',
            field: 'name',
          },
          {
            name: 'Description',
            typeOf: 'string',
            field: 'description',
          },
          {
            name: 'Security Currency',
            typeOf: 'string',
            field: 'Currency.text',
          },
          {
            name: 'Seniority',
            typeOf: 'string',
            field: 'genericSeniorityTypeSystem.text',
          },
          {
            name: 'Bloomberg Seniority',
            typeOf: 'string',
            field: 'bloombergSeniority',
          },
          {
            name: 'Maturity Date',
            typeOf: 'date',
            field: 'maturityDate',
          },
          {
            name: 'Is Matured',
            typeOf: 'boolean',
            field: 'isMatured',
          },
          {
            name: 'Callable Flag',
            typeOf: 'boolean',
            field: 'callableFlag',
          },
          {
            name: 'Next Call Date',
            typeOf: 'date',
            field: 'nextCallDate',
          },
          {
            name: 'Called',
            typeOf: 'string',
            field: 'called',
          },
          {
            name: 'Bail In Status',
            typeOf: 'string',
            field: 'bailInStatus',
          },
          {
            name: 'Perpetual Flag',
            typeOf: 'string',
            field: 'perpetual',
          },
          {
            name: 'SP Rating',
            typeOf: 'string',
            field: 'snpIssueRating.text',
          },
          {
            name: 'MO Rating',
            typeOf: 'string',
            field: 'moIssueRating.text',
          },
          {
            name: 'Fitch Rating',
            typeOf: 'string',
            field: 'fitchIssueRating.text',
          },
          {
            name: 'Instrument Debt Ticker',
            typeOf: 'string',
            field: 'instrumentDebtTicker',
          },
          {
            name: 'Issuer',
            typeOf: 'string',
            field: 'Issuer.text',
          },
          {
            name: 'Issuer Equity Ticker',
            typeOf: 'string',
            field: 'issuerEquityTicker',
          },
          {
            name: 'Keepwell Agreement',
            typeOf: 'string',
            field: 'keepwellAgreement',
          },
          {
            name: 'Issuer Description',
            typeOf: 'string',
            field: 'issuerDescription',
          },
          {
            name: 'Issuer Country',
            typeOf: 'string',
            field: 'issuerCountry',
          },
          {
            name: 'Guaranteed',
            typeOf: 'boolean',
            field: 'isGuaranteed',
          },
          {
            name: 'Guarantor Issuer',
            typeOf: 'string',
            field: 'guaranteeIssuer.text',
          },
          {
            name: 'Guarantor Equity Ticker',
            typeOf: 'string',
            field: 'guarantorEquityTicker',
          },
          {
            name: 'Guarantor Issuer Description',
            typeOf: 'string',
            field: 'guarantorIssuerDescription',
          },
          {
            name: 'Guarantor Issuer Country',
            typeOf: 'string',
            field: 'guarantorIssuerCountry',
          },
          {
            name: 'OECD Indicator',
            typeOf: 'boolean',
            field: 'isOECD',
          },
          {
            name: 'SBLC Entity',
            typeOf: 'string',
            field: 'SBLCEntity',
          },
          {
            name: 'SP Resultant Rating',
            typeOf: 'string',
            field: 'SPResultantRating.text',
          },
          {
            name: 'MO Resultant Rating',
            typeOf: 'string',
            field: 'MOResultantRating.text',
          },
          {
            name: 'Fitch Resultant Rating',
            typeOf: 'string',
            field: 'FitchResultantRating.text',
          },
          {
            name: 'APRA Derived Rating',
            typeOf: 'string',
            field: 'apraDerivedRating',
          },
          {
            name: 'APRA Derived Rating Override',
            typeOf: 'string',
            field: 'derivedRatingOverride.text',
          },
          {
            name: 'APRA Derived Rating Override Comment',
            typeOf: 'string',
            field: 'derivedRatingOverrideComment',
          },
          {
            name: 'Limit Entity',
            typeOf: 'string',
            field: 'limitEntityIssuer.text',
          },
          {
            name: 'Entity of Risk',
            typeOf: 'string',
            field: 'entityOfRiskIssuer.text',
          },
          {
            name: 'Entity of Risk Comment',
            typeOf: 'string',
            field: 'entityOfRiskComment',
          },
          {
            name: 'Country of Risk',
            typeOf: 'string',
            field: 'countryOfRisk',
          },
          {
            name: 'Country of Risk Override',
            typeOf: 'string',
            field: 'countryOfRiskOverride',
          },
          {
            name: 'Country of Risk Override Comment',
            typeOf: 'string',
            field: 'countryOfRiskOverrideComment',
          },
          {
            name: 'BICS Level 1',
            typeOf: 'string',
            field: 'BICSLevel1',
          },
          {
            name: 'BICS Level 2',
            typeOf: 'string',
            field: 'BICSLevel2',
          },
          {
            name: 'BICS Level 3',
            typeOf: 'string',
            field: 'BICSLevel3',
          },
          {
            name: 'Capital Trigger Type',
            typeOf: 'string',
            field: 'capitalTriggerType',
          },
          {
            name: 'Capital Trigger Level',
            typeOf: 'string',
            field: 'capitalTriggerLevel',
          },
          {
            name: 'Lead Manager',
            typeOf: 'string',
            field: 'leadManager',
          },
          {
            name: 'Issue Outstanding Amount',
            typeOf: 'string',
            field: 'issueOutstandingAmount',
          },
          {
            name: 'Date Of Issue',
            typeOf: 'date',
            field: 'dateOfIssue',
          },
          {
            name: 'Instrument Utilisation',
            typeOf: 'string',
            field: 'instrumentUtilisation',
          },
          {
            name: 'Override Category',
            typeOf: 'string',
            field: 'overrideSRCatSec.text',
          },
          {
            name: 'Override Rating Band',
            typeOf: 'string',
            field: 'overrideRatingBandSec.text',
          },
          {
            name: 'Use Of Proceeds',
            typeOf: 'string',
            field: 'useOfProceeds',
          },
          {
            name: 'Domestic SUKUK',
            typeOf: 'string',
            field: 'domesticSUKUK',
          },
          {
            name: 'International SUKUK',
            typeOf: 'string',
            field: 'internationalSUKUK',
          },
          {
            name: 'Description Notes',
            typeOf: 'string',
            field: 'descriptionNotes',
          },
          {
            name: 'Market Issue',
            typeOf: 'string',
            field: 'marketIssue',
          },
          {
            name: 'Is Good ISIN',
            typeOf: 'boolean',
            field: 'isGoodISIN',
          },
          {
            name: 'Grp: Holding Period Status',
            typeOf: 'string',
            field: 'holdingPeriodStatusTypeSystem.text',
          },
          {
            name: 'Is Due Dilligence',
            typeOf: 'boolean',
            field: 'isDueDilligence',
          },
          {
            name: 'Due Dilligence Date',
            typeOf: 'date',
            field: 'dueDilligenceDate',
          },
          {
            name: 'Days to Review',
            typeOf: 'string',
            field: 'daysToReview',
          },
          {
            name: 'Grp: CR Index Type',
            typeOf: 'string',
            field: 'creditIndexTypeTypeSystem.text',
          },
          {
            name: 'Sec_FstAccDate',
            typeOf: 'date',
            field: 'secFstAccDate',
          },
          {
            name: 'Issuance Country',
            typeOf: 'string',
            field: 'issuanceCountry.text',
          },
          {
            name: 'Related Product',
            typeOf: 'string',
            field: 'relatedProduct',
          },
          {
            name: 'Credit Tick',
            typeOf: 'boolean',
            field: 'creditTick',
          },
          {
            name: 'Is Data Reviewed',
            typeOf: 'boolean',
            field: 'isDataReview',
          },
          {
            name: 'Is Additional Data',
            typeOf: 'boolean',
            field: 'isIgnore',
          },
          {
            name: 'AC Key',
            typeOf: 'string',
            field: 'acKey',
          },
          {
            name: 'Equity Market Cap Type',
            typeOf: 'string',
            field: 'equityMarketCapTypeSystem.text',
          },
          {
            name: 'APRA Rank',
            typeOf: 'string',
            field: 'apraRankTypeSystem.text',
          },
          {
            name: 'APRA Approved',
            typeOf: 'boolean',
            field: 'isApraApproved',
          },
          {
            name: 'Override Tenor Maturity',
            typeOf: 'string',
            field: 'overrideTenor',
          },
          {
            name: 'Is Tier1/Tier2',
            typeOf: 'boolean',
            field: 'isTier1Tier2',
          },
          {
            name: 'Basel III Designation',
            typeOf: 'string',
            field: 'basel3Designation',
          },
          {
            name: 'Basel III Designation Override',
            typeOf: 'string',
            field: 'basel3DesignationOverrideSystem.text',
          },
          {
            name: 'APRA Stress Securitisation',
            typeOf: 'string',
            field: 'apraStressSecTypeSystem.text',
          },
          {
            name: 'Country Of Domicile',
            typeOf: 'string',
            field: 'countryOfDomicile',
          },
          {
            name: 'Industry Sector',
            typeOf: 'string',
            field: 'industrySector',
          },
          {
            name: 'Industry Group',
            typeOf: 'string',
            field: 'industryGroup',
          },
          {
            name: 'Market Sector Description',
            typeOf: 'string',
            field: 'marketSectorDescription',
          },
          {
            name: 'Redemption Currency',
            typeOf: 'string',
            field: 'redemptionCurrency',
          },
          {
            name: 'Coupon Frequency Description',
            typeOf: 'string',
            field: 'couponFrequencyDescription',
          },
          {
            name: 'Coupon Type',
            typeOf: 'string',
            field: 'couponType',
          },
          {
            name: 'Floater Formula',
            typeOf: 'string',
            field: 'floaterFormula',
          },
          {
            name: 'Floater Spread',
            typeOf: 'string',
            field: 'floaterSpread',
          },
          {
            name: 'Make-Whole Call Spread',
            typeOf: 'string',
            field: 'makeWholeCallSpread',
          },
          {
            name: 'Make-Whole Indicator',
            typeOf: 'string',
            field: 'makeWholeIndicator',
          },
          {
            name: 'Entity Of Risk S&P',
            typeOf: 'string',
            field: 'entityOfRiskSP',
          },
          {
            name: 'Entity Of Risk Moody',
            typeOf: 'string',
            field: 'entityOfRiskMoody',
          },
          {
            name: 'Entity Of Risk Fitch',
            typeOf: 'string',
            field: 'entityOfRiskFitch',
          },
          {
            name: 'Entity Of Risk SP Override',
            typeOf: 'string',
            field: 'entityOfRiskSPOverride',
          },
          {
            name: 'Entity Of Risk Moody Override',
            typeOf: 'string',
            field: 'entityOfRiskMoodyOverride',
          },
          {
            name: 'Entity Of Risk Fitch Override',
            typeOf: 'string',
            field: 'entityOfRiskFitchOverride',
          },
          {
            name: 'AC SP Resultant Rating',
            typeOf: 'string',
            field: 'ACSPResultantRating.text',
          },
          {
            name: 'AC Moody Resultant Rating',
            typeOf: 'string',
            field: 'ACMoodyResultantRating.text',
          },
          {
            name: 'AC Fitch Resultant Rating',
            typeOf: 'string',
            field: 'ACFitchResultantRating.text',
          },
          {
            name: 'AC APRA Derived Rating',
            typeOf: 'string',
            field: 'ACApraDerivedRating.text',
          },
          {
            name: 'Curve Assignment Rating Override',
            typeOf: 'string',
            field: 'curveAssignmentRatingOverride.text',
          },
          {
            name: 'Curve Assignment Rating',
            typeOf: 'string',
            field: 'curveAssignmentRating.text',
          },
          {
            name: 'Market Risk Rating Comment',
            typeOf: 'string',
            field: 'marketRiskRatingComment',
          },
          {
            name: 'Step Up',
            typeOf: 'string',
            field: 'stepUp',
          },
          {
            name: 'Risk Comment',
            typeOf: 'string',
            field: 'riskComment',
          },
          {
            name: 'Type Of Bond',
            typeOf: 'string',
            field: 'typeOfBond',
          },
          {
            name: '144A Flag',
            typeOf: 'boolean',
            field: 'flag144A',
          },
          {
            name: 'Is Reg S',
            typeOf: 'boolean',
            field: 'isRegS',
          },
          {
            name: 'Credit Curve Label',
            typeOf: 'string',
            field: 'creditCurveLabel',
          },
          {
            name: 'comment',
            typeOf: 'string',
            field: 'comment',
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'date',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            name: 'Static Data Instrument',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataBookTypeQuery = () => `
  {
    StaticDataBookTypes {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/book-type/csv': {
    get: {
      name: 'staticDataBookType',
      summary: 'Export static data book type csv',
      description: 'Returns all static data book types in csv file',
      filename: 'Static_Data_Book_Type',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataBookTypeQuery,
        returnDataName: 'StaticDataBookTypes',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Value',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Book Type',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

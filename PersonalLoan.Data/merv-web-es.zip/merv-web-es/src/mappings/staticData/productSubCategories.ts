import { APIMappingEntities } from '../../models/api.model';

const staticDataProductSubCategoriesQuery = () => `
{
  ProductSubCategoryMappings {
    id
    modified
    description
    globalProductLine{
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/product-sub-categories/csv': {
    get: {
      name: 'staticDataProductSubCategories',
      summary: 'Export static data Product Sub Categories csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_product_sub_categories',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataProductSubCategoriesQuery,
        returnDataName: 'ProductSubCategoryMappings',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'description',
        fields: [
          {
            field: 'description',
            name: 'Product Sub Category',
            typeOf: 'string',
          },
          {
            field: 'globalProductLine.text',
            name: 'Global Product Line',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Product Sub Categories',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

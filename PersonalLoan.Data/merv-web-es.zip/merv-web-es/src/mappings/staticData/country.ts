import { APIMappingEntities } from '../../models/api.model';

const staticDataCountryQuery = () => `
  {
    StaticDataCountries {
      id
      modified
      name
      STFGeographyTypeSystem {
        id
        text
      }
      OECDIndicator
      isCMRC
      FRTBGeographyTypeSystem {
        id
        text
      }
      geography {
        id
        text
      }
      countryCode
      baseCurrency {
        id
        text
      }
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/country/csv': {
    get: {
      name: 'staticDataCountry',
      summary: 'Export static data country csv',
      description: 'Returns all static data countries in csv file',
      filename: 'Static_Data_Country',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCountryQuery,
        returnDataName: 'StaticDataCountries',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Country Code',
            typeOf: 'string',
            field: 'countryCode',
          },
          {
            name: 'Name',
            typeOf: 'string',
            field: 'name',
            sorting: true,
          },
          {
            name: 'Base Currency',
            typeOf: 'string',
            field: 'baseCurrency.text',
          },
          {
            name: 'Geography',
            typeOf: 'string',
            field: 'geography.text',
          },
          {
            name: 'STF Geography',
            typeOf: 'string',
            field: 'STFGeographyTypeSystem.text',
          },
          {
            name: 'FRTB Geography',
            typeOf: 'string',
            field: 'FRTBGeographyTypeSystem.text',
          },
          {
            name: 'Is CMRC',
            typeOf: 'boolean',
            field: 'isCMRC',
          },
          {
            name: 'OECD Indicator',
            typeOf: 'boolean',
            field: 'OECDIndicator',
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'string',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            name: 'Static Data Country',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

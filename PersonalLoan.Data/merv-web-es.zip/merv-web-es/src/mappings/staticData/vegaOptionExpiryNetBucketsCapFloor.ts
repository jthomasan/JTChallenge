import { APIMappingEntities } from '../../models/api.model';

const staticDataVegaOptionExpiryNetBucketsCapFloorQuery = () => `
{
  StaticDataVegaOptionExpiryNetBucketsCapFloorList {
    modified
    term
    termUnit
    net3m
    net1y
    net3y
    net10y
    net20y
  }
}
`;

export default {
  '/reference-data/static-data/vega-option-expiry-net-buckets-cap-floor/csv': {
    get: {
      name: 'staticDataVegaOptionExpiryNetBucketsCapFloor',
      summary: 'Export static data Vega Option Expiry Net Buckets Cap Floor csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_vega_option_expiry_net_buckets_cap_floor',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataVegaOptionExpiryNetBucketsCapFloorQuery,
        returnDataName: 'StaticDataVegaOptionExpiryNetBucketsCapFloorList',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net3m',
            name: 'Net3m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: 'Net1y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: 'Net3y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: 'Net10y',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: 'Net20y',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Vega Option Expiry Net Buckets Cap Floor',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

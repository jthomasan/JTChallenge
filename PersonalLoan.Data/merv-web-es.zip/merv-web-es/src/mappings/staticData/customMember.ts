import { APIMappingEntities } from '../../models/api.model';
import { mapArrayItemsToString } from '../../helpers/stringUtils';

const staticDataCustomMemberQuery = () => `
{
  StaticDataCustomMembers {
    id
    modified
    name
    underlyingType {
      id
      text
    }
    operation {
      id
      text
    }
    nameofUnderlying {
      id
      text
      weight
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

interface NameOfUnderlying {
  id: string;
  text: string;
  weight?: number;
}

const nameOfUnderlyingDisplayRenderer = (data: NameOfUnderlying[]): string =>
  mapArrayItemsToString(
    data,
    (item) => `${item.weight != null && item.weight !== 1 ? `(${item.weight}) ` : ''}${item.text}`,
    ', ',
  );

export default {
  '/reference-data/static-data/custom-member/csv': {
    get: {
      name: 'staticDataCustomMember',
      summary: 'Export static data Custom Member csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_custom_member',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCustomMemberQuery,
        returnDataName: 'StaticDataCustomMembers',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'name',
        fields: [
          {
            field: 'name',
            name: 'Name',
            typeOf: 'string',
          },
          {
            field: 'operation.text',
            name: 'Operation',
            typeOf: 'string',
          },
          {
            field: 'underlyingType.text',
            name: 'Underlying Type',
            typeOf: 'string',
          },
          {
            field: 'nameofUnderlying',
            name: 'Name of Underlying',
            typeOf: 'array',
            displayRenderer: nameOfUnderlyingDisplayRenderer,
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Custom Member',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

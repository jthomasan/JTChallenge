import { APIMappingEntities } from '../../models/api.model';

const staticDataInternalCounterpartyQuery = () => `
  {
    StaticDataInternalCounterParties {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/internal-counterparty/csv': {
    get: {
      name: 'staticDataInternalCounterparty',
      summary: 'Export static data internal counterparty csv',
      description: 'Returns all static data internal counterparties in csv file',
      filename: 'Static_Data_Internal_Counterparty',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataInternalCounterpartyQuery,
        returnDataName: 'StaticDataInternalCounterParties',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Value',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Internal Counterparty',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataCounterpartyQuery = () => `
{
  StaticDataCounterparties
}
`;

export default {
  '/reference-data/static-data/counterparty/csv': {
    get: {
      name: 'staticDataCounterparty',
      summary: 'Export static data Counterparty csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_counterparty',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCounterpartyQuery,
        returnDataName: 'StaticDataCounterparties',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'counterpartyExternalId',
        fields: [
          {
            field: 'counterpartyExternalId',
            name: 'External ID',
            typeOf: 'string',
            defaultSortColumn: true,
          },
          {
            field: 'SourceKey.text',
            name: 'Source',
            typeOf: 'string',
          },
          {
            field: 'Country.text',
            name: 'Country',
            typeOf: 'string',
          },
          {
            field: 'internalGroupTypeSystem.text',
            name: 'Grp: InternalCounterparty',
            typeOf: 'string',
          },
          {
            field: 'STFSectorTypeSystem.text',
            name: 'Grp: STF Sector',
            typeOf: 'string',
          },
          {
            field: 'isInternal',
            name: 'Is Internal',
            typeOf: 'string',
          },
          {
            field: 'razorCode',
            name: 'RazorCode',
            typeOf: 'string',
          },
          {
            field: 'CTPYCOUNTRYOFRISK',
            name: 'CTPY_COUNTRY_OF_RISK',
            typeOf: 'string',
          },
          {
            field: 'COUNTRYOFDOMICILE',
            name: 'COUNTRY_OF_DOMICILE',
            typeOf: 'string',
          },
          {
            field: 'interbank',
            name: 'Interbank',
            typeOf: 'string',
          },
          {
            field: 'setNo',
            name: 'Set No.',
            typeOf: 'string',
          },
          {
            field: 'controlPoint',
            name: 'Control Point',
            typeOf: 'string',
          },
          {
            field: 'interdeskDescription',
            name: 'Interdesk - Description',
            typeOf: 'string',
          },
          {
            field: 'comment',
            name: 'Comment',
            typeOf: 'string',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Counterparty',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

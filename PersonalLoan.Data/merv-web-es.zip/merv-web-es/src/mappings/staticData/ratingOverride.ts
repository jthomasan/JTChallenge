import { APIMappingEntities } from '../../models/api.model';

const staticDataRatingOverrideQuery = () => `
{
  StaticDataRatingOverrides {
    id
    modified
    agency {
      text
    }
    issuer {
      id
      text
    }
    creditRating {
      id
      text
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/rating-override/csv': {
    get: {
      name: 'staticDataRatingOverride',
      summary: 'Export static data Rating Override csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_rating_override',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataRatingOverrideQuery,
        returnDataName: 'StaticDataRatingOverrides',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'issuer.text',
        fields: [
          {
            field: 'issuer.text',
            name: 'Issuer',
            typeOf: 'string',
          },
          {
            field: 'agency.text',
            name: 'Agency',
            typeOf: 'string',
          },
          {
            field: 'creditRating.text',
            name: 'Rating',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Rating Override',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataTenorDaysToMaturityQuery = () => `
{
  StaticDataTenorAndDaystoMaturities {
    id
    modified
    bondETOInstrument
    sEFName
    tRNGRP
    tenor
    daysToMaturity
    isDeliverable
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/tenor-days-to-maturity/csv': {
    get: {
      name: 'staticDataTenorDaysToMaturity',
      summary: 'Export static data Tenor Days To Maturity csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_tenor_days_to_maturity',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataTenorDaysToMaturityQuery,
        returnDataName: 'StaticDataTenorAndDaystoMaturities',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'bondETOInstrument',
        fields: [
          {
            field: 'bondETOInstrument',
            name: 'Bond ETO Instrument',
            typeOf: 'string',
          },
          {
            field: 'sEFName',
            name: 'Contract Description',
            typeOf: 'string',
          },
          {
            field: 'tRNGRP',
            name: 'Contract Group',
            typeOf: 'string',
          },
          {
            field: 'tenor',
            name: 'Tenor',
            typeOf: 'string',
          },
          {
            field: 'daysToMaturity',
            name: 'Days to Maturity',
            typeOf: 'number',
          },
          {
            field: 'isDeliverable',
            name: 'Is Deliverable',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Tenor Days To Maturity',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

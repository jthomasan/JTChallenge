import { APIMappingEntities } from '../../models/api.model';

const staticDataPillarsCr01Query = () => `
{
  StaticDataPillarsCr01s {
    modified
    net15y
    net7y
    net10y
    net30y
    net20y
    net6m
    net3m
    net1y
    net2y
    term
    termUnit
    net5y
    net3y
    net4y
  } 
}
`;

export default {
  '/reference-data/static-data/pillars-cr01/csv': {
    get: {
      name: 'staticDataPillarsCr01',
      summary: 'Export static data Pillars Cr01 csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_pillars_cr01',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataPillarsCr01Query,
        returnDataName: 'StaticDataPillarsCr01s',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net3m',
            name: '3m',
            typeOf: 'number',
          },
          {
            field: 'net6m',
            name: '6m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: '1y',
            typeOf: 'number',
          },
          {
            field: 'net2y',
            name: '2y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: '3y',
            typeOf: 'number',
          },
          {
            field: 'net4y',
            name: '4y',
            typeOf: 'number',
          },
          {
            field: 'net5y',
            name: '5y',
            typeOf: 'number',
          },
          {
            field: 'net7y',
            name: '7y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: '10y',
            typeOf: 'number',
          },
          {
            field: 'net15y',
            name: '15y',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: '20y',
            typeOf: 'number',
          },
          {
            field: 'net30y',
            name: '30y',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Pillars Cr01',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

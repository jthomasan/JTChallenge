import { APIMappingEntities } from '../../models/api.model';

const staticDataVegaUnderlyingSwapBondMaturityNetBucketsQuery = () => `
{
  StaticDataVegaUnderlyingSwapBondMaturityNetBuckets {
    modified
    term
    termUnit
    net3m
    net2y
    net5y
    net10y
    net20y
  }
}
`;

export default {
  '/reference-data/static-data/vega-underlying-swap-bond-maturity-net-buckets/csv': {
    get: {
      name: 'staticDataVegaUnderlyingSwapBondMaturityNetBuckets',
      summary: 'Export static data Vega Underlying Swap Bond Maturity Net Buckets csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_vega_underlying_swap_bond_maturity_net_buckets',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataVegaUnderlyingSwapBondMaturityNetBucketsQuery,
        returnDataName: 'StaticDataVegaUnderlyingSwapBondMaturityNetBuckets',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net3m',
            name: 'Net3m',
            typeOf: 'number',
          },
          {
            field: 'net2y',
            name: 'Net2y',
            typeOf: 'number',
          },
          {
            field: 'net5y',
            name: 'Net5y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: 'Net10y',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: 'Net20y',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Vega Underlying Swap Bond Maturity Net Buckets',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

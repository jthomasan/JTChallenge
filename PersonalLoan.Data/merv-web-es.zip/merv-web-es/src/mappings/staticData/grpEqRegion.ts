import { APIMappingEntities } from '../../models/api.model';

const staticDataGrpEqRegionQuery = () => `
{
  StaticDataGrpEQRegions {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/grp-eq-region/csv': {
    get: {
      name: 'staticDataGrpEqRegion',
      summary: 'Export static data Grp Eq Region csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_grp_eq_region',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGrpEqRegionQuery,
        returnDataName: 'StaticDataGrpEQRegions',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'value',
        fields: [
          {
            field: 'value',
            name: 'Value',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Grp Eq Region',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

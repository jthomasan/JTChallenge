import { APIMappingEntities } from '../../models/api.model';

const staticDataPillarsXccyBasisBasisGammaQuery = () => `
{
  StaticDataPillarXCCYBasisBasisGammaList {
    modified
    term
    net1m
    net2m
    net3m
    net6m
    net9m
    net1y
    net2y
    net3y
    net4y
    net5y
    net7y
    net10y
    net15y
    net20y
    net25y
    net30y
  }
}
`;

export default {
  '/reference-data/static-data/pillars-xccy-basis-basis-gamma/csv': {
    get: {
      name: 'staticDataPillarsXccyBasisBasisGamma',
      summary: 'Export static data Pillars Xccy Basis Basis Gamma csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_pillars_xccy_basis_basis_gamma',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataPillarsXccyBasisBasisGammaQuery,
        returnDataName: 'StaticDataPillarXCCYBasisBasisGammaList',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'term',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'number',
          },
          {
            field: 'net1m',
            name: '1m',
            typeOf: 'number',
          },
          {
            field: 'net2m',
            name: '2m',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: '3m',
            typeOf: 'number',
          },
          {
            field: 'net6m',
            name: '6m',
            typeOf: 'number',
          },
          {
            field: 'net9m',
            name: '9m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: '1y',
            typeOf: 'number',
          },
          {
            field: 'net2y',
            name: '2y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: '3y',
            typeOf: 'number',
          },
          {
            field: 'net4y',
            name: '4y',
            typeOf: 'number',
          },
          {
            field: 'net5y',
            name: '5y',
            typeOf: 'number',
          },
          {
            field: 'net7y',
            name: '7y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: '10y',
            typeOf: 'number',
          },
          {
            field: 'net15y',
            name: '15y',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: '20y',
            typeOf: 'number',
          },
          {
            field: 'net25y',
            name: '25y',
            typeOf: 'number',
          },
          {
            field: 'net30y',
            name: '30y',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Pillars Xccy Basis Basis Gamma',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';
import staticDataAuditHistoryProcessor from '../../processors/staticData/staticDataAuditHistoryProcessor';

const staticDataAuditHistoryQuery = () => `
  query getStaticDataAuditHistory($staticDataTypeId: ID, $auditId: ID, $additionalParam: JSON) {
        StaticDataAuditHistory(
          staticDataTypeId: $staticDataTypeId
          auditId: $auditId
          additionalParam: $additionalParam
        ) {
          columns {
            field
            title
            type
          }
          rows
        }
      }
`;

const staticDataAuditHistoryQueryVariables = ({ staticDataTypeId, auditId, additionalParam }) => ({
  auditId,
  staticDataTypeId,
  additionalParam,
});

export default {
  '/reference-data/static-data/audit-history/csv': {
    get: {
      name: 'staticDataAuditHistory',
      summary: 'Export static data audit history csv',
      description: 'Returns all static data audit histories in csv file',
      filename: 'Static_Data_Audit_History_{args.datasetName}',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data Audit History' }],
      parameters: [
        {
          name: 'staticDataTypeId',
          in: 'query',
          description: 'Search by type id',
          required: false,
          type: 'string',
        },
        {
          name: 'auditId',
          in: 'query',
          description: 'Search by audit id',
          required: false,
          type: 'string',
        },
        {
          name: 'additionalParam',
          in: 'query',
          description: 'additional parameters to query audit history',
          required: false,
          type: 'object',
        },
      ],
      dataSource: {
        query: staticDataAuditHistoryQuery,
        queryVariables: staticDataAuditHistoryQueryVariables,
        returnDataName: 'StaticDataAuditHistory',
      },
      exportInfo: {
        customProcessor: staticDataAuditHistoryProcessor,
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data audit history',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

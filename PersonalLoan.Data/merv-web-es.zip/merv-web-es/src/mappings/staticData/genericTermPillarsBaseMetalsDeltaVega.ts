import { APIMappingEntities } from '../../models/api.model';

const staticDataGenericTermPillarsBaseMetalsDeltaVegaQuery = () => `
{
  StaticDataGenericTermPillarsBaseMetalsDeltaVegas {
    modified
    term
    termUnit
    net1m
    net2m
    net3m
    net4m
    net5m
    net6m
    net9m
    net1y
    net1y3m
    net1y6m
    net1y9m
    net2y
    net2y3m
    net3y3m
    net4y3m
    net5y3m
    net6y3m
    net7y3m
    net8y3m
    net9y3m
    net10y3m
    net1m_1y3m
    net1y3mPlus
    net1y4m_2y3m
    net2y3mPlus
  }
}
`;

export default {
  '/reference-data/static-data/generic-term-pillars-base-metals-delta-vega/csv': {
    get: {
      name: 'staticDataGenericTermPillarsBaseMetalsDeltaVega',
      summary: 'Export static data Generic Term Pillars Base Metals Delta Vega csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_generic_term_pillars_base_metals_delta_vega',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGenericTermPillarsBaseMetalsDeltaVegaQuery,
        returnDataName: 'StaticDataGenericTermPillarsBaseMetalsDeltaVegas',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net1m',
            name: 'Net1m',
            typeOf: 'number',
          },
          {
            field: 'net2m',
            name: 'Net2m',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: 'Net3m',
            typeOf: 'number',
          },
          {
            field: 'net4m',
            name: 'Net4m',
            typeOf: 'number',
          },
          {
            field: 'net5m',
            name: 'Net5m',
            typeOf: 'number',
          },
          {
            field: 'net6m',
            name: 'Net6m',
            typeOf: 'number',
          },
          {
            field: 'net9m',
            name: 'Net9m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: 'Net1y',
            typeOf: 'number',
          },
          {
            field: 'net1y3m',
            name: 'Net1y3m',
            typeOf: 'number',
          },
          {
            field: 'net1y6m',
            name: 'Net1y6m',
            typeOf: 'number',
          },
          {
            field: 'net1y9m',
            name: 'Net1y9m',
            typeOf: 'number',
          },
          {
            field: 'net2y',
            name: 'Net2y',
            typeOf: 'number',
          },
          {
            field: 'net2y3m',
            name: 'Net2y3m',
            typeOf: 'number',
          },
          {
            field: 'net3y3m',
            name: 'Net3y3m',
            typeOf: 'number',
          },
          {
            field: 'net4y3m',
            name: 'Net4y3m',
            typeOf: 'number',
          },
          {
            field: 'net5y3m',
            name: 'Net5y3m',
            typeOf: 'number',
          },
          {
            field: 'net6y3m',
            name: 'Net6y3m',
            typeOf: 'number',
          },
          {
            field: 'net7y3m',
            name: 'Net7y3m',
            typeOf: 'number',
          },
          {
            field: 'net8y3m',
            name: 'Net8y3m',
            typeOf: 'number',
          },
          {
            field: 'net9y3m',
            name: 'Net9y3m',
            typeOf: 'number',
          },
          {
            field: 'net10y3m',
            name: 'Net10y3m',
            typeOf: 'number',
          },
          {
            field: 'net1m_1y3m',
            name: 'Net1m_1y3m',
            typeOf: 'number',
          },
          {
            field: 'net1y3mPlus',
            name: 'Net1y3mPlus',
            typeOf: 'number',
          },
          {
            field: 'net1y4m_2y3m',
            name: 'Net1y4m_2y3m',
            typeOf: 'number',
          },
          {
            field: 'net2y3mPlus',
            name: 'Net2y3mPlus',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Generic Term Pillars Base Metals Delta Vega',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

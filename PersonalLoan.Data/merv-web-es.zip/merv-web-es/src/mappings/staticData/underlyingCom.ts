import { APIMappingEntities } from '../../models/api.model';

const staticDataUnderlyingComQuery = () => `
{
  StaticDataUnderlyingCOMs {
    id
    modified
    comment
    priceQuotationTypeSystem {
      id
      text
    }
    productSubGroupTypeSystem {
      id
      text
    }
    unitTypeSystem {
      id
      text
    }
    isTenorBucketed
    underlyingCode
    ANZStressLabelTypeSystem {
      id
      text
    }
    APRAStressLabelTypeSystem {
      id
      text
    }
    agriculturalExpiryMonths {
      id
      text
    }
    indexNameTypeSystem {
      id
      text
    }
    productGroupTypeSystem {
      id
      text
    }
    deltaGammaLotConversionTypeSystem {
      id
      text
    }
    description
    isActive
    added {
      by
      time
    }
  }
}
`;

interface Props {
  id: string;
  text: string;
}

const agriculturalExpiryMonthsDisplayRenderer = (prop: Props[]) =>
  prop.map((item) => item.text).join(',');

export default {
  '/reference-data/static-data/underlying-com/csv': {
    get: {
      name: 'staticDataUnderlyingCom',
      summary: 'Export static data Underlying Com csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_underlying_com',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataUnderlyingComQuery,
        returnDataName: 'StaticDataUnderlyingCOMs',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'underlyingCode',
            name: 'Underlying - COM',
            typeOf: 'string',
            sorting: 'true',
          },
          {
            field: 'description',
            name: 'COM Long Name',
            typeOf: 'string',
          },
          {
            field: 'productGroupTypeSystem.text',
            name: 'Grp: COM Type',
            typeOf: 'string',
          },
          {
            field: 'productSubGroupTypeSystem.text',
            name: 'Grp: COM Sub-Type',
            typeOf: 'string',
          },
          {
            field: 'APRAStressLabelTypeSystem.text',
            name: 'Grp: COM APRA Stress Label',
            typeOf: 'string',
          },
          {
            field: 'ANZStressLabelTypeSystem.text',
            name: 'Grp: COM ANZ Stress Group',
            typeOf: 'string',
          },
          {
            field: 'indexNameTypeSystem.text',
            name: 'Grp: COM Index Name',
            typeOf: 'string',
          },
          {
            field: 'unitTypeSystem.text',
            name: 'Grp: COM Unit',
            typeOf: 'string',
          },
          {
            field: 'deltaGammaLotConversionTypeSystem.text',
            name: 'Grp: COM Delta Gamma - Lot Conversion Factor',
            typeOf: 'string',
          },
          {
            field: 'priceQuotationTypeSystem.text',
            name: 'Grp: COM Price Quotation',
            typeOf: 'string',
          },
          {
            field: 'agriculturalExpiryMonths',
            name: 'Agricultural Expiry Month',
            typeOf: 'array',
            displayRenderer: agriculturalExpiryMonthsDisplayRenderer,
          },
          {
            field: 'isTenorBucketed',
            name: 'Is Tenor Bucketed',
            typeOf: 'boolean',
          },
          {
            field: 'comment',
            name: 'Comment',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
        responses: {
          '200': {
            description: 'An array of strings',
            schema: {
              title: 'Static Data Underlying Com',
              type: 'array',
              items: {
                type: 'string',
              },
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

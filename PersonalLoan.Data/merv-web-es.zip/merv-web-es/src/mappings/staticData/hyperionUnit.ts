import { APIMappingEntities } from '../../models/api.model';

const staticDataHyperionUnitQuery = () => `
  {
    StaticDataHyperionUnits {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/hyperion-unit/csv': {
    get: {
      name: 'staticDataHyperionUnit',
      summary: 'Export static data hyperion unit csv',
      description: 'Returns all static data hyperion units in csv file',
      filename: 'Static_Data_Hyperion_Unit',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataHyperionUnitQuery,
        returnDataName: 'StaticDataHyperionUnits',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'HyperionUnit',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Description',
            typeOf: 'string',
            field: 'description',
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Hyperion Unit',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

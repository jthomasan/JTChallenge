import { APIMappingEntities } from '../../models/api.model';

const staticDataProductHierarchyQuery = () => `
{
  StaticDataProductHierarchies {
    id
    modified
    description
    name
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/product-hierarchy/csv': {
    get: {
      name: 'staticDataProductHierarchy',
      summary: 'Export static data Product Hierarchy csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_product_hierarchy',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataProductHierarchyQuery,
        returnDataName: 'StaticDataProductHierarchies',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'name',
        fields: [
          {
            field: 'name',
            name: 'Name',
            typeOf: 'string',
          },
          {
            field: 'description',
            name: 'Description',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Product Hierarchy',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataPillarsSingleCcyBasisQuery = () => `
{
  StaticDataPillarsSingleCCYBasisList {
    modified
    term
    net1m
    net3m
    net6m
    net1y
    net2y
    net3y
    net4y
    net5y
    net7y
    net10y
    net15y
    net20y
    net25y
    net30y
  }
}
`;

export default {
  '/reference-data/static-data/pillars-single-ccy-basis/csv': {
    get: {
      name: 'staticDataPillarsSingleCcyBasis',
      summary: 'Export static data Pillars Single Ccy Basis csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_pillars_single_ccy_basis',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataPillarsSingleCcyBasisQuery,
        returnDataName: 'StaticDataPillarsSingleCCYBasisList',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'term',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'number',
          },
          {
            field: 'net1m',
            name: '1m',
            typeOf: 'number',
          },
          {
            field: 'net3m',
            name: '3m',
            typeOf: 'number',
          },
          {
            field: 'net6m',
            name: '6m',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: '1y',
            typeOf: 'number',
          },
          {
            field: 'net2y',
            name: '2y',
            typeOf: 'number',
          },
          {
            field: 'net3y',
            name: '3y',
            typeOf: 'number',
          },
          {
            field: 'net4y',
            name: '4y',
            typeOf: 'number',
          },
          {
            field: 'net5y',
            name: '5y',
            typeOf: 'number',
          },
          {
            field: 'net7y',
            name: '7y',
            typeOf: 'number',
          },
          {
            field: 'net10y',
            name: '10y',
            typeOf: 'number',
          },
          {
            field: 'net15y',
            name: '15y',
            typeOf: 'number',
          },
          {
            field: 'net20y',
            name: '20y',
            typeOf: 'number',
          },
          {
            field: 'net25y',
            name: '25y',
            typeOf: 'number',
          },
          {
            field: 'net30y',
            name: '30y',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Pillars Single Ccy Basis',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataMarketRiskBusinessQuery = () => `
{
  MarketRiskBusinessMappings {
    code
    marketRiskBusinessDescription
    marketRiskBusinessGroup {
      id
      text
    }
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/market-risk-business/csv': {
    get: {
      name: 'staticDataMarketRiskBusiness',
      summary: 'Export static data Market Risk Business csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_market_risk_business',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataMarketRiskBusinessQuery,
        returnDataName: 'MarketRiskBusinessMappings',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'code',
        fields: [
          {
            field: 'code',
            name: 'Code',
            typeOf: 'string',
          },
          {
            field: 'marketRiskBusinessDescription',
            name: 'MarketRiskBusinessDescription',
            typeOf: 'string',
          },
          {
            field: 'marketRiskBusinessGroup.text',
            name: 'Grouping',
            typeOf: 'string',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Market Risk Business',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

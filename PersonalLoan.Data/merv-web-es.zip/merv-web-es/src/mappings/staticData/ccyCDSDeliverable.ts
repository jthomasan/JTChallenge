import { APIMappingEntities } from '../../models/api.model';

const staticDataCCYCDSDeliverableQuery = () => `
  {
    StaticDataCCYCDSDeliverables {
      id
      modified
      description
      value
      isActive
      added {
        by
        time
      }
    }
  }
`;

export default {
  '/reference-data/static-data/ccy-cds-deliverable/csv': {
    get: {
      name: 'staticDataCCYCDSDeliverable',
      summary: 'Export static data CCY CDS Deliverable csv',
      description: 'Returns all static data CCY CDS Deliverables in csv file',
      filename: 'Static_Data_CCY_CDS_Deliverable',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCCYCDSDeliverableQuery,
        returnDataName: 'StaticDataCCYCDSDeliverables',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Value',
            typeOf: 'string',
            field: 'value',
            sorting: true,
          },
          {
            name: 'Is Active',
            typeOf: 'boolean',
            field: 'isActive',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data CCY CDS Deliverable',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

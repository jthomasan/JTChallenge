import { APIMappingEntities } from '../../models/api.model';

const staticDataCreditStressSpread_10BondDefaultStressQuery = () => `
{
  StaticDataCreditStressSpreadTenBondDefaultStresses {
    modified
    anzRatingTypeSystem {
      id
      text
    }
    stressFactor
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/credit-stress-spread-10-bond-default-stress/csv': {
    get: {
      name: 'staticDataCreditStressSpread_10BondDefaultStress',
      summary: 'Export static data Credit Stress Spread 10 Bond Default Stress csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_credit_stress_spread_10_bond_default_stress',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataCreditStressSpread_10BondDefaultStressQuery,
        returnDataName: 'StaticDataCreditStressSpreadTenBondDefaultStresses',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'anzRatingTypeSystem.text',
        fields: [
          {
            field: 'anzRatingTypeSystem.text',
            name: 'Rating',
            typeOf: 'string',
          },
          {
            field: 'stressFactor',
            name: 'Stress Factor',
            typeOf: 'number',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Credit Stress Spread 10 Bond Default Stress',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataLongTermCreditRatingQuery = () => `
  {
    StaticDataLongTermCreditRatings {
      id
      modified
      rating
      agency
      ratingBandSecTypeSystem {
        id
        text
      }
      ranking
      anzRatingTypeSystem {
        id
        text
      }
      isIssue
      ratingBandOtherTypeSystem {
        id
        text
      }
      ratingBandTypeSystem {
        id
        text
      }
      investmentGradeTypeSystem {
        id
        text
      }
      isIssuer
      added {
        by
        time
      }
      comment
    }
  }
`;

export default {
  '/reference-data/static-data/long-term-credit-rating/csv': {
    get: {
      name: 'staticDataLongTermCreditRating',
      summary: 'Export static data long term credit rating csv',
      description: 'Returns all static data long term credit ratings in csv file',
      filename: 'Static_Data_Long_Term_Credit_Rating',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataLongTermCreditRatingQuery,
        returnDataName: 'StaticDataLongTermCreditRatings',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            name: 'Grp: CR Rating',
            typeOf: 'string',
            field: 'rating',
            sorting: true,
          },
          {
            name: 'Grp: CR Agency',
            typeOf: 'string',
            field: 'agency',
          },
          {
            name: 'Is Issuer',
            typeOf: 'boolean',
            field: 'isIssuer',
          },
          {
            name: 'Is Issue',
            typeOf: 'boolean',
            field: 'isIssue',
          },
          {
            name: 'Ranking',
            typeOf: 'numeric',
            field: 'ranking',
          },
          {
            name: 'Grp: CR Rating - Generic',
            typeOf: 'string',
            field: 'anzRatingTypeSystem.text',
          },
          {
            name: 'Grp: CR Investment Grade',
            typeOf: 'string',
            field: 'investmentGradeTypeSystem.text',
          },
          {
            name: 'Grp: CR Rating Band - LT',
            typeOf: 'string',
            field: 'ratingBandTypeSystem.text',
          },
          {
            name: 'Grp: CR Rating Band - Other',
            typeOf: 'string',
            field: 'ratingBandOtherTypeSystem.text',
          },
          {
            name: 'Grp: CR Rating Band - Sec',
            typeOf: 'string',
            field: 'ratingBandSecTypeSystem.text',
          },
          {
            name: 'Comment',
            typeOf: 'string',
            field: 'comment',
          },
          {
            name: 'Added By',
            typeOf: 'string',
            field: 'added.by',
          },
          {
            name: 'Added Time',
            typeOf: 'dateTime',
            field: 'added.time',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Long Term Credit Rating',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

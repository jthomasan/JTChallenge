import { APIMappingEntities } from '../../models/api.model';

const staticDataGenericTermPilarsPetroleumVegaQuery = () => `
{
  StaticDataGenericTermPilarsPetroleumVegas {
    modified
    term
    termUnit
    net1m_2m
    net3m_5m
    net6m_11m
    net1y_2y
    net2yPlus
  }
}
`;

export default {
  '/reference-data/static-data/generic-term-pilars-petroleum-vega/csv': {
    get: {
      name: 'staticDataGenericTermPilarsPetroleumVega',
      summary: 'Export static data Generic Term Pilars Petroleum Vega csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_generic_term_pilars_petroleum_vega',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGenericTermPilarsPetroleumVegaQuery,
        returnDataName: 'StaticDataGenericTermPilarsPetroleumVegas',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'termUnit',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'string',
          },
          {
            field: 'net1m_2m',
            name: 'Net1m_2m',
            typeOf: 'number',
          },
          {
            field: 'net3m_5m',
            name: 'Net3m_5m',
            typeOf: 'number',
          },
          {
            field: 'net6m_11m',
            name: 'Net6m_11m',
            typeOf: 'number',
          },
          {
            field: 'net1y_2y',
            name: 'Net1y_2y',
            typeOf: 'number',
          },
          {
            field: 'net2yPlus',
            name: 'Net2yPlus',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Generic Term Pilars Petroleum Vega',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

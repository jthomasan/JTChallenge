import { APIMappingEntities } from '../../models/api.model';

const staticDataGrpNationalMarketQuery = () => `
{
  StaticDataGrpNationalMarkets {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/grp-national-market/csv': {
    get: {
      name: 'staticDataGrpNationalMarket',
      summary: 'Export static data Grp National Market csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_grp_national_market',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGrpNationalMarketQuery,
        returnDataName: 'StaticDataGrpNationalMarkets',
      },
      exportInfo: {
        customProcessor: null,
        fields: [
          {
            field: 'value',
            name: 'Value',
            typeOf: 'string',
            sorting: 'true',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Grp National Market',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const staticDataPillarsVegaEtoBondsQuery = () => `
{
  StaticDataPillarsVegaETOBonds {
    modified
    term
    net1y
    net2y
    net3y
    net4y
    net5y
    net6y
    net7y
    net8y
    net9y
    net10y
    net15y
    net20y
    net25y
    net30y
  }
}
`;

export default {
  '/reference-data/static-data/pillars-vega-eto-bonds/csv': {
    get: {
      name: 'staticDataPillarsVegaEtoBonds',
      summary: 'Export static data Pillars Vega Eto Bonds csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_pillars_vega_eto_bonds',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataPillarsVegaEtoBondsQuery,
        returnDataName: 'StaticDataPillarsVegaETOBonds',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'term',
        fields: [
          {
            field: 'term',
            name: 'Days to Maturity',
            typeOf: 'number',
          },
          {
            field: 'net1y',
            name: '1y',
            typeOf: 'string',
          },
          {
            field: 'net2y',
            name: '2y',
            typeOf: 'string',
          },
          {
            field: 'net3y',
            name: '3y',
            typeOf: 'string',
          },
          {
            field: 'net4y',
            name: '4y',
            typeOf: 'string',
          },
          {
            field: 'net5y',
            name: '5y',
            typeOf: 'string',
          },
          {
            field: 'net6y',
            name: '6y',
            typeOf: 'string',
          },
          {
            field: 'net7y',
            name: '7y',
            typeOf: 'string',
          },
          {
            field: 'net8y',
            name: '8y',
            typeOf: 'string',
          },
          {
            field: 'net9y',
            name: '9y',
            typeOf: 'string',
          },
          {
            field: 'net10y',
            name: '10y',
            typeOf: 'string',
          },
          {
            field: 'net15y',
            name: '15y',
            typeOf: 'string',
          },
          {
            field: 'net20y',
            name: '20y',
            typeOf: 'string',
          },
          {
            field: 'net25y',
            name: '25y',
            typeOf: 'string',
          },
          {
            field: 'net30y',
            name: '30y',
            typeOf: 'string',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Pillars Vega Eto Bonds',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

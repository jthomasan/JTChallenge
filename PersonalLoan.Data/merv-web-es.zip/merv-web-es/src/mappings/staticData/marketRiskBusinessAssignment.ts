import { APIMappingEntities } from '../../models/api.model';

const staticDataMarketRiskBusinessAssignmentQuery = () => `
{
  MarketRiskBusinessAssignmentMappings {
    modified
    marketRiskBusiness{
      id
      text
    }
    user{
      id
      text
    }
    receiveNotifications
    isActive
    added{
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/market-risk-business-assignment/csv': {
    get: {
      name: 'staticDataMarketRiskBusinessAssignment',
      summary: 'Export static data Market Risk Business Assignment csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_market_risk_business_assignment',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataMarketRiskBusinessAssignmentQuery,
        returnDataName: 'MarketRiskBusinessAssignmentMappings',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'user.text',
        fields: [
          {
            field: 'marketRiskBusiness.text',
            name: 'Market Risk Business',
            typeOf: 'string',
          },
          {
            field: 'user.text',
            name: 'User',
            typeOf: 'string',
          },
          {
            field: 'receiveNotifications',
            name: 'Receive Notifications',
            typeOf: 'boolean',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Market Risk Business Assignment',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

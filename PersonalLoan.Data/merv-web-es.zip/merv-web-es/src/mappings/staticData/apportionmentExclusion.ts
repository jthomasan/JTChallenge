import { APIMappingEntities } from '../../models/api.model';

const staticDataApportionmentExclusionQuery = () => `
{
  StaticDataApportionmentExclusions {
    modified
    apportionmentExclusion
    node {
      id
      value
    }
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/apportionment-exclusion/csv': {
    get: {
      name: 'staticDataApportionmentExclusion',
      summary: 'Export static data Apportionment Exclusion csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_apportionment_exclusion',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataApportionmentExclusionQuery,
        returnDataName: 'StaticDataApportionmentExclusions',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'node.value',
        fields: [
          {
            field: 'node.value',
            name: 'Risk Portfolio Hierarchy',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Apportionment Exclusion',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

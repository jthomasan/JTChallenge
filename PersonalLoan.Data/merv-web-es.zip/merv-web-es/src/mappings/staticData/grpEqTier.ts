import { APIMappingEntities } from '../../models/api.model';

const staticDataGrpEqTierQuery = () => `
{
  StaticDataGrpEQTiers {
    id
    modified
    description
    value
    isActive
    added {
      by
      time
    }
  }
}
`;

export default {
  '/reference-data/static-data/grp-eq-tier/csv': {
    get: {
      name: 'staticDataGrpEqTier',
      summary: 'Export static data Grp Eq Tier csv',
      description: 'Returns all data in csv file',
      filename: 'static_data_grp_eq_tier',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Static Data' }],
      parameters: [],
      dataSource: {
        query: staticDataGrpEqTierQuery,
        returnDataName: 'StaticDataGrpEQTiers',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'value',
        fields: [
          {
            field: 'value',
            name: 'Value',
            typeOf: 'string',
          },
          {
            field: 'isActive',
            name: 'Is Active',
            typeOf: 'boolean',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Static Data Grp Eq Tier',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

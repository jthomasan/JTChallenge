import { APIMappingEntities } from '../../models/api.model';

const query = () => `query getFeedMonitorStatusLog($logIds: [ID]) {
    FMRefDataStatusLog(logIds: $logIds) {
      id
      reportName
      portfolio
      message
    }
  }`;

const refParams = ({ logIds }) => ({
  logIds,
});

const columns = [
  {
    field: 'id',
    name: 'Feed ID',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'reportName',
    name: 'Report Name',
    typeOf: 'string',
  },
  {
    field: 'portfolio',
    name: 'Portfolio',
    typeOf: 'string',
  },
  {
    field: 'message',
    name: 'Message',
    typeOf: 'string',
  },
];

export default {
  '/feed-monitor/status/reference-data-log/csv': {
    get: {
      name: 'feedMonitorStatusReferenceDataLog',
      summary: 'Export Feed Monitor Status Reference Data Log',
      description: 'Returns all data in csv file',
      filename: 'feed_monitor_status_refdata_log',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed monitor Status Log' }],
      parameters: [
        {
          name: 'logIds',
          in: 'query',
          description: 'Search by logIds',
          required: true,
          type: 'array',
        },
      ],
      dataSource: {
        query,
        returnDataName: 'FMRefDataStatusLog',
        queryVariables: refParams,
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'feedId',
        fields: columns,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Feed Monitor Status Reference Data Log',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

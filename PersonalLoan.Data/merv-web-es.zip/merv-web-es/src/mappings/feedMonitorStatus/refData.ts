import { APIMappingEntities } from '../../models/api.model';

const query = () => `
query NonUvrFeedStatusesQuery($date: String!, $snapshot: String, $sourceSystemIds: [ID]) {
  data: NonUvrFeedStatuses(date: $date, snapshot: $snapshot, sourceSystemIds: $sourceSystemIds) {
    id
    feedId
    feedType
    businessDate
    reportName
    cubeInstance {
      id
    }
    isFmFeed
    snapshot
    sourceSystem {
      id
      version
    }
    sourceSystemEnvironment
    status {
      cubeLoad
      cubeTradeEtl
      download
      riskEngine
    }
    lastUpdated {
      time
    }
  }
}
`;

const refParams = ({ date, snapshot, sourceSystemIds }) => ({
  date,
  snapshot,
  sourceSystemIds,
});

const columns = [
  {
    field: 'feedId',
    name: 'Feed ID',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'feedType',
    name: 'Feed Type',
    typeOf: 'string',
  },
  {
    field: 'reportName',
    name: 'Report Name',
    typeOf: 'string',
  },
  {
    field: 'snapshot',
    name: 'Snapshot',
    typeOf: 'string',
  },
  {
    field: 'sourceSystemEnvironment',
    name: 'Source Environment',
    typeOf: 'string',
  },
  {
    field: 'sourceSystem.version',
    name: 'Platform',
    typeOf: 'string',
  },
  {
    field: 'cubeInstance.id',
    name: 'Cube ID',
    typeOf: 'string',
  },
  {
    field: 'status.riskEngine',
    name: 'Source System',
    typeOf: 'string',
  },
  {
    field: 'status.download',
    name: 'Download',
    typeOf: 'string',
  },
  {
    field: 'status.cubeLoad',
    name: 'MaRRS Load',
    typeOf: 'string',
  },
  {
    field: 'lastUpdated.time',
    name: 'Updated Time',
    typeOf: 'dateTime',
  },
];

export default {
  '/feed-monitor/status/reference-data/csv': {
    get: {
      name: 'feedMonitorStatusReferenceData',
      summary: 'Export Feed Monitor Status Reference Data',
      description: 'Returns all data in csv file',
      filename: 'feed_monitor_status_refdata_{args.cobDate}',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed monitor Status' }],
      parameters: [
        {
          name: 'date',
          in: 'query',
          description: 'Search by date',
          required: true,
          type: 'string',
        },
        {
          name: 'snapshot',
          in: 'query',
          description: 'Search by snapshot',
          required: false,
          type: 'string',
        },
        {
          name: 'sourceSystemIds',
          in: 'query',
          description: 'Search by sourceSystemIds',
          required: false,
          type: 'array',
        },
      ],
      dataSource: {
        query,
        returnDataName: 'data',
        queryVariables: refParams,
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'feedId',
        fields: columns,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Feed Monitor Status Reference Data',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

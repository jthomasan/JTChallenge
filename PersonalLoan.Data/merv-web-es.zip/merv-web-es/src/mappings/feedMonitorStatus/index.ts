import { APIMappingEntities } from '../../models/api.model';
import refData from './refData';
import refDataLog from './refDataLog';
import job from './job';

export default {
  ...refData,
  ...refDataLog,
  ...job,
} as APIMappingEntities;

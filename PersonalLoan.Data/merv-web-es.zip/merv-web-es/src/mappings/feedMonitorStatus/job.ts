import * as moment from 'moment';
import { APIMappingEntities, Field } from '../../models/api.model';

const fmQuery = () => `
query FMRefDataStatusJobsQuery($date: String!) {
  FMRefDataStatusJobs(date: $date) {
    id
    businessDate
    job {
      id
      type {
        id
        name
      }
    }
    runDate
    status {
      id
      name
    }
    log
    time {
      start
      complete
    }
    added {
      by
      time
    }
    lastUpdated {
      by
      time
    }
  }
}
`;

const refParams = ({ date }) => ({
  date,
});

const columns: Field[] = [
  {
    field: 'job.id',
    name: 'Job ID',
    typeOf: 'string',
  },
  {
    field: 'job.type.name',
    name: 'Job Type',
    typeOf: 'string',
  },
  {
    field: 'runDate',
    name: 'Run Date',
    typeOf: 'date',
  },
  {
    field: 'status.name',
    name: 'Status',
    typeOf: 'string',
  },
  {
    field: 'log',
    name: 'Log',
    typeOf: 'string',
  },
  {
    field: 'time.start',
    name: 'Start Time',
    typeOf: 'dateTime',
  },
  {
    field: 'time.complete',
    name: 'Complete Time',
    typeOf: 'dateTime',
  },
  {
    field: 'added.by',
    name: 'Added By',
    typeOf: 'string',
  },
  {
    field: 'added.time',
    name: 'Added Time',
    typeOf: 'dateTime',
  },
  {
    field: 'lastUpdated.by',
    name: 'Updated By',
    typeOf: 'string',
  },
  {
    field: 'lastUpdated.time',
    name: 'Updated Time',
    typeOf: 'dateTime',
  },
];

export default {
  '/feed-monitor/status/job/csv': {
    get: {
      name: 'feedMonitorStatusJob',
      summary: 'Export Feed Monitor Status Job',
      description: 'Returns all data in csv file',
      filename: ({ query }) => {
        const parsedDate = (query.date as string) ?? '';
        const cobDate = moment(parsedDate).format('YYYYMMDD');

        return `feed_monitor_status_job_${cobDate}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed monitor Status' }],
      parameters: [
        {
          name: 'date',
          in: 'query',
          description: 'Search by date',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: fmQuery,
        returnDataName: 'FMRefDataStatusJobs',
        queryVariables: refParams,
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'job.id',
        fields: columns,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Feed Monitor Status Job',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';
import pricingErrorDownload from './pricingErrorDownload';
import feedLogMessage from './feedLogMessage';

export default {
  ...pricingErrorDownload,
  ...feedLogMessage,
} as APIMappingEntities;

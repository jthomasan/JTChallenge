import apiMappings from '.';

describe('apiMappings', () => {
  it('all mappings have the suffix /csv', () => {
    /* 
      All mappings must currently end in /csv
      this is used to build the /fields endpoint (used by bulk update)
    */
    const paths = Object.keys(apiMappings);
    paths.forEach((endpointPath) => {
      expect(endpointPath.slice(endpointPath.length - 4)).toBe('/csv');
    });

    expect.hasAssertions();
  });
});

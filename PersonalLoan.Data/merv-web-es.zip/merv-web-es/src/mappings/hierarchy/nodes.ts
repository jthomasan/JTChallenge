import { APIMappingEntities } from '../../models/api.model';
import { NodeParam } from '../../models/hierarchyModel';
import { getArgs } from '../index';
import nodesProcessor from '../../processors/hierarchy/nodesProcessor';

const nodesQuery = (params: NodeParam) => `
query {
  Nodes(${getArgs(params)}) {
    id
    title
    children
    parent
    fullPath
  }
}
`;

export default {
  '/reference-data/hierarchy/nodes/csv': {
    get: {
      name: 'nodes',
      summary: 'Export nodes csv',
      description: 'Returns all nodes in csv file',
      filename: 'Hierarchy_Nodes',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Reference Data - (Hierarchy)' }],
      parameters: [
        {
          name: 'id',
          in: 'query',
          description: 'Search by node id',
          required: false,
          type: 'string',
        },
        {
          name: 'typeId',
          in: 'query',
          description: 'Search by hierarchy type id',
          required: false,
          type: 'string',
        },
        {
          name: 'cob',
          in: 'query',
          description: 'Search by close of business date',
          required: false,
          type: 'string',
          default: '',
        },
      ],
      dataSource: {
        query: nodesQuery,
        returnDataName: 'Nodes',
      },
      exportInfo: {
        customProcessor: nodesProcessor,
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Nodes',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';
import { getArgs } from '..';
import { PortfolioParam } from '../../models/hierarchyModel';
import portfoliosProcessor from '../../processors/hierarchy/portfoliosProcessor';

export const portfoliosQuery = (params: PortfolioParam) => `
query {
  Portfolios(${getArgs(params)}) {
    id
    title
    isActive
    parent {
      nodeId
    }
    createdOn
    source
  }
  Nodes(id: ${params.nodeId || ''}, typeId: ${params.typeId}) {
    id
    title
    children
    parent
    fullPath
  }
}
`;

export default {
  '/reference-data/hierarchy/portfolios/csv': {
    get: {
      name: 'portfolios',
      summary: 'Export portfolios csv',
      description: 'Returns all portfolios in csv file',
      filename: 'Hierarchy_Portfolios',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Reference Data - (Hierarchy)' }],
      parameters: [
        {
          name: 'nodeId',
          in: 'query',
          description: 'Search by node id',
          required: false,
          type: 'string',
        },
        {
          name: 'typeId',
          in: 'query',
          description: 'Search by portfolio type id',
          required: false,
          type: 'string',
        },
        {
          name: 'titleSearch',
          in: 'query',
          description: 'Search by title',
          required: false,
          type: 'string',
          default: '',
        },
        {
          name: 'cob',
          in: 'query',
          description: 'Search by close of business date',
          required: false,
          type: 'string',
          default: '',
        },
      ],
      dataSource: {
        query: portfoliosQuery,
        returnDataName: 'Portfolios',
      },
      exportInfo: {
        customProcessor: portfoliosProcessor,
        fields: [],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Portfolios',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

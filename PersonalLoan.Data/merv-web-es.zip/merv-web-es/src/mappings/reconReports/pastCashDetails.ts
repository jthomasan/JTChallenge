import { APIMappingEntities } from '../../models/api.model';

const pastCashDetailsQuery = () => `
  query PastCashReconDetailsQuery($dates: [Date]!, $statuses: [String]) {
    PastCashReconDetails(dates: $dates, statuses: $statuses) {
      id
      status
      cobDate
      userComment
      portfolio
      currency

      added {
        by
      }
      updated {
        time
      }

      trn {
        family
        group
        type
      }

      pastCash {
        murex
        sky
      }

      difference {
        actual
        percentage
      }
    }
  }
`;

export default {
  '/feed-monitor/recon-reports/past-cash-reconciliation/csv': {
    get: {
      name: 'pastCashReconciliation',
      summary: 'Export past cash reconciliation csv',
      description: 'Returns all past cash reconciliation in csv file',
      filename: 'feed_monitor_past_cash_reconciliation',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Past cash reconciliation' }],
      parameters: [
        {
          name: 'dates',
          in: 'query',
          description: 'Filter by cob dates',
          required: true,
          type: 'string',
        },
        {
          name: 'statuses',
          in: 'query',
          description: 'Filter by status',
          required: false,
          type: 'string',
        },
      ],
      dataSource: {
        query: pastCashDetailsQuery,
        queryVariables: (params) => params,
        returnDataName: 'PastCashReconDetails',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'cobDate',
        fields: [
          {
            field: 'userComment',
            name: 'User Comment',
            typeOf: 'string',
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string',
          },
          {
            field: 'updated.time',
            name: 'Updated Time',
            typeOf: 'dateTime',
          },
          {
            field: 'cobDate',
            name: 'COB Date',
            typeOf: 'date',
          },
          {
            field: 'status',
            name: 'Recon Status',
            typeOf: 'string',
          },
          {
            field: 'portfolio',
            name: 'TP_PFOLIO',
            typeOf: 'string',
          },
          {
            field: 'trn.family',
            name: 'TRN_FMLY',
            typeOf: 'string',
          },
          {
            field: 'trn.group',
            name: 'TRN_GRP',
            typeOf: 'string',
          },
          {
            field: 'trn.type',
            name: 'TRN_TYPE',
            typeOf: 'string',
          },
          {
            field: 'currency',
            name: 'Currency',
            typeOf: 'string',
          },
          {
            field: 'pastCash.murex',
            name: 'MUREX Past Cash',
            typeOf: 'number',
          },
          {
            field: 'pastCash.sky',
            name: 'SKY Past Cash',
            typeOf: 'number',
          },
          {
            field: 'difference.actual',
            name: 'Difference Actual',
            typeOf: 'number',
          },
          {
            field: 'difference.percentage',
            name: 'Difference Percentage',
            typeOf: 'number',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Past Cash Reconciliation',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

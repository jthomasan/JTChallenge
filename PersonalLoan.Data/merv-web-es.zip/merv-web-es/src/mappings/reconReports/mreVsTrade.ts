import { APIMappingEntities } from '../../models/api.model';

const mreVsTradeDetailsQuery = () => `
query MurexRiskEngineReconDetailsQuery($dates: [Date]!, $statuses: [String]) {
  MurexRiskEngineReconDetails(dates: $dates, statuses: $statuses) {
    id
    modified
    cobDate
    status
    userComment
    murexVersion
    mre {
      nb
      instrument
      trn {
        family
        group
      }
      tp {
        portfolio
        timeSystem
        cntrp
        dateDTETRN
      }
      brw {
        nom1
        nom2
      }
      pl {
        insCurrency
        fmv2
        csnfcp2
        fpnfcp2
      }
    }
    trade {
      nb
      instrument
      trn {
        family
        group
      }
      tp {
        portfolio
        timeSystem
        cntrp
        dateDTETRN
      }
      brw {
        nom1
        nom2
      }
      pl {
        insCurrency
        fmv2
        csnfcp2
        fpnfcp2
      }
    }
    added {
      by
      time
    }
    updated {
      time
    }
  }
}
`;

export default {
  '/feed-monitor/recon-reports/murex-risk-engine-vs-trade-db/csv': {
    get: {
      name: 'murexRiskEngineVsTrade',
      summary: 'Export murex risk engine vs trade reconciliation csv',
      description: 'Returns all murex risk engine vs trade reconciliation in csv file',
      filename: 'feed_monitor_mre_vs_trade_reconciliation',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Murex risk engine vs trade reconciliation' }],
      parameters: [
        {
          name: 'dates',
          in: 'query',
          description: 'Filter by cob dates',
          required: true,
          type: 'string',
        },
        {
          name: 'statuses',
          in: 'query',
          description: 'Filter by status',
          required: false,
          type: 'string',
        },
      ],
      dataSource: {
        query: mreVsTradeDetailsQuery,
        queryVariables: (params) => params,
        returnDataName: 'MurexRiskEngineReconDetails',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'cobDate',
        fields: [
          {
            field: 'userComment',
            name: 'User Comment',
            typeOf: 'string'
          },
          {
            field: 'added.by',
            name: 'Added By',
            typeOf: 'string'
          },
          {
            field: 'updated.time',
            name: 'Updated Time',
            typeOf: 'dateTime'
          },
          {
            field: 'cobDate',
            name: 'COB Date',
            typeOf: 'date',
          },
          {
            field: 'status',
            name: 'Status',
            typeOf: 'string'
          },
          {
            field: 'mre.nb',
            name: 'MRE_NB',
            typeOf: 'string'
          },
          {
            field: 'trade.nb',
            name: 'TRADE_NB',
            typeOf: 'string'
          },
          {
            field: 'mre.tp.portfolio',
            name: 'MRE_TP_PFOLIO',
            typeOf: 'string'
          },
          {
            field: 'trade.tp.portfolio',
            name: 'TRADE_TP_PFOLIO',
            typeOf: 'string'
          },
          {
            field: 'mre.instrument',
            name: 'MRE_INSTRUMENT',
            typeOf: 'string'
          },
          {
            field: 'trade.instrument',
            name: 'TRADE_INSTRUMENT',
            typeOf: 'string'
          },
          {
            field: 'mre.pl.insCurrency',
            name: 'MRE_PL_INSCURR',
            typeOf: 'string'
          },
          {
            field: 'trade.pl.insCurrency',
            name: 'TRADE_PL_INSCURR',
            typeOf: 'string'
          },
          {
            field: 'mre.brw.nom1',
            name: 'MRE_BRW_NOM1',
            typeOf: 'string'
          },
          {
            field: 'trade.brw.nom1',
            name: 'TRADE_BRW_NOM1',
            typeOf: 'string'
          },
          {
            field: 'mre.brw.nom2',
            name: 'MRE_BRW_NOM2',
            typeOf: 'string'
          },
          {
            field: 'trade.brw.nom2',
            name: 'TRADE_BRW_NOM2',
            typeOf: 'string'
          },
          {
            field: 'mre.pl.csnfcp2',
            name: 'MRE_PL_CSNFP2',
            typeOf: 'string'
          },
          {
            field: 'trade.pl.csnfcp2',
            name: 'TRADE_PL_CSNFP2',
            typeOf: 'string'
          },
          {
            field: 'mre.pl.fmv2',
            name: 'MRE_PL_FMV2',
            typeOf: 'string'
          },
          {
            field: 'trade.pl.fmv2',
            name: 'TRADE_PL_FMV2',
            typeOf: 'string'
          },
          {
            field: 'mre.pl.fpnfcp2',
            name: 'MRE_PL_FPNFCP2',
            typeOf: 'string'
          },
          {
            field: 'trade.pl.fpnfcp2',
            name: 'TRADE_PL_FPNFCP2',
            typeOf: 'string'
          },
          {
            field: 'mre.trn.group',
            name: 'MRE_TRN_GRP',
            typeOf: 'string'
          },
          {
            field: 'trade.trn.group',
            name: 'TRADE_TRN_GRP',
            typeOf: 'string'
          },
          {
            field: 'murexVersion',
            name: 'Murex Version',
            typeOf: 'string'
          },
          {
            field: 'added.time',
            name: 'Added Time',
            typeOf: 'dateTime',
          },
          {
            field: 'mre.tp.timeSystem',
            name: 'MRE_TP_TIMSYS',
            typeOf: 'string'
          },
          {
            field: 'trade.tp.timeSystem',
            name: 'TRADE_TP_TIMSYS',
            typeOf: 'string'
          },
          {
            field: 'mre.tp.timeSystem',
            name: 'MRE_TP_TIMSYS',
            typeOf: 'string'
          },
          {
            field: 'trade.tp.timeSystem',
            name: 'TRADE_TP_TIMSYS',
            typeOf: 'string'
          },
          {
            field: 'mre.trn.family',
            name: 'MRE_TRN_FMLY',
            typeOf: 'string'
          },
          {
            field: 'trade.trn.family',
            name: 'TRADE_TRN_FMLY',
            typeOf: 'string'
          },
          {
            field: 'mre.tp.cntrp',
            name: 'MRE_TP_CNTRP',
            typeOf: 'string'
          },
          {
            field: 'trade.tp.cntrp',
            name: 'TRADE_TP_CNTRP',
            typeOf: 'string'
          },
          {
            field: 'mre.tp.dateDTETRN',
            name: 'MRE_TP_DTETRN',
            typeOf: 'string'
          },
          {
            field: 'trade.tp.dateDTETRN',
            name: 'TRADE_TP_DTETRN',
            typeOf: 'string'
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Murex Risk Engine Vs Trade Reconciliation',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

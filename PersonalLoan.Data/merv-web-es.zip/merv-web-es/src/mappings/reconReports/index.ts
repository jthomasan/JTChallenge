import { APIMappingEntities } from '../../models/api.model';
import pastCashDetails from './pastCashDetails';

export default {
  ...pastCashDetails,
  ...require('./dailyTradeDetails').default,
  ...require('./tradePricingErrorDetails').default,
  ...require('./mreVsTrade').default,
} as APIMappingEntities;

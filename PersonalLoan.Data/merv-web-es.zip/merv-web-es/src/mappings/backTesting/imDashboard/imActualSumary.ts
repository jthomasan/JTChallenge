import * as moment from 'moment';
import { APIMappingEntities } from '../../../models/api.model';

const summaryQuery = () => `
query IMDashboardActualSummaryQuery(
    $cobDate: String!
    $product: String!
  ) {
    IMDashboardActualSummary(cobDate: $cobDate, product: $product) {
      pnL
      averageInitialMarginExposure
      averageActualPnL
      daysActualPnLAboveInitialMargin
      isProxy
      cobDate
      version
      currency
      initialMargin
      pledgorCurrency
      creditSupportAnnex {
        id
        name
      }
      pledgorInitialMargin
      initialMarginTrades
      riskEngineTrades
      statusMessage
      product
    }
  }`;

const refParams = ({ cobDate, product }) => ({
  cobDate,
  product,
});

const roundDisplayRenderer = (prop: number) => Math.round(prop).toString();

const columns = [
  {
    field: 'creditSupportAnnex.id',
    name: 'ID',
    typeOf: 'number',
  },
  {
    field: 'creditSupportAnnex.name',
    name: 'Name',
    typeOf: 'string',
  },
  {
    field: 'product',
    name: 'Product',
    typeOf: 'string',
  },
  {
    field: 'initialMargin',
    name: 'Initial Margin (USD)',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },

  {
    field: 'pnL',
    name: 'PnL (USD)',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },
  {
    field: 'initialMarginTrades',
    name: 'Initial Margin Trades',
    typeOf: 'number',
  },
  {
    field: 'riskEngineTrades',
    name: 'Risk Engine Trades',
    typeOf: 'number',
  },
  {
    field: 'averageInitialMarginExposure',
    name: 'Average Initial Margin (USD)',
    typeOf: 'number',
  },
  {
    field: 'averageActualPnL',
    name: 'Average PnL (USD)',
    typeOf: 'number',
  },
  {
    field: 'daysActualPnLAboveInitialMargin',
    name: 'Days PnL Above IM',
    typeOf: 'number',
  },
  {
    field: 'statusMessage',
    name: 'Status Message',
    typeOf: 'string',
  },
  {
    field: 'isProxy',
    name: 'Is Proxy',
    typeOf: 'boolean',
  },
];

export default {
  '/im-backtesting/dashboard/actual/csv': {
    get: {
      name: 'imBackTestingDashboardActualSummaryCSV',
      summary: 'Export IM Backtesting Dashboard Actual Summary',
      description: 'Returns all data in csv file',
      filename: ({ query }) => {
        const parsedDate = (query.cobDate as string) ?? '';
        const cobDate = moment(parsedDate).format('YYYYMMDD');

        return `im_backtesting_dashboard_actual_${cobDate}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'IM Backtesting Dashboard Actual Summary' }],
      parameters: [
        {
          name: 'cobDate',
          in: 'query',
          description: 'Search by cobDate',
          required: true,
          type: 'string',
        },
        {
          name: 'product',
          in: 'query',
          description: 'Search by product',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: summaryQuery,
        returnDataName: 'IMDashboardActualSummary',
        queryVariables: refParams,
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'creditSupportAnnex.id',
        fields: columns,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'IM Backtesting Dashboard Actual Summary',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import * as moment from 'moment';
import { APIMappingEntities } from '../../../models/api.model';

const summaryQuery = () => `
query IMDashboardVarSummaryQuery(
    $cobDate: String!
    $product: String!
  ) {
    IMDashboardVarSummary(
      cobDate: $cobDate
      product: $product
    ) {
      percentile01
      percentile99
      var500Percentile01
      var500Percentile99
      stressedVarPercentile01
      stressedVarPercentile99
      observations
      exceedances
      trafficLight
      cobDate
      version
      creditSupportAnnex {
        id
        name
      }
      currency
      initialMargin
      pledgorCurrency
      pledgorInitialMargin
      initialMarginTrades
      riskEngineTrades
      statusMessage
      product
    }
  }`;

const refParams = ({ cobDate, product }) => ({
  cobDate,
  product,
});

const roundDisplayRenderer = (prop: number) => Math.round(prop).toString();

const columns = [
  {
    field: 'creditSupportAnnex.id',
    name: 'ID',
    typeOf: 'number',
  },
  {
    field: 'creditSupportAnnex.name',
    name: 'Name',
    typeOf: 'string',
  },
  {
    field: 'product',
    name: 'Product',
    typeOf: 'string',
  },
  {
    field: 'initialMargin',
    name: 'Initial Margin (USD) - Secured',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },
  {
    field: 'pledgorInitialMargin',
    name: 'Initial Margin (USD) - Pledgor',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },
  {
    field: 'percentile01',
    name: 'Full Window - 1%',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },
  {
    field: 'percentile99',
    name: 'Full Window - 99%',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },
  {
    field: 'var500Percentile01',
    name: '500 Day - 1%',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },
  {
    field: 'var500Percentile99',
    name: '500 Day - 99%',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },
  {
    field: 'stressedVarPercentile01',
    name: 'Stressed VaR - 1%',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },
  {
    field: 'stressedVarPercentile99',
    name: 'Stressed VaR - 99%',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },
  {
    field: 'initialMarginTrades',
    name: 'Initial Margin Trades',
    typeOf: 'number',
  },
  {
    field: 'riskEngineTrades',
    name: 'Risk Engine Trades',
    typeOf: 'string',
  },
  {
    field: 'exceedances',
    name: 'Exceedances',
    typeOf: 'string',
  },
  {
    field: 'trafficLight',
    name: 'Result',
    typeOf: 'string',
  },
  {
    field: 'statusMessage',
    name: 'Status Message',
    typeOf: 'string',
  },
];

export default {
  '/im-backtesting/dashboard/var/csv': {
    get: {
      name: 'imBackTestingDashboardVarSummaryCSV',
      summary: 'Export IM Backtesting Dashboard Var Summary',
      description: 'Returns all data in csv file',
      filename: ({ query }) => {
        const parsedDate = (query.cobDate as string) ?? '';
        const cobDate = moment(parsedDate).format('YYYYMMDD');

        return `im_backtesting_dashboard_var_${cobDate}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'IM Backtesting Dashboard Var Summary' }],
      parameters: [
        {
          name: 'cobDate',
          in: 'query',
          description: 'Search by cobDate',
          required: true,
          type: 'string',
        },
        {
          name: 'product',
          in: 'query',
          description: 'Search by product',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: summaryQuery,
        returnDataName: 'IMDashboardVarSummary',
        queryVariables: refParams,
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'creditSupportAnnex.id',
        fields: columns,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'IM Backtesting Dashboard Var Summary',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

import * as moment from 'moment';
import { APIMappingEntities } from '../../../models/api.model';

const summaryQuery = () => `
query IMDashboardHypoSummaryQuery($cobDate: String!, $product: String!) {
    IMDashboardHypoSummary(cobDate: $cobDate, product: $product) {
      hypoPnL
      averageInitialMarginExposure
      averageHypoPnL
      daysHypoAboveInitialMargin
      cobDate
      version
      currency
      initialMargin
      pledgorCurrency
      pledgorInitialMargin
      creditSupportAnnex {
        id
        name
      }
      initialMarginTrades
      riskEngineTrades
      statusMessage
      product
    }
  }`;

const refParams = ({ cobDate, product }) => ({
  cobDate,
  product,
});

const roundDisplayRenderer = (prop: number) => Math.round(prop).toString();

const columns = [
  {
    field: 'creditSupportAnnex.id',
    name: 'ID',
    typeOf: 'number',
  },
  {
    field: 'creditSupportAnnex.name',
    name: 'Name',
    typeOf: 'string',
  },
  {
    field: 'product',
    name: 'Product',
    typeOf: 'string',
  },
  {
    field: 'initialMargin',
    name: 'Initial Margin (USD)',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },

  {
    field: 'hypoPnL',
    name: 'Hypo (USD)',
    typeOf: 'array',
    displayRenderer: roundDisplayRenderer,
  },
  {
    field: 'initialMarginTrades',
    name: 'Initial Margin Trades',
    typeOf: 'number',
  },
  {
    field: 'riskEngineTrades',
    name: 'Risk Engine Trades',
    typeOf: 'number',
  },
  {
    field: 'averageInitialMarginExposure',
    name: 'Average Initial Margin (USD)',
    typeOf: 'number',
  },
  {
    field: 'averageHypoPnL',
    name: 'Average Hypo (USD)',
    typeOf: 'number',
  },
  {
    field: 'daysHypoAboveInitialMargin',
    name: 'Days Hypo Above IM',
    typeOf: 'number',
  },
  {
    field: 'statusMessage',
    name: 'Status Message',
    typeOf: 'string',
  },
];

export default {
  '/im-backtesting/dashboard/hypo/csv': {
    get: {
      name: 'imBackTestingDashboardHypoSummaryCSV',
      summary: 'Export IM Backtesting Dashboard Hypo Summary',
      description: 'Returns all data in csv file',
      filename: ({ query }) => {
        const parsedDate = (query.cobDate as string) ?? '';
        const cobDate = moment(parsedDate).format('YYYYMMDD');

        return `im_backtesting_dashboard_hypo_${cobDate}`;
      },
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'IM Backtesting Dashboard Hypo Summary' }],
      parameters: [
        {
          name: 'cobDate',
          in: 'query',
          description: 'Search by cobDate',
          required: true,
          type: 'string',
        },
        {
          name: 'product',
          in: 'query',
          description: 'Search by product',
          required: true,
          type: 'string',
        },
      ],
      dataSource: {
        query: summaryQuery,
        returnDataName: 'IMDashboardHypoSummary',
        queryVariables: refParams,
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'creditSupportAnnex.id',
        fields: columns,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'IM Backtesting Dashboard Hypo Summary',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

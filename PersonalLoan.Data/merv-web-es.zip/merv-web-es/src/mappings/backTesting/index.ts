import { APIMappingEntities } from '../../models/api.model';
import imConfigTrafficLightsThreshold from './imConfig/imConfigTrafficLightsThreshold';
import imProducts from './imConfig/imProducts';
import imConfigTrafficLightsThresholdAuditHistory from './imConfig/imConfigTrafficLightsThresholdAuditHistory';
import imRunManagement from './imRunManagement';
import imVarSummary from './imDashboard/imVarSummary';
import imHypoSummary from './imDashboard/imHypoSummary';
import imActualSumary from './imDashboard/imActualSumary';
import imAnalysis from './imAnalysis';

export default {
  ...imConfigTrafficLightsThreshold,
  ...imProducts,
  ...imConfigTrafficLightsThresholdAuditHistory,
  ...imRunManagement,
  ...imVarSummary,
  ...imHypoSummary,
  ...imActualSumary,
  ...imAnalysis,
} as APIMappingEntities;

import { APIMappingEntities } from '../../models/api.model';

const query = () => `
{    
    IMRunManagement {
        cobDate
        version
        productClass
        pnLFilter
        type
        creditSupportAnnexes
        initialMarginTrades
        riskEngineTrades
        statusMessage
        runTime
        endTime
        isProxy
        added {
          by
          time
        }
      }
}`;

const columns = [
  {
    field: 'cobDate',
    name: 'COB Date',
    typeOf: 'date',
  },
  {
    field: 'version',
    name: 'Version',
    typeOf: 'string',
  },
  {
    field: 'type',
    name: 'Type',
    typeOf: 'string',
  },
  {
    field: 'productClass',
    name: 'Product',
    typeOf: 'string',
  },
  {
    field: 'pnLFilter',
    name: 'P&L Filter',
    typeOf: 'string',
  },
  {
    field: 'creditSupportAnnexes',
    name: 'CSAs',
    typeOf: 'string',
  },
  {
    field: 'initialMarginTrades',
    name: 'Initial Margin Trades',
    typeOf: 'string',
  },
  {
    field: 'riskEngineTrades',
    name: 'Risk Engine Trades',
    typeOf: 'string',
  },
  {
    field: 'runTime',
    name: 'Run Time',
    typeOf: 'dateTime',
  },
  {
    field: 'endTime',
    name: 'End Time',
    typeOf: 'dateTime',
  },
  {
    field: 'added.by',
    name: 'Run By',
    typeOf: 'string',
  },
  {
    field: 'statusMessage',
    name: 'Status Message',
    typeOf: 'string',
  },
  {
    field: 'isProxy',
    name: 'Is Proxy',
    typeOf: 'boolean',
  },
];

export default {
  '/im-backtesting/run-management/csv': {
    get: {
      name: 'imBackTestingRunManagementCSV',
      summary: 'Export IM Backtesting Run Management',
      description: 'Returns all data in csv file',
      filename: 'im_backtesting_run_management',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'IM Backtesting Run Management' }],
      parameters: [],
      dataSource: {
        query,
        returnDataName: 'IMRunManagement',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'cobDate',
        fields: columns,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'IM Backtesting Run Management',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

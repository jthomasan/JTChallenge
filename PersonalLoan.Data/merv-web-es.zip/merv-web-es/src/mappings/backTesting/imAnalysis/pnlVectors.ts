
import {gql} from 'graphql-tag';
import * as moment from "moment";
import { DocumentNode } from "graphql";
import { APIMappingEntities, Field, Parameter } from "../../../models/api.model";

const NonVarQuery = gql`
  query IMBackTestingResults(
    $type: String!
    $cobDate: Date!
    $product: ID!
    $csa: ID!
    $pastMonths: Int!
  ) {
    data: IMBackTestingResults(
      type: $type
      date: $cobDate
      product: $product
      csa: $csa
      months: $pastMonths
    ) {
      cobDate
      difference
      initialMargin
      pnl {
        amount
      }
    }
  }
`;

const VarQuery = gql`
  query IMBackTestingVaRResults($cobDate: Date!, $product: ID!, $csa: ID!) {
    data: IMBackTestingVaRResults(date: $cobDate, product: $product, csa: $csa) {
      pnl {
        date
        amount
      }
    }
  }
`;

function getEndpoint(type: string, {
  pnlTitle,
  pnlOnly,
  takesPastMonthsParameter,
  dateField,
  pnlField,
  query,
  dataPath,
}: {
  pnlTitle: string,
  pnlOnly: boolean,
  dateField: string,
  pnlField: string,
  query: DocumentNode,
  dataPath: string,
  takesPastMonthsParameter: boolean;
}): APIMappingEntities {
  const columns: Field[] = [{
    name: 'Date',
    field: dateField,
    typeOf: 'date',
  }]

  if(!pnlOnly) {
    columns.push({
      name: 'Initial Margin',
      field: 'initialMargin',
      typeOf: 'number',
    });
  }

  columns.push({
    name: pnlTitle,
    field: pnlField,
    typeOf: 'number',
  });

  if(!pnlOnly) {
    columns.push({
      name: 'Difference',
      field: 'difference',
      typeOf: 'number',
    });
  }

  const parameters: Parameter[] = [{
    name: 'cobDate',
    in: 'query',
    description: 'Search by cobDate',
    required: true,
    type: 'string',
  },
  {
    name: 'product',
    in: 'query',
    description: 'Search by product',
    required: true,
    type: 'string',
  },
  {
    name: 'csa',
    in: 'query',
    description: 'Search by csa',
    required: true,
    type: 'string',
  }];

  if(takesPastMonthsParameter) {
    parameters.push({
      name: 'pastMonths',
      in: 'query',
      description: 'Search by pastMonths',
      required: true,
      type: 'number',
    })
  }

  return {
    [`/im-backtesting/analysis/pnl-vectors/${type}/csv`]: {
      get: {
        name: 'imBackTestingAnalysisPnLVectorsCSV',
        summary: 'Export IM Backtesting Analysis PnL Vectors',
        description: 'Returns all data in a csv file',
        filename: ({query: queryParams}) => {
          const cobDate = moment(queryParams.cobDate as string ?? '').format('YYYYMMDD');

          const fileName = `im_backtesting_analysis_${type}_${cobDate}_${queryParams.product}_${queryParams.csa}`;

          if(takesPastMonthsParameter) {
            return `${fileName}_${queryParams.pastMonths}months`;
          }

          return fileName;
        },
        produces: [{ name: 'application/csv' }],
        tags: [{ name: 'IM Backtesting Analysis' }],
        parameters,
        dataSource: {
          query,
          queryVariables: (params) => ({
            ...params,
            type,
          }),
          returnDataName: dataPath,
        },
        exportInfo: {
          customProcessor: null,
          sortField: dateField,
          sortOrder: 'desc',
          fields: columns,
        },
        responses: {
          '200': {
            description: 'An array of strings',
            schema: {
              title: 'IM Backtesting Analysis PnL Vectors',
              type: 'array',
              items: {
                type: 'string',
              },
            },
          },
        },
      },
    },
  };
}

export default {
  ...getEndpoint('var', {
    pnlTitle: 'PnL',
    pnlOnly: true,
    dateField: 'date',
    pnlField: 'amount',
    query: VarQuery,
    dataPath: 'data.pnl',
    takesPastMonthsParameter: false,
  }),
  ...getEndpoint('hypo', {
    pnlTitle: 'Hypo PnL',
    pnlOnly: false,
    dateField: 'cobDate',
    pnlField: 'pnl.amount',
    query: NonVarQuery,
    dataPath: 'data',
    takesPastMonthsParameter: true,
  }),
  ...getEndpoint('actualpnl', {
    pnlTitle: 'PnL',
    pnlOnly: false,
    dateField: 'cobDate',
    pnlField: 'pnl.amount',
    query: NonVarQuery,
    dataPath: 'data',
    takesPastMonthsParameter: true,
  }),
} as APIMappingEntities;
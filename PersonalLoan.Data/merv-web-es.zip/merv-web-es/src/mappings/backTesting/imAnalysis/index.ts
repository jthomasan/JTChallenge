import pnlVectors from './pnlVectors';
import pnlVectorsPopup from './pnlVectorsPopup';
import tradeDrilldown from './tradeDrilldown';

export default {
  ...pnlVectors,
  ...pnlVectorsPopup,
  ...tradeDrilldown,
};
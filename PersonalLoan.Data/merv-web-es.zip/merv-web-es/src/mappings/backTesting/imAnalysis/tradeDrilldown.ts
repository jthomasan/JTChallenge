
import {gql} from 'graphql-tag';
import * as moment from "moment";
import { DocumentNode } from "graphql";
import { APIMappingEntities, Field, Parameter } from "../../../models/api.model";

const NonVarQuery = gql`
  query IMBackTestingTrades(
    $type: String!
    $cobDate: Date!
    $product: ID!
    $csa: ID!
    $aggregate: Boolean!
  ) {
    data: IMBackTestingTrades(
      type: $type
      date: $cobDate
      product: $product
      csa: $csa
      aggregate: $aggregate
    ) {
      tradeId
      cobDate
      productClass
      pnl
      portfolio
      currency
      family
      group
      type
      instrument
      counterparty
      sourceSystem

      expiryDate
      isProxy
    }
  }
`;

const VarQuery = gql`
  query IMBackTestingVaRTrades($cobDate: Date!, $product: ID!, $csa: ID!, $scenarioDate: Date!) {
    data: IMBackTestingVaRTrades(
      date: $cobDate
      product: $product
      csa: $csa
      scenarioDate: $scenarioDate
    ) {
      tradeId
      cobDate
      productClass
      pnl
      portfolio
      currency
      family
      group
      type
      instrument
      counterparty
      sourceSystem
    }
  }
`;

function getEndpoint(type: string, {
  query,
  hasExpiryDate,
  hasIsProxy,
}: {
  query: DocumentNode,
  hasExpiryDate: boolean;
  hasIsProxy: boolean;
}): APIMappingEntities {
  const columns: Field[] = [{
    name: 'Trade ID',
    field: 'tradeId',
    typeOf: 'string',
  },
  {
    name: 'COB Date',
    field: 'cobDate',
    typeOf: 'date',
  }, {
    name: 'Product',
    field: 'productClass',
    typeOf: 'string',
  }, {
    name: 'PnL',
    field: 'pnl',
    typeOf: 'number',
  }];

  if(hasExpiryDate) {
    columns.push({
      name: 'Expiry Date',
      field: 'expiryDate',
      typeOf: 'date',
    })
  }

  columns.push(...[
    {
      name: 'Portfolio',
      field: 'portfolio',
      typeOf: 'string' as const,
    },
    {
      name: 'Currency',
      field: 'currency',
      typeOf: 'string' as const,
    },
    {
      name: 'Family',
      field: 'family',
      typeOf: 'string' as const,
    },
    {
      name: 'Group',
      field: 'group',
      typeOf: 'string' as const,
    },
    {
      name: 'Type',
      field: 'type',
      typeOf: 'string' as const,
    },
    {
      name: 'Instrument',
      field: 'instrument',
      typeOf: 'string' as const,
    },
    {
      name: 'Counterparty',
      field: 'counterparty',
      typeOf: 'string' as const,
    },
    {
      name: 'Source System',
      field: 'sourceSystem',
      typeOf: 'string' as const,
    },
  ]);

  if(hasIsProxy) {
    columns.push({
      name: 'Is Proxy',
      field: 'isProxy',
      typeOf: 'boolean',
    })
  }

  const parameters: Parameter[] = [{
    name: 'cobDate',
    in: 'query',
    description: 'Search by cobDate',
    required: true,
    type: 'string',
  },
  {
    name: 'product',
    in: 'query',
    description: 'Search by product',
    required: true,
    type: 'string',
  },
  {
    name: 'csa',
    in: 'query',
    description: 'Search by csa',
    required: true,
    type: 'string',
  }];

  if(type === 'var') {
    parameters.push({
      name: 'scenarioDate',
      in: 'query',
      description: 'Search by scenarioDate',
      required: true,
      type: 'date',
    })
  } else {
    parameters.push({
      name: 'aggregate',
      in: 'query',
      description: 'Aggregate results',
      required: false,
      type: 'boolean',
    })
  }

  return {
    [`/im-backtesting/analysis/trades/${type}/csv`]: {
      get: {
        name: 'imBackTestingAnalysisTradesCSV',
        summary: 'Export IM Backtesting Analysis Trades',
        description: 'Returns all data in a csv file',
        filename: ({query: queryParams}) => {
          const cobDate = moment(queryParams.cobDate as string ?? '');
          if(type === 'actualpnl') {
            cobDate.add(1, 'day');
          }

          const cobDateStr = cobDate.format('YYYYMMDD');

          let fileName = `im_backtesting_analysis_${type}_${cobDateStr}_${queryParams.product}_${queryParams.csa}`;

          if(type === 'var') {
            const scenarioDate = moment(queryParams.scenarioDate as string ?? '').format('YYYYMMDD');
            fileName = `${fileName}_${scenarioDate}`;
          } 
          
          if(queryParams.aggregate && queryParams.aggregate !== 'false') {
            fileName = `${fileName}_aggregated`;
          }

          return fileName;
        },
        produces: [{ name: 'application/csv' }],
        tags: [{ name: 'IM Backtesting Analysis' }],
        parameters,
        dataSource: {
          query,
          queryVariables: (params) => {
            if(type === 'var') return {...params, type};

            return {
              ...params,
              aggregate: params.aggregate ?? false,
              type,
            }
          },
          returnDataName: 'data',
        },
        exportInfo: {
          customProcessor: null,
          sortField: 'cobDate',
          sortOrder: 'desc',
          fields: columns,
        },
        responses: {
          '200': {
            description: 'An array of strings',
            schema: {
              title: 'IM Backtesting Analysis Trades',
              type: 'array',
              items: {
                type: 'string',
              },
            },
          },
        },
      },
    },
  };
}

export default {
  ...getEndpoint('var', {
    query: VarQuery,
    hasExpiryDate: false,
    hasIsProxy: false,
  }),
  ...getEndpoint('hypo', {
    query: NonVarQuery,
    hasExpiryDate: false,
    hasIsProxy: false,
  }),
  ...getEndpoint('actualpnl', {
    query: NonVarQuery,
    hasExpiryDate: true,
    hasIsProxy: true,
  }),
} as APIMappingEntities;
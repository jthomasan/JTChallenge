import {gql} from 'graphql-tag';
import * as moment from 'moment';
import { APIMappingEntities, Field } from '../../../models/api.model';

function getEndpoint(type: string, columnConfig: {
  showAttributions: boolean;
    showPnL: boolean;
}): APIMappingEntities {
  const columns: Field[] = [{
    name: 'Date',
    field: 'date',
    typeOf: 'date',
  }];

  if(columnConfig.showPnL) {
    columns.push({
      name: 'PnL',
      field: 'amount',
      typeOf: 'number',
    });
  }

  if(columnConfig.showAttributions) {
    columns.push({
      name: 'Attribution',
      field: 'attribution',
      typeOf: 'string',
    });
  }

  return {
    [`/im-backtesting/analysis/trade-pnl-vector/${type}/csv`]: {
      get: {
        name: 'imBackTestingAnalysisTradePnLVectorsCSV',
        summary: 'Export IM Backtesting Analysis Trade PnL Vectors',
        description: 'Returns all data in a csv file',
        filename: ({query: queryParams}) => {
          const cobDate = moment(queryParams.cobDate as string ?? '').format('YYYYMMDD');

          return `im_backtesting_analysis_${type}_${cobDate}_${queryParams.product}_${queryParams.tradeId}`;
        },
        produces: [{ name: 'application/csv' }],
        tags: [{ name: 'IM Backtesting Analysis' }],
        parameters: [
          {
            name: 'cobDate',
            in: 'query',
            description: 'Search by cobDate',
            required: true,
            type: 'string',
          },
          {
            name: 'product',
            in: 'query',
            description: 'Search by product',
            required: true,
            type: 'string',
          },
          {
            name: 'tradeId',
            in: 'query',
            description: 'Search by tradeId',
            required: true,
            type: 'string',
          },
        ],
        dataSource: {
          query: gql`
            query IMBackTestingPnlByTradeId($type: String!, $cobDate: Date!, $product: ID!, $tradeId: ID!) {
              data: IMBackTestingPnlByTradeId(
                type: $type
                date: $cobDate
                product: $product
                tradeId: $tradeId
              ) {
                pnls {
                  attribution
                  date
                  amount
                }
              }
            }
          `,
          queryVariables: (params) => ({
            ...params,
            type,
          }),
          returnDataName: 'data.pnls',
        },
        exportInfo: {
          customProcessor: null,
          sortField: 'date',
          fields: columns,
        },
        responses: {
          '200': {
            description: 'An array of strings',
            schema: {
              title: 'IM Backtesting Analysis Trade PnL Vectors',
              type: 'array',
              items: {
                type: 'string',
              },
            },
          },
        },
      },
    },
  };
}

export default {
  ...getEndpoint('var', {
    showAttributions: false,
    showPnL: true,
  }),
  ...getEndpoint('hypo', {
    showAttributions: false,
    showPnL: true,
  }),
  ...getEndpoint('actualpnl', {
    showAttributions: true,
    showPnL: true,
  }),
} as APIMappingEntities;
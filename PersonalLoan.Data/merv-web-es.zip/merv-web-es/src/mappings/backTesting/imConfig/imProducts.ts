import { APIMappingEntities } from '../../../models/api.model';

const query = () => `
{    
    ImProductsConfiguration  {
        name
        isActive
    }
}`;

const columns = [
  {
    field: 'name',
    name: 'Name',
    typeOf: 'string',
  },
  {
    field: 'isActive',
    name: 'Is Active',
    typeOf: 'boolean',
  },
];

export default {
  '/im-backtesting/configuration/products/csv': {
    get: {
      name: 'imBackTestingConfigurationCSV',
      summary: 'Export IM Backtesting Configuration Products',
      description: 'Returns all data in csv file',
      filename: 'im_backtesting_configuration_products',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'IM Backtesting Configuration' }],
      parameters: [],
      dataSource: {
        query,
        returnDataName: 'ImProductsConfiguration',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'name',
        fields: columns,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'IM Backtesting Configuration Products',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

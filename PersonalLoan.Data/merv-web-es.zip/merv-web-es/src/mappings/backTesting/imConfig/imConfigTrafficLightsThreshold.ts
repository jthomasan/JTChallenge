import { APIMappingEntities } from '../../../models/api.model';

const query = () => `
{    
    TrafficLightsThreshold  {
        numberOfObservations
        maxExceedancesGreen
        maxExceedancesAmber
        isActive
    }
}`;

const columns = [
  {
    field: 'numberOfObservations',
    name: 'Observations',
    typeOf: 'number',
  },
  {
    field: 'maxExceedancesGreen',
    name: 'Max Exceedances Green',
    typeOf: 'number',
  },
  {
    field: 'maxExceedancesAmber',
    name: 'Max Exceedances Amber',
    typeOf: 'number',
  },
  {
    field: 'isActive',
    name: 'Is Active',
    typeOf: 'boolean',
  },
];

export default {
  '/im-backtesting/configuration/traffic-light-thresholds/csv': {
    get: {
      name: 'imBackTestingConfigurationCSV',
      summary: 'Export IM Backtesting Configuration Traffic Light Thresholds',
      description: 'Returns all data in csv file',
      filename: 'im_backtesting_configuration_traffic_light_thresholds',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'IM Backtesting Configuration' }],
      parameters: [],
      dataSource: {
        query,
        returnDataName: 'TrafficLightsThreshold',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'numberOfObservations',
        fields: columns,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'IM Backtesting Configuration Traffic Light Thresholds',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

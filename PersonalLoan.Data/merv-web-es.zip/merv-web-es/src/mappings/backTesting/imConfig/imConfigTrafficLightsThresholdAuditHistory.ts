import { APIMappingEntities } from '../../../models/api.model';

const query = () => `
  query getTrafficLightsThresholdHistory($auditId: ID!) {
    TrafficLightsThresholdHistory(auditId: $auditId) {
        numberOfObservations
        maxExceedancesGreen
        maxExceedancesAmber
        isActive
        added {
          by
          time
        }
      }
}`;

const queryVariables = ({ auditId }) => ({
  auditId,
});

const columns = [
  { field: 'numberOfObservations', name: 'Observations', typeOf: 'number' },
  {
    field: 'maxExceedancesGreen',
    name: 'Max Exceedances Green',
    typeOf: 'number',
  },
  {
    field: 'maxExceedancesAmber',
    name: 'Max Exceedances Amber',
    typeOf: 'number',
  },
  {
    field: 'isActive',
    name: 'Is Active',
    typeOf: 'boolean',
  },
  { field: 'added.by', name: 'Added By', typeOf: 'string' },
  {
    field: 'added.time',
    name: 'Added Time',
    typeOf: 'date',
  },
];

export default {
  '/im-backtesting/configuration/traffic-light-thresholds-history/csv': {
    get: {
      name: 'imBackTestingConfigurationHistoryCSV',
      summary: 'Export IM Backtesting Configuration Traffic Light Thresholds Audit History',
      description: 'Returns all data in csv file',
      filename: 'im_backtesting_configuration_traffic_light_thresholds_audit_history',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'IM Backtesting Configuration Audit History' }],
      parameters: [
        {
          name: 'auditId',
          in: 'query',
          description: 'Search by audit id',
          required: false,
          type: 'string',
        },
      ],
      dataSource: {
        query,
        returnDataName: 'TrafficLightsThresholdHistory',
        queryVariables,
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'numberOfObservations',
        fields: columns,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'IM Backtesting Configuration Traffic Light Thresholds Audit History',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

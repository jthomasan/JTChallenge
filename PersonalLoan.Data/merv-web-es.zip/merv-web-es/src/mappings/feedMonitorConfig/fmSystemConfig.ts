import { APIMappingEntities } from '../../models/api.model';

const query = () => `
{  
    SystemConfiguration {
        id
        modified
        name
        value
        added {
          by
          time
        }
      }
}
`;

const customProcessorExportFields = [
  {
    field: 'name',
    name: 'Name',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'value',
    name: 'Value',
    typeOf: 'string',
  },
  {
    field: 'added.time',
    name: 'Last Edited Time',
    typeOf: 'dateTime',
  },
  {
    field: 'added.by',
    name: 'Last Edited By',
    typeOf: 'string',
  },
];

export default {
  '/feed-monitor/configuration/system-config/csv': {
    get: {
      name: 'feedMonitorConfigurationSystem',
      summary: 'Export Feed Monitor Configuration System Config',
      description: 'Returns all data in csv file',
      filename: 'feed_monitor_config_system',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed monitor Configuration' }],
      parameters: [],
      dataSource: {
        query,
        returnDataName: 'SystemConfiguration',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'name',
        fields: customProcessorExportFields,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Feed Monitor Configuration System Config',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

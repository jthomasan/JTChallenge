import { APIMappingEntities } from '../../models/api.model';
import fmCsvConfig from './fmCsvConfig';
import fmNotificationConfig from './fmNotificationConfig';
import auditHistory from './auditHistory';
import feedMonitorConfigLog from './feedMonitorConfigLog';
import fmReconThresholdSetting from './fmReconThresholdSetting';
import fmSystemConfig from './fmSystemConfig';

export default {
  ...fmCsvConfig,
  ...fmNotificationConfig,
  ...auditHistory,
  ...feedMonitorConfigLog,
  ...fmReconThresholdSetting,
  ...fmSystemConfig,
} as APIMappingEntities;

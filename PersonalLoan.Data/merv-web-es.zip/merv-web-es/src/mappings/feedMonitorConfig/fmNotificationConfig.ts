import { APIMappingEntities } from '../../models/api.model';

const fmNotificationConfigQuery = () => `
{  
  NotificationConfiguration {
      id
      modified
      name
      description
      assemblyName
      typeName
      isActive
      pollIntervalInMinute
      sqlStatement
      isEmailEnabled
      email {
        templateName
        toList
        ccList
        subjectText
        bodyText
      }
      event {
        id
        logName
        logSource
        eventText
      }
      isEventEnabled
      moduleName
      additional {
        param1
        param2
        param3
      }
      allowManualTrigger
      scheduleStart
      scheduleEnd
      workingDayOnly        
      added {
        by
        time
      }
  }
}
`;

const customProcessorExportFields = [
  {
    field: 'name',
    name: 'Name',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'description',
    name: 'Description',
    typeOf: 'string',
  },
  {
    field: 'assemblyName',
    name: 'Assembly Name',
    typeOf: 'string',
  },
  {
    field: 'typeName',
    name: 'Type Name',
    typeOf: 'string',
  },
  {
    field: 'isActive',
    name: 'Is Active',
    typeOf: 'boolean',
  },
  {
    field: 'added.time',
    name: 'Added Time',
    typeOf: 'dateTime',
  },
  {
    field: 'added.by',
    name: 'Added By',
    typeOf: 'string',
  },
  {
    field: 'pollIntervalInMinute',
    name: 'Poll Interval In Minute',
    typeOf: 'number',
  },
  {
    field: 'workingDayOnly',
    name: 'Working Day Only',
    typeOf: 'boolean',
  },
  {
    field: 'scheduleStart',
    name: 'Schedule Start',
    typeOf: 'string',
  },
  {
    field: 'scheduleEnd',
    name: 'Schedule End',
    typeOf: 'string',
  },
  {
    field: 'sqlStatement',
    name: 'SQL Statement',
    typeOf: 'string',
  },
  {
    field: 'isEmailEnabled',
    name: 'Is Email enabled',
    typeOf: 'boolean',
  },
  {
    field: 'email.templateName',
    name: 'Email Template Name',
    typeOf: 'string',
  },
  {
    field: 'email.toList',
    name: 'Email To List',
    typeOf: 'string',
  },
  {
    field: 'email.ccList',
    name: 'Email Cc List',
    typeOf: 'string',
  },
  {
    field: 'email.subjectText',
    name: 'Email Subject Text',
    typeOf: 'string',
  },
  {
    field: 'email.bodyText',
    name: 'Email Body Text',
    typeOf: 'string',
  },
  {
    field: 'isEventEnabled',
    name: 'Is Event Enabled',
    typeOf: 'boolean',
  },
  {
    field: 'allowManualTrigger',
    name: 'Allow Manual Trigger',
    typeOf: 'boolean',
  },
  {
    field: 'event.logName',
    name: 'Event Log Name',
    typeOf: 'string',
  },
  {
    field: 'event.logSource',
    name: 'Event Log Source',
    typeOf: 'string',
  },
  {
    field: 'event.id',
    name: 'Event ID',
    typeOf: 'number',
  },
  {
    field: 'event.text',
    name: 'Event Text',
    typeOf: 'string',
  },
  {
    field: 'moduleName',
    name: 'Module Name',
    typeOf: 'string',
  },
  {
    field: 'additional.param1',
    name: 'Additional Param 1',
    typeOf: 'string',
  },
  {
    field: 'additional.param2',
    name: 'Additional Param 2',
    typeOf: 'string',
  },
  {
    field: 'additional.param3',
    name: 'Additional Param 3',
    typeOf: 'string',
  },
];

export default {
  '/feed-monitor/configuration/notification-config/csv': {
    get: {
      name: 'feedMonitorConfigurationNotification',
      summary: 'Export Feed Monitor Configuration Notification Config',
      description: 'Returns all data in csv file',
      filename: 'feed_monitor_configuration_notification_config',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed monitor Configuration' }],
      parameters: [],
      dataSource: {
        query: fmNotificationConfigQuery,
        returnDataName: 'NotificationConfiguration',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'name',
        fields: customProcessorExportFields,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            name: 'Feed Monitor Configuration Notification Config',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

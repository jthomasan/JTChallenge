import { APIMappingEntities } from '../../models/api.model';

const feedMonitorLogQuery = () => `
query getFeedMonitorLog($fmConfigTypeId: ID, $logId: ID) {
    FeedMonitorLog(fmConfigTypeId: $fmConfigTypeId, logId: $logId) {
      jobName
      startTime
      endTime
      resultMessage
      errorMessage
    }
  }
`;
const columnsWithCustomCells = [
  {
    field: 'jobName',
    name: 'Job Name',
    typeOf: 'string',
    sorting: true,
  },
  {
    field: 'startTime',
    name: 'Start Time',
    typeOf: 'dateTime',
  },
  {
    field: 'endTime',
    name: 'End Time',
    typeOf: 'dateTime',
  },
  {
    field: 'resultMessage',
    name: 'Result Message',
    typeOf: 'string',
  },
  {
    field: 'errorMessage',
    name: 'Error Message',
    typeOf: 'string',
  },
];

const feedMonitorLogQueryVariables = ({ fmConfigTypeId, logId }) => ({
  logId,
  fmConfigTypeId,
});

export default {
  '/feed-monitor/log/csv': {
    get: {
      name: 'feedMonitorLog',
      summary: 'Export feed monitor log csv',
      description: 'Returns all feed monitor logs in csv file',
      filename: 'Feed_Monitor_Log_{args.datasetName}',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed Monitor Log' }],
      parameters: [
        {
          name: 'fmConfigTypeId',
          in: 'query',
          description: 'Search by type id',
          required: false,
          type: 'string',
        },
        {
          name: 'logId',
          in: 'query',
          description: 'Search by audit id',
          required: false,
          type: 'string',
        },
      ],
      dataSource: {
        query: feedMonitorLogQuery,
        queryVariables: feedMonitorLogQueryVariables,
        returnDataName: 'FeedMonitorLog',
      },
      exportInfo: {
        customProcessor: null,
        fields: columnsWithCustomCells,
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Feed Monitor Log',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

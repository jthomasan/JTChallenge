import { formatStrings } from '../../processors/genericExportProcessor';
import { APIMappingEntities } from '../../models/api.model';

interface Request {
  resultCount: number;
}

const query = () => `
query DataLoadRequestsQuery($resultCount: Int) {
  DataLoadRequests(resultCount: $resultCount) {
    id
      description
      requestedBy
      expiryDate
      status {
        request
        load
      }
      progress
      runDates
      businessDates
      sourceSystemEnvironments
      snapshot
      reports
      portfolios
      lastUpdated {
        time
      }
  }
}
`;

const dateDisplayRenderer = (prop: string[]) =>
  prop.map((c: string) => formatStrings.date(c)).join(';');

const sourceSystemDisplayRenderer = (prop: string[]) => prop.join(';');

const percDisplayRenderer = (prop: number) => (Math.round(prop * 100 * 100) / 100).toString();

export default {
  '/feed-monitor/user-requests/data-load-requests/csv': {
    get: {
      name: 'dataLoadRequests',
      summary: 'Export csv',
      description: 'Returns all data in csv file',
      filename: 'feed_monitor_data_load_requests',
      produces: [{ name: 'application/csv' }],
      tags: [{ name: 'Feed Monitor' }],
      parameters: [
        {
          name: 'resultCount',
          in: 'query',
          description: 'Result Count',
          required: true,
          type: 'number',
        },
      ],
      dataSource: {
        query,
        queryVariables: (params: Request) => params,
        returnDataName: 'DataLoadRequests',
      },
      exportInfo: {
        customProcessor: null,
        sortField: 'lastUpdated.time',
        fields: [
          {
            field: 'description',
            name: 'Description',
            typeOf: 'string',
          },
          {
            field: 'requestedBy',
            name: 'Requested By',
            typeOf: 'string',
          },
          {
            field: 'expiryDate',
            name: 'Expiry Date',
            typeOf: 'dateTime',
          },
          {
            field: 'status.request',
            name: 'Status',
            typeOf: 'string',
          },
          {
            field: 'progress',
            name: 'Progress',
            typeOf: 'array',
            displayRenderer: percDisplayRenderer,
          },
          {
            field: 'runDates',
            name: 'Run Dates',
            typeOf: 'array',
            displayRenderer: dateDisplayRenderer,
          },
          {
            field: 'businessDates',
            name: 'Business Date',
            typeOf: 'string',
          },
          {
            field: 'sourceSystemEnvironments',
            name: 'Source Environment',
            typeOf: 'array',
            displayRenderer: sourceSystemDisplayRenderer,
          },
          {
            field: 'snapshot',
            name: 'Snapshot',
            typeOf: 'string',
          },
          {
            field: 'lastUpdated.time',
            name: 'Last Updated',
            typeOf: 'dateTime',
          },
        ],
      },
      responses: {
        '200': {
          description: 'An array of strings',
          schema: {
            title: 'Data Load requests',
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    },
  },
} as APIMappingEntities;

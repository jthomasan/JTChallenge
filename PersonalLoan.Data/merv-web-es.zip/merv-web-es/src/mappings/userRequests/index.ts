import { APIMappingEntities } from '../../models/api.model';
import containerWorkflowRequests from './containerWorkflowRequests';
import reportWorkflowRequests from './reportWorkflowRequests';
import dataLoadRequests from './dataLoadRequests';

export default {
  ...containerWorkflowRequests,
  ...reportWorkflowRequests,
  ...dataLoadRequests,
} as APIMappingEntities;

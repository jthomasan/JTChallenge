import axios from 'axios';
import { DataSourceService } from './dataSourceService';
import { nodes } from '../processors/__mocks__/nodes';
import { portfolios } from '../processors/__mocks__/portfolios';

jest.mock('axios');

describe('Data Source Service Tests', () => {
  let dataSourceService: DataSourceService;
  const mockReq = { reqId: '12345', logger: { info: jest.fn() } };

  beforeEach(() => {
    dataSourceService = new DataSourceService();
  });

  it('should fetch all nodes from api', async () => {
    (axios.post as any).mockImplementationOnce(() => Promise.resolve(nodes));

    const response = await dataSourceService.getDataFromSource(
      mockReq,
      { cookie: 'test' },
      '{ query dummy {} }',
    );
    expect(response).toEqual(nodes.data);
  });

  it('should fetch all portfolios from api', async () => {
    (axios.post as any).mockImplementationOnce(() => Promise.resolve(portfolios));

    const response = await dataSourceService.getDataFromSource(
      mockReq,
      { cookie: 'test' },
      '{ query dummy {} }',
    );
    expect(response).toEqual(portfolios.data);
  });
});

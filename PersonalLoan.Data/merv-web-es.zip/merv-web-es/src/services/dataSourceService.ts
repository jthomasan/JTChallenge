import axios from 'axios';
import { IncomingHttpHeaders } from 'http';

/** Class representing the sources for retrieving data based of provided queries . */
export class DataSourceService {
  private readonly backendUrl = `${process.env.SERVER_URL}/graphql`;

  /**
   * Fetch data from given sources.
   *
   * @param  {IncomingHttpHeaders}  headers
   * @param  {string}  query
   * @returns {Promise}  Promise return response
   */
  public async getDataFromSource(
    req: { logger: any; reqId: string },
    headers: IncomingHttpHeaders,
    query: string,
    queryVariables?: any,
  ): Promise<any> {
    const { logger, reqId } = req;
    const payload = { query: query || {}, variables: queryVariables || {} };
    logger.info(payload, `POST ${this.backendUrl}`);

    const outgoingHeaders: Record<string, any> = {
      'X-Request-ID': reqId,
    };
    if (headers.cookie) outgoingHeaders['Cookie'] = headers.cookie;
    if (headers.authorization) outgoingHeaders['Authorization'] = headers.authorization;

    return axios
      .post(this.backendUrl, payload, {
        headers: outgoingHeaders,
      })
      .then((response) => {
        logger.info({ method: 'POST', url: this.backendUrl, payload }, 'successful response');
        return response.data;
      })
      .catch((error) => {
        throw error;
      });
  }
}

export interface StaticDataPortfolio {
  id: string;
  modified: boolean;
  name: string;
  comment: string;
  isActive: boolean;
  isEaR: boolean;
  isFinance: boolean;
  reportRunList: string;
  volckerDeskName: string;
  accountingTypeSystem: AccountingTypeSystem;
  assetTypeSystem: AccountingTypeSystem;
  capitalHierarchy: AccountingTypeSystem;
  bookTypeSystem: AccountingTypeSystem;
  creditBookTypeSystem: AccountingTypeSystem;  
  tradeBookingSystem: AccountingTypeSystem;
  aggregateTradeCubeFlag: boolean;
  riskHierarchy: RiskHierarchy;
  financeHierarchy: Hierarchy;
  geographyHierarchy: Hierarchy;
  hyperionUnit: AccountingTypeSystem;
  added: Added;
  exclusion: Exclusion;
  isLEGroupSubset: boolean;
  mxLegalEntityCode: string;
  quarantine: Quarantine;
  reviewDate: string;
  reviewer: Reviewer;
  source: AccountingTypeSystem;
  syntheticPortfolio: AccountingTypeSystem;
  isReviewed: boolean;
}

export interface AccountingTypeSystem {
  id: string;
  text: string;
}

export interface Added {
  by: string;
  time: string;
}

export interface Exclusion {
  by: string;
  reason: string;
}

export interface Hierarchy {
  id: string;
  value: string;
}

export interface Quarantine {
  isQuarantined: boolean;
  date: string;
}

export interface Reviewer {
  id: string;
  text: string;
}

export interface RiskHierarchy {
  id: string;
  value: string;
  fullPath: string;
}

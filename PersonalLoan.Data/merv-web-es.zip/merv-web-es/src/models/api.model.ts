import { Request } from 'express';
import { DocumentNode } from 'graphql';

export interface Parameter {
  name: string;
  in: string;
  description?: string;
  required: boolean;
  type: 'boolean' | 'number' | 'object' | 'date' | 'string' | 'datetime' | 'array';
  default?: string;
}

export interface DataSource {
  query: DocumentNode | string | ((params?: any) => DocumentNode | string);
  queryVariables?: (params?: Record<string, any>) => Record<string, any>;
  returnDataName: string;
}

export interface Field {
  name: string;
  typeOf: 'string' | 'number' | 'boolean' | 'dateTime' | 'date';
  field: string;
  displayRenderer?: (params: any) => string;
}

export interface ExportInfo {
  customProcessor: Function | null;
  sortField?: string;
  sortOrder?: 'asc' | 'desc';
  fields: Field[];
}

export interface EndPointInfo {
  name: string;
  filename: string | ((request: Request) => string);
  parameters: Parameter[];
  dataSource: DataSource;
  exportInfo: ExportInfo;
  [name: string]: any;
}

export interface APIMapping {
  get: EndPointInfo;
}

export interface APIMappingEntities {
  [path: string]: APIMapping;
}

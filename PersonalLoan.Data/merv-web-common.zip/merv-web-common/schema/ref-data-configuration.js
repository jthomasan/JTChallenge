const gql = require("graphql-tag");
exports.schema = gql`
  extend input BatchActions {
    replacePortfolioRunList: UpdatePortfolioRunList
    replaceVolckerDeskMapping: UpdateVolckerDeskMapping
    replaceHoldingPeriodNode: UpdateHoldingPeriodNode
    replaceCTDMapping: UpdateCTDMapping
  }

  extend type Query {
    PortfolioRunList: [PortfolioRunList]
    PortfolioCurrentReports: [RefDataConfigReport]
    VolckerDeskMappings: [VolckerDeskMapping]
    VolckerDeskNames: [VolckerDeskName]
    HoldingPeriodNodes: [HoldingPeriodNode]
    CTDMappings: [CTDMapping]
  }

  type PortfolioRunList {
    id: ID!
    modified: Boolean!
    parent: ID
    title: String
    fullPath: String
    currentReports: [RefDataConfigReport]
    inheritedReports: [RefDataConfigReport]
    excludedReports: [RefDataConfigReport]
    added: Added
  }

  type VolckerDeskMapping {
    id: ID!
    modified: Boolean!
    isForVolcker: Boolean
    parent: ID
    title: String
    fullPath: String
    volckerDesk: RefDataConfigReport
    inheritedVolckerDesk: RefDataConfigReport
    added: Added
  }

  type HoldingPeriodNode {
    id: ID!
    modified: Boolean!
    parent: ID
    title: String
    fullPath: String
    isForHoldingPeriod: Boolean
    excludeInternalTrades: Boolean
    added: Added
  }

  type CTDMapping {
    id: ID!
    modified: Boolean!
    isCTD: Boolean
    parent: ID
    title: String
    fullPath: String
    added: Added
  }

  type RefDataConfigReport {
    id: ID
    text: String
  }

  type VolckerDeskName {
    id: ID
    text: String
  }

  input UpdatePortfolioRunList {
    id: ID
    currentReports: [ConfigInputOptionType]
    excludedReports: [ConfigInputOptionType]
  }

  input UpdateVolckerDeskMapping {
    id: ID
    isForVolcker: Boolean
    volckerDesk: ConfigInputOptionType
  }

  input UpdateHoldingPeriodNode {
    id: ID
    isForHoldingPeriod: Boolean
    excludeInternalTrades: Boolean
  }

  input UpdateCTDMapping {
    id: ID
    isCTD: Boolean
  }

  input ConfigInputOptionType {
    id: ID!
    text: String
  }
`;

const gql = require("graphql-tag");
exports.schema = gql`
  extend type Query {
    Hierarchies: [Hierarchy]
    Nodes(id: ID, typeId: ID, cob: Date): [Node]
    Portfolios(
      nodeId: ID
      typeId: ID
      titleSearch: String
      cob: Date
    ): [Portfolio]
    ClassificationOptions: ClassificationOptions
  }

  type NodeId {
    nodeId: ID
  }

  enum HierarchyRef {
    RISK_PORTFOLIO
    GEOGRAPHY
    LEGAL_ENTITY
    FINANCE_BUSINESS
    REVENUE
  }

  type Hierarchy {
    id: ID!
    ref: HierarchyRef
    name: String
    maxLevel: Int!
    applyClassification: Boolean
  }

  type Node {
    id: ID!
    typeId: ID
    title: String!
    portfolios: [Portfolio]
    fullPath: String
    parent: ID
    children: [ID]
    classification: Classification
  }

  type Portfolio {
    id: Int!
    title: String!
    isActive: Boolean!
    createdOn: DateTime!
    source: String
    classification: Classification
    parent: NodeId
  }

  type Classification {
    assetType: String
    capitalMultiplier: String
    hyperionUnit: String
    syntheticPortfolio: String
    comment: String
  }

  type AssetTypeOption {
    id: String!
    text: String!
  }

  type HyperionUnitOption {
    id: ID
    text: String
  }
  type SyntheticPortfolioOption {
    id: ID
    text: String
  }

  type ClassificationOptions {
    assetType: [AssetTypeOption]
    capitalMultiplier: [CapitalMultiplierOption]
    hyperionUnit: [HyperionUnitOption]
    syntheticPortfolio: [SyntheticPortfolioOption]
  }

  extend input BatchActions {
    renameNode: RenameNode
    deleteNode: DeleteNode
    addNode: AddNode
    setNodeClassification: SetNodeClassification
    setPortfolioClassification: SetPortfolioClassification
    moveNode: MoveNode
  }

  input RenameNode {
    nodeId: ID!
    typeId: ID!
    title: String!
  }

  input DeleteNode {
    nodeId: ID!
    typeId: ID!
  }

  input AddNode {
    nodeId: ID!
    parent: NodeIdInput!
    title: String!
    typeId: ID!
  }

  input SetNodeClassification {
    typeId: ID!
    nodeId: ID!
    assetType: String!
    capitalMultiplier: String!
    hyperionUnit: String
    syntheticPortfolio: String
    comment: String
  }

  input SetPortfolioClassification {
    portfolioId: ID!
    assetType: String!
    capitalMultiplier: String!
    hyperionUnit: String!
    syntheticPortfolio: String
    comment: String
  }

  input MoveNode {
    nodeId: ID!
    parent: NodeIdInput!
    typeId: ID!
  }

  input NodeIdInput {
    nodeId: ID!
  }
`;

const gql = require("graphql-tag");
exports.schema = gql`
  extend input BatchActions {
    replaceStaticDataPortfolio: UpdateStaticDataPortfolio
    addStaticDataPortfolio: UpdateStaticDataPortfolio
    acknowledgeStaticDataPortfolio: UpdateStaticDataPortfolio
    replaceStaticDataRevenueCode: UpdateStaticDataRevenueCode
    addStaticDataRevenueCode: UpdateStaticDataRevenueCode
    replaceStaticDataCapitalHierarchy: UpdateStaticDataCapitalHierarchy
    addStaticDataCapitalHierarchy: UpdateStaticDataCapitalHierarchy
    addStaticDataProductHierarchy: UpdateStaticDataProductHierarchy
    replaceStaticDataProductHierarchy: UpdateStaticDataProductHierarchy
    addStaticDataUnderlyingIRCurve: UpdateStaticDataUnderlyingIRCurve
    replaceStaticDataUnderlyingIRCurve: UpdateStaticDataUnderlyingIRCurve
    addStaticDataLegalEntityHierarchy: UpdateStaticDataLegalEntityHierarchy
    replaceStaticDataLegalEntityHierarchy: UpdateStaticDataLegalEntityHierarchy
    addStaticDataHaircutReference: UpdateStaticDataHaircutReference
    replaceStaticDataHaircutReference: UpdateStaticDataHaircutReference
    addStaticDataBespokeHaircut: UpdateStaticDataBespokeHaircut
    replaceStaticDataBespokeHaircut: UpdateStaticDataBespokeHaircut
    addStaticDataHoldingPeriodTrade: UpdateStaticDataHoldingPeriodTrade
    replaceStaticDataHoldingPeriodTrade: UpdateStaticDataHoldingPeriodTrade
    addStaticDataGrpCOMType: UpdateStaticDataGrpCOMType
    replaceStaticDataGrpCOMType: UpdateStaticDataGrpCOMType
    addStaticDataInstrumentCreditIndexType: UpdateStaticDataInstrumentCreditIndexType
    replaceStaticDataInstrumentCreditIndexType: UpdateStaticDataInstrumentCreditIndexType
    addStaticDataCommodityTypeMapping: UpdateStaticDataCommodityTypeMapping
    replaceStaticDataCommodityTypeMapping: UpdateStaticDataCommodityTypeMapping
    addStaticDataGrpCOMUnit: UpdateStaticDataGrpCOMUnit
    replaceStaticDataGrpCOMUnit: UpdateStaticDataGrpCOMUnit
    addStaticDataGrpCOMIndexName: UpdateStaticDataGrpCOMIndexName
    replaceStaticDataGrpCOMIndexName: UpdateStaticDataGrpCOMIndexName
    addStaticDataUnderlyingCCYPAIR: UpdateStaticDataUnderlyingCCYPAIR
    replaceStaticDataUnderlyingCCYPAIR: UpdateStaticDataUnderlyingCCYPAIR
    addStaticDataSpecificRiskCapitalCharge: UpdateStaticDataSpecificRiskCapitalCharge
    replaceStaticDataSpecificRiskCapitalCharge: UpdateStaticDataSpecificRiskCapitalCharge
    addStaticDataUnderlyingCOM: UpdateStaticDataUnderlyingCOM
    replaceStaticDataUnderlyingCOM: UpdateStaticDataUnderlyingCOM
    addStaticDataUnderlyingCCY: UpdateStaticDataUnderlyingCCY
    replaceStaticDataUnderlyingCCY: UpdateStaticDataUnderlyingCCY
    addStaticDataSTFSector: UpdateStaticDataSTFSector
    replaceStaticDataSTFSector: UpdateStaticDataSTFSector
    addStaticDataGrpCOMDeltaGammaLotConversionFactor: UpdateStaticDataGrpCOMDeltaGammaLotConversionFactor
    replaceStaticDataGrpCOMDeltaGammaLotConversionFactor: UpdateStaticDataGrpCOMDeltaGammaLotConversionFactor
    addStaticDataCurrencyPairStealthType: UpdateStaticDataCurrencyPairStealthType
    replaceStaticDataCurrencyPairStealthType: UpdateStaticDataCurrencyPairStealthType
    addStaticDataCCYFamilyFXO: UpdateStaticDataCCYFamilyFXO
    replaceStaticDataCCYFamilyFXO: UpdateStaticDataCCYFamilyFXO
    addStaticDataCurveTypeCurve: UpdateStaticDataCurveTypeCurve
    replaceStaticDataCurveTypeCurve: UpdateStaticDataCurveTypeCurve
    addStaticDataGrpCOMSubType: UpdateStaticDataGrpCOMSubType
    replaceStaticDataGrpCOMSubType: UpdateStaticDataGrpCOMSubType
    addStaticDataCreditBook: UpdateStaticDataCreditBook
    replaceStaticDataCreditBook: UpdateStaticDataCreditBook
    addStaticDataHyperionUnit: UpdateStaticDataHyperionUnit
    replaceStaticDataHyperionUnit: UpdateStaticDataHyperionUnit
    addStaticDataCCYGroup: UpdateStaticDataCCYGroup
    replaceStaticDataCCYGroup: UpdateStaticDataCCYGroup
    addStaticDataAssetType: UpdateStaticDataAssetType
    replaceStaticDataAssetType: UpdateStaticDataAssetType
    addStaticDataD2ADefaultNamespace: UpdateStaticDataD2ADefaultNamespace
    replaceStaticDataD2ADefaultNamespace: UpdateStaticDataD2ADefaultNamespace
    addStaticDataInstrumentAPRARank: UpdateStaticDataInstrumentAPRARank
    replaceStaticDataInstrumentAPRARank: UpdateStaticDataInstrumentAPRARank
    addStaticDataInternalCounterParty: UpdateStaticDataInternalCounterParty
    replaceStaticDataInternalCounterParty: UpdateStaticDataInternalCounterParty
    addStaticDataCOMANZStressGroup: UpdateStaticDataCOMANZStressGroup
    replaceStaticDataCOMANZStressGroup: UpdateStaticDataCOMANZStressGroup
    addStaticDataCOMAPRAStressLabel: UpdateStaticDataCOMAPRAStressLabel
    replaceStaticDataCOMAPRAStressLabel: UpdateStaticDataCOMAPRAStressLabel
    addStaticDataLiquidityGeoMapping: UpdateStaticDataLiquidityGeoMapping
    replaceStaticDataLiquidityGeoMapping: UpdateStaticDataLiquidityGeoMapping
    addStaticDataSeniorityMap: UpdateStaticDataSeniorityMap
    replaceStaticDataSeniorityMap: UpdateStaticDataSeniorityMap
    addStaticDataCOMPriceQuotation: UpdateStaticDataCOMPriceQuotation
    replaceStaticDataCOMPriceQuotation: UpdateStaticDataCOMPriceQuotation
    addStaticDataGrpSTFGeography: UpdateStaticDataGrpSTFGeography
    replaceStaticDataGrpSTFGeography: UpdateStaticDataGrpSTFGeography
    addStaticDataCCYCDSDeliverable: UpdateStaticDataCCYCDSDeliverable
    replaceStaticDataCCYCDSDeliverable: UpdateStaticDataCCYCDSDeliverable
    addStaticDataCCYPairFamily: UpdateStaticDataCCYPairFamily
    replaceStaticDataCCYPairFamily: UpdateStaticDataCCYPairFamily
    addStaticDataIssuerFamily: UpdateStaticDataIssuerFamily
    replaceStaticDataIssuerFamily: UpdateStaticDataIssuerFamily
    addStaticDataIssuerGuaranteed: UpdateStaticDataIssuerGuaranteed
    replaceStaticDataIssuerGuaranteed: UpdateStaticDataIssuerGuaranteed
    addStaticDataIssuerType: UpdateStaticDataIssuerType
    replaceStaticDataIssuerType: UpdateStaticDataIssuerType
    addStaticDataGrpNationalMarket: UpdateStaticDataGrpNationalMarket
    replaceStaticDataGrpNationalMarket: UpdateStaticDataGrpNationalMarket
    addStaticDataEQSpecificRiskWeight: UpdateStaticDataEQSpecificRiskWeight
    replaceStaticDataEQSpecificRiskWeight: UpdateStaticDataEQSpecificRiskWeight
    addStaticDataGrpEQRegion: UpdateStaticDataGrpEQRegion
    replaceStaticDataGrpEQRegion: UpdateStaticDataGrpEQRegion
    addStaticDataGrpEQTier: UpdateStaticDataGrpEQTier
    replaceStaticDataGrpEQTier: UpdateStaticDataGrpEQTier
    addStaticDataGrpEQType: UpdateStaticDataGrpEQType
    replaceStaticDataGrpEQType: UpdateStaticDataGrpEQType
    addStaticDataD2AForms: UpdateStaticDataD2AForms
    replaceStaticDataD2AForms: UpdateStaticDataD2AForms
    addStaticDataCountry: UpdateStaticDataCountry
    replaceStaticDataCountry: UpdateStaticDataCountry
    addStaticDataApportionmentExclusion: UpdateStaticDataApportionmentExclusion
    replaceStaticDataApportionmentExclusion: UpdateStaticDataApportionmentExclusion
    addStaticDataCICSIssuerCodeMappingType: UpdateStaticDataCICSIssuerCodeMappingType
    replaceStaticDataCICSIssuerCodeMappingType: UpdateStaticDataCICSIssuerCodeMappingType
    addStaticDataIssuer: UpdateStaticDataIssuer
    replaceStaticDataIssuer: UpdateStaticDataIssuer
    addStaticDataStealthHealthRange: UpdateStaticDataStealthHealthRange
    replaceStaticDataStealthHealthRange: UpdateStaticDataStealthHealthRange
    addStaticDataRiskThresholdCatchAll: UpdateStaticDataRiskThresholdCatchAll
    replaceStaticDataRiskThresholdCatchAll: UpdateStaticDataRiskThresholdCatchAll
    addStaticDataHoldingPeriodExcludedIssuerCcy: UpdateStaticDataHoldingPeriodExcludedIssuerCcy
    replaceStaticDataHoldingPeriodExcludedIssuerCcy: UpdateStaticDataHoldingPeriodExcludedIssuerCcy
    addStaticDataSingleCurveTypeCurve: UpdateStaticDataSingleCurveTypeCurve
    replaceStaticDataSingleCurveTypeCurve: UpdateStaticDataSingleCurveTypeCurve
    addStaticDataCCYPairOnOffShore: UpdateStaticDataCCYPairOnOffShore
    replaceStaticDataCCYPairOnOffShore: UpdateStaticDataCCYPairOnOffShore
    addStaticDataNationalMarket: UpdateStaticDataNationalMarket
    replaceStaticDataNationalMarket: UpdateStaticDataNationalMarket
    addStaticDataSpecificRiskLongTermIssue: UpdateStaticDataSpecificRiskLongTermIssue
    replaceStaticDataSpecificRiskLongTermIssue: UpdateStaticDataSpecificRiskLongTermIssue
    addStaticDataSpecificRiskShortTermIssue: UpdateStaticDataSpecificRiskShortTermIssue
    replaceStaticDataSpecificRiskShortTermIssue: UpdateStaticDataSpecificRiskShortTermIssue
    addStaticDataCRDIComposition: UpdateStaticDataCRDIComposition
    replaceStaticDataCRDIComposition: UpdateStaticDataCRDIComposition
    addStaticDataUnderlyingEq: UpdateStaticDataUnderlyingEq
    replaceStaticDataUnderlyingEq: UpdateStaticDataUnderlyingEq
    addStaticDataLongTermCreditRating: UpdateStaticDataLongTermCreditRating
    replaceStaticDataLongTermCreditRating: UpdateStaticDataLongTermCreditRating
    addStaticDataVolckerDesk: UpdateStaticDataVolckerDesk
    replaceStaticDataVolckerDesk: UpdateStaticDataVolckerDesk
    addStaticDataSpecRiskTradeExclusion: UpdateStaticDataSpecRiskTradeExclusion
    replaceStaticDataSpecRiskTradeExclusion: UpdateStaticDataSpecRiskTradeExclusion
    addStaticDataCounterparty: UpdateStaticDataCounterparty
    replaceStaticDataCounterparty: UpdateStaticDataCounterparty
    addStaticDataGeography: UpdateStaticDataGeography
    replaceStaticDataGeography: UpdateStaticDataGeography
    addStaticDataEquityUnderlyingSpecificRiskMap: UpdateStaticDataEquityUnderlyingSpecificRiskMap
    replaceStaticDataEquityUnderlyingSpecificRiskMap: UpdateStaticDataEquityUnderlyingSpecificRiskMap
    addStaticDataEquityVegaOptionExpiryNetBucketsCapFloor: UpdateStaticDataEquityVegaOptionExpiryNetBucketsCapFloor
    replaceStaticDataEquityVegaOptionExpiryNetBucketsCapFloor: UpdateStaticDataEquityVegaOptionExpiryNetBucketsCapFloor
    addStaticDataCreditStressBondIssuer: UpdateStaticDataCreditStressBondIssuer
    replaceStaticDataCreditStressBondIssuer: UpdateStaticDataCreditStressBondIssuer
    addStaticDataEquityVegaNetBuckets: UpdateStaticDataEquityVegaNetBuckets
    replaceStaticDataEquityVegaNetBuckets: UpdateStaticDataEquityVegaNetBuckets
    addStaticDataFXOVegaNetBuckets: UpdateStaticDataFXOVegaNetBuckets
    replaceStaticDataFXOVegaNetBuckets: UpdateStaticDataFXOVegaNetBuckets
    addStaticDataVegaOptionExpiryNetBucketsSwaptionEtOs: UpdateStaticDataVegaOptionExpiryNetBucketsSwaptionEtOs
    replaceStaticDataVegaOptionExpiryNetBucketsSwaptionEtOs: UpdateStaticDataVegaOptionExpiryNetBucketsSwaptionEtOs
    addStaticDataVegaUnderlyingSwapBondMaturityNetBuckets: UpdateStaticDataVegaUnderlyingSwapBondMaturityNetBuckets
    replaceStaticDataVegaUnderlyingSwapBondMaturityNetBuckets: UpdateStaticDataVegaUnderlyingSwapBondMaturityNetBuckets
    addStaticDataNetBucketingCr01: UpdateStaticDataNetBucketingCr01
    replaceStaticDataNetBucketingCr01: UpdateStaticDataNetBucketingCr01
    addStaticDataNetBucketingDv01SrIrgCpiDv01: UpdateStaticDataNetBucketingDv01SrIrgCpiDv01
    replaceStaticDataNetBucketingDv01SrIrgCpiDv01: UpdateStaticDataNetBucketingDv01SrIrgCpiDv01
    addStaticDataNetBucketingSingleCcyBasis: UpdateStaticDataNetBucketingSingleCcyBasis
    replaceStaticDataNetBucketingSingleCcyBasis: UpdateStaticDataNetBucketingSingleCcyBasis
    addStaticDataNetBucketingXccyBasisBasisGamma: UpdateStaticDataNetBucketingXccyBasisBasisGamma
    replaceStaticDataNetBucketingXccyBasisBasisGamma: UpdateStaticDataNetBucketingXccyBasisBasisGamma
    addStaticDataCreditStressCdsRating: UpdateStaticDataCreditStressCdsRating
    replaceStaticDataCreditStressCdsRating: UpdateStaticDataCreditStressCdsRating
    addStaticDataCreditStressCreditIndices: UpdateStaticDataCreditStressCreditIndices
    replaceStaticDataCreditStressCreditIndices: UpdateStaticDataCreditStressCreditIndices
    addStaticDataCreditStressTopCdsIssuers: UpdateStaticDataCreditStressTopCdsIssuers
    replaceStaticDataCreditStressTopCdsIssuers: UpdateStaticDataCreditStressTopCdsIssuers
    addStaticDataGenericSeniority: UpdateStaticDataGenericSeniority
    replaceStaticDataGenericSeniority: UpdateStaticDataGenericSeniority
    addStaticDataCreditStressSpreadTenBondDefaultStress: UpdateStaticDataCreditStressSpreadTenBondDefaultStress
    replaceStaticDataCreditStressSpreadTenBondDefaultStress: UpdateStaticDataCreditStressSpreadTenBondDefaultStress
    addStaticDataRepoTypologyMap: UpdateStaticDataRepoTypologyMap
    replaceStaticDataRepoTypologyMap: UpdateStaticDataRepoTypologyMap
    addStaticDataRatingOverride: UpdateStaticDataRatingOverride
    replaceStaticDataRatingOverride: UpdateStaticDataRatingOverride
    addStaticDataStealthMaturityRange: UpdateStaticDataStealthMaturityRange
    replaceStaticDataStealthMaturityRange: UpdateStaticDataStealthMaturityRange
    addStaticDataCreditStressBondRating: UpdateStaticDataCreditStressBondRating
    replaceStaticDataCreditStressBondRating: UpdateStaticDataCreditStressBondRating
    addStaticDataCustomMember: UpdateStaticDataCustomMember
    replaceStaticDataCustomMember: UpdateStaticDataCustomMember
    addStaticDataTenorDaysToMaturity: UpdateStaticDataTenorDaysToMaturity
    replaceStaticDataTenorDaysToMaturity: UpdateStaticDataTenorDaysToMaturity
    addStaticDataLMENonDeliveryDay: UpdateStaticDataLMENonDeliveryDay
    replaceStaticDataLMENonDeliveryDay: UpdateStaticDataLMENonDeliveryDay
    addStaticDataPortfolioConfig: UpdateStaticDataPortfolioConfig
    replaceStaticDataPortfolioConfig: UpdateStaticDataPortfolioConfig
    addStaticDataInstrumentAssetSwapSpread: UpdateStaticDataInstrumentAssetSwapSpread
    replaceStaticDataInstrumentAssetSwapSpread: UpdateStaticDataInstrumentAssetSwapSpread
    addStaticDataMarketRiskBusinessGroup: UpdateStaticDataMarketRiskBusinessGroup
    replaceStaticDataMarketRiskBusinessGroup: UpdateStaticDataMarketRiskBusinessGroup
    addMarketRiskBusinessMapping: UpdateMarketRiskBusinessMapping
    replaceMarketRiskBusinessMapping: UpdateMarketRiskBusinessMapping
    addStaticDataLimitClassifications: UpdateStaticDataLimitClassifications
    replaceStaticDataLimitClassifications: UpdateStaticDataLimitClassifications
    addStaticDataInstrument: UpdateStaticDataInstrument
    replaceStaticDataInstrument: UpdateStaticDataInstrument
    addStaticDataExcessReasons: UpdateStaticDataExcessReasons
    replaceStaticDataExcessReasons: UpdateStaticDataExcessReasons
    addStaticDataPurposeForChange: UpdateStaticDataPurposeForChange
    replaceStaticDataPurposeForChange: UpdateStaticDataPurposeForChange
    addStaticDataDynamicLimitThreshold: UpdateStaticDataDynamicLimitThreshold
    replaceStaticDataDynamicLimitThreshold: UpdateStaticDataDynamicLimitThreshold
    addStaticDataGlobalProductLine: UpdateStaticDataGlobalProductLine
    replaceStaticDataGlobalProductLine: UpdateStaticDataGlobalProductLine
    addMarketRiskBusinessAssignmentMapping: UpdateMarketRiskBusinessAssignmentMapping
    replaceMarketRiskBusinessAssignmentMapping: UpdateMarketRiskBusinessAssignmentMapping
    addCMRCPeriod: UpdateCMRCPeriod
    replaceCMRCPeriod: UpdateCMRCPeriod
    addMarketRiskBusinessGroupEmailMapping: UpdateMarketRiskBusinessGroupEmailMapping
    replaceMarketRiskBusinessGroupEmailMapping: UpdateMarketRiskBusinessGroupEmailMapping
    addProductSubCategoryMapping: UpdateProductSubCategoryMapping
    replaceProductSubCategoryMapping: UpdateProductSubCategoryMapping
    addScheduleMapping: UpdateScheduleMapping
    replaceScheduleMapping: UpdateScheduleMapping
    addStaticDataCreditExtraOrdinaryStress: UpdateStaticDataCreditExtraOrdinaryStress
    replaceStaticDataCreditExtraOrdinaryStress: UpdateStaticDataCreditExtraOrdinaryStress
  }

  extend type Query {
    CapitalMultiplier: [CapitalMultiplierOption]
    AssetType: [AssetTypeSystemOption]
    RiskHierarchy: [RiskHierarchyOption]
    GeographyHierarchy: [GeographyHierarchyOption]
    RevenueCodeHierarchy: [RevenueCodeHierarchyOption]
    FinanceHierarchy: [FinanceHierarchyOption]
    HyperionUnit: [HyperionUnitOption]
    SyntheticPortfolio: [SyntheticPortfolioOption]
    BookType: [BookTypeSystemOption]
    AccountingType: [AccountingTypeSystemOption]
    CreditBookType: [CreditBookTypeSystemOption]
    Source: [SourceDropDownOption]
    UserList: [UserListOption]
    StaticDataAuditHistory(
      staticDataTypeId: ID
      auditId: ID
      additionalParam: JSON
    ): StaticDataAuditHistoryType
    StaticDataPortfolios: [StaticDataPortfolio]
    StaticDataRevenueCodes: [StaticDataRevenueCode]
    StaticDataLegalEntities: [StaticDataLegalEntity]
    StaticDataCapitalHierarchies: [StaticDataCapitalHierarchy]
    StaticDataAssetTypes: [StaticDataAssetType]
    StaticDataBookTypes: [StaticDataBookType]
    StaticDataInstrumentAPRARanks: [StaticDataInstrumentAPRARank]
    StaticDataHyperionUnits: [StaticDataHyperionUnit]
    StaticDataCreditBooks: [StaticDataCreditBook]
    StaticDataInstrumentCreditIndexTypes: [StaticDataInstrumentCreditIndexType]
    StaticDataUnderlyingCCYs: [StaticDataUnderlyingCCY]
    StaticDataCountries: [StaticDataCountry]
    StaticDataSeniorityMaps: [StaticDataSeniorityMap]
    StaticDataIssuerFamilies: [StaticDataIssuerFamily]
    StaticDataIssuerTypes: [StaticDataIssuerType]
    StaticDataIssuerGuaranteedList: [StaticDataIssuerGuaranteed]
    StaticDataLongTermCreditRatings(
      agency: [String!]
    ): [StaticDataLongTermCreditRating]
    StaticDataCapletSwaptionVegaBuckets: [StaticDataCapletSwaptionVegaBucket]
    StaticDataGenericSeniorities: [StaticDataGenericSeniority]
    StaticDataInstrumentAssetSwapSpreads(cob: Date): Any
    StaticDataCCYGroups: [StaticDataCCYGroup]
    StaticDataSTFSectors: [StaticDataSTFSector]
    StaticDataCCYCDSDeliverables: [StaticDataCCYCDSDeliverable]
    StaticDataCCYFamilyFXOs(cob: Date): [StaticDataCCYFamilyFXO]
    StaticDataCCYPairOnOffShores: [StaticDataCCYPairOnOffShore]
    StaticDataCCYPairFamilies: [StaticDataCCYPairFamily]
    StaticDataCurrencyPairStealthTypes: [StaticDataCurrencyPairStealthType]
    StaticDataInternalCounterParties: [StaticDataInternalCounterParty]
    StaticDataCOMDeltaGammaLotConversionFactors: [StaticDataCOMDeltaGammaLotConversionFactor]
    StaticDataCOMAPRAStressLabels: [StaticDataCOMAPRAStressLabel]
    StaticDataUnderlyingCCYPairs: [StaticDataUnderlyingCCYPair]
    StaticDataUnderlyingCOMs: [StaticDataUnderlyingCOM]
    StaticDataCOMIndexNames: [StaticDataCOMIndexName]
    StaticDataEQSpecificRiskWeights: [StaticDataEQSpecificRiskWeight]
    StaticDataUnderlyingIRCurves: [StaticDataUnderlyingIRCurve]
    StaticDataCOMPriceQuotations: [StaticDataCOMPriceQuotation]
    StaticDataCOMTypes: [StaticDataCOMType]
    StaticDataCOMSubTypes: [StaticDataCOMSubType]
    StaticDataSingleCurveTypeCurves: [StaticDataSingleCurveTypeCurve]
    StaticDataCOMUnits: [StaticDataCOMUnit]
    StaticDataCurveTypeCurves: [StaticDataCurveTypeCurve]
    StaticDataGeographies: [StaticDataGeography]
    StaticDataGrpNationalMarkets: [StaticDataGrpNationalMarket]
    StaticDataStealthHealthRanges: [StaticDataStealthHealthRangeType]
    StaticDataCOMANZStressGroups: [StaticDataCOMANZStressGroup]
    StaticDataUnderlyingEQs: [StaticDataUnderlyingEQType]
    StaticDataStealthMaturityRanges: [StaticDataStealthMaturityRangeType]
    StaticDataGenericTermPillarsBaseMetalsDeltaVegas: [StaticDataGenericTermPillarsBaseMetalsDeltaVega]
    StaticDataEquityVegaNetBuckets: [StaticDataEquityVegaNetBucket]
    StaticDataFXOVegaNetBuckets: [StaticDataFXOVegaNetBucket]
    StaticDataNationalMarkets: [StaticDataNationalMarket]
    StaticDataCreditStressBondRatings: [StaticDataCreditStressBondRating]
    StaticDataCreditStressCDSRatings: [StaticDataCreditStressCDSRating]
    StaticDataCreditStressTopCDSIssuers: [StaticDataCreditStressTopCDSIssuer]
    StaticDataHaircutReferences: [StaticDataHaircutReference]
    StaticDataBespokeHaircuts: [StaticDataBespokeHaircut]
    StaticDataD2ADefaultNamespaces: [StaticDataD2ADefaultNamespace]
    StaticDataGrpEQTypes: [StaticDataGrpEQType]
    StaticDataGrpEQRegions: [StaticDataGrpEQRegion]
    StaticDataGrpEQTiers: [StaticDataGrpEQTier]
    StaticDataCreditStressCreditIndices: [StaticDataCreditStressCreditIndice]
    StaticDataCreditStressSpreadTenBondDefaultStresses: [StaticDataCreditStressSpreadTenBondDefaultStress]
    StaticDataCreditStressBondIssuers: [StaticDataCreditStressBondIssuer]
    StaticDataCICSIssuerCodeMappings: [StaticDataCICSIssuerCodeMappingType]
    StaticDataEquityVegaUnderlyingBondETOTenors: [StaticDataEquityVegaUnderlyingBondETOTenor]
    StaticDataVegaOptionExpiryNetBucketsCapFloorList: [StaticDataVegaOptionExpiryNetBucketsCapFloor]
    StaticDataGrpSTFGeographies: [StaticDataGrpSTFGeography]
    StaticDataGenericTermPilarsPetroleumVegas: [StaticDataGenericTermPilarsPetroleumVega]
    StaticDataApportionmentExclusions: [StaticDataApportionmentExclusion]
    StaticDataCRDICompositions(cob: Date): [StaticDataCRDIComposition]
    StaticDataVegaOptionExpiryNetBucktsSwaptionEtos: [StaticDataVegaOptionExpiryNetBucktsSwaptionEtoType]
    StaticDataDTwoAForms: [StaticDataDTwoAForm]
    StaticDataEquityUnderlyingSpecificRiskMaps: [StaticDataEquityUnderlyingSpecificRiskMap]
    StaticDataCommodityTypeMappings: [StaticDataCommodityTypeMapping]
    StaticDataLMENonDeliveryDays: [StaticDataLMENonDeliveryDay]
    StaticDataRatingOverrides: [StaticDataRatingOverride]
    StaticDataRepoTypologyMaps: [StaticDataRepoTypologyMap]
    StaticDataRiskThresholdCatchAllList: [StaticDataRiskThresholdCatchAll]
    StaticDataShortTermCreditRatings: [StaticDataShortTermCreditRating]
    StaticDataSpecRiskTradeExclusions: [StaticDataSpecRiskTradeExclusion]
    StaticDataSpecificRiskCapitalCharges: [StaticDataSpecificRiskCapitalCharge]
    StaticDataGenericTermPillarsCoalIronOreDeltas: [StaticDataGenericTermPillarsCoalIronOreDeltaType]
    StaticDataGenericTermPillarsPetroleumDeltas: [StaticDataGenericTermPillarsPetroleumDeltaType]
    StaticDataGenericTermPillarsEmissions: [StaticDataGenericTermPillarsEmissionType]
    StaticDataSpecificRiskLongTermIssues: [StaticDataSpecificRiskLongTermIssue]
    StaticDataVegaUnderlyingSwapBondMaturityNetBuckets: [StaticDataVegaUnderlyingSwapBondMaturityNetBucket]
    StaticDataCustomMembers: [StaticDataCustomMember]
    StaticDataHoldingPeriodExcludedIssuerCcys: [StaticDataHoldingPeriodExcludedIssuerCcyType]
    StaticDataLiquidityGeoMappings: [StaticDataLiquidityGeoMapping]
    StaticDataSpecificRiskShortTermIssues: [StaticDataSpecificRiskShortTermIssue]
    StaticDataVegaNetBucketingAllList: [StaticDataVegaNetBucketingAll]
    StaticDataHoldingPeriodTrades(cob: Date): [StaticDataHoldingPeriodTradeType]
    StaticDataPillarXCCYBasisBasisGammaList: [StaticDataPillarXCCYBasisBasisGamma]
    StaticDataTenorAndDaystoMaturities: [StaticDataTenorAndDaystoMaturity]
    StaticDataPillarsSingleCCYBasisList: [StaticDataPillarsSingleCCYBasis]
    StaticDataNetBucketingCR01List: [StaticDataNetBucketingCR01]
    StaticDataNetBucketingDV01List: [StaticDataNetBucketingDV01]
    StaticDataPillarsDV01List: [StaticDataPillarsDV01]
    StaticDataPillarsVegaETOBonds: [StaticDataPillarsVegaETOBond]
    StaticDataNetBucketXccyBasisGammas: [StaticDataNetBucketXccyBasisGammaType]
    StaticDataNetBucketSingleCcyBasisList: [StaticDataNetBucketSingleCcyBasisType]
    StaticDataPillarsCr01s: [StaticDataPillarsCr01Type]
    StaticDataProductHierarchies: [StaticDataProductHierarchy]
    StaticDataRepoStfSensitivities: [StaticDataRepoStfSensitivityType]
    StaticDataCounterparties: Any
    StaticDataIssuers: Any
    ReturnIdentifiers: [ReturnIdentifierOption]
    SingleCurveType: [SCCYTypeTypeSystemOption]
    CurveType: [CurveTypeSystemOption]
    LegalEntityHierarchy: [LegalEntityHierarchyType]
    CommodityUnderlyingCode: [CommodityUnderlyingCodeOption]
    StaticDataVolckerDesk: [StaticDataVolckerDeskType]
    CCYPairFamily: [CCYPairFamilyTypeSystemOption]
    CCYPairOnOffShore: [CCYPairFamilyTypeSystemOption]
    SrCategory: [SRCategoryInputOption]
    SrTenor: [TenorInputOption]
    RatingBandTypeSystem(sRCategoryId: ID): [SrRatingBandTypeSystemOption]
    PriceQuotationTypeSystem: [PriceQuotationTypeSystemOption]
    ProductGroupTypeSystem: [ProductGroupTypeSystemOption]
    ProductSubGroupTypeSystem: [ProductSubGroupTypeSystemOption]
    ApraStressLabelTypeSystem: [APRAStressLabelTypeSystemOption]
    AnzStressLabelTypeSystem: [ANZStressLabelTypeSystemOption]
    IndexNameTypeSystem: [IndexNameTypeSystemOption]
    UnitTypeSystem: [UnitTypeSystemOption]
    DeltaGammaLotConversionTypeSystem: [DeltaGammaLotConversionTypeSystemOption]
    CCYFamilyGroup: [CCYFamilyFXOTypeSystemOption]
    CCYGroupType: [CCYGroupTypeSystemOption]
    CCYCdsDeliverableType: [CCYCdsDeliverableTypeSystemOption]
    CurveList: [CurveListOption]
    StaticDataInstruments(type: String): Any
    GenericSeniority: [GenericSeniorityInputOption]
    BaseCurrency: [BaseCurrencyInputOption]
    Geography: [GeographyInputOption]
    STFGeographyTypeSystem: [STFGeographyTypeSystemOption]
    FRTBGeographyTypeSystem: [FRTBGeographyTypeSystemOption]
    CICSIssuer: [IssuerInputOption]
    IssuerType: [IssuerTypeInputOption]
    RatingBandOverrideTypeSystem: [RatingBandOverrideTypeSystemInputOption]
    IssuerFamilyType: [IssuerFamilyTypeInputOption]
    IssuerGuaranteedTypeSystem: [IssuerGuaranteedTypeSystemInputOption]
    SnpIssueRatingTypeSystem: [SnpIssueRatingTypeSystemInputOption]
    MOIssueRatingTypeSystem: [MOIssueRatingTypeSystemInputOption]
    FitchIssueRatingTypeSystem: [FitchIssueRatingTypeSystemInputOption]
    StfSectorTypeSystem: [StfSectorTypeSystemInputOption]
    Currency: [CCYOption]
    NationalMarketType: [NationalMarketTypeSystem]
    SecurityMarket: [SecurityMarketOptionType]
    EQType: [EQTypeTypeSystemOption]
    EQRegion: [EQRegionTypeSystemOption]
    EQTier: [EQTierTypeSystemOption]
    EQSpecificRiskWeight: [EQSpecificRiskWeightTypeSystemOption]
    GlobalBusinessUnit: [GlobalBusinessUnitType]
    ReportingCategory: [ReportingCategoryType]
    ReportType: [ReportTypeOption]
    Country: [CountryInputOption]
    InternalCounterparty: [InternalCounterpartyInputOption]
    STFSector: [STFSectorInputOption]
    UnderlyingEQList: [UnderlyingEQListOption]
    NetBucketCR01: [NetBucketCR01Option]
    ANZRatingBand: [ANZRatingBandOption]
    CRIndexType: [CRIndexTypeOption]
    Agency: [AgencyOption]
    Operation: [OperationTypeOption]
    UnderlyingType: [UnderlyingTypeOption]
    UnderlyingNameList(typeId: Int): [UnderlyingNameListOption]
    TenorList: [TenorListInputOption]
    StaticDataPortfolioConfigs: [StaticDataPortfolioConfig]
    Portfolio: [PortfolioInputOption]
    SourceSystems: [SourceSystemsInputOption]
    OfficialSources(sources: [String]): [SourceSystemsInputOption]
    CMRCPeriods: [CMRCPeriod]
    Months: [MonthType]
    StaticDataDynamicLimitThresholds: [StaticDataDynamicLimitThreshold]
    StaticDataExcessReasons: [StaticDataExcessReason]
    MarketRiskBusinessGroupEmailMappings: [MarketRiskBusinessGroupEmailMapping]
    StaticDataMarketRiskBusinessGroups: [StaticDataMarketRiskBusinessGroup]
    StaticDataLimitClassifications: [StaticDataLimitClassification]
    MarketRiskBusinessMappings: [MarketRiskBusinessMapping]
    StaticDataPurposeForChanges: [StaticDataPurposeForChange]
    StaticDataGlobalProductLines: [StaticDataGlobalProductLine]
    ProductSubCategoryMappings: [ProductSubCategoryMapping]
    MarketRiskBusinessAssignmentMappings: [MarketRiskBusinessAssignmentMapping]
    MRBusinessGrouping: [MarketRiskBusinessGroupingInputOption]
    ScheduleMappings: [ScheduleMapping]
    Basel3DesignationOverrideSystem: [Basel3DesignationOverrideSystemTypeOption]
    DerivedRating: [DerivedRatingTypeOption]
    EquityMarketCapTypeSystem: [EquityMarketCapTypeSystemTypeOption]
    APRARankTypeSystem: [APRARankTypeSystemTypeOption]
    APRAStressSecuritisation: [APRAStressSecuritisationTypeOption]
    HoldingPeriodStatus: [HoldingPeriodStatusTypeOption]
    PerpetualFlagStatus: [PerpetualFlagStatusOption]
    TradeBookingSystem: [TradeBookingSystemInputOption]
    MarketRiskBusinessSelectors: [MarketRiskBusinessOption]
    GlobalProductLine: [GlobalProductLineInputOption]
    SnapShot: [SnapShotOption]
    KeepwellAgreement: [KeepwellAgreementOption]
    StaticDataCreditExtraOrdinaryStress: [StaticDataCreditExtraOrdinaryStress]
  }

  type StaticDataAuditHistoryType {
    columns: [AuditHistoryColumnType]
    rows: [JSON]
  }

  type AuditHistoryColumnType {
    field: String
    type: String
    title: String
  }

  type StaticDataPortfolio {
    id: ID!
    modified: Boolean!
    name: String!
    comment: String
    isActive: Boolean!
    isEaR: Boolean!
    isFinance: Boolean!
    reportRunList: String
    volckerDeskName: String
    accountingTypeSystem: AccountingTypeSystemOption
    assetTypeSystem: AssetTypeSystemOption!
    capitalHierarchy: CapitalHierarchyOption!
    bookTypeSystem: BookTypeSystemOption
    creditBookTypeSystem: CreditBookTypeSystemOption
    tradeBookingSystem: TradeBookingSystemInputOption
    aggregateTradeCubeFlag: Boolean!
    riskHierarchy: RiskHierarchy!
    financeHierarchy: FinanceHierarchy
    geographyHierarchy: GeographyHierarchy
    hyperionUnit: HyperionUnitOption
    added: Added
    exclusion: Exclusion
    isLEGroupSubset: Boolean!
    mxLegalEntityCode: String
    quarantine: Quarantine
    reviewDate: DateTime
    reviewer: Reviewer
    source: SourceOption
    syntheticPortfolio: SyntheticPortfolio
    isReviewed: Boolean
  }

  input UpdateStaticDataPortfolio {
    id: ID!
    name: String
    capitalHierarchy: InputOptionType
    assetTypeSystem: InputOptionType
    bookTypeSystem: InputOptionType
    hyperionUnit: InputOptionType
    syntheticPortfolio: InputOptionType
    creditBookTypeSystem: InputOptionType
    tradeBookingSystem: InputOptionType
    aggregateTradeCubeFlag: Boolean
    isLEGroupSubset: Boolean
    isFinance: Boolean
    isEaR: Boolean
    isActive: Boolean
    accountingTypeSystem: InputOptionType
    riskHierarchy: RiskHierarchyInput
    geographyHierarchy: HierarchyInput
    financeHierarchy: HierarchyInput
    source: InputOptionType
    comment: String
    reviewer: InputOptionType
    exclusion: PortfolioExclusion
    isReviewed: Boolean
  }

  input PortfolioExclusion {
    reason: String
    by: String
  }

  input UpdateStaticDataRevenueCode {
    id: ID!
    name: String
    isClean: Boolean
    isActive: Boolean
    hierarchy: HierarchyInput
  }

  input InputOptionType {
    id: ID!
    text: String
  }

  type StaticDataRevenueCode {
    id: ID!
    modified: Boolean!
    isActive: Boolean!
    name: String!
    isClean: Boolean
    hierarchy: RevenueCodeHierarchy!
    added: Added!
  }

  type StaticDataLegalEntity {
    id: ID!
    modified: Boolean!
    isActive: Boolean!
    name: String!
    hierarchy: LegalEntityHierarchyOption!
    added: Added!
  }

  type StaticDataCapitalHierarchy {
    id: ID!
    modified: Boolean!
    name: String!
    isActive: Boolean!
    stressFactor: Float!
    tenDayStd: Float!
    added: Added!
  }

  input UpdateStaticDataCapitalHierarchy {
    id: ID
    name: String
    tenDayStd: Float
    stressFactor: Float
    isActive: Boolean
  }

  type StaticDataAssetType {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataBookType {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataHyperionUnit {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCreditBook {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataInstrumentCreditIndexType {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataInstrumentAPRARank {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataUnderlyingCCY {
    id: ID!
    modified: Boolean
    name: String
    offShore: String
    isMajor: Boolean
    isISO: Boolean
    ccyPreciousMetalsNonPMTypeSystem: CCYPreciousMetalsNonPMTypeSystemOption
    ccyOnshoreOffshoreTypeSystem: CCYOnshoreOffshoreTypeSystemOption
    ccyMajorMinorTypeSystem: CCYMajorMinorTypeSystemOption
    ccyGroupTypeSystem: CCYGroupTypeSystemOption
    ccyFamilyLMTypeSystem: CCYFamilyLMTypeSystemOption
    ccyFamilyFXTypeSystem: CCYFamilyFXTypeSystemOption
    ccyFamilyFXOTypeSystem: CCYFamilyFXOTypeSystemOption
    ccyCdsDeliverableTypeSystem: CCYCdsDeliverableTypeSystemOption
    Curve: CurveOption
    added: Added
    isActive: Boolean
    description: String
    comment: String
  }

  type CCYPreciousMetalsNonPMTypeSystemOption {
    id: ID
    text: String
  }

  type CCYOnshoreOffshoreTypeSystemOption {
    id: ID
    text: String
  }

  type StaticDataCountry {
    id: ID!
    modified: Boolean
    name: String
    STFGeographyTypeSystem: STFGeographyTypeSystemOption
    OECDIndicator: Boolean!
    isCMRC: Boolean!
    FRTBGeographyTypeSystem: FRTBGeographyTypeSystemOption
    geography: GeographyOption
    countryCode: String!
    baseCurrency: BaseCurrencyOption
    isActive: Boolean
    added: Added!
  }

  type BaseCurrencyOption {
    id: ID
    text: String
  }

  type GeographyOption {
    id: ID
    text: String
  }

  type CCYMajorMinorTypeSystemOption {
    id: ID
    text: String
  }

  type CCYGroupTypeSystemOption {
    id: ID
    text: String
  }

  type CCYFamilyLMTypeSystemOption {
    id: ID
    text: String
  }

  type CCYFamilyFXTypeSystemOption {
    id: ID
    text: String
  }

  type CCYFamilyFXOTypeSystemOption {
    id: ID
    text: String
  }

  type CCYCdsDeliverableTypeSystemOption {
    id: ID
    text: String
  }

  type CurveOption {
    id: ID
    text: String
  }

  type FRTBGeographyTypeSystemOption {
    id: ID
    text: String
  }

  type STFGeographyTypeSystemOption {
    id: ID
    text: String
  }

  type StaticDataSeniorityMap {
    id: ID!
    seniority: String!
    modified: Boolean!
    genericSeniorityTypeSystem: GenericSeniorityTypeSystemOption
    isActive: Boolean
    added: Added
  }

  type StaticDataIssuerFamily {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataIssuerType {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataIssuerGuaranteed {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataLongTermCreditRating {
    id: ID!
    modified: Boolean!
    rating: String
    agency: String
    ratingBandSecTypeSystem: RatingBandSecTypeSystem
    ranking: Int
    anzRatingTypeSystem: AnzRatingTypeSystem
    isIssue: Boolean
    ratingBandOtherTypeSystem: RatingBandOtherTypeSystem
    ratingBandTypeSystem: RatingBandTypeSystem
    investmentGradeTypeSystem: InvestmentGradeTypeSystem
    isIssuer: Boolean
    added: Added
    comment: String
  }

  type InvestmentGradeTypeSystem {
    id: ID!
    text: String
  }

  type RatingBandTypeSystem {
    id: ID!
    text: String
  }

  type RatingBandOtherTypeSystem {
    id: ID!
    text: String
  }

  type RatingBandSecTypeSystem {
    id: ID!
    text: String
  }

  type AnzRatingTypeSystem {
    id: ID!
    text: String
  }

  type StaticDataCapletSwaptionVegaBucket {
    term: ID!
    modified: Boolean!
    termUnit: Int!
    net1m: String
    net3m: String
    net6m: String
    net1y: String
    net2y: String
    net3y: String
    net4y: String
    net5y: String
    net7y: String
    net10y: String
    net15y: String
    net20y: String
    net25y: String
    net30yPlus: String
  }

  type StaticDataGenericSeniority {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCCYFamilyFXO {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCCYGroup {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCCYPairOnOffShore {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCCYPairFamily {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataInternalCounterParty {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataSTFSector {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCCYCDSDeliverable {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type GenericSeniorityTypeSystemOption {
    id: ID
    text: String
  }

  type RevenueCodeHierarchyOption {
    id: ID!
    title: String!
    fullPath: String
    parent: ID
    children: [ID]
  }

  type LegalEntityHierarchyOption {
    id: ID
    value: String
  }

  type AccountingTypeSystemOption {
    id: ID
    text: String
  }

  type AssetTypeSystemOption {
    id: ID
    text: String
  }

  type RiskHierarchyOption {
    id: ID!
    title: String!
    fullPath: String
    parent: ID
    children: [ID]
  }

  type CapitalHierarchyOption {
    id: ID
    text: String
  }

  type CapitalMultiplierOption {
    id: ID
    text: String
  }

  type BookTypeSystemOption {
    id: ID
    text: String
  }

  type CreditBookTypeSystemOption {
    id: ID
    text: String
  }

  type FinanceHierarchy {
    id: ID
    value: String
  }

  type FinanceHierarchyOption {
    id: ID!
    title: String!
    fullPath: String
    parent: ID
    children: [ID]
  }

  type GeographyHierarchy {
    id: ID
    value: String
  }

  type RevenueCodeHierarchy {
    id: ID
    value: String
  }

  type GeographyHierarchyOption {
    id: ID!
    title: String!
    fullPath: String
    parent: ID
    children: [ID]
  }

  type SourceOption {
    id: ID
    text: String
  }

  type SourceDropDownOption {
    id: ID
    text: String
  }

  type SyntheticPortfolio {
    id: ID
    text: String
  }

  type UserListOption {
    id: ID
    text: String
  }

  type RiskHierarchy {
    id: ID
    value: String
    fullPath: String
  }

  input RiskHierarchyInput {
    id: ID
    value: String
    fullPath: String
  }

  input GeographyHierarchyInput {
    id: ID
    value: String
    fullPath: String
  }

  input HierarchyInput {
    id: ID
    value: String
  }

  type Quarantine {
    isQuarantined: Boolean!
    date: String
  }

  type Reviewer {
    id: ID
    text: String
  }

  type StaticDataCurrencyPairStealthType {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCOMDeltaGammaLotConversionFactor {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCOMAPRAStressLabel {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataUnderlyingCCYPair {
    id: ID!
    modified: Boolean!
    name: String
    description: String
    isActive: Boolean!
    added: Added!
    comment: String
    foreignCurrency: String
    baseCurrency: String
    stealthTypeTypeSystem: StealthTypeTypeSystemOption
    ccyPairGroupTypeSystem: CCYPairGroupTypeSystemOption
    ccyPairFamilyTypeSystem: CCYPairFamilyTypeSystemOption
  }

  type StealthTypeTypeSystemOption {
    id: ID
    text: String
  }

  type CCYPairGroupTypeSystemOption {
    id: ID
    text: String
  }

  type CCYPairFamilyTypeSystemOption {
    id: ID
    text: String
  }

  type StaticDataUnderlyingCOM {
    id: ID!
    modified: Boolean!
    comment: String
    priceQuotationTypeSystem: PriceQuotationTypeSystemOption
    productSubGroupTypeSystem: ProductSubGroupTypeSystemOption
    unitTypeSystem: UnitTypeSystemOption
    isTenorBucketed: Boolean
    underlyingCode: String
    ANZStressLabelTypeSystem: ANZStressLabelTypeSystemOption
    APRAStressLabelTypeSystem: APRAStressLabelTypeSystemOption
    agriculturalExpiryMonths: [AgriculturalExpiryMonthsOption]
    indexNameTypeSystem: IndexNameTypeSystemOption
    productGroupTypeSystem: ProductGroupTypeSystemOption
    deltaGammaLotConversionTypeSystem: DeltaGammaLotConversionTypeSystemOption
    description: String
    isActive: Boolean!
    added: Added!
  }

  type PriceQuotationTypeSystemOption {
    id: ID
    text: String
  }

  type ProductSubGroupTypeSystemOption {
    id: ID
    text: String
  }

  type UnitTypeSystemOption {
    id: ID
    text: String
  }

  type ANZStressLabelTypeSystemOption {
    id: ID
    text: String
  }

  type APRAStressLabelTypeSystemOption {
    id: ID
    text: String
  }

  type IndexNameTypeSystemOption {
    id: ID
    text: String
  }

  type ProductGroupTypeSystemOption {
    id: ID
    text: String
  }

  type DeltaGammaLotConversionTypeSystemOption {
    id: ID
    text: String
  }

  type AgriculturalExpiryMonthsOption {
    id: ID
    text: String
  }

  type StaticDataCOMIndexName {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataEQSpecificRiskWeight {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataUnderlyingIRCurve {
    id: ID!
    modified: Boolean!
    description: String
    SCCYTypeTypeSystem: SCCYTypeTypeSystemOption
    tenorLowerDays: String
    tenorUpperDays: String
    curveTypeSystem: CurveTypeSystemOption
    curve: String
    isActive: Boolean!
    added: Added
  }

  type SystemType {
    id: ID!
    name: String
  }

  type SCCYTypeTypeSystemOption {
    id: ID
    text: String
  }

  type CurveTypeSystemOption {
    id: ID
    text: String
  }

  type StaticDataCOMPriceQuotation {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type MonthType {
    id: ID
    text: String
  }

  type StaticDataCOMType {
    id: ID!
    modified: Boolean!
    system: SystemType!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCOMSubType {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataSingleCurveTypeCurve {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCOMUnit {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCurveTypeCurve {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataGeography {
    id: ID!
    modified: Boolean!
    description: String
    name: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataGrpNationalMarket {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataStealthHealthRangeType {
    id: ID!
    modified: Boolean!
    name: String!
    rangeFrom: Float!
    rangeTo: Float!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCOMANZStressGroup {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataUnderlyingEQType {
    id: ID!
    modified: Boolean!
    ticker: String!
    description: String
    SecurityMarket: SecurityMarketOption
    EQTypeTypeSystem: EQTypeTypeSystemOption
    EQRegionTypeSystem: EQRegionTypeSystemOption
    EQTierTypeSystem: EQTierTypeSystemOption
    EQSpecificRiskWeightTypeSystem: EQSpecificRiskWeightTypeSystemOption
    isIgnore: Boolean
    comment: String
    isActive: Boolean!
    added: Added!
  }

  type SecurityMarketOption {
    id: ID
    text: String
  }

  type StaticDataGenericTermPillarsBaseMetalsDeltaVega {
    modified: Boolean!
    termUnit: Int!
    net1y3mPlus: String!
    net2y3mPlus: String!
    net1m: String!
    net10y3m: String!
    net5m: String!
    net3m: String!
    net9m: String!
    net9y3m: String!
    net1y9m: String!
    net5y3m: String!
    net2y: String!
    term: String!
    net7y3m: String!
    net1y3m: String!
    net3y3m: String!
    net2m: String!
    net6m: String!
    net4m: String!
    net1m_1y3m: String!
    net1y4m_2y3m: String!
    net1y: String!
    net6y3m: String!
    net2y3m: String!
    net8y3m: String!
    net1y6m: String!
    net4y3m: String!
  }

  type StaticDataEquityVegaNetBucket {
    id: ID!
    modified: Boolean!
    compositeKey: [String]
    sp_id: Int!
    termUnit: Int!
    term: String!
    net1m: Float!
    net2m: Float!
    net1y: Float!
    net2y: Float!
    net6m: Float!
    net3m: Float!
    net3y: Float!
    net4y: Float!
  }

  type StaticDataFXOVegaNetBucket {
    id: ID!
    modified: Boolean!
    compositeKey: [String]!
    termUnit: Int!
    term: String!
    sp_id: Int!
    net1m: Float!
    net3m: Float!
    net1y: Float!
    net3y: Float!
    net10y: Float!
    net15y: Float!
    net1m_1y: Float!
    net1yPlus: Float!
    net6mPlus: Float!
  }

  type StaticDataNationalMarket {
    id: ID!
    modified: Boolean!
    securityMarket: String!
    nationalMarketTypeSystem: NationalMarketTypeSystemOption
    comment: String
    added: Added
  }

  type NationalMarketTypeSystemOption {
    id: ID
    text: String
  }

  type EQTypeTypeSystemOption {
    id: ID
    text: String
  }

  type EQRegionTypeSystemOption {
    id: ID
    text: String
  }

  type EQTierTypeSystemOption {
    id: ID
    text: String
  }

  type EQSpecificRiskWeightTypeSystemOption {
    id: ID
    text: String
  }

  type StaticDataStealthMaturityRangeType {
    id: ID!
    modified: Boolean!
    name: String!
    rangeFrom: Float!
    rangeTo: Float!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCreditStressBondRating {
    id: ID!
    modified: Boolean!
    auditId: ID
    additionalParamsForAuditHistory: CreditStressBondRatingAuditHistoryAdditionalParam
    compositeKey: [String]!
    anzRatingTypeSystem: AnzRatingTypeSystemOption!
    daysToMaturity: String!
    longStress: Int!
    shortStress: Int!
    Currency: CurrencyOption!
    isActive: Boolean!
    added: Added
  }

  type CreditStressBondRatingAuditHistoryAdditionalParam {
    ccyID: ID
    daysToMaturity: String
  }

  type AnzRatingTypeSystemOption {
    id: ID
    text: String
  }

  type CurrencyOption {
    id: ID
    text: String
  }

  type StaticDataCreditStressCDSRating {
    id: ID!
    modified: Boolean!
    anzRatingTypeSystem: AnzRatingTypeSystemOption!
    longStress: Int!
    shortStress: Int!
    isActive: Boolean!
    added: Added!
    compositeKey: [String]!
  }

  type StaticDataCreditStressTopCDSIssuer {
    id: ID!
    modified: Boolean!
    Issuer: IssuerOption!
    longStress: Int!
    shortStress: Int!
    isActive: Boolean!
    added: Added!
    compositeKey: [String]!
  }

  type IssuerOption {
    id: ID
    text: String
    description: String
  }

  type StaticDataHaircutReference {
    id: ID
    modified: Boolean!
    counterpartyCcr: String!
    counterpartySector: String!
    maturityBucket: String!
    haircut: Float!
    tier: String!
    rating: String!
    added: Added
  }

  type StaticDataBespokeHaircut {
    id: ID
    modified: Boolean!
    type: String!
    issuerCountry: String!
    issuerName: String!
    variationToGuideline: Float!
    maxRepoTenor: String
    razorCode: String!
    startDate: Date!
    counterpartyName: String!
    minCollateralRating: String!
    approver: String!
    endDate: String!
    added: Added!
  }

  type StaticDataD2ADefaultNamespace {
    id: ID!
    modified: Boolean!
    uri: String!
    prefix: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataGrpEQType {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataGrpEQRegion {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataGrpEQTier {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataCreditStressCreditIndice {
    id: ID!
    modified: Boolean!
    CRIndexType: CRIndexTypeOption!
    longStress: Int!
    shortStress: Int!
    isActive: Boolean!
    added: Added!
    compositeKey: [String]!
  }

  type CRIndexTypeOption {
    id: ID
    text: String
  }

  type CCYOption {
    id: ID
    text: String
  }

  type StaticDataCreditStressSpreadTenBondDefaultStress {
    id: ID
    modified: Boolean!
    anzRatingTypeSystem: AnzRatingTypeSystemOption!
    stressFactor: Int!
    isActive: Boolean!
    added: Added
  }

  type StaticDataCreditStressBondIssuer {
    id: ID!
    auditId: ID
    modified: Boolean
    Issuer: IssuerOption!
    Currency: CurrencyOption!
    isActive: Boolean!
    added: Added!
    longStress: String!
    shortStress: String!
    daysToMaturity: String!
    compositeKey: [String]!
    additionalParamsForAuditHistory: CreditStressBondIssuerAuditHistoryAdditionalParam
  }

  type CreditStressBondIssuerAuditHistoryAdditionalParam {
    ccyID: ID
    daysToMaturity: String
  }

  type StaticDataCICSIssuerCodeMappingType {
    id: ID!
    modified: Boolean!
    CICSIssuerCode: String
    Issuer: IssuerOption
    added: Added!
  }

  type StaticDataEquityVegaUnderlyingBondETOTenor {
    modified: Boolean!
    term: String!
    net2y: String!
    net3y: String!
    net5y: String!
    net10y: String!
    net30y: String!
  }

  type StaticDataVegaOptionExpiryNetBucketsCapFloor {
    id: ID!
    modified: Boolean!
    compositeKey: [String]
    sp_id: Int!
    term: ID!
    termUnit: Int!
    net3m: Float!
    net1y: Float!
    net3y: Float!
    net10y: Float!
    net20y: Float!
  }

  type StaticDataGrpSTFGeography {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataGenericTermPilarsPetroleumVega {
    modified: Boolean!
    term: String!
    termUnit: Int!
    net1m_2m: String!
    net3m_5m: String!
    net6m_11m: String!
    net1y_2y: String!
    net2yPlus: String!
  }

  type StaticDataApportionmentExclusion {
    id: ID!
    apportionmentExclusion: ID!
    modified: Boolean!
    node: NodeOption!
    isActive: Boolean!
    added: Added!
  }

  type NodeOption {
    id: ID!
    value: String!
    shortValue: String!
  }

  type StaticDataCRDIComposition {
    id: ID!
    modified: Boolean!
    indexLabel: String!
    date: Date!
    issuer: String!
    Instrument: Int!
    compositionPercentage: Float
    seniority: String!
    added: Added!
  }

  type StaticDataVegaOptionExpiryNetBucktsSwaptionEtoType {
    id: ID!
    modified: Boolean!
    compositeKey: [String]
    sp_id: Int!
    net10y: Float!
    net30yPlus: Float!
    net20y: Float!
    net1y: Float!
    net3m: Float!
    termUnit: Int!
    term: String!
    net20yPlus: Float!
    net3y: Float!
  }

  type StaticDataDTwoAForm {
    id: ID!
    modified: Boolean!
    version: Int
    order: Int
    formCode: String
    returnIdentifier: ReturnIdentifierOption
    formName: String!
    calculateTwoLevels: Boolean
    isActive: Boolean
    added: Added!
  }

  type ReturnIdentifierOption {
    id: ID!
    text: String!
  }

  type StaticDataEquityUnderlyingSpecificRiskMap {
    id: ID!
    modified: Boolean!
    mappedTicker: MappedTickerOption
    ticker: TickerOption
    isActive: Boolean!
    added: Added!
  }

  type MappedTickerOption {
    id: ID!
    text: String!
  }

  type TickerOption {
    id: ID!
    text: String!
  }

  type StaticDataCommodityTypeMapping {
    id: ID!
    modified: Boolean!
    added: Added!
    MXRiskLabel1: String!
    MXRiskLabel3: String!
    commodity: CommodityOption
  }

  type CommodityOption {
    id: ID
    text: String
  }

  type StaticDataLMENonDeliveryDay {
    id: ID!
    compositeKey: [String]
    modified: Boolean!
    date: DateTime!
    isLMENonDelivery: Boolean!
  }

  type StaticDataRatingOverride {
    id: ID!
    modified: Boolean
    agency: AgencyOption
    issuer: IssuerOption
    creditRating: CreditRatingOption
    isActive: Boolean!
    added: Added!
  }

  type CreditRatingOption {
    id: ID
    text: String
  }

  type StaticDataRepoTypologyMap {
    id: ID!
    auditId: ID
    modified: Boolean!
    typology: String!
    mapValue: String!
    isActive: Boolean!
    added: Added!
    compositeKey: [String]!
    additionalParamsForAuditHistory: RepoTypologyMapAuditHistoryAdditionalParam
  }

  type RepoTypologyMapAuditHistoryAdditionalParam {
    typology: String
  }

  type StaticDataRiskThresholdCatchAll {
    id: ID!
    modified: Boolean!
    name: String!
    description: String!
    reconThresholdAmt: Int!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataShortTermCreditRating {
    id: ID!
    modified: Boolean!
    rating: String!
    comment: String
    agency: String!
    ratingBandTypeSystem: RatingBandTypeSystemOption!
    added: Added!
  }

  type RatingBandTypeSystemOption {
    id: ID
    text: String
  }

  type StaticDataSpecRiskTradeExclusion {
    id: ID!
    modified: Boolean!
    reportName: ReportNameOption!
    tradeNumber: Int!
    comment: String
    isActive: Boolean!
    added: Added!
  }

  type ReportNameOption {
    id: ID
    text: String
  }

  type StaticDataSpecificRiskCapitalCharge {
    id: ID!
    modified: Boolean!
    ratingBandTypeSystem: RatingBandTypeSystemOption
    tenor: TenorOption
    sRCapitalCharge: Float
    sRCategory: SRCategoryOption
    isActive: Boolean!
    added: Added!
  }

  type TenorOption {
    id: ID
    text: String
  }

  type SRCategoryOption {
    id: ID
    text: String
  }

  type StaticDataGenericTermPillarsCoalIronOreDeltaType {
    modified: Boolean!
    net7m_12m: String!
    net4m_6m: String!
    net2y: String!
    term: String!
    termUnit: Int!
    net0m_3m: String!
    net3y_5y: String!
  }

  type StaticDataGenericTermPillarsPetroleumDeltaType {
    modified: Boolean!
    termUnit: Int!
    term: String!
    net0y_5y: String!
    net5y_8y: String!
  }

  type StaticDataGenericTermPillarsEmissionType {
    modified: Boolean!
    net13m_24m: String!
    net19m_30m: String!
    net25m_36m: String!
    net4m_18m: String!
    net4m_12m: String!
    term: String!
    termUnit: Int!
    net0m_3m: String!
    net31m_42m: String!
    net0m_12m: String!
    net37m_48m: String!
    net49m_60m: String!
  }

  type StaticDataSpecificRiskLongTermIssue {
    id: ID!
    modified: Boolean!
    ratingBandSecTypeSystem: RatingBandSecTypeSystemOption
    resecuritisationExposures: Float
    securitisationExposures: Float
    added: Added!
  }

  type RatingBandSecTypeSystemOption {
    id: ID
    text: String
  }

  type StaticDataVegaUnderlyingSwapBondMaturityNetBucket {
    id: ID!
    modified: Boolean!
    compositeKey: [String]
    sp_id: Int!
    term: ID!
    termUnit: Int!
    net3m: Float!
    net2y: Float!
    net5y: Float!
    net10y: Float!
    net20y: Float!
  }

  type StaticDataCustomMember {
    id: ID!
    modified: Boolean!
    name: String
    underlyingType: UnderlyingTypeCMOption
    operation: OperationOption
    nameofUnderlying: [NameOfUnderlyingOption]
    isActive: Boolean!
    added: Added!
  }

  type OperationOption {
    id: ID
    text: String
  }

  type UnderlyingTypeCMOption {
    id: ID
    text: String
  }

  type NameOfUnderlyingOption {
    id: ID
    text: String
    weight: Float
  }

  type StaticDataHoldingPeriodExcludedIssuerCcyType {
    id: ID!
    auditId: ID
    modified: Boolean!
    issuer: IssuerOption!
    ccy: CurrencyOption!
    compositeKey: [String]!
    additionalParamsForAuditHistory: HoldingPeriodExcludedIssuerCcyAdditionalParam
    isActive: Boolean!
    added: Added!
  }

  type HoldingPeriodExcludedIssuerCcyAdditionalParam {
    ccyID: ID
  }

  type StaticDataLiquidityGeoMapping {
    id: ID!
    modified: Boolean!
    geographyHierarchy: GeographyHierarchyMappingOption
    geographyMapping: GeographyMappingOption
    country: String
    added: Added!
  }

  type GeographyHierarchyMappingOption {
    id: ID!
    value: String!
    fullPath: String!
  }

  type GeographyMappingOption {
    id: ID
    text: String
  }

  type StaticDataSpecificRiskShortTermIssue {
    id: ID!
    modified: Boolean!
    sTRatingBandTypeSystem: STRatingBandTypeSystemOption
    resecuritisationExposures: Float
    securitisationExposures: Float
    added: Added!
  }

  type STRatingBandTypeSystemOption {
    id: ID
    text: String
  }

  type StaticDataVegaNetBucketingAll {
    modified: Boolean!
    term: Int!
    net3m: String!
    net1y: String!
    net3y: String!
    net5y: String!
    net10y: String!
    net20y: String!
    net30yPlus: String!
  }

  type StaticDataHoldingPeriodTradeType {
    id: ID!
    auditId: ID
    modified: Boolean!
    currencyName: String
    family: String
    group: String
    isActive: Boolean
    added: Added!
    issuerName: String
    baseNotional: Float
    instrumentName: String
    isInMRE: Boolean
    isExcludedTrade: Boolean
    isLongDated: Boolean
    isReplacedTrade: Boolean
    isSettlementTrade: Boolean
    maturityDate: Date
    notional: String
    portfolioName: String
    rank: String
    replaceDate: Date
    replaced: Int
    reportDate: Date!
    nb: Int!
    additionalParamsForAuditHistory: HoldingPeriodTradeAuditHistoryAdditionalParam
  }

  type HoldingPeriodTradeAuditHistoryAdditionalParam {
    cobDate: Date
  }

  type StaticDataPillarXCCYBasisBasisGamma {
    modified: Boolean!
    term: Int!
    net25y: String!
    net15y: String!
    net7y: String!
    net10y: String!
    net1m: String!
    net2m: String!
    net30y: String!
    net20y: String!
    net6m: String!
    net3m: String!
    net9m: String!
    net1y: String!
    net2y: String!
    net5y: String!
    net3y: String!
    net4y: String!
  }

  type StaticDataTenorAndDaystoMaturity {
    id: ID!
    modified: Boolean!
    tenor: String
    daysToMaturity: Int
    bondETOInstrument: String
    isDeliverable: Boolean
    sEFName: String
    tRNGRP: String
    added: Added!
  }

  type StaticDataPillarsSingleCCYBasis {
    modified: Boolean!
    term: Int!
    net25y: String!
    net15y: String!
    net7y: String!
    net10y: String!
    net1m: String!
    net30y: String!
    net20y: String!
    net6m: String!
    net3m: String!
    net1y: String!
    net2y: String!
    net5y: String!
    net3y: String!
    net4y: String!
  }

  type StaticDataNetBucketingCR01 {
    id: ID!
    modified: Boolean!
    compositeKey: [String]
    sp_id: Int!
    term: String!
    termUnit: Int!
    net10y: Float!
    net30yPlus: Float!
    net20y: Float!
    net1y: Float!
    net3m: Float!
    net5y: Float!
    net3y: Float!
    net3mRAT: Float!
    net1yRAT: Float!
    net2yRAT: Float!
    net3yRAT: Float!
    net5yRAT: Float!
    net7yRAT: Float!
    net10yRAT: Float!
    net15yRAT: Float!
    net20yRAT: Float!
    net25yRAT: Float!
    net30yPlusRAT: Float!
  }

  type StaticDataNetBucketingDV01 {
    id: ID!
    modified: Boolean!
    compositeKey: [String]
    sp_id: Int!
    term: String!
    termUnit: Int!
    net3mCom: Float!
    net1yPlus: Float!
    net10y: Float!
    net4yFXO: Float!
    net20y: Float!
    net1mFXO: Float!
    net3m: Float!
    net10yCom: Float!
    net1yCom: Float!
    net6mPlus: Float!
    net30yPlus: Float!
    net3yFXO: Float!
    net2yFXO: Float!
    net2mFXO: Float!
    net7yFXO: Float!
    nFA10y: Float!
    net2m_3m: Float!
    net6mFXO: Float!
    nFA2y: Float!
    nFA30y: Float!
    nFA5y: Float!
    net10yPlus: Float!
    net10yFXO: Float!
    net1yFXO: Float!
    net5yCom: Float!
    net2yPlus: Float!
    net3mFXO: Float!
    net3yCom: Float!
    netLess1yCom: Float!
    net5yFXO: Float!
    net1y: Float!
    net5y: Float!
    net20yPlus: Float!
    net3y: Float!
    net3mRAT: Float!
    net1yRAT: Float!
    net2yRAT: Float!
    net3yRAT: Float!
    net5yRAT: Float!
    net7yRAT: Float!
    net10yRAT: Float!
    net15yRAT: Float!
    net20yRAT: Float!
    net25yRAT: Float!
    net30yPlusRAT: Float!
  }

  type StaticDataPillarsDV01 {
    modified: Boolean!
    term: Int!
    net9y: String!
    net7y: String!
    t_N: String!
    net10y: String!
    net1m: String!
    net30y: String!
    net20y: String!
    net5m: String!
    net3m: String!
    net9m: String!
    net1d: String!
    net7d: String!
    net1y9m: String!
    net2y: String!
    net6y: String!
    net1y3m: String!
    net4y: String!
    net25y: String!
    net15y: String!
    net8y: String!
    net2m: String!
    net6m: String!
    net4m: String!
    net1y: String!
    net40y: String!
    net5y: String!
    net1y6m: String!
    net3y: String!
  }

  type StaticDataPillarsVegaETOBond {
    modified: Boolean!
    term: Int!
    net25y: String!
    net9y: String!
    net15y: String!
    net7y: String!
    net8y: String!
    net10y: String!
    net30y: String!
    net20y: String!
    net1y: String!
    net2y: String!
    net5y: String!
    net6y: String!
    net3y: String!
    net4y: String!
  }

  type StaticDataNetBucketXccyBasisGammaType {
    id: ID!
    modified: Boolean!
    compositeKey: [String]
    sp_id: Int!
    net10y: Float!
    net30yPlus: Float!
    net20y: Float!
    net10yPlus: Float!
    net1y: Float!
    net3m: Float!
    term: String!
    termUnit: Int!
    netUnder3m: Float!
    net5y: Float!
    net3y: Float!
    net3mRAT: Float
    net1yRAT: Float
    net2yRAT: Float
    net3yRAT: Float
    net5yRAT: Float
    net7yRAT: Float
    net10yRAT: Float
    net15yRAT: Float
    net20yRAT: Float
    net25yRAT: Float
    net30yPlusRAT: Float
  }

  type StaticDataNetBucketSingleCcyBasisType {
    id: ID!
    modified: Boolean!
    compositeKey: [String]
    sp_id: Int!
    net10y: Float!
    net30yPlus: Float!
    net20y: Float!
    net10yPlus: Float!
    net1y: Float!
    net3m: Float!
    term: String!
    termUnit: Int!
    net5y: Float!
    net3y: Float!
    net3mRAT: Float
    net1yRAT: Float
    net2yRAT: Float
    net3yRAT: Float
    net5yRAT: Float
    net7yRAT: Float
    net10yRAT: Float
    net15yRAT: Float
    net20yRAT: Float
    net25yRAT: Float
    net30yPlusRAT: Float
  }

  type StaticDataPillarsCr01Type {
    modified: Boolean!
    net15y: String
    net7y: String
    net10y: String
    net30y: String
    net20y: String
    net6m: String
    net3m: String
    net1y: String
    net2y: String
    term: String!
    termUnit: Int!
    net5y: String
    net3y: String
    net4y: String
  }

  type StaticDataProductHierarchy {
    id: ID!
    modified: Boolean!
    description: String
    name: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataRepoStfSensitivityType {
    modified: Boolean!
    net7d: String
    net1y: String
    net3m: String
    net3yPlus: String
    term: String!
    termUnit: Int!
    net9m: String
    net3y: String
  }

  type STFSectorTypeSystemOption {
    id: ID
    text: String
  }

  input UpdateStaticDataProductHierarchy {
    id: ID
    name: String
    description: String
    isActive: Boolean
  }

  type LegalEntityHierarchyType {
    id: ID!
    title: String!
    fullPath: String
    parent: ID
    children: [ID]
  }

  input UpdateStaticDataLegalEntityHierarchy {
    id: ID!
    name: String
    hierarchy: HierarchyInput
  }

  input UpdateStaticDataHaircutReference {
    id: ID
    rating: String
    counterpartyCcr: String
    counterpartySector: String
    haircut: Float
    maturityBucket: String
    tier: String
  }

  input UpdateStaticDataUnderlyingIRCurve {
    id: ID!
    curve: String
    isActive: Boolean
    description: String
    tenorLowerDays: Int
    tenorUpperDays: Int
    SCCYTypeTypeSystem: InputOptionType
    curveTypeSystem: InputOptionType
  }

  input UpdateStaticDataBespokeHaircut {
    id: ID!
    type: String
    issuerCountry: String
    issuerName: String
    variationToGuideline: Float
    maxRepoTenor: String
    razorCode: String
    startDate: Date
    counterpartyName: String
    minCollateralRating: String
    approver: String
    endDate: String
  }

  input UpdateStaticDataHoldingPeriodTrade {
    id: ID
    cob: String!
    baseNotional: Float
    notional: String
    isActive: Boolean
  }

  input UpdateStaticDataGrpCOMType {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input SystemInputType {
    id: ID!
    name: String
  }

  input UpdateStaticDataInstrumentCreditIndexType {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataGrpCOMUnit {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  type CommodityUnderlyingCodeOption {
    id: ID
    text: String
  }

  input UpdateStaticDataCommodityTypeMapping {
    id: ID
    commodity: InputOptionType
  }

  type ReportTypeOption {
    id: ID
    text: String
  }

  input UpdateStaticDataGrpCOMIndexName {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  type StaticDataVolckerDeskType {
    id: ID!
    modified: Boolean
    name: String
    description: String
    added: Added!
    isActive: Boolean!
    reportingCategory: ReportingCategoryOption
    GlobalBusinessUnit: GlobalBusinessUnitOption
  }

  type ReportingCategoryOption {
    id: ID
    text: String
  }

  type GlobalBusinessUnitOption {
    id: ID
    text: String
  }

  input UpdateStaticDataUnderlyingCCYPAIR {
    id: ID!
    name: String
    description: String
    isActive: Boolean
    comment: String
    foreignCurrency: String
    baseCurrency: String
    ccyPairGroupTypeSystem: InputOptionType
    ccyPairFamilyTypeSystem: InputOptionType
  }

  input UpdateStaticDataSpecificRiskCapitalCharge {
    id: ID
    sRCategory: InputOptionType
    tenor: InputOptionType
    ratingBandTypeSystem: InputOptionType
    sRCapitalCharge: Float
    isActive: Boolean
  }

  type SRCategoryInputOption {
    id: ID
    text: String
  }

  type TenorInputOption {
    id: ID
    text: String
  }

  type SrRatingBandTypeSystemOption {
    id: ID
    text: String
    typeSystemId: String
  }

  input UpdateStaticDataUnderlyingCOM {
    id: ID
    underlyingCode: String
    comment: String
    priceQuotationTypeSystem: InputOptionType
    productSubGroupTypeSystem: InputOptionType
    ANZStressLabelTypeSystem: InputOptionType
    APRAStressLabelTypeSystem: InputOptionType
    indexNameTypeSystem: InputOptionType
    productGroupTypeSystem: InputOptionType
    unitTypeSystem: InputOptionType
    deltaGammaLotConversionTypeSystem: InputOptionType
    description: String
    agriculturalExpiryMonths: String
    isTenorBucketed: Boolean
    isActive: Boolean
  }

  input UpdateStaticDataUnderlyingCCY {
    id: ID!
    name: String
    offShore: String
    isMajor: Boolean
    isISO: Boolean
    ccyGroupTypeSystem: InputOptionType
    ccyFamilyFXOTypeSystem: InputOptionType
    ccyCdsDeliverableTypeSystem: InputOptionType
    Curve: InputOptionType
    isActive: Boolean
    description: String
    comment: String
  }

  type CurveListOption {
    id: ID
    text: String
  }

  input UpdateStaticDataSTFSector {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataGrpCOMDeltaGammaLotConversionFactor {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataCurrencyPairStealthType {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataCCYFamilyFXO {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataCurveTypeCurve {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataGrpCOMSubType {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataCreditBook {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataHyperionUnit {
    id: ID
    value: String
    description: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataCCYGroup {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataAssetType {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataD2ADefaultNamespace {
    id: ID
    uri: String
    prefix: String
    isActive: Boolean
  }

  input UpdateStaticDataInstrumentAPRARank {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataInternalCounterParty {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataCOMANZStressGroup {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataCOMAPRAStressLabel {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataLiquidityGeoMapping {
    id: ID
    geographyHierarchy: GeographyHierarchyInput
  }

  input UpdateStaticDataSeniorityMap {
    id: ID
    seniority: String
    genericSeniorityTypeSystem: InputOptionType
    isActive: Boolean
  }

  type GenericSeniorityInputOption {
    id: ID
    text: String
  }

  input UpdateStaticDataCOMPriceQuotation {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataGrpSTFGeography {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataCCYCDSDeliverable {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataCCYPairFamily {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataIssuerFamily {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataIssuerGuaranteed {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataIssuerType {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataGrpNationalMarket {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataEQSpecificRiskWeight {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataGrpEQRegion {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataGrpEQTier {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataGrpEQType {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataD2AForms {
    id: ID
    version: Int
    order: Int
    formCode: String
    returnIdentifier: InputOptionType
    formName: String
    calculateTwoLevels: Boolean
    isActive: Boolean
  }

  input UpdateStaticDataCountry {
    id: ID
    countryCode: String
    name: String
    baseCurrency: InputOptionType
    geography: InputOptionType
    OECDIndicator: Boolean
    isCMRC: Boolean
    STFGeographyTypeSystem: InputOptionType
    FRTBGeographyTypeSystem: InputOptionType
    isActive: Boolean
  }

  type GlobalBusinessUnitType {
    id: ID
    text: String
  }

  type ReportingCategoryType {
    id: ID
    text: String
  }

  type NationalMarketTypeSystem {
    id: ID
    text: String
  }

  type BaseCurrencyInputOption {
    id: ID
    text: String
  }

  type GeographyInputOption {
    id: ID
    text: String
  }

  input UpdateStaticDataApportionmentExclusion {
    id: ID
    node: HierarchyInput
    isActive: Boolean
  }

  input UpdateStaticDataCICSIssuerCodeMappingType {
    id: ID
    Issuer: IssuerInputOptionType
  }

  type IssuerInputOption {
    id: ID
    text: String
    description: String
  }

  input SystemTypeInput {
    id: ID!
    name: String
  }

  input UpdateStaticDataIssuer {
    id: ID
    issuerCode: String
    description: String
    ackey: String
    issuerEquityTicker: String
    parentIssuer: ParentIssuerOptionType
    issuerTypeTypeSystem: InputOptionType
    Country: CountryOptionType
    APRAApproved: Boolean
    isExclude: Boolean
    SRCategory: InputOptionType
    ratingBandTypeSystem: InputOptionType
    commentISS: String
    issuerFamilyTypeSystem: InputOptionType
    issuerGuaranteedTypeSystem: InputOptionType
    parentOwned: Boolean
    snpIssueRating: InputOptionType
    moIssueRating: InputOptionType
    fitchIssueRating: InputOptionType
    sector: String
    STFSectorTypeSystem: InputOptionType
    amountOutstanding: Float
    isDataReview: Boolean
    isIgnore: Boolean
    murexVersions: String
    isMurexRiskless: Boolean
    countryOfDomicile: String
    industrySector: String
    industryGroup: String
    marketSectorDescription: String
    comment: String
    isActive: Boolean
  }

  input ParentIssuerOptionType {
    id: ID
    text: String
    description: String
  }

  input UpdateStaticDataStealthHealthRange {
    id: ID
    name: String
    rangeFrom: Float
    rangeTo: Float
    isActive: Boolean
  }

  input UpdateStaticDataRiskThresholdCatchAll {
    id: ID
    reconThresholdAmt: Float
    isActive: Boolean
  }

  input UpdateStaticDataHoldingPeriodExcludedIssuerCcy {
    id: ID
    issuer: InputOptionType
    ccy: InputOptionType
    isActive: Boolean
  }

  input UpdateStaticDataSingleCurveTypeCurve {
    id: ID
    value: String
    system: SystemTypeInput
    isActive: Boolean
  }

  input UpdateStaticDataCCYPairOnOffShore {
    id: ID
    value: String
    system: SystemTypeInput
    isActive: Boolean
  }

  input UpdateStaticDataNationalMarket {
    id: ID
    nationalMarketTypeSystem: InputOptionType
    comment: String
  }

  input UpdateStaticDataSpecificRiskLongTermIssue {
    id: ID
    resecuritisationExposures: Float
    securitisationExposures: Float
  }

  input UpdateStaticDataSpecificRiskShortTermIssue {
    id: ID
    resecuritisationExposures: Float
    securitisationExposures: Float
  }

  input UpdateStaticDataCRDIComposition {
    id: ID
    cob: String
    compositionPercentage: Float
  }

  input UpdateStaticDataUnderlyingEq {
    id: ID
    ticker: String
    description: String
    SecurityMarket: InputOptionType
    EQTypeTypeSystem: InputOptionType
    EQRegionTypeSystem: InputOptionType
    EQTierTypeSystem: InputOptionType
    EQSpecificRiskWeightTypeSystem: InputOptionType
    isIgnore: Boolean
    comment: String
    isActive: Boolean
  }

  input CountryOptionType {
    id: ID
    text: String
    countryCode: String
  }

  type CountryInputOption {
    id: ID
    text: String
    countryCode: String
  }

  type IssuerTypeInputOption {
    id: ID
    text: String
  }

  type RatingBandOverrideTypeSystemInputOption {
    id: ID
    text: String
    displayName: String
  }

  type IssuerFamilyTypeInputOption {
    id: ID
    text: String
  }

  type IssuerGuaranteedTypeSystemInputOption {
    id: ID
    text: String
  }

  type SnpIssueRatingTypeSystemInputOption {
    id: ID
    text: String
  }

  type MOIssueRatingTypeSystemInputOption {
    id: ID
    text: String
  }

  type SecurityMarketOptionType {
    id: ID
    text: String
  }

  input UpdateStaticDataLongTermCreditRating {
    id: ID
    ranking: Int
    comment: String
  }

  input UpdateStaticDataVolckerDesk {
    id: ID
    name: String
    description: String
    reportingCategory: InputOptionType
    GlobalBusinessUnit: InputOptionType
    isActive: Boolean
  }

  input UpdateStaticDataSpecRiskTradeExclusion {
    id: ID
    reportName: InputOptionType
    tradeNumber: Int
    comment: String
    isActive: Boolean
  }

  input UpdateStaticDataCounterparty {
    id: ID
    counterpartyName: String
    Country: InputOptionType
    internalGroupTypeSystem: InputOptionType
    STFSectorTypeSystem: InputOptionType
    isInternal: Boolean
    razorCode: String
    CTPYCOUNTRYOFRISK: String
    COUNTRYOFDOMICILE: String
    interbank: String
    CTPYCCR: String
    setNo: String
    controlPoint: String
    CTPYRazorName: String
    interdeskDescription: String
    comment: String
  }

  type InternalCounterpartyInputOption {
    id: ID
    text: String
  }

  type STFSectorInputOption {
    id: ID
    text: String
  }

  input UpdateStaticDataGeography {
    id: ID
    name: String
    isActive: Boolean
  }
  input UpdateStaticDataEquityUnderlyingSpecificRiskMap {
    id: ID
    mappedTicker: InputOptionType
    ticker: InputOptionType
    isActive: Boolean
  }

  type UnderlyingEQListOption {
    id: ID
    text: String
  }

  input UpdateStaticDataEquityVegaOptionExpiryNetBucketsCapFloor {
    id: ID
    term: ID
    sp_id: Int
    net3m: Float
    net1y: Float
    net3y: Float
    net10y: Float
    net20y: Float
  }

  input UpdateStaticDataCreditStressBondIssuer {
    id: ID
    Issuer: InputOptionType
    Currency: InputOptionType
    daysToMaturity: String
    longStress: Int
    shortStress: Int
    isActive: Boolean
  }

  type NetBucketCR01Option {
    id: ID
    text: String
  }

  type FitchIssueRatingTypeSystemInputOption {
    id: ID
    text: String
  }

  type StfSectorTypeSystemInputOption {
    id: ID
    text: String
  }

  input UpdateStaticDataEquityVegaNetBuckets {
    id: ID
    term: ID
    sp_id: Int
    net1m: Float
    net2m: Float
    net1y: Float
    net2y: Float
    net6m: Float
    net3m: Float
    net3y: Float
    net4y: Float
  }

  input UpdateStaticDataFXOVegaNetBuckets {
    id: ID
    term: ID
    sp_id: Int
    net1m: Float
    net3m: Float
    net1y: Float
    net3y: Float
    net10y: Float
    net15y: Float
    net1m_1y: Float
    net1yPlus: Float
    net6mPlus: Float
  }

  input UpdateStaticDataVegaOptionExpiryNetBucketsSwaptionEtOs {
    id: ID
    term: ID
    sp_id: Int
    net10y: Float
    net30yPlus: Float
    net20y: Float
    net1y: Float
    net3m: Float
    net20yPlus: Float
    net3y: Float
  }

  input UpdateStaticDataVegaUnderlyingSwapBondMaturityNetBuckets {
    id: ID
    term: ID
    sp_id: Int
    net3m: Float
    net2y: Float
    net5y: Float
    net10y: Float
    net20y: Float
  }

  input UpdateStaticDataNetBucketingCr01 {
    id: ID
    term: ID
    sp_id: Int
    net10y: Float
    net30yPlus: Float
    net20y: Float
    net1y: Float
    net3m: Float
    net5y: Float
    net3y: Float
    net3mRAT: Float
    net1yRAT: Float
    net2yRAT: Float
    net3yRAT: Float
    net5yRAT: Float
    net7yRAT: Float
    net10yRAT: Float
    net15yRAT: Float
    net20yRAT: Float
    net25yRAT: Float
    net30yPlusRAT: Float
  }

  input UpdateStaticDataNetBucketingDv01SrIrgCpiDv01 {
    id: ID
    term: ID
    sp_id: Int
    net3mCom: Float
    net1yPlus: Float
    net10y: Float
    net4yFXO: Float
    net20y: Float
    net1mFXO: Float
    net3m: Float
    net10yCom: Float
    net1yCom: Float
    net6mPlus: Float
    net30yPlus: Float
    net3yFXO: Float
    net2yFXO: Float
    net2mFXO: Float
    net7yFXO: Float
    nFA10y: Float
    net2m_3m: Float
    net6mFXO: Float
    nFA2y: Float
    nFA30y: Float
    nFA5y: Float
    net10yPlus: Float
    net10yFXO: Float
    net1yFXO: Float
    net5yCom: Float
    net2yPlus: Float
    net3mFXO: Float
    net3yCom: Float
    netLess1yCom: Float
    net5yFXO: Float
    net1y: Float
    net5y: Float
    net20yPlus: Float
    net3y: Float
    net3mRAT: Float
    net1yRAT: Float
    net2yRAT: Float
    net3yRAT: Float
    net5yRAT: Float
    net7yRAT: Float
    net10yRAT: Float
    net15yRAT: Float
    net20yRAT: Float
    net25yRAT: Float
    net30yPlusRAT: Float
  }

  input UpdateStaticDataNetBucketingSingleCcyBasis {
    id: ID
    term: ID
    sp_id: Int
    net10y: Float
    net30yPlus: Float
    net20y: Float
    net10yPlus: Float
    net1y: Float
    net3m: Float
    net5y: Float
    net3y: Float
    net3mRAT: Float
    net1yRAT: Float
    net2yRAT: Float
    net3yRAT: Float
    net5yRAT: Float
    net7yRAT: Float
    net10yRAT: Float
    net15yRAT: Float
    net20yRAT: Float
    net25yRAT: Float
    net30yPlusRAT: Float
  }

  input UpdateStaticDataNetBucketingXccyBasisBasisGamma {
    id: ID
    term: ID
    sp_id: Int
    net10y: Float
    net30yPlus: Float
    net20y: Float
    net10yPlus: Float
    net1y: Float
    net3m: Float
    netUnder3m: Float
    net5y: Float
    net3y: Float
    net3mRAT: Float
    net1yRAT: Float
    net2yRAT: Float
    net3yRAT: Float
    net5yRAT: Float
    net7yRAT: Float
    net10yRAT: Float
    net15yRAT: Float
    net20yRAT: Float
    net25yRAT: Float
    net30yPlusRAT: Float
  }

  input UpdateStaticDataCreditStressCdsRating {
    id: ID
    anzRatingTypeSystem: InputOptionType
    longStress: Int
    shortStress: Int
    isActive: Boolean
  }

  type ANZRatingBandOption {
    id: ID
    text: String
  }

  input UpdateStaticDataCreditStressCreditIndices {
    id: ID
    CRIndexType: InputOptionType
    longStress: Int
    shortStress: Int
    isActive: Boolean
  }

  input UpdateStaticDataCreditStressTopCdsIssuers {
    id: ID
    Issuer: InputOptionType
    longStress: Int
    shortStress: Int
    isActive: Boolean
  }

  input UpdateStaticDataGenericSeniority {
    id: ID
    value: String
    system: SystemInputType
    isActive: Boolean
  }

  input UpdateStaticDataCreditStressSpreadTenBondDefaultStress {
    id: ID
    stressFactor: Int
    isActive: Boolean
  }

  input UpdateStaticDataRepoTypologyMap {
    id: ID
    typology: String
    mapValue: String
    isActive: Boolean
  }

  type AgencyOption {
    id: ID!
    text: String!
  }

  input UpdateStaticDataRatingOverride {
    id: ID
    issuer: InputOptionType
    agency: InputOptionType
    creditRating: InputOptionType
    isActive: Boolean
  }

  input UpdateStaticDataCreditStressBondRating {
    id: ID
    anzRatingTypeSystem: InputOptionType
    daysToMaturity: String
    Currency: InputOptionType
    longStress: Int
    shortStress: Int
    isActive: Boolean
  }

  input UpdateStaticDataStealthMaturityRange {
    id: ID
    name: String
    rangeFrom: Float
    rangeTo: Float
    isActive: Boolean
  }

  input UpdateStaticDataCustomMember {
    id: ID
    name: String
    underlyingType: InputOptionType
    operation: InputOptionType
    nameofUnderlying: [NameOfUnderlyingInputOption]
    isActive: Boolean
  }

  input NameOfUnderlyingInputOption {
    id: ID
    text: String
    weight: Float
  }

  type OperationTypeOption {
    id: ID
    text: String
  }

  type UnderlyingTypeOption {
    id: ID
    text: String
  }

  type UnderlyingNameListOption {
    id: ID
    typeId: Int
    text: String
  }

  input UpdateStaticDataTenorDaysToMaturity {
    id: ID
    tenor: String
    daysToMaturity: Int
    isDeliverable: Boolean
  }

  type TenorListInputOption {
    id: ID
    text: String
  }

  type StaticDataPortfolioConfig {
    id: ID!
    modified: Boolean!
    portfolio: PortfolioOption
    container: RiskContainerOption
    sources: [SourceSystemOption]
    officialSource: SourceSystemOption
    isActive: Boolean!
    added: Added!
  }

  type PortfolioOption {
    id: ID
    text: String
  }

  type RiskContainerOption {
    id: ID
    text: String
  }

  type SourceSystemOption {
    id: ID
    text: String
  }

  input UpdateStaticDataLMENonDeliveryDay {
    id: ID
    date: DateTime
    isLMENonDelivery: Boolean
  }

  input UpdateStaticDataPortfolioConfig {
    id: ID
    portfolio: InputOptionType
    sources: [InputOptionType]
    officialSource: InputOptionType
    isActive: Boolean
  }

  type PortfolioInputOption {
    id: ID
    text: String
  }

  type SourceSystemsInputOption {
    id: ID
    text: String
  }

  type CMRCPeriod {
    id: ID
    modified: Boolean!
    cmrcPeriodDate: DateTime!
    isActive: Boolean!
    isCmrcReported: Boolean!
    added: Added!
  }

  type StaticDataMarketRiskBusinessGroup {
    id: ID!
    modified: Boolean!
    description: String
    value: String!
    isActive: Boolean!
    added: Added!
  }

  type StaticDataLimitClassification {
    id: ID!
    modified: Boolean!
    description: String
    isActive: Boolean!
    added: Added!
  }

  type MarketRiskBusinessMapping {
    modified: Boolean!
    id: ID!
    code: String
    marketRiskBusinessDescription: String
    marketRiskBusinessGroup: MarketRiskBusinessGroup
    added: Added!
  }

  type MarketRiskBusinessGroup {
    id: ID
    text: String
  }

  type StaticDataPurposeForChange {
    id: ID!
    modified: Boolean!
    description: String
    isActive: Boolean!
    added: Added!
  }

  input UpdateStaticDataInstrumentAssetSwapSpread {
    id: ID
    ISIN: String
    spread: Float
    cob: String!
  }

  type StaticDataDynamicLimitThreshold {
    id: ID!
    modified: Boolean!
    isin: String!
    percentageLong: Float
    percentageShort: Float
    expiryDate: String!
    isActive: Boolean!
    added: Added!
  }
  type StaticDataExcessReason {
    id: ID!
    modified: Boolean!
    description: String
    isActive: Boolean!
    added: Added!
  }

  type MarketRiskBusinessGroupEmailMapping {
    id: ID!
    modified: Boolean!
    snapshot: String
    marketRiskBusinessGroup: MarketRiskBusinessGroup
    emailToList: String
    emailCcList: String
    added: Added!
  }

  type StaticDataGlobalProductLine {
    id: ID!
    modified: Boolean!
    description: String
    isActive: Boolean!
    added: Added!
  }

  type ProductSubCategoryMapping {
    id: ID!
    modified: Boolean!
    description: String
    globalProductLine: GlobalProductLine
    isActive: Boolean!
    added: Added!
  }

  type MarketRiskBusinessAssignmentMapping {
    id: ID!
    additionalParamsForAuditHistory: MRBAssignmentAuditHistoryAdditionalParam
    modified: Boolean!
    marketRiskBusiness: MarketRiskBusiness
    user: SystemUser
    receiveNotifications: Boolean
    compositeKey: [String]
    isActive: Boolean!
    added: Added!
  }

  type MRBAssignmentAuditHistoryAdditionalParam {
    marketRiskBusinessId: ID
    userId: String
  }

  type SystemUser {
    id: ID
    text: String
  }

  type GlobalProductLine {
    id: ID
    text: String
  }

  type MarketRiskBusiness {
    id: ID
    text: String
  }

  input UpdateStaticDataMarketRiskBusinessGroup {
    id: ID
    description: String
    value: String
    isActive: Boolean
  }

  input UpdateMarketRiskBusinessMapping {
    id: ID
    code: String
    marketRiskBusinessDescription: String
    marketRiskBusinessGroup: InputOptionType
  }

  type MarketRiskBusinessGroupingInputOption {
    id: ID
    text: String
  }

  type TradeBookingSystemInputOption {
    id: ID
    text: String
  }

  type ScheduleMapping {
    id: ID!
    modified: Boolean!
    name: String
    scheduleLocation: String
    lastIssuedOn: String
    lastIssuedBy: SystemUser
    marketRiskBusiness: MarketRiskBusiness
    reviewDate: String
    isActive: Boolean!
    added: Added!
  }

  input UpdateStaticDataLimitClassifications {
    id: ID
    description: String
    isActive: Boolean
  }

  input UpdateStaticDataInstrument {
    id: ID
    instrumentFilter: String
    name: String
    ISIN: String
    description: String
    bloombergSeniority: String
    called: String
    bailInStatus: String
    instrumentDebtTicker: String
    issuerEquityTicker: String
    keepwellAgreement: String
    guarantorEquityTicker: String
    SBLCEntity: String
    apraDerivedRating: String
    derivedRatingOverrideComment: String
    entityOfRiskComment: String
    countryOfRisk: String
    countryOfRiskOverrideComment: String
    BICSLevel1: String
    BICSLevel2: String
    BICSLevel3: String
    capitalTriggerType: String
    capitalTriggerLevel: String
    leadManager: String
    useOfProceeds: String
    domesticSUKUK: String
    internationalSUKUK: String
    descriptionNotes: String
    marketIssue: String
    acKey: String
    basel3Designation: String
    countryOfDomicile: String
    industrySector: String
    industryGroup: String
    marketSectorDescription: String
    redemptionCurrency: String
    couponFrequencyDescription: String
    couponType: String
    floaterFormula: String
    floaterSpread: String
    makeWholeCallSpread: String
    makeWholeIndicator: String
    entityOfRiskSP: String
    entityOfRiskMoody: String
    entityOfRiskFitch: String
    entityOfRiskSPOverride: String
    entityOfRiskMoodyOverride: String
    entityOfRiskFitchOverride: String
    marketRiskRatingComment: String
    perpetual: String
    stepUp: String
    riskComment: String
    typeOfBond: String
    creditCurveLabel: String
    countryOfRiskOverride: Float
    issueOutstandingAmount: Float
    instrumentUtilisation: Float
    Currency: InputOptionType
    genericSeniorityTypeSystem: InputOptionType
    snpIssueRating: InputOptionType
    moIssueRating: InputOptionType
    fitchIssueRating: InputOptionType
    Issuer: IssuerInputOptionType
    guaranteeIssuer: IssuerInputOptionType
    derivedRatingOverride: InputOptionType
    limitEntityIssuer: IssuerInputOptionType
    entityOfRiskIssuer: IssuerInputOptionType
    overrideSRCatSec: InputOptionType
    creditIndexTypeTypeSystem: InputOptionType
    issuanceCountry: CountryInputOptionType
    equityMarketCapTypeSystem: InputOptionType
    apraRankTypeSystem: InputOptionType
    basel3DesignationOverrideSystem: InputOptionType
    ACSPResultantRating: InputOptionType
    ACMoodyResultantRating: InputOptionType
    ACFitchResultantRating: InputOptionType
    ACApraDerivedRating: InputOptionType
    curveAssignmentRatingOverride: InputOptionType
    curveAssignmentRating: InputOptionType
    apraStressSecTypeSystem: InputOptionType
    overrideRatingBandSec: RatingBandOverrideInputTypeOption
    holdingPeriodStatusTypeSystem: InputOptionType
    maturityDate: String
    nextCallDate: String
    dateOfIssue: String
    dueDilligenceDate: String
    secFstAccDate: String
    callableFlag: Boolean
    isGuaranteed: Boolean
    isOECD: Boolean
    isGoodISIN: Boolean
    isDueDilligence: Boolean
    isDataReview: Boolean
    isIgnore: Boolean
    isCollateralised: Boolean
    isApraApproved: Boolean
    isTier1Tier2: Boolean
    flag144A: Boolean
    isRegS: Boolean
    creditTick: Boolean
    comment: String
    isActive: Boolean
  }

  type Basel3DesignationOverrideSystemTypeOption {
    id: ID
    text: String
  }

  type DerivedRatingTypeOption {
    id: ID
    text: String
  }

  type EquityMarketCapTypeSystemTypeOption {
    id: ID
    text: String
  }

  type APRARankTypeSystem {
    id: ID
    text: String
  }

  type APRARankTypeSystemTypeOption {
    id: ID
    text: String
  }

  type APRAStressSecuritisationTypeOption {
    id: ID
    text: String
  }

  type HoldingPeriodStatusTypeOption {
    id: ID
    text: String
  }

  type PerpetualFlagStatusOption {
    id: ID
    text: String
  }

  input IssuerInputOptionType {
    id: ID
    text: String
    description: String
  }

  input CountryInputOptionType {
    id: ID
    text: String
    countryCode: String
  }

  input RatingBandOverrideInputTypeOption {
    id: ID
    text: String
    displayName: String
  }

  input UpdateStaticDataExcessReasons {
    id: ID
    description: String
    isActive: Boolean
  }

  input UpdateStaticDataPurposeForChange {
    id: ID
    description: String
    isActive: Boolean
  }

  input UpdateStaticDataDynamicLimitThreshold {
    id: ID
    percentageLong: Float
    percentageShort: Float
    isActive: Boolean
  }

  input UpdateStaticDataGlobalProductLine {
    id: ID
    description: String
    isActive: Boolean
  }

  input UpdateMarketRiskBusinessAssignmentMapping {
    id: ID
    marketRiskBusiness: InputOptionType
    user: InputOptionType
    receiveNotifications: Boolean
    isActive: Boolean
  }

  type MarketRiskBusinessOption {
    id: ID
    text: String
  }

  input UpdateCMRCPeriod {
    id: ID
    cmrcPeriodDate: DateTime
    isActive: Boolean
    isCmrcReported: Boolean
  }

  input UpdateMarketRiskBusinessGroupEmailMapping {
    id: ID
    marketRiskBusinessGroup: InputOptionType
    snapshot: String
    emailToList: String
    emailCcList: String
    isActive: Boolean
  }

  input UpdateProductSubCategoryMapping {
    id: ID
    description: String
    globalProductLine: InputOptionType
    isActive: Boolean
  }

  type GlobalProductLineInputOption {
    id: ID
    text: String
  }

  type SnapShotOption {
    id: ID
    text: String
  }

  input UpdateScheduleMapping {
    id: ID
    name: String
    scheduleLocation: String
    lastIssuedOn: String
    lastIssuedBy: InputOptionType
    marketRiskBusiness: InputOptionType
    reviewDate: String
    updateLimits: Boolean
    isActive: Boolean
  }

  type KeepwellAgreementOption {
    id: ID
    text: String
  }

  type StaticDataCreditExtraOrdinaryStress {
    id: ID!
    modified: Boolean!
    key: String!
    genericRating: String!
    dealCurrency: String!
    financialMarketCrash: Float
    usEconomicCrash: Float
    globalInflationaryCrisis: Float
    asianCrisis: Float
    chinaHardLanding: Float
    sustainedDeflation: Float
    sovereignDowngradeAust: Float
    cnyAndHkdFreeFloat: Float
    isActive: Boolean
    added: Added!
  }

  input UpdateStaticDataCreditExtraOrdinaryStress {
    id: ID
    key: String
    genericRating: String
    dealCurrency: String
    financialMarketCrash: Float
    usEconomicCrash: Float
    globalInflationaryCrisis: Float
    asianCrisis: Float
    chinaHardLanding: Float
    sustainedDeflation: Float
    sovereignDowngradeAust: Float
    cnyAndHkdFreeFloat: Float
    isActive: Boolean
  }
`;

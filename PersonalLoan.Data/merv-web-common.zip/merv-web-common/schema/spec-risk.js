const gql = require("graphql-tag");
exports.schema = gql`
  extend input BatchActions {
    sendSpecificRiskReportRegen: SendSpecificRiskReportRegenInput
    sendSpecificRiskDraftEmail: SendSpecificRiskEmailInput
    sendSpecificRiskConfirmedEmail: SendSpecificRiskEmailInput
  }

  input SendSpecificRiskReportRegenInput {
    from: Date!
    to: Date!
    reportTypes: [ID!]!
    recalculateApportionmentOnly: Boolean!
  }

  input SendSpecificRiskEmailInput {
    date: Date
  }

  extend type Query {
    SpecificRiskAudit(from: Date!, to: Date!, measureType: ID!): [SpecificRiskAudit]
    SpecificRiskAuditMeasureTypes: [Option]
    SpecificRiskAuditReportTypes: [Option]
    SpecificRiskRegenAudit(from: Date!): [SpecificRiskRegenAudit]
  }

  type SpecificRiskRegenAudit {
    id: ID
    status: String
    message: String
    reportType: String
    startTime: DateTime
    date: DateRange
    added: Added
  }

  type SpecificRiskAudit {
    date: Date
    tenDayVaR: String
    stressVaR: String
    specRiskIR: String
    specRiskEQ: String
    specRiskSec: String
    economicalCap: String
    tenDayVaRAssetType: String
    stressVaRAssetType: String
  }
`;

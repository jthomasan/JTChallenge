const gql = require("graphql-tag");
exports.schema = gql`  
  extend type Query {
    RiskMeasures: [RiskMeasure]
  }

  type RiskMeasure {
    id: ID!
    name: String
  }  
`;

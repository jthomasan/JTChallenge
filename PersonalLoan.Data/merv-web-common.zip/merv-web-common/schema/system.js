const gql = require("graphql-tag");
exports.schema = gql`
  scalar DateTime
  scalar Date
  scalar JSON
  scalar Any

  type Mutation {
    batchChange(actions: [BatchActions!]!): MutationResult
  }

  input BatchActions

  type MutationResult {
    success: Boolean!
    actions: [ActionResult]!
  }

  type ActionResult {
    name: String!
    message: String
  }

  type Query {
    User: User
  }

  type User {
    username: String
    firstName: String
    lastName: String

    authority: [String]
  }

  type Added {
    by: String
    time: DateTime
  }

  type Exclusion {
    by: String
    reason: String
  }

  type Option {
    id: ID
    text: String
  }

  type DateRange {
    from: Date
    to: Date
  }
`;

const gql = require("graphql-tag");
exports.schema = gql`
  enum WorkflowType {
    RERUN
    PROXY
    EXCLUSION
    INCLUSION
    SIGN_OFF
    RELOAD
  }

  extend input BatchActions {
    sendDataLoadUpdateStatusRequest: UpdateDataLoadRequestStatus
    sendDataLoadUpdateExpiryRequest: UpdateDataLoadRequestExpiry
  }

  extend type Query {
    WorkflowRequests(date: Date!, type: WorkflowType!): [WorkflowRequest]
    EndpointSourceUris: [EndpointSourceUri]
    DataLoadRequestReports: [DataLoadRequestReport]
    DataLoadRequests(resultCount: Int): [DataLoadRequest]
    DataLoadRequestStatuses(requestId: Int): [DataLoadRequestStatus]
    DataLoadRequestReportStatuses(
      date: Date!
      reportName: String
      snapshot: String
      sourceSystemEnvironment: String
    ): [DataLoadRequestReportStatus]
  }

  type WorkflowRequest {
    id: ID
    type: WorkflowType
    businessDate: Date
    runDate: Date
    report: String
    container: String
    portfolio: String
    status: String
    isProcessed: Boolean
    comment: String
    snapshot: String
    sourceBusinessDate: Date
    sourceSystem: SourceSystem

    portfolioNode: PortfolioInfo
    # sourceFeed: FeedInfo # Not yet needed for signOff

    useVersion: Int

    message: String

    added: Added
    lastUpdated: Added
  }

  type DataLoadRequest {
    id: ID
    description: String
    requestedBy: String
    expiryDate: String
    status: DataLoadStatus
    progress: Float
    runDates: [String]
    businessDates: String
    sourceSystemEnvironments: [String]
    snapshot: String
    reports: [String]
    portfolios: [String]
    requestFeedType: String
    parent: DataLoadRequestParent
    lastUpdated: Added
  }

  type DataLoadRequestParent {
    id: ID
  }

  type DataLoadStatus {
    request: LoadStatusDetail
    load: LoadStatusDetail
  }

  type LoadStatusDetail {
    id: ID
    value: String
  }

  type EndpointSourceUri {
    id: ID
    name: String
    endpoints: String
    isActive: Boolean
  }

  type DataLoadRequestReport {
    id: ID
    name: String
    containers: DataLoadRequestReportContainer
    sourceSystem: DataLoadRequestReportSourceSystem
    isFmProcessing: Boolean
  }

  type DataLoadRequestReportContainer {
    cube: [String]
    publish: [String]
  }

  type DataLoadRequestReportSourceSystem {
    id: ID
    value: String
  }

  type DataLoadRequestStatus {
    businessDate: String
    snapshot: String
    sourceSystemEnvironment: String
    reportName: String
    riskEngineStatus: DataLoadProgressStatus
    downloadStatus: DataLoadProgressStatus
    cubeTradeEtlStatus: DataLoadProgressStatus
    loadStatus: DataLoadProgressStatus
    lastUpdatedTime: Date
    isFmProcessing: Boolean
    isMREDependent: Boolean
    isMXRateDependent: Boolean
  }

  type DataLoadProgressStatus {
    Total: Int
    NotStarted: Int
    Pending: Int
    Processing: Int
    Failure: Int
    Completed: Int
  }

  type DataLoadRequestReportStatus {
    feedId: Int
    businessDate: String
    snapshot: String
    sourceSystemEnvironment: String
    reportName: String
    portfolio: String
    status: DataLoadReportStatus
    containerName: String
    riskEngine: DataLoadRiskEngineStatus
    download: DataLoadProcessStatus
    cubeTradeEtl: DataLoadProcessStatus
    cubeLoad: DataLoadProcessStatus
  }

  type DataLoadReportStatus {
    riskEngine: String
    download: String
    cubeTradeEtl: String
    rdw: String
    load: String
    mrePosition: String
    fxRate: String
    hierarchy: String
  }

  type DataLoadRiskEngineStatus {
    lastUpdatedTime: String
  }

  type DataLoadProcessStatus {
    file: String
    message: String
    lastUpdatedTime: String
  }

  input UpdateDataLoadRequestStatus {
    id: ID
    status: String
  }

  input UpdateDataLoadRequestExpiry {
    id: ID
    expiryDate: Date
  }
`;

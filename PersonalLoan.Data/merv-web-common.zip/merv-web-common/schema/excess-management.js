const gql = require("graphql-tag");
exports.schema = gql`
  extend input BatchActions {
    sendLoadExposuresRequest: LoadExposuresRequestInput
    signOffExposuresRequest: SignOffExposuresRequestInput
  }

  extend type Query {
    ExcessMonitors(fromDate: Date, toDate: Date): [ExcessMonitor]
    LimitExposures(
      excessMonitorId: String
      breachTypes: [String]
      isIntraDay: Boolean
      marketRiskBusinessIds: [ID]
      limitScheduleIds: [ID]
      riskMeasureIds: [ID]
      riskNodeIds: [ID]
      customMemberIds: [ID]
    ): [LimitExposure]
    LoadExposuresOptions: LoadExposuresOptions
  }

  type ExcessMonitor {
    id: ID!
    businessDate: Date
    exposureType: String
    exposureField: String
    snapshotName: String
    marketRiskBusinessGroup: MarketRiskBusinessGroup
    containerName: String
    status: String
    exposureStartTime: DateTime
    exposureCompletedTime: DateTime
    excessStartTime: DateTime
    excessEndTime: DateTime
    added: Added!
  }

  type LimitExposure {
    id: ID!
    limitId: ID
    breachType: String
    marketRiskControl: String
    marketRiskBusiness: String
    limitSchedule: String
    riskMeasure: String
    scenarioValue: String
    hierarchy: [LimitHierarchy]
    underlying: String
    tradePortfolioAttributes: [String]
    customMembers: [String]
    exposureAmount: String
    unit: String
    limitAmount: String
    isMonitored: Boolean
    exposureUnderlying: String
  }

  type LimitHierarchy {
    type: String
    value: String
  }

  type LoadExposuresOptions {
    snapshots: [String]
    repoExposureFields: [String]
    repoLimitTypes: [RepoLimitType]
    businessDates: [BusinessDateType]
  }

  type RepoLimitType {
    id: ID
    value: String
  }

  type BusinessDateType {
    date: String
    isCob: Boolean
  }

  input LoadExposuresRequestInput {
    cobDate: String!
    exposureType: String!
    exposureField: String
    snapshot: String
    marketRiskBusinessGroupID: ID
    repoLimitTypes: [ID]
  }

  input SignOffExposuresRequestInput {
    excessMonitorId: ID
  }
`;

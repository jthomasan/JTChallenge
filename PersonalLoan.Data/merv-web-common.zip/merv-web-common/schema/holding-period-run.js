const gql = require("graphql-tag");
exports.schema = gql`
  extend input BatchActions {
    sendHoldingPeriodRegenerateRequest: RegenerateHoldingPeriodRun
  }

  extend type Query {
    HoldingPeriodRunAudit(from: Date!): [HoldingPeriodRunAudit]
  }

  type HoldingPeriodRunAudit {
    status: String
    message: String
    date: DateRange
    regenFromMRE: Boolean
    startTime: DateTime
    added: Added
  }

  input RegenerateHoldingPeriodRun {
    fromCobDate: DateTime
    toCobDate: DateTime
    regenFromMRE: Boolean
  }
`;

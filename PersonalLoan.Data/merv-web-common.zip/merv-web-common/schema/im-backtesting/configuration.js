const gql = require("graphql-tag");
exports.schema = gql`
  extend input BatchActions {
    replaceTrafficLightsThreshold: UpdateTrafficLightsThreshold
    addTrafficLightsThreshold: UpdateTrafficLightsThreshold
  }
  extend type Query {
    TrafficLightsThreshold: [TrafficLightsThreshold]
    TrafficLightsThresholdHistory(auditId: ID!): [TrafficLightsThresholdHistory]
    ImProductsConfiguration: [ImProductsConfiguration]
  }
  type TrafficLightsThreshold {
    id: ID
    modified: Boolean!
    auditId: Int
    numberOfObservations: Int
    maxExceedancesGreen: Int
    maxExceedancesAmber: Int
    isActive: Boolean
  }
  type TrafficLightsThresholdHistory {
    numberOfObservations: Int
    maxExceedancesGreen: Int
    maxExceedancesAmber: Int
    isActive: Boolean
    added: Added
  }

  type ImProductsConfiguration {
    modified: Boolean!
    name: String
    isActive: Boolean
  }

  input UpdateTrafficLightsThreshold {
    id: ID
    numberOfObservations: Int
    maxExceedancesGreen: Int
    maxExceedancesAmber: Int
    isActive: Boolean
  }
`;

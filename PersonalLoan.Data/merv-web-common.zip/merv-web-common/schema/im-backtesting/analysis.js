const gql = require("graphql-tag");
exports.schema = gql`
  extend type Query {
    IMBackTestingProducts(active: Boolean): [IMBackTestingProduct]
    IMBackTestingCSAs(type: String!, date: Date!, product: ID!): [IMBackTestingCSA]
    IMBackTestingCSA(id: ID!, type: String!, date: Date!, product: ID!): IMBackTestingCSA
    IMBackTestingDates(type: String!): [Date]
    IMBackTestingVaRResults(date: Date!, product: ID!, csa: ID!): IMBackTestingVaRResult
    IMBackTestingResults(type: String!, date: Date!, product: ID!, csa: ID!, months: Int!): [IMBackTestingResult]
    IMBackTestingTrades(type: String!, date: Date!, product: ID!, csa: ID!, aggregate: Boolean!): [IMBackTestingTrade]
    IMBackTestingVaRTrades(date: Date!, product: ID!, csa: ID!, scenarioDate: Date!): [IMBackTestingTrade]
    IMBackTestingPnlByTradeId(type: String!, date: Date!, product: ID!, tradeId: ID!): IMBackTestingPnlVectorSummary
  }

  type IMBackTestingPnlVectorSummary {
    pnls: [IMBackTestingPnl]
    currency: String
  }

  type IMBackTestingPnl {
    attribution: String
    date: Date
    amount: Float
  }

  type IMBackTestingProduct {
    id: ID!
    name: String!
    isActive: Boolean
  }

  type IMBackTestingCSA {
    id: ID!
    name: String!
  }

  type IMBackTestingVaRResult {
    cobDate: Date
    version: Int
    productClass: String
    creditSupportAnnex: IMBackTestingCSA
    currency: String
    initialMargin: Float
    pledgorCurrency: String
    pledgorInitialMargin: Float
    initialMarginTrades: Int
    riskEngineTrades: Int
    statusMessage: String

    percentile01: Float
    percentile99: Float
    var500Percentile01: Float
    var500Percentile99: Float
    trafficLight: String
    exceedances: [DateTime]
    pnl: [PnLVector]
  }

  type PnLVector {
    date: Date
    amount: Float
  }

  type IMBackTestingResult {
    cobDate: Date
    version: Int
    productClass: String
    creditSupportAnnex: IMBackTestingCSA
    currency: String
    initialMargin: Float
    pledgorCurrency: String
    pledgorInitialMargin: Float
    initialMarginTrades: Int
    riskEngineTrades: Int
    statusMessage: String

    pnl: PnLVector
    difference: Float
  }

  type IMBackTestingTrade {
    tradeId: ID!
    cobDate: Date
    creditSupportAnnex: IMBackTestingCSA
    scenarioDate: Date
    pnl: Float
    portfolio: String
    sourceSystem: String
    family: String
    group: String
    type: String
    instrument: String
    currency: String
    counterparty: String
    productClass: String

    expiryDate: Date
    isProxy: Boolean
  }
`;

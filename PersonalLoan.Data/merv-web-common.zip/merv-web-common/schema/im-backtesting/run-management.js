const gql = require("graphql-tag");
exports.schema = gql`
  extend input BatchActions {
    sendImRunManagementActualRequest: UpdateIMRunManagementActual
    sendImRunManagementHypoRequest: UpdateIMRunManagementHypo
    sendImRunManagementVarRequest: UpdateIMRunManagementVar
  }

  extend type Query {
    IMRunManagement: [IMRunManagement]
    IMAttributionTypes: [String]
  }

  type IMRunManagement {
    cobDate: Date
    version: Int
    productClass: String
    pnLFilter: [String]
    type: String
    creditSupportAnnexes: Int
    initialMarginTrades: Int
    riskEngineTrades: Int
    statusMessage: String
    runTime: DateTime
    endTime: DateTime
    added: Added
    isProxy: Boolean
  }

  input UpdateIMRunManagementActual {
    selectedType: String
    product: [InputOptionType]
    fromDate: Date
    toDate: Date
    attributions: [InputOptionType]
  }

  input UpdateIMRunManagementHypo {
    selectedType: String
    product: [InputOptionType]
    fromDate: Date
    toDate: Date
  }

  input UpdateIMRunManagementVar {
    selectedType: String
    cobDate: Date
    product: [InputOptionType]
  }
`;

const gql = require("graphql-tag");
exports.schema = gql`
  extend type Query {
    IMDashboardVarSummary(
      cobDate: String!
      product: String!
    ): [IMDashboardVarSummary]
    IMDashboardHypoSummary(
      cobDate: String!
      product: String!
    ): [IMDashboardHypoSummary]
    IMDashboardActualSummary(
      cobDate: String!
      product: String!
    ): [IMDashboardActualSummary]
  }

  type IMDashboardVarSummary {
    percentile01: Float
    percentile99: Float
    var500Percentile01: Float
    var500Percentile99: Float
    stressedVarPercentile01: Float
    stressedVarPercentile99: Float
    observations: Int
    exceedances: Int
    trafficLight: String
    cobDate: Date
    version: Int
    creditSupportAnnex: CreditSupportAnnex
    currency: String
    initialMargin: Float
    pledgorCurrency: String
    pledgorInitialMargin: Float
    initialMarginTrades: Int
    riskEngineTrades: Int
    statusMessage: String
    product: String
  }

  type IMDashboardHypoSummary {
    hypoPnL: Float
    averageInitialMarginExposure: Int
    averageHypoPnL: Int
    daysHypoAboveInitialMargin: Int
    cobDate: Date
    version: Int
    creditSupportAnnex: CreditSupportAnnex
    currency: String
    initialMargin: Float
    pledgorCurrency: String
    pledgorInitialMargin: Float
    initialMarginTrades: Int
    riskEngineTrades: Int
    statusMessage: String
    product: String
  }

  type IMDashboardActualSummary {
    pnL: Float
    averageInitialMarginExposure: Float
    averageActualPnL: Float
    daysActualPnLAboveInitialMargin: Int
    isProxy: Boolean
    cobDate: Date
    version: Int
    creditSupportAnnex: CreditSupportAnnex
    currency: String
    initialMargin: Float
    pledgorCurrency: String
    pledgorInitialMargin: Int
    initialMarginTrades: Int
    riskEngineTrades: Int
    statusMessage: String
    product: String
  }

  type CreditSupportAnnex {
    id: ID
    name: String
  }
`;

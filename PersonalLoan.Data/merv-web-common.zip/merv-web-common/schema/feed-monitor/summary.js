const gql = require("graphql-tag");
exports.schema = gql`
  extend type Query {
    SignOffSummary(dates: [Date!]!): [SignOffSummary]
  }

  type RiskContainerLink {
    id: ID!
    name: String
  }

  type StatusSummaryCounts {
    notStarted: Int
    completed: Int
    failed: Int
    total: Int
  }

  type SignOffSummary {
    container: RiskContainerLink!
    date: Date
    counts: StatusSummaryCounts
  }
`;

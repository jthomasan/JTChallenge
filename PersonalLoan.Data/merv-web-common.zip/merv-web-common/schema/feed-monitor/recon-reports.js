const gql = require("graphql-tag");
exports.schema = gql`
  extend input BatchActions {
    updateReconReportComments: UpdateReconReportCommentsInput
  }

  input UpdateReconReportCommentsInput {
    ids: [ID]!
    comment: String!
    reconTypeId: ID!
  }

  extend type Query {
    ReconReportTypes: [ReconReportType]
    ReconReportType(id: ID!): ReconReportType
    PastBusinessDates(count: Int!): [Date]
    PastBusinessDatesBetween(from: Date!, to: Date!): [Date]
    PastCashReconDetails(
      dates: [Date]!
      statuses: [String]
    ): [PastCashReconDetail]
    DailyTradeReconDetails(dates: [Date], sourceSystems: [String], statuses: [String]): [DailyTradeReconDetail]
    ReconSystems(from: Date!, to: Date!, reportType: ID!): [String]
    TradePricingErrorDetails(dates: [Date], sourceSystems: [String], statuses: [String]): [TradePricingErrorDetail]
    MurexRiskEngineReconDetails(dates: [Date], statuses: [String]): [MurexRiskEngineReconDetail]
    ReconReportSummary(from: Date!, to: Date!, reportType: ID!): [ReconReportSummary]
  }

  type ReconReportSummary {
    date: Date
    reviewRequired: Boolean
    review: ReviewStatus
    statuses: [ReconReportStatusSummary]
    sourceSystem: String
    valuationType: String
  }

  type ReviewStatus {
    finished: Boolean
    reviewed: Int
    total: Int
  }

  type ReconReportStatusSummary {
    name: String
    threshold: ReconReportStatus
    value: Int
  }

  type ReconReportType {
    id: ID!
    value: String!
    name: String
    description: String

    statuses(isActive: Boolean): [ReconReportStatus]

    added: Added
  }

  type ReconReportStatus {
    id: ID
    name: String
    range: Float
    isActive: Boolean

    added: Added
  }

  type PastCashReconTRN {
    family: String
    type: String
    group: String
  }

  type PastCashReconDifference {
    actual: Float
    percentage: Float
  }

  type PastCashReconNumbers {
    murex: Float
    sky: Float
  }

  type PastCashReconDetail {
    id: ID
    modified: Boolean
    cobDate: Date
    userComment: String
    status: String

    portfolio: String
    currency: String

    trn: PastCashReconTRN
    difference: PastCashReconDifference
    pastCash: PastCashReconNumbers

    added: Added
    updated: Added
  }

   type DailyTradeReconDetail {
    id: ID
    modified: Boolean
    COBDate: Date
    maRRSDealNumber: String
    MREDealNumber: String
    maRRSPortfolio: String
    MREPortfolio: String
    tradeFamily: String
    tradeGroup: String
    tradeType: String
    instrument: String
    effectiveMaturity: Date
    sourceSystem: String
    valuationType: String
    status: String
    reason: String
    systemComment: String
    userComment: String
    added: Added
    updated: Added
  }
  
  type InstrumentDetails {
    tradeID: ID
    family: String
    type: String
    group: String
    instrument: String
  }

  type ReportDetails {
    name: String
    description: String
  }

  type SourceSystemDetails {
    name: String
    environment: String
  }

  type TradePricingErrorDetail {
    id: ID
    modified: Boolean
    cobDate: Date
    contractName: String
    counterParty: String
    error: String
    jobName: String
    portfolio: String
    status: String
    tradeType: String
    oos: String
    userComment: String
    mx: InstrumentDetails
    report: ReportDetails
    sky: InstrumentDetails
    sourceSystem: SourceSystemDetails
    added: Added
    updated: Added
  }

  type TrnAttributes {
    family: String
    group: String
  }

  type TpAttributes {
    portfolio: String
    timeSystem: DateTime
    cntrp: String
    dateDTETRN: Date
  }

  type BrwAttributes {
    nom1: Float
    nom2: Float
  }

  type PlAttributes {
    insCurrency: String
    fmv2: Float
    csnfcp2: Float
    fpnfcp2: Float
  }

  type RiskEngineDetail {
    nb: ID
    instrument: String
    trn: TrnAttributes
    tp: TpAttributes
    brw: BrwAttributes
    pl: PlAttributes
  }

  type MurexRiskEngineReconDetail {
    id: ID
    modified: Boolean
    cobDate: Date
    status: String
    userComment: String
    murexVersion: String
    mre: RiskEngineDetail
    trade: RiskEngineDetail
    added: Added
    updated: Added
  }
`;

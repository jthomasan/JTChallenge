const gql = require("graphql-tag");
exports.schema = gql`
  extend type Query {
    NonUvrFeedStatuses(
      date: String!
      snapshot: String
      sourceSystemIds: [ID]
    ): [NonUvrFeedStatus]
    FMRefDataStatusLog(logIds: [ID]): [FMRefDataStatusLog]
    FMRefDataStatusJobs(date: String!): [FMJobStatus]
  }

  type NonUvrFeedStatus {
    id: ID
    feedId: ID
    feedType: String
    businessDate: String
    reportName: String
    cubeInstance: CubeInstance
    isFmFeed: Boolean
    snapshot: String
    sourceSystem: SourceSystemDetail
    sourceSystemEnvironment: String
    status: StatusFeedDetails
    lastUpdated: Added
  }

  type CubeInstance {
    id: ID!
  }

  type StatusFeedDetails {
    cubeLoad: String
    cubeTradeEtl: String
    download: String
    riskEngine: String
  }

  type SourceSystemDetail {
    id: ID!
    version: String
  }

  type FMRefDataStatusLog {
    id: ID
    reportName: String
    portfolio: String
    message: String
  }

  type FMJobStatus {
    id: ID
    businessDate: Date
    job: FMJob
    runDate: Date
    status: FMStatus
    log: String
    time: FMJobStatusTime
    added: Added
    lastUpdated: Added
  }

  type FMStatus {
    id: ID
    name: String
  }

  type FMJob {
    id: ID
    type: FMJobType
  }

  type FMJobType {
    id: ID
    name: String
  }

  type FMJobStatusTime {
    start: DateTime
    complete: DateTime
  }
`;

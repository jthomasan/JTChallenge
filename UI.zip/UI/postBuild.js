const fs = require('fs');
const packageVersion = require('./package.json').version;

fs.appendFileSync('dist/index.html', `<!-- merv-web-ui@${packageVersion} -->`);

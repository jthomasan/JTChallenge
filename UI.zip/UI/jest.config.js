module.exports = {
  testURL: 'http://localhost:8000',
  extraSetupFiles: ['./tests/setupTests.js'],

  // Required to emulate umi-test while adding an after env setup
  setupFilesAfterEnv: [
    require.resolve('umi-test/lib/jasmine'),
    '<rootDir>/tests/setupTestsAfterEnv.js',
  ],
  snapshotSerializers: ['enzyme-to-json/serializer'],
  globals: {
    ANT_DESIGN_PRO_ONLY_DO_NOT_USE_IN_YOUR_PRODUCTION: false,
    localStorage: null,
    __UMI_HTML_SUFFIX: false,
  },
  testEnvironment: 'node',
  collectCoverage: true,
};

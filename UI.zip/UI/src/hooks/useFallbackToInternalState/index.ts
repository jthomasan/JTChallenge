import { useMergedState, SetStateMethod } from '../useMergedState';

export function useFallbackToInternalState<S>(
  externalState: S | undefined | null,
  setExternalState: SetStateMethod<S> | undefined | null,
  defaultInitialValue: S | (() => S),
): [S, SetStateMethod<S>];

export function useFallbackToInternalState<S = undefined>(
  externalState: S | undefined | null,
  setExternalState: SetStateMethod<S> | undefined | null,
): [S | undefined, SetStateMethod<S | undefined>];

export function useFallbackToInternalState<S>(
  externalState: S | undefined | null,
  setExternalState: SetStateMethod<S> | undefined | null,
  defaultInitialValue?: S | (() => S),
): [S | null | undefined, SetStateMethod<S>] {
  const [internalState, setInternalState] = useMergedState<S>(defaultInitialValue as any);

  if (setExternalState) {
    return [externalState, setExternalState];
  }

  return [internalState, setInternalState];
}

import { useState, useCallback } from 'react';

type MergedSetStateAction<S> = Partial<S> | ((prevState: S) => Partial<S>);
type SetStateAction<S> = S | ((prevState: S) => S);

export interface SetStateMethod<S> {
  /**
   * Will merge provided state with existing state
   */
  (state: MergedSetStateAction<S>, noMerge?: false): void;

  /**
   * Will override existing state
   */
  (state: SetStateAction<S>, noMerge: true): void;
}

export function useMergedState<S>(
  initialState: S | (() => S),
  componentName?: string,
): [S, SetStateMethod<S>];
export function useMergedState<S = undefined>(): [S | undefined, SetStateMethod<S | undefined>];
export function useMergedState<S>(initialState?: any): [S, SetStateMethod<S>] {
  const [state, setState] = useState(initialState);

  const setStateWithMerge = useCallback<SetStateMethod<S>>(
    (newState: MergedSetStateAction<S> | SetStateAction<S>, noMerge: boolean = false) => {
      if (noMerge) {
        setState(newState as SetStateAction<S>);
        return;
      }

      setState((currentState: any) => {
        const newStateDelta = newState as MergedSetStateAction<S>;
        const finalNewStateDelta =
          typeof newStateDelta === 'function' ? newStateDelta(currentState) : newStateDelta;
        return {
          ...currentState,
          ...finalNewStateDelta,
        };
      });
    },
    [setState],
  );

  return [state, setStateWithMerge];
}

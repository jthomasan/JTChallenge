import { useQuery, useApolloClient, useMutation } from 'umi-plugin-apollo-anz/apolloClient';

import useUncommittedChanges from '.';

describe('useUncommittedChanges hook', () => {
  const FIRST_CHANGE = 'change1';
  const CHANGES = [FIRST_CHANGE];
  let writeFragmentMock;
  let readFragmentMock;

  beforeAll(() => {
    const mockedPageData = {
      data: {
        page: {
          mockPage: {
            changes: CHANGES,
          },
        },
      },
    };

    useQuery.mockReturnValue(mockedPageData);

    writeFragmentMock = jest.fn();
    readFragmentMock = jest.fn().mockReturnValue({ changes: CHANGES });

    useApolloClient.mockReturnValue({
      writeFragment: writeFragmentMock,
      readFragment: readFragmentMock,
    });
  });

  beforeEach(() => {
    writeFragmentMock.mockClear();
    readFragmentMock.mockClear();
  });

  it('should return current cached value', () => {
    // When
    const [changes] = useUncommittedChanges();

    // Then
    expect(changes).toEqual(CHANGES);
  });

  it('should return empty array if data is not retrieved', () => {
    // Given
    useQuery.mockReturnValue({});

    // When
    const [changes] = useUncommittedChanges();

    // Then
    expect(changes.length).toStrictEqual(0);
  });

  it('should be able to add UPDATE action to change cache', async () => {
    // Given
    const NEW_VALUE = 'NEW_VAL';
    const updateCacheMock = jest.fn();
    const NEW_CHANGE = { to: NEW_VALUE, action: 'UPDATE', updateCache: updateCacheMock };

    const [, addChange] = useUncommittedChanges();

    // When
    await addChange(NEW_CHANGE);

    // Then

    // assert element added to change array
    expect(writeFragmentMock).toHaveBeenCalledTimes(1);
    const arg = writeFragmentMock.mock.calls[0][0];

    expect(arg.id).toEqual('MOCKPAGE:mockPage');
    expect(arg.data.changes.length).toEqual(2);
    expect(arg.data.changes[0]).toEqual(FIRST_CHANGE);
    expect(arg.data.changes[1].to).toEqual(NEW_VALUE);

    //  assert call made to update cached data
    expect(updateCacheMock).toHaveBeenCalledTimes(1);
  });

  it('should be able to add RENAME action to change cache even if page is not properly read', async () => {
    // Given
    const NEW_VALUE = 'NEW_VAL';
    const updateCacheMock = jest.fn();
    const NEW_CHANGE = { to: NEW_VALUE, action: 'RENAME', updateCache: updateCacheMock };

    const [, addChange] = useUncommittedChanges();
    readFragmentMock.mockReturnValue(null);

    // When
    await addChange(NEW_CHANGE);

    // Then

    // assert element added to change array
    expect(writeFragmentMock).toHaveBeenCalledTimes(1);
    const arg = writeFragmentMock.mock.calls[0][0];

    expect(arg.id).toEqual('MOCKPAGE:mockPage');
    expect(arg.data.changes.length).toEqual(1);
    expect(arg.data.changes[0].to).toEqual(NEW_VALUE);

    //  assert call made to update cached data
    expect(updateCacheMock).toHaveBeenCalledTimes(1);
  });

  it('should be able to undo UPDATE action from change cache', async () => {
    // Given
    const undoCacheMock = jest.fn();
    const NEW_CHANGE = { to: 'NEW_VAL', action: 'UPDATE', undoCache: undoCacheMock };

    const mockedPageData = {
      data: {
        page: {
          mockPage: {
            changes: ['a', NEW_CHANGE],
          },
        },
      },
    };

    useQuery.mockReturnValue(mockedPageData);
    readFragmentMock.mockReturnValue({ changes: ['a', NEW_CHANGE] });

    const [, , undoChange] = useUncommittedChanges();

    // When
    await undoChange();

    // Then

    // assert element removed from change array
    expect(writeFragmentMock).toHaveBeenCalledTimes(1);
    const arg = writeFragmentMock.mock.calls[0][0];

    expect(arg.id).toEqual('MOCKPAGE:mockPage');
    expect(arg.data.changes.length).toEqual(1);
    expect(arg.data.changes[0]).toEqual('a');

    //  assert call made to update cached data
    expect(undoCacheMock).toHaveBeenCalledTimes(1);
  });

  it('should not undo if change array is empty', async () => {
    // Given
    const mockedPageData = {
      data: {
        page: {
          mockPage: {
            changes: [],
          },
        },
      },
    };

    useQuery.mockReturnValue(mockedPageData);
    readFragmentMock.mockReturnValue({ changes: [] });

    const [, , undoChange] = useUncommittedChanges();

    // When
    await undoChange();

    // Then

    expect(writeFragmentMock).toHaveBeenCalledTimes(0);
  });

  it('should be able to clear all changes', async () => {
    // Given
    const [, , , clearAll] = useUncommittedChanges();

    // When
    await clearAll();

    // Then

    // assert change array cleared
    expect(writeFragmentMock).toHaveBeenCalledTimes(2);
    const arg = writeFragmentMock.mock.calls[0][0];

    expect(arg.id).toEqual('MOCKPAGE:mockPage');
    expect(arg.data.changes.length).toEqual(0);
  });

  it('should be able to commit actions from change cache', async () => {
    // Given
    const commitMock = jest.fn();
    const NEW_CHANGES = [
      { to: 'NEW_VAL', action: 'UPDATE', getMutationAction: jest.fn().mockReturnValue('action a') },
      {
        to: 'NEW_VAL2',
        action: 'UPDATE',
        getMutationAction: jest.fn().mockReturnValue('action b'),
      },
    ];

    const mockedPageData = {
      data: {
        page: {
          mockPage: {
            changes: NEW_CHANGES,
          },
        },
      },
    };

    useQuery.mockReturnValue(mockedPageData);
    readFragmentMock.mockReturnValue({ changes: NEW_CHANGES });
    useMutation.mockReturnValue([commitMock]);

    const [, , , , commitChanges] = useUncommittedChanges();

    // When
    await commitChanges();

    // Then

    // assert getMuationAction called
    expect(NEW_CHANGES[0].getMutationAction).toHaveBeenCalledTimes(1);
    expect(NEW_CHANGES[1].getMutationAction).toHaveBeenCalledTimes(1);

    // commit called
    expect(commitMock).toHaveBeenCalledTimes(1);
    const commitArg = commitMock.mock.calls[0][0];

    expect(commitArg.variables.actions).toEqual(['action a', 'action b']);
  });
});

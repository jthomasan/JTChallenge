import { useCallback } from 'react';

import uuid from 'uuid-random';

import {
  useApolloClient,
  useQuery,
  gql,
  ApolloClient,
  useMutation,
  FetchResult,
} from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLActivePage } from 'umi-plugin-apollo-anz/apolloPageState';

import { UncommittedChangesError } from '@/error/types';
import { Change, ChangeError } from '@/types/change';

const updateCache = (client: ApolloClient<object>, change: Change) => {
  if (change.updateCache) {
    return change.updateCache();
  }

  return undefined;
};

type Setter<T> = (value: T) => Promise<void>;
type Getter<T> = () => Promise<T>;

function useUncommittedChangesScopedVar<T>(
  name: string,
  fallbackValue: T,
  pageId: string,
  pageType: string,
): [Setter<T>, Getter<T>] {
  const client = useApolloClient();

  const setter = useCallback<Setter<T>>(
    async (value: T) => {
      client.writeFragment({
        id: pageId,
        fragment: gql`
          fragment uncommittedChangesScopedVar on ${pageType} {
            ${name}
          }
        `,
        data: {
          [name]: value,
        },
      });
    },
    [name, client, pageId, pageType],
  );

  const getter = useCallback<Getter<T>>(async () => {
    const page = client.readFragment({
      id: pageId,
      fragment: gql`
        fragment uncommittedChangesScopedVar on ${pageType} {
          ${name}
        }
      `,
    });

    return page?.[name] || fallbackValue;
  }, [fallbackValue, name, client, pageId, pageType]);

  return [setter, getter];
}

export default function useUncommittedChanges(): [
  Change[],
  (change: Change) => Promise<void>,
  () => Promise<void>,
  (undoAll?: boolean) => void,
  () => Promise<FetchResult | null>,
  ChangeError[],
  (error: ChangeError) => Promise<void>,
  (sourceType: string, sourceId: string, errors: ChangeError[]) => Promise<void>,
  Setter<() => void | null>,
  Setter<(actions: any) => Promise<boolean>>,
] {
  const client = useApolloClient();
  const [{ _selected: currentPage }, , { id: pageId, pageType }] = useGQLActivePage();

  const [commit] = useMutation(gql`
    mutation batch($actions: [BatchActions!]!) {
      batchChange(actions: $actions) {
        success
        actions
      }
    }
  `);

  let changes: Change[] = [];
  let changeErrors: ChangeError[] = [];

  // get uncommitted changes
  const { data: changeData } = useQuery(
    gql`query{ page @client { ${currentPage}{ changes errors } }}`,
  );

  if (changeData?.page?.[currentPage]) {
    ({ changes, errors: changeErrors } = changeData.page[currentPage]);
  }

  const [setPostSaveCallback, getPostSaveCallback] = useUncommittedChangesScopedVar<
    (() => void) | null
  >('postSaveCallback', null, pageId, pageType);
  const [setPreSaveCallback, getPreSaveCallback] = useUncommittedChangesScopedVar<
    ((actions: any) => Promise<boolean>) | null
  >('preSaveCallback', null, pageId, pageType);

  const [writeChanges, getExistingChanges] = useUncommittedChangesScopedVar<Change[]>(
    'changes',
    [],
    pageId,
    pageType,
  );

  const [writeErrors, getExistingErrors] = useUncommittedChangesScopedVar<ChangeError[]>(
    'errors',
    [],
    pageId,
    pageType,
  );

  // add change to cache and actually update cached data
  const addChange = useCallback(
    async (change: Change) => {
      const newChange: Change = {
        ...change,
        __typename: 'Change',
        id: uuid(),
      };

      const existingChanges = await getExistingChanges();
      const newChanges = [...existingChanges, newChange];

      newChange.undoCache = await updateCache(client, newChange);
      await writeChanges(newChanges);
    },
    [client, getExistingChanges, writeChanges],
  );

  // add error to cache
  const addError = useCallback(
    async (error: ChangeError) => {
      const newError: ChangeError = {
        ...error,
        __typename: 'ChangeError',
        id: uuid(),
      };

      const existingErrors = await getExistingErrors();
      const newErrors = [...existingErrors, newError];

      await writeErrors(newErrors);
    },
    [getExistingErrors, writeErrors],
  );

  // replace all errors for a given source id
  const replaceAllErrorsForSourceId = useCallback(
    async (sourceType: string, sourceId: string, errors: ChangeError[]) => {
      const newErrors = errors.map((error) => ({
        ...error,
        __typename: 'ChangeError',
        id: uuid(),
      }));

      const existingErrors = (await getExistingErrors()).filter(
        (e) => e.sourceType !== sourceType || e.sourceId !== sourceId,
      );
      await writeErrors([...existingErrors, ...newErrors]);
    },
    [getExistingErrors, writeErrors],
  );

  // Actual Implementation of undoChange based on the existing changes passed in
  const undoExistingChanges = useCallback(
    async (existingChanges: Change[]) => {
      if (!existingChanges.length) return;
      const newChanges = existingChanges.slice(0, existingChanges.length - 1);
      const lastChange = existingChanges[existingChanges.length - 1];

      writeChanges(newChanges);

      const undoResult = lastChange.undoCache ? await lastChange.undoCache(existingChanges) : null;

      if (undoResult && undoResult.shouldUndoAgain) {
        undoExistingChanges(newChanges);
      }
    },
    [writeChanges],
  );

  // remove last change to cache and actually update cache data
  const undoChange = useCallback(async () => {
    const existingChanges = await getExistingChanges();
    await undoExistingChanges(existingChanges);
  }, [getExistingChanges, undoExistingChanges]);

  const undoAllExistingChanges = useCallback(async () => {
    const existingChanges = await getExistingChanges();
    if (existingChanges.length === 0) {
      return;
    }

    await undoExistingChanges(existingChanges);
    await undoAllExistingChanges();
  }, [getExistingChanges, undoExistingChanges]);

  const clearAll = useCallback(
    (undoAll?: boolean) => {
      if (!undoAll) {
        writeChanges([]);
        writeErrors([]);
      } else {
        undoAllExistingChanges();
        writeErrors([]);
      }
    },
    [writeChanges, writeErrors, undoAllExistingChanges],
  );

  const handlePreSave = useCallback(
    async (actions: any): Promise<boolean> => {
      try {
        const preSaveCallback = await getPreSaveCallback();
        if (preSaveCallback) {
          return await preSaveCallback(actions);
        }
        return actions;
      } catch (e) {
        throw new UncommittedChangesError(e);
      }
    },
    [getPreSaveCallback],
  );

  const commitChanges = useCallback(async () => {
    let actions = (await getExistingChanges()).map((change) => change.getMutationAction());

    actions = actions.flat();
    let hasErrors = false;

    try {
      const preSaveResult = await handlePreSave(actions);
      if (preSaveResult !== false) {
        const result = await commit({ variables: { actions: preSaveResult } });
        return result;
      }
      return null;
    } catch (e) {
      hasErrors = true;
      if (e.graphQLErrors && e.graphQLErrors.length > 0) {
        const error = e.graphQLErrors[0].extensions;
        if (error.status === 500) {
          const existingChanges = await getExistingChanges();
          const completedActions = existingChanges.slice(0, error.successfulActions.length);
          const updatedChanges = existingChanges.slice(completedActions.length);
          const committedActionsMessage = `First ${completedActions.length} changes saved successfully`;
          updatedChanges[0] = {
            ...updatedChanges[0],
            ...{
              error: e.message,
            },
          };

          await writeChanges(updatedChanges);
          throw new UncommittedChangesError(e, committedActionsMessage, completedActions);
        }
      }
      throw new UncommittedChangesError(e);
    } finally {
      if (!hasErrors) {
        const postSaveCallback = await getPostSaveCallback();
        if (postSaveCallback) {
          postSaveCallback();
        }
      }
    }
  }, [commit, getExistingChanges, getPostSaveCallback, handlePreSave, writeChanges]);

  return [
    changes,
    addChange,
    undoChange,
    clearAll,
    commitChanges,
    changeErrors,
    addError,
    replaceAllErrorsForSourceId,
    setPostSaveCallback,
    setPreSaveCallback,
  ];
}

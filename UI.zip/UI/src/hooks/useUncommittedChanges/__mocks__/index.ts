export const addChangeMock = jest.fn();

const mock = jest
  .fn()
  .mockReturnValue([
    [],
    addChangeMock,
    jest.fn(),
    jest.fn(),
    jest.fn(),
    [],
    jest.fn(),
    jest.fn(),
    jest.fn(),
  ]);

export default mock;

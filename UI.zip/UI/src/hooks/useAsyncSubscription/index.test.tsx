/* eslint-disable no-unused-expressions */
import React, { _unmock as unmockReact } from 'react';
import { renderHook, act as actHook } from '@testing-library/react-hooks';
import { render, act, waitFor } from '@testing-library/react';

import { createSubscriptionContext } from '.';

describe('useAsyncSubscription', () => {
  beforeEach(() => {
    unmockReact();
  });

  it('calls only relevant subscriptions on trigger', async () => {
    // Create two contexts, and ensure triggering one doesn't trigger the other
    const context1 = createSubscriptionContext();
    const context2 = createSubscriptionContext();

    const onTrigger1 = jest.fn();
    const onTrigger2 = jest.fn();

    const { result, waitForNextUpdate } = renderHook(
      () => [
        context1.useAsyncSubscription(onTrigger1, []),
        context2.useAsyncSubscription(onTrigger2, []),
      ],
      {
        wrapper: ({ children }) => {
          const Provider1 = context1.Provider;
          const Provider2 = context2.Provider;

          return (
            <Provider1>
              <Provider2>{children}</Provider2>
            </Provider1>
          );
        },
      },
    );

    await actHook(async () => {
      result.current[0].trigger();
      await waitForNextUpdate();
    });

    expect(onTrigger1).toHaveBeenCalledTimes(1);
    expect(result.current[0].processing).toBe(false);
    expect(onTrigger2).toHaveBeenCalledTimes(0);
    expect(result.current[1].processing).toBe(false);
  });

  it('remains processing until all promises are complete', async () => {
    // Trigger multiple times, and ensure that processing != false until all subscriptions from both triggers have resolved
    const context = createSubscriptionContext();

    const resolves: (() => void)[] = [];

    const onTrigger = jest.fn(
      () =>
        new Promise<void>((resolve) => {
          resolves.push(resolve);
        }),
    );

    const { result, waitForNextUpdate } = renderHook(
      () => context.useAsyncSubscription(onTrigger, []),
      {
        wrapper: context.Provider,
      },
    );

    expect(result.current.processing).toBe(false);
    expect(onTrigger).toHaveBeenCalledTimes(0);

    await actHook(async () => {
      result.current.trigger();
      await waitForNextUpdate();
    });

    expect(result.current.processing).toBe(true);
    expect(onTrigger).toHaveBeenCalledTimes(1);

    await actHook(async () => {
      result.current.trigger();
      await waitForNextUpdate();
    });

    expect(result.current.processing).toBe(true);
    expect(onTrigger).toHaveBeenCalledTimes(2);

    expect(resolves).toHaveLength(2);

    actHook(() => {
      resolves.shift()?.();
    });

    expect(result.current.processing).toBe(true);
    expect(onTrigger).toHaveBeenCalledTimes(2);

    await actHook(async () => {
      resolves.shift()?.();
      await waitForNextUpdate();
    });

    expect(result.current.processing).toBe(false);
    expect(onTrigger).toHaveBeenCalledTimes(2);
  });

  it("won't trigger a subscriber after unmount", async () => {
    const resolves: (() => void)[] = [];
    const { Provider, useAsyncSubscription } = createSubscriptionContext();
    const TestComponent: React.FC<{ onTrigger: () => void; id: string }> = ({ onTrigger, id }) => {
      const { trigger, processing } = useAsyncSubscription(onTrigger, []);

      return (
        <div
          data-testid={id}
          onClick={() => {
            trigger();
          }}
        >
          {processing.toString()}
        </div>
      );
    };

    const onTrigger1 = jest.fn(
      () =>
        new Promise<void>((resolve) => {
          resolves.push(resolve);
        }),
    );
    const onTrigger2 = jest.fn();

    const { rerender, getByTestId } = render(
      <>
        <TestComponent key="1" id="1" onTrigger={onTrigger1} />
        <TestComponent key="2" id="2" onTrigger={onTrigger2} />
      </>,
      { wrapper: Provider },
    );

    expect(onTrigger1).toHaveBeenCalledTimes(0);
    expect(onTrigger2).toHaveBeenCalledTimes(0);

    await act(async () => {
      getByTestId('1').click();
      await waitFor(() => expect(getByTestId('1')).toHaveTextContent('true'));
      resolves.pop()?.();
      await waitFor(() => expect(getByTestId('1')).toHaveTextContent('false'));
    });

    expect(onTrigger1).toHaveBeenCalledTimes(1);
    expect(onTrigger2).toHaveBeenCalledTimes(1);

    rerender(
      <>
        <TestComponent key="1" id="1" onTrigger={onTrigger1} />
      </>,
    );

    await act(async () => {
      getByTestId('1').click();
      await waitFor(() => expect(getByTestId('1')).toHaveTextContent('true'));
      resolves.pop()?.();
      await waitFor(() => expect(getByTestId('1')).toHaveTextContent('false'));
    });

    expect(onTrigger1).toHaveBeenCalledTimes(2);
    expect(onTrigger2).toHaveBeenCalledTimes(1);
  });

  it("won't trigger an old subscriber after dependency change", async () => {
    const { Provider, useAsyncSubscription } = createSubscriptionContext();

    const onTrigger1 = jest.fn();
    const onTrigger2 = jest.fn();

    const { result, rerender, waitForNextUpdate } = renderHook(
      ({ onTrigger }: { onTrigger: () => void }) => useAsyncSubscription(onTrigger, [onTrigger]),
      {
        wrapper: ({ children }) => <Provider>{children}</Provider>,
        initialProps: {
          onTrigger: onTrigger1,
        },
      },
    );

    await actHook(async () => {
      result.current.trigger();
      await waitForNextUpdate();
    });

    expect(onTrigger1).toBeCalledTimes(1);
    expect(onTrigger2).toBeCalledTimes(0);

    rerender({ onTrigger: onTrigger2 });

    expect(onTrigger1).toBeCalledTimes(1);
    expect(onTrigger2).toBeCalledTimes(0);

    await actHook(async () => {
      result.current.trigger();
      await waitForNextUpdate();
    });

    expect(onTrigger1).toBeCalledTimes(1);
    expect(onTrigger2).toBeCalledTimes(1);
  });

  it('passes trigger context to subscribers', async () => {
    // Ensure subscriptions receive the context passed to trigger()
    const context = createSubscriptionContext<string>();

    const onTrigger = jest.fn();

    const { result, waitForNextUpdate } = renderHook(
      () => context.useAsyncSubscription(onTrigger, []),
      {
        wrapper: context.Provider,
      },
    );

    expect(result.current.processing).toBe(false);
    expect(onTrigger).toHaveBeenCalledTimes(0);

    await actHook(async () => {
      const { trigger } = result.current;
      trigger('abc');
      await waitForNextUpdate();
    });

    expect(onTrigger).toHaveBeenCalledWith('abc');
  });

  it('passes latest context out while processing, before setting back to default', async () => {
    // Check that only the latest context is stored in the provider's state despite multiple triggers
    const context = createSubscriptionContext<string>();

    const resolves: (() => void)[] = [];

    const onTrigger = jest.fn(
      () =>
        new Promise<void>((resolve) => {
          resolves.push(resolve);
        }),
    );

    const { result, waitForNextUpdate } = renderHook(
      () => context.useAsyncSubscription(onTrigger, []),
      {
        wrapper: context.Provider,
      },
    );

    expect(result.current.processing).toBe(false);
    expect(onTrigger).toHaveBeenCalledTimes(0);

    await actHook(async () => {
      result.current.trigger('abc');
      await waitForNextUpdate();
    });

    expect(result.current.processing).toBe(true);
    expect(result.current.context).toBe('abc');
    expect(onTrigger).toHaveBeenCalledTimes(1);

    await actHook(async () => {
      result.current.trigger('123');
      await waitForNextUpdate();
    });

    expect(result.current.processing).toBe(true);
    expect(result.current.context).toBe('123');
    expect(onTrigger).toHaveBeenCalledTimes(2);

    expect(resolves).toHaveLength(2);

    actHook(() => {
      resolves.shift()?.();
    });

    expect(result.current.processing).toBe(true);
    expect(result.current.context).toBe('123');
    expect(onTrigger).toHaveBeenCalledTimes(2);

    await actHook(async () => {
      resolves.shift()?.();
      await waitForNextUpdate();
    });

    expect(result.current.processing).toBe(false);
    expect(result.current.context).toBe(undefined);
    expect(onTrigger).toHaveBeenCalledTimes(2);
  });
});

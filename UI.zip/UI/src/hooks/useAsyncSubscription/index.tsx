import React, { useContext, createContext, useMemo, useEffect, useState } from 'react';

export type Subscriber<T = void> = (context: T) => Promise<any> | void;
type OnTriggerCallback<T> = (promise: Promise<any[]>, context: T) => void;

type SubscriptionReactContext<T> = {
  trigger: TwoWaySubject<T>['trigger'];
  subscribe: TwoWaySubject<T>['subscribe'];
  processing: boolean;
  context?: T;
} | null;

export type AsyncSubscriptionProvider = React.ComponentType<{}>;

export interface useAsyncSubscriptionFunction<T> {
  (): UseAsyncSubscriptionHookReturn<T>;
  (onTrigger: Subscriber<T>, deps: React.DependencyList): UseAsyncSubscriptionHookReturn<T>;
}

export interface SubscriptionContext<T> {
  useAsyncSubscription: useAsyncSubscriptionFunction<T>;
  Provider: AsyncSubscriptionProvider;
}

interface UseAsyncSubscriptionHookReturn<T> {
  processing: boolean;
  trigger: (context: T) => void;
  context: T;
}

type UnsubscribeFunction = () => void;

class TwoWaySubject<T> {
  private subscriptions: Subscriber<T>[];

  private onTrigger: OnTriggerCallback<T>;

  constructor(onTrigger: OnTriggerCallback<T>) {
    this.subscriptions = [];
    this.onTrigger = onTrigger;
  }

  subscribe = (subscription: Subscriber<T>): UnsubscribeFunction => {
    this.subscriptions.push(subscription);
    return () => {
      const index = this.subscriptions.indexOf(subscription);
      if (index >= 0) {
        this.subscriptions.splice(index, 1);
      }
    };
  };

  trigger = (context: T) => {
    this.onTrigger(
      Promise.all(this.subscriptions.map((subscription) => subscription(context))),
      context,
    );
  };
}

function generateUseAsyncSubscriptionHook<T>(
  reactContext: React.Context<SubscriptionReactContext<T>>,
): useAsyncSubscriptionFunction<T> {
  return function useAsyncSubscription(
    onTrigger?: Subscriber<T>,
    deps: React.DependencyList = [],
  ): UseAsyncSubscriptionHookReturn<T> {
    const context = useContext(reactContext);
    if (!context) {
      throw new Error('No async subscription context can be found');
    }

    const { subscribe, trigger } = context;

    useEffect(
      () => (onTrigger ? context.subscribe(onTrigger) : () => {}),
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [subscribe, ...deps],
    );

    return {
      trigger,
      processing: context.processing,
      context: context.context as T,
    };
  };
}

function generateUseAsyncSubscriptionProvider<T>(
  { Provider }: React.Context<SubscriptionReactContext<T>>,
  defaultContext?: T,
): AsyncSubscriptionProvider {
  const CustomProvider: React.FC = ({ children }) => {
    const [providerState, setProviderState] = useState({
      processing: false,
      context: defaultContext,
    });

    const subject = useMemo(() => {
      // Ensure we don't set processing = false until all promises have finished
      let activePromises = 0;
      return new TwoWaySubject<T>((promise, context) => {
        activePromises += 1;
        setProviderState({
          processing: true,
          context,
        });

        promise.finally(() => {
          activePromises -= 1;
          if (activePromises > 0) return;

          setProviderState({
            processing: false,
            context: defaultContext,
          });
        });
      });
    }, [setProviderState]);

    return (
      <Provider
        value={{
          trigger: subject.trigger,
          subscribe: subject.subscribe,
          ...providerState,
        }}
      >
        {children}
      </Provider>
    );
  };

  return CustomProvider;
}

export function createSubscriptionContext<T = void>(): SubscriptionContext<T | undefined>;
export function createSubscriptionContext<T>(defaultContext: T): SubscriptionContext<T>;
export function createSubscriptionContext<T>(defaultContext?: T): SubscriptionContext<T> {
  const context = createContext<SubscriptionReactContext<T>>(null);

  return {
    Provider: generateUseAsyncSubscriptionProvider(context, defaultContext),
    useAsyncSubscription: generateUseAsyncSubscriptionHook(context),
  };
}

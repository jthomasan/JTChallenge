import { _unmock as unmockReact } from 'react';
import { renderHook, act } from '@testing-library/react-hooks';
import { advanceBy } from 'jest-date-mock';
import { useDebouncedEffect, useDebouncedMemo } from '.';

jest.useFakeTimers();

const advance = (time: number) => {
  act(() => {
    advanceBy(time);
    jest.advanceTimersByTime(time);
  });
};

describe('useDebouncedEffect', () => {
  beforeEach(() => {
    unmockReact();
    jest.clearAllTimers();
  });

  it('debounces any calls to the effect', () => {
    const fn = jest.fn();
    renderHook(() => useDebouncedEffect(fn, [], 1000));

    expect(fn).toHaveBeenCalledTimes(0);

    advance(2000);

    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('resets debounce on dep change', () => {
    const fn = jest.fn();
    const { rerender } = renderHook(({ counter }) => useDebouncedEffect(fn, [counter], 1000), {
      initialProps: {
        counter: 1,
      },
    });

    expect(fn).toHaveBeenCalledTimes(0);

    advance(750);
    expect(fn).toHaveBeenCalledTimes(0);

    rerender({
      counter: 2,
    });
    expect(fn).toHaveBeenCalledTimes(0);

    advance(750);
    expect(fn).toHaveBeenCalledTimes(0);

    advance(750);
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('will cancel pending debounces after timeout change', () => {
    const fn = jest.fn();
    const { rerender } = renderHook(({ timeout }) => useDebouncedEffect(fn, [], timeout), {
      initialProps: {
        timeout: 1000,
      },
    });

    expect(fn).toHaveBeenCalledTimes(0);

    advance(750);
    expect(fn).toHaveBeenCalledTimes(0);

    rerender({
      timeout: 999,
    });

    expect(fn).toHaveBeenCalledTimes(0);

    advance(750);
    expect(fn).toHaveBeenCalledTimes(0);

    advance(750);
    expect(fn).toHaveBeenCalledTimes(1);
  });
});

describe('useDebouncedMemo', () => {
  beforeEach(() => {
    unmockReact();
    jest.clearAllTimers();
  });

  it('calls the factory and returns the initial value', () => {
    const fn = jest.fn(() => 'ABC123');
    const { result } = renderHook(() => useDebouncedMemo(fn, [], 1000));

    expect(result.current).toBe('ABC123');
    expect(fn).toHaveBeenCalledTimes(1);

    advance(2000);

    expect(fn).toHaveBeenCalledTimes(2);
  });

  it('restarts debounce after dep change', () => {
    const fn = jest.fn(() => -1);
    const { result, rerender } = renderHook(
      ({ counter }) => {
        fn.mockReturnValue(counter);
        return useDebouncedMemo(fn, [counter], 1000);
      },
      {
        initialProps: {
          counter: 1,
        },
      },
    );

    expect(result.current).toBe(1);
    expect(fn).toHaveBeenCalledTimes(1);

    advance(750);
    expect(fn).toHaveBeenCalledTimes(1);

    rerender({
      counter: 2,
    });

    expect(result.current).toBe(1);
    expect(fn).toHaveBeenCalledTimes(1);

    advance(750);
    expect(result.current).toBe(1);
    expect(fn).toHaveBeenCalledTimes(1);

    advance(750);
    expect(result.current).toBe(2);
    expect(fn).toHaveBeenCalledTimes(2);
  });

  it('will cancel pending debounces after timeout change', () => {
    const fn = jest.fn(() => 'ABC123');
    const { result, rerender } = renderHook(({ timeout }) => useDebouncedMemo(fn, [], timeout), {
      initialProps: {
        timeout: 1000,
      },
    });

    expect(result.current).toBe('ABC123');
    expect(fn).toHaveBeenCalledTimes(1);

    advance(750);
    expect(fn).toHaveBeenCalledTimes(1);

    rerender({
      timeout: 999,
    });

    expect(fn).toHaveBeenCalledTimes(1);

    advance(750);
    expect(fn).toHaveBeenCalledTimes(1);

    advance(750);
    expect(fn).toHaveBeenCalledTimes(2);
  });
});

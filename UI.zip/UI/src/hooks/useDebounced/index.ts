import { DependencyList, EffectCallback, useEffect, useMemo, useState } from 'react';
import { debounce } from 'lodash';

export function useDebouncedEffect(effect: EffectCallback, deps: DependencyList, timeout: number) {
  const debouncedEffect = useMemo(() => debounce(effect, timeout), [...deps, timeout]);

  useEffect(
    () => () => {
      debouncedEffect.cancel(); // Cancel any pending calls on unmount/timeout change
    },
    [debouncedEffect],
  );

  useEffect(debouncedEffect, [...deps, debouncedEffect]);
}

export function useDebouncedMemo<T>(factory: () => T, deps: DependencyList, timeout: number) {
  const [state, setState] = useState(() => factory());
  const debouncedSetState = useMemo(() => debounce(setState, timeout), [timeout]);

  useEffect(
    () => () => {
      debouncedSetState.cancel(); // Cancel any pending calls on unmount/timeout change
    },
    [debouncedSetState],
  );

  useEffect(() => {
    debouncedSetState(() => factory());
  }, [...deps, debouncedSetState]);

  return state;
}

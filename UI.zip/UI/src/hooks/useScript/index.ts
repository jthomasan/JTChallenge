import { useEffect } from 'react';

const appendURL = (url: string) => {
  const appendString = url.indexOf('?') >= 0 ? '&' : '?';

  return url + appendString;
};

const useScript = ({ url, id }: { url: string; id?: string }) => {
  useEffect(() => {
    const script = document.createElement('script');

    script.src = appendURL(url);

    if (id) {
      script.id = id;
    }

    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, [url]);
};

export default useScript;

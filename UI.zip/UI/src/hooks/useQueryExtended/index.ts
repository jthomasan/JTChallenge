/* eslint-disable no-underscore-dangle */
import { isPlainObject } from 'lodash';

import {
  useApolloClient,
  useQuery,
  DocumentNode,
  QueryHookOptions,
  QueryResult,
  OperationVariables,
  clearCacheOfType,
  ApolloQueryResult,
} from 'umi-plugin-apollo-anz/apolloClient';

import { QueryError } from '@/error/types';

function getTypesnamesFromData(data: any | undefined) {
  const typenames: Set<string> = new Set<string>();
  if (data && isPlainObject(data)) {
    Object.keys(data).forEach((k) => {
      const res = data[k];
      if (Array.isArray(res) && res.length && res[0].__typename) {
        typenames.add(res[0].__typename);
      }
    });
  }

  return Array.from(typenames);
}

interface ExtendedQueryResult<TData, TVariables> extends QueryResult<TData, TVariables> {
  clearCacheAndRefetch(variables?: Partial<TVariables>): Promise<ApolloQueryResult<TData>>;
}

export default function useQueryExtended<TData = any, TVariables = OperationVariables>(
  query: DocumentNode,
  options?: QueryHookOptions<TData, TVariables>,
): ExtendedQueryResult<TData, TVariables> {
  const client = useApolloClient();
  const result = useQuery<TData, TVariables>(query, { ...options, ...{ errorPolicy: 'none' } });
  const { error, data, refetch } = result;

  if (error) {
    throw new QueryError(error.message);
  }

  const typenames: string[] = getTypesnamesFromData(data);

  const clearCacheAndRefetch = (variables?: Partial<TVariables> | undefined) => {
    typenames.forEach((typename) => {
      clearCacheOfType(client, typename);
    });

    return refetch(variables);
  };

  return { ...result, clearCacheAndRefetch };
}

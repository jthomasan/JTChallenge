import { useEffect, useState, useRef, useCallback } from 'react';
import { MD5 } from 'crypto-js';
// eslint-disable-next-line import/no-extraneous-dependencies
import { print, ScalarTypeDefinitionNode } from 'graphql';
import {
  OperationVariables,
  DocumentNode,
  useLazyQuery,
  LazyQueryResult,
  QueryLazyOptions,
  LazyQueryHookOptions,
} from 'umi-plugin-apollo-anz/apolloClient';
import { createDBTable, putDataToDB, getDataFromDBById } from '@/services/storage';

interface DataFromIDB {
  id: string;
  data: any;
}

const getQueryName = (query: DocumentNode): string => {
  const { definitions } = query;
  const { value } = (definitions[0] as ScalarTypeDefinitionNode).name;

  return value;
};

/**
 * @description create a unique id based on query name and the variable
 * @param query
 * @param variable
 */
const getQueryID = (query: DocumentNode, variables?: any): string => {
  const queryAST = print(query);
  const queryStr = JSON.stringify({ queryAST, variables });

  return String(MD5(queryStr));
};

interface QueryResult<TData, TVariables>
  extends Pick<LazyQueryResult<TData, TVariables>, 'data' | 'loading' | 'networkStatus'> {
  refetch: (options?: QueryLazyOptions<TVariables> | undefined) => void;
}

export default <TData = any, TVariables = OperationVariables>(
  query: DocumentNode,
  options?: Omit<LazyQueryHookOptions<TData, TVariables>, 'fetchPolicy'>,
): QueryResult<TData, TVariables> => {
  const [cachedData, setCachedData] = useState<TData>();
  const name = getQueryName(query);
  const queryID = getQueryID(query, options?.variables);
  const cachedQueryID = useRef(queryID);
  const [loading, setLoading] = useState(true);
  const variableRef = useRef<TVariables | undefined>(options?.variables);

  useEffect(() => {
    variableRef.current = options?.variables;
  }, [options]);

  const addDataFromApiToDBTable = async (dataFromApi: TData) => {
    try {
      if (dataFromApi) {
        await putDataToDB(name, { id: queryID, data: dataFromApi });

        setCachedData(dataFromApi);
        setLoading(false);
      }
    } catch (e) {
      throw new Error(e);
    }
  };

  const [executeQuery, result] = useLazyQuery(query, {
    ...options,
    fetchPolicy: 'no-cache',
    onCompleted: addDataFromApiToDBTable,
    variables: undefined,
  });
  const { data } = result;

  const fetchDataFromDBIfDataExist = useCallback(async () => {
    try {
      const dataFromDB = (await getDataFromDBById(name, queryID)) as DataFromIDB;

      if (!dataFromDB) {
        executeQuery({
          variables: variableRef.current,
        });
      } else {
        setCachedData(dataFromDB.data);
        setLoading(false);
      }
    } catch (e) {
      throw new Error(e);
    }
  }, [executeQuery, name, queryID]);

  useEffect(() => {
    createDBTable(name).then(fetchDataFromDBIfDataExist);
  }, []);

  useEffect(() => {
    if (queryID !== cachedQueryID.current) {
      setLoading(true);
      fetchDataFromDBIfDataExist();
      cachedQueryID.current = queryID;
    }
  }, [fetchDataFromDBIfDataExist, queryID]);

  const refetch = (params?: QueryLazyOptions<TVariables> | undefined) => {
    setLoading(true);
    executeQuery({ variables: variableRef.current, ...params });
  };

  return { ...result, loading, refetch, data: cachedData ?? data };
};

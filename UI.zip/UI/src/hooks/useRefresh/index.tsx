import React, { DependencyList, useCallback } from 'react';
import { createSubscriptionContext, Subscriber } from '../useAsyncSubscription';

type RefreshContext = {
  background: boolean;
};

const subscriptionContext = createSubscriptionContext<RefreshContext>({
  background: false,
});

export const RefreshProvider = subscriptionContext.Provider;

export interface UseRefresh extends RefreshContext {
  refreshing: boolean;
  refresh: (background?: boolean) => void;
}

export function withRefresh<P>(Element: React.ComponentType<P>): React.ComponentType<P> {
  const WithRefresh: React.FC<P> = (props) => (
    <RefreshProvider>
      <Element {...props} />
    </RefreshProvider>
  );

  return WithRefresh;
}

export function useRefresh(): UseRefresh;
export function useRefresh(onRefresh: Subscriber<RefreshContext>, deps: DependencyList): UseRefresh;
export function useRefresh(onRefresh?: Subscriber<RefreshContext>, deps?: DependencyList) {
  const { trigger, processing, context } = subscriptionContext.useAsyncSubscription(
    onRefresh as any,
    deps as any,
  );

  const refresh = useCallback(
    (background: boolean = false) => {
      trigger({ background });
    },
    [trigger],
  );

  return {
    refreshing: processing,
    refresh,
    ...context,
  };
}

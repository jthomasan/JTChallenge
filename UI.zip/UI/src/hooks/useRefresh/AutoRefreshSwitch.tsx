import React, { useEffect } from 'react';
import { AUTO_REFRESH_INTERVAL } from '@/constants/refresh';
import { Switch } from 'antd';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import classNames from 'classnames';
import { useRefresh } from '.';

import styles from './AutoRefreshSwitch.less';

export const AutoRefreshSwitch: React.FC<JSX.IntrinsicElements['div']> = ({
  className,
  ...props
}) => {
  const { refresh } = useRefresh();
  const [externalState, setExternalState] = useGQLComponentState(
    { autoRefresh: false },
    'autoRefresh',
  );

  useEffect(() => {
    if (!externalState.autoRefresh) {
      return () => {};
    }

    const interval = setInterval(() => {
      refresh(true);
    }, AUTO_REFRESH_INTERVAL);

    return () => {
      clearInterval(interval);
    };
  }, [externalState.autoRefresh, refresh]);

  return (
    <div {...props} className={classNames(className, styles.wrapper)}>
      <small style={{ marginRight: '5px' }}>Auto Refresh</small>
      <Switch
        size="small"
        checked={externalState.autoRefresh}
        onChange={(checked) => {
          setExternalState({ autoRefresh: checked });
        }}
      />
    </div>
  );
};

import Button, { ButtonProps } from 'antd/lib/button';
import React from 'react';
import { useRefresh } from '.';

export const RefreshButton: React.FC<{ backgroundRefresh?: boolean } & Omit<
  ButtonProps,
  'onClick'
>> = ({ icon, disabled, backgroundRefresh, ...props }) => {
  const { refresh, refreshing } = useRefresh();

  return (
    <Button
      {...props}
      icon={icon ?? (refreshing ? 'loading' : 'reload')}
      onClick={() => {
        if (refreshing || disabled) {
          return;
        }

        refresh(backgroundRefresh);
      }}
      disabled={refreshing || disabled}
    />
  );
};

import { useQuery, useApolloClient, gql } from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLActivePage } from 'umi-plugin-apollo-anz/apolloPageState';
import { enqueueMutation } from 'umi-plugin-apollo-anz/mutationQueue';

export default (): any[] => {
  const client = useApolloClient();

  const [{ _selected: currentPage }, , { id: pageId, pageType }] = useGQLActivePage();

  const query = useQuery(gql`query{ page @client { ${currentPage}{ shouldRefresh } }}`);
  const { data } = query;
  let shouldRefresh: boolean = false;

  if (data?.page?.[currentPage]) {
    ({ shouldRefresh } = data.page[currentPage]);
  }

  const updateRefresh = (toRefresh: boolean) => {
    enqueueMutation(async () => {
      await client.writeFragment({
        id: pageId,
        fragment: gql`fragment updateRefresh on ${pageType}{
          shouldRefresh
        }`,
        data: {
          shouldRefresh: toRefresh,
        },
      });
    });
  };

  return [shouldRefresh, updateRefresh];
};

export default () => [false, jest.fn()];

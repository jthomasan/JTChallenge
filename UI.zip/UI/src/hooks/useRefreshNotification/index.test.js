import { useQuery, useApolloClient } from 'umi-plugin-apollo-anz/apolloClient';
import { waitForCacheWrites } from 'umi-plugin-apollo-anz/mutationQueue';
import useRefreshNotification from '.';

describe('useRefreshNotification hook', () => {
  const SHOULD_REFRESH = 'refreshData';

  beforeAll(() => {
    const mockedPageData = {
      data: {
        page: {
          mockPage: {
            shouldRefresh: SHOULD_REFRESH,
          },
        },
      },
    };

    useQuery.mockReturnValue(mockedPageData);
  });

  it('should return current cached value', () => {
    // Given
    const [shouldRefresh] = useRefreshNotification();

    // Then
    expect(shouldRefresh).toEqual(SHOULD_REFRESH);
  });

  it('should update cache with value', async () => {
    // Setup
    const writeFragmentMock = jest.fn();

    useApolloClient.mockReturnValue({
      writeFragment: writeFragmentMock,
    });

    // Given
    const NEW_VALUE = 'XYZ';

    const [, updateShouldRefresh] = useRefreshNotification();

    // When
    updateShouldRefresh(NEW_VALUE);
    jest.runAllTimers();
    await waitForCacheWrites();

    // Then
    expect(writeFragmentMock).toHaveBeenCalledTimes(1);
    const arg = writeFragmentMock.mock.calls[0][0];

    expect(arg.id).toEqual('MOCKPAGE:mockPage');
    expect(arg.data.shouldRefresh).toEqual(NEW_VALUE);
  });

  it('should return false if data is not retrieved', () => {
    // Given
    useQuery.mockReturnValue({});

    // When
    const [shouldRefresh] = useRefreshNotification();

    // Then
    expect(shouldRefresh).toStrictEqual(false);
  });
});

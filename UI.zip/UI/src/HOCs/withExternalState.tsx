import React from 'react';
import { ExternalisedStateProps } from '@/types/externalised-state';

interface ExternalisedStateComponent {
  externalState?: { [key: string]: any };
}

export default <P extends object>(
  WrappedComponent: ExternalisedStateComponent & React.ComponentType<P>,
) => (props: P & ExternalisedStateProps<any>) => {
  const { externalState: defaultExternalState } = WrappedComponent;
  const externalState = { ...(defaultExternalState || {}), ...(props.externalState || {}) };

  return <WrappedComponent {...props} externalState={externalState} />;
};

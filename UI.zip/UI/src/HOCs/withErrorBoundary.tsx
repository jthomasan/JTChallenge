import React, { ComponentType, ReactElement } from 'react';
import ErrorBoundary from '../error/ErrorBoundary';

export default (FallbackComponent: ReactElement) => (CatchableComponent: ComponentType<any>) => (
  props: any,
) => (
  <ErrorBoundary fallback={FallbackComponent}>
    <CatchableComponent {...props} />
  </ErrorBoundary>
);

export default {
  'exceptionand500.exception.back': 'Back to home',
  'exceptionand500.description.500': 'Sorry, the server is reporting an error.',
};

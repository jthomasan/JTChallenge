export default {
  'exceptionand500.exception.back': 'Voltar para Início',
  'exceptionand500.description.500': 'Desculpe, o servidor está reportando um erro.',
};

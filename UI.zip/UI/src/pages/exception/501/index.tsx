import React from 'react';
import { Icon, Result } from 'antd';

export default () => (
  <Result
    title="501"
    icon={<Icon type="experiment" />}
    style={{
      background: 'none',
    }}
    subTitle="This page has not yet been implemented"
  />
);

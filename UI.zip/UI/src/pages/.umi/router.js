import React from 'react';
import {
  Router as DefaultRouter,
  Route,
  Switch,
  StaticRouter,
} from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@@/history';
import RendererWrapper0 from 'C:/Jacob/UiSource/merv-ui/merv-web-ui/src/pages/.umi/LocaleWrapper.jsx';
import RendererWrapper1 from './apollo/index';
import { routerRedux, dynamic as _dvaDynamic } from 'dva';

const Router = routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__SecurityLayout" */ '../../layouts/SecurityLayout'),
          LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
            .default,
        })
      : require('../../layouts/SecurityLayout').default,
    routes: [
      {
        path: '/',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../../layouts/SideMenuLayout'),
              LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                .default,
            })
          : require('../../layouts/SideMenuLayout').default,
        Routes: [require('../Authorized').default],
        routes: [
          {
            name: 'home',
            icon: 'dashboard',
            path: '/home',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__home" */ '../home'),
                  LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                    .default,
                })
              : require('../home').default,
            routes: [
              {
                name: 'home',
                shortname: 'home',
                icon: 'home',
                path: '/home/welcome',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "p__home" */ '../home/welcome'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../home/welcome').default,
                exact: true,
              },
              {
                name: 'Dashboard',
                shortname: 'Dashboard',
                icon: 'dashboard',
                path: '/home/dashboard',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "p__home" */ '../home/dashboard'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../home/dashboard').default,
                authority: {
                  devOnly: true,
                },
                exact: true,
              },
              {
                name: 'Tasks',
                shortname: 'Tasks',
                icon: 'unordered-list',
                path: '/home/tasks',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "p__home" */ '../home/tasks'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../home/tasks').default,
                authority: {
                  devOnly: true,
                },
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'market-risk-reporting',
            icon: 'bar-chart',
            path: '/market-risk-reporting',
            authority: {
              devOnly: true,
            },
            routes: [
              {
                name: 'Reports',
                shortname: 'Reports',
                icon: 'file-done',
                path: '/market-risk-reporting/2',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                name: 'Reports Extractor',
                shortname: 'Extractor',
                icon: 'setting',
                path: '/market-risk-reporting/3',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                name: 'Holding Period Run Management',
                shortname: 'Hldg Pd Mgt',
                icon: 'warning',
                path: '/market-risk-reporting/5',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'rates-repository',
            icon: 'percentage',
            path: '/rates-repository',
            authority: {
              devOnly: true,
            },
            routes: [
              {
                name: 'Rates Editor',
                shortname: 'Rates Edit.',
                icon: 'select',
                path: '/rates-repository/6',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                name: 'Risk Factors',
                shortname: 'Risk Factrs',
                icon: 'robot',
                path: '/rates-repository/7',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                name: 'Container Browser',
                shortname: 'Containers',
                icon: 'block',
                path: '/rates-repository/8',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'market-risk-limits',
            icon: 'column-height',
            path: '/market-risk-limits',
            routes: [
              {
                name: 'Approved Limits',
                shortname: 'Approved',
                icon: 'check-square',
                path: '/market-risk-limits/approved-limits',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../market-risk-limits/approved-limits'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../market-risk-limits/approved-limits').default,
                exact: true,
              },
              {
                name: 'Pending Limits',
                shortname: 'Pending',
                icon: 'file-sync',
                path: '/market-risk-limits/pending-limits',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../market-risk-limits/pending-limits'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../market-risk-limits/pending-limits').default,
                authority: {
                  devOnly: true,
                },
                exact: true,
              },
              {
                name: 'Default Limits',
                shortname: 'Default',
                icon: 'profile',
                path: '/market-risk-limits/default-limits',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../market-risk-limits/default-limits'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../market-risk-limits/default-limits').default,
                exact: true,
              },
              {
                name: 'Bulk Upload',
                shortname: 'Bulk Upload',
                icon: 'upload',
                path: '/market-risk-limits/bulk-upload',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../market-risk-limits/bulk-upload'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../market-risk-limits/bulk-upload').default,
                exact: true,
              },
              {
                name: 'Limit Summary',
                path: '/market-risk-limits/limit-summary/:id',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../market-risk-limits/limit-summary'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../market-risk-limits/limit-summary').default,
                hideInMenu: true,
                exact: true,
              },
              {
                name: 'Submission Summary',
                path: '/market-risk-limits/submission-summary/:id',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../market-risk-limits/submission-summary'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../market-risk-limits/submission-summary').default,
                hideInMenu: true,
                exact: true,
              },
              {
                name: 'New Limit',
                path: '/market-risk-limits/new-limit',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../market-risk-limits/new-limit'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../market-risk-limits/new-limit').default,
                hideInMenu: true,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/reference-data',
            name: 'reference-data',
            icon: 'table',
            routes: [
              {
                name: 'Hierarchy',
                shortname: 'Hierarchy',
                icon: 'apartment',
                path: '/reference-data/hierarchy',
                authority: {
                  devOnly: false,
                  scopes: ['REF_DATA.HIERARCHY.READ'],
                },
                writeAuthority: ['REF_DATA.HIERARCHY.WRITE'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../reference-data/hierarchy'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../reference-data/hierarchy').default,
                exact: true,
              },
              {
                name: 'Static Data',
                shortname: 'Static Data',
                icon: 'database',
                path: '/reference-data/static-data/:category?/:dataset?',
                authority: ['REF_DATA.STATIC_DATA.READ'],
                writeAuthority: ['REF_DATA.STATIC_DATA.WRITE'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../reference-data/static-data'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../reference-data/static-data').default,
                exact: true,
              },
              {
                name: 'Configuration',
                shortname: 'Configuration',
                icon: 'setting',
                path: '/reference-data/configuration',
                authority: ['REF_DATA.CONFIGURATION.READ'],
                writeAuthority: ['REF_DATA.CONFIGURATION.WRITE'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../reference-data/configuration'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../reference-data/configuration').default,
                exact: true,
              },
              {
                name: 'Pending Updates',
                shortname: 'Pend. Updts',
                icon: 'profile',
                path: '/reference-data/pending-updates',
                authority: {
                  devOnly: true,
                },
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                name: 'MRE Position',
                shortname: 'MRE Pos.',
                icon: 'warning',
                path: '/reference-data/mre-position',
                authority: {
                  devOnly: true,
                },
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/feed-monitor',
            name: 'feed-monitor',
            icon: 'database',
            routes: [
              {
                name: 'Risk Data',
                shortname: 'Risk Data',
                icon: 'apartment',
                path: '/feed-monitor/risk-data',
                authority: ['FEED_MONITOR.RISK_DATA.READ'],
                writeAuthority: ['FEED_MONITOR.RISK_DATA.WRITE'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../feed-monitor/risk-data'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../feed-monitor/risk-data').default,
                exact: true,
              },
              {
                name: 'User Requests',
                shortname: 'User Req.',
                icon: 'team',
                path: '/feed-monitor/user-requests',
                authority: ['FEED_MONITOR.USER_REQ.READ'],
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../feed-monitor/user-requests'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../feed-monitor/user-requests').default,
                exact: true,
              },
              {
                name: 'Reconciliation Reports',
                shortname: 'Recon. Report',
                icon: 'file-search',
                path: '/feed-monitor/recon-reports/:reconType?',
                authority: {
                  scopes: ['FEED_MONITOR.RECON_REPORTS.READ'],
                },
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../feed-monitor/recon-reports'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../feed-monitor/recon-reports').default,
                exact: true,
              },
              {
                name: 'Specific Risk Management',
                shortname: 'Spec. Risk',
                icon: 'profile',
                path: '/feed-monitor/specific-risk/:measureType?',
                authority: {
                  scopes: ['FEED_MONITOR.SPEC_RISK.READ'],
                },
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../feed-monitor/specific-risk'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../feed-monitor/specific-risk').default,
                exact: true,
              },
              {
                name: 'Status',
                shortname: 'Status',
                icon: 'sync',
                path: '/feed-monitor/status',
                authority: {
                  devOnly: true,
                  scopes: ['FEED_MONITOR.STATUS.READ'],
                },
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                name: 'Summary',
                shortname: 'Summary',
                icon: 'file',
                path: '/feed-monitor/summary',
                authority: {
                  devOnly: true,
                  scopes: ['FEED_MONITOR.SUMMARY.READ'],
                },
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                name: 'Configuration',
                shortname: 'Configuration',
                icon: 'setting',
                path: '/feed-monitor/configuration',
                authority: {
                  scopes: ['FEED_MONITOR.CONFIG.READ'],
                },
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../feed-monitor/configuration'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../feed-monitor/configuration').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'apra-d2a',
            icon: 'area-chart',
            path: '/apra-d2a',
            authority: {
              devOnly: true,
            },
            routes: [
              {
                name: 'Report Admin',
                shortname: 'Admin',
                icon: 'setting',
                path: '/apra-d2a/report-admin',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../apra-d2a/report-admin'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../apra-d2a/report-admin').default,
                exact: true,
              },
              {
                name: 'Report Browser',
                shortname: 'Browser',
                icon: 'file',
                path: '/apra-d2a/report-browser',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../apra-d2a/report-browser'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../apra-d2a/report-browser').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'back-testing',
            icon: 'fund',
            path: '/back-testing',
            authority: {
              devOnly: true,
            },
            routes: [
              {
                name: 'Dashboard',
                shortname: 'Dashboard',
                icon: 'select',
                path: '/back-testing/9',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                name: 'Exception Browser',
                shortname: 'Exceptions',
                icon: 'schedule',
                path: '/back-testing/10',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__SideMenuLayout" */ '../exception/501'),
                      LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../exception/501').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/exception/403',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__exception__403" */ '../exception/403'),
                  LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                    .default,
                })
              : require('../exception/403').default,
            exact: true,
          },
          {
            path: '/',
            redirect: '/home/welcome',
            exact: true,
          },
          {
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__404" */ '../404'),
                  LoadingComponent: require('C:/Jacob/UiSource/merv-ui/merv-web-ui/src/components/PageLoading/index')
                    .default,
                })
              : require('../404').default,
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        component: () =>
          React.createElement(
            require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    component: () =>
      React.createElement(
        require('C:/Jacob/UiSource/merv-ui/merv-web-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    // dva 中 history.listen 会初始执行一次
    // 这里排除掉 dva 的场景，可以避免 onRouteChange 在启用 dva 后的初始加载时被多执行一次
    const isDva =
      history.listen
        .toString()
        .indexOf('callback(history.location, history.action)') > -1;
    if (!isDva) {
      routeChangeHandler(history.location);
    }
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper1>
        <RendererWrapper0>
          <Router history={history}>{renderRoutes(routes, props)}</Router>
        </RendererWrapper0>
      </RendererWrapper1>
    );
  }
}

/* eslint-disable import/no-unresolved */
/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React from 'react';
import { print } from 'graphql/language/printer';
import { merge } from 'lodash';
import { makeExecutableSchema } from 'graphql-tools';
import {
  ApolloClient,
  ApolloProvider,
  HttpLink,
  ApolloLink,
  InMemoryCache,
  gql,
} from 'umi-plugin-apollo-anz/apolloClient';
import SchemaContext from 'umi-plugin-apollo-anz/schemaContext';
// <%= ImportReactApolloHooks %> // import { ApolloProvider as ApolloHooksProvider } from "react-apollo-hooks";
import * as options from './../../../options/apollo.ts';
import remoteLink from './remote-link';
import pageTypeDefs from './pageSchema';
import { resolvers as pageResolvers, defaults as pageDefaults } from './pageResolvers';

const mainTypeDefs = gql`
  type Query {
    _void: String
  }

  type Mutation {
    _void: String
  }
`;

const mainDefaults = {
  _void: '_void',
};

const mainResolvers = {};

const typeDefs = [print(mainTypeDefs), print(pageTypeDefs)];
const defaults = merge(mainDefaults, pageDefaults);
const resolvers = merge(mainResolvers, pageResolvers);

const cacheOptions = options.cacheOptions || {};
const stateLinkOptions = options.stateLinkOptions || {};
const clientOptions = options.clientOptions || {};
const providerOptions = options.providerOptions || {};
const extraLinks = options.extraLinks || [];

const cache = options.makeCache
  ? options.makeCache({ cacheOptions })
  : new InMemoryCache({ ...cacheOptions });

const link = options.makeLink
  ? options.makeLink({ remoteLink, extraLinks })
  : ApolloLink.from([...extraLinks, remoteLink]);

const client = options.makeClient
  ? options.makeClient({ link, cache, resolvers, typeDefs, clientOptions })
  : new ApolloClient({ link, cache, resolvers, typeDefs, ...clientOptions });

function isObject(o) {
  return o !== null && typeof o === 'object' && Array.isArray(o) === false;
}

function transformObject(o) {
  let query = '';

  Object.keys(o).forEach((key) => {
    const value = o[key];
    query = `${query} ${key} `;

    if (isObject(value)) {
      query = `${query} { ${transformObject(value)} }`;
    } else if (Array.isArray(value) && value.length) {
      query = `${query} { ${transformObject(value[0])} }`;
    }
  });

  return query;
}

// create query from defaults
const query = gql`query{
  page @client {
    ${transformObject(defaults.page)}
  }
}`;

cache.writeQuery({ query, data: defaults });

export const schema = makeExecutableSchema({
  typeDefs,
  resolverValidationOptions: {
    requireResolversForResolveType: false,
  },
});

const provider = options.makeProvider
  ? options.makeProvider({ client, providerOptions })
  : ({ children }) => (
      <ApolloProvider client={client} {...providerOptions}>
        <SchemaContext.Provider value={schema}>
          {children}
        </SchemaContext.Provider>
      </ApolloProvider>
    );

export default provider;

import { HttpLink } from '@apollo/client';
import * as options from './../../../options/apollo.ts';

const uri = '/graphql';
const httpLinkOptions = options.httpLinkOptions || {};

const httpLink = options.makeHttpLink
  ? options.makeHttpLink({ uri, httpLinkOptions })
  : new HttpLink({ uri, ...httpLinkOptions });

export default httpLink;

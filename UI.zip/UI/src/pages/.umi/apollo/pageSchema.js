import { print } from 'graphql/language/printer';
import { gql } from '@apollo/client';
import schemaTsPageSchema from '../../schema';
import feedMonitorConfigurationPageSchema from '../../feed-monitor/configuration/schema';
import feedMonitorReconReportsPageSchema from '../../feed-monitor/recon-reports/schema';
import feedMonitorRiskDataPageSchema from '../../feed-monitor/risk-data/schema';
import feedMonitorSpecificRiskPageSchema from '../../feed-monitor/specific-risk/schema';
import feedMonitorUserRequestsPageSchema from '../../feed-monitor/user-requests/schema';
import referenceDataConfigurationPageSchema from '../../reference-data/configuration/schema';
import referenceDataHierarchyPageSchema from '../../reference-data/hierarchy/schema';
import referenceDataStaticDataPageSchema from '../../reference-data/static-data/schema';


const pageRootSchema = gql`
  scalar object

  type ComponentState {
    id: ID
    data: object
  }

  type Page {
    id: ID
    _selected: String
    _componentCounter: Int
    pageComponentStates: [ComponentState]
  }

  extend type Query {
    page: Page
  }

  extend type Mutation {
    setActivePage(value: String): String
    updateComponentState(page: String, state: object): object
    updatePageData(page: String, data: object): object
  }
`;

export default gql`
  ${print(pageRootSchema)}
    ${print(schemaTsPageSchema)}
  ${print(feedMonitorConfigurationPageSchema)}
  ${print(feedMonitorReconReportsPageSchema)}
  ${print(feedMonitorRiskDataPageSchema)}
  ${print(feedMonitorSpecificRiskPageSchema)}
  ${print(feedMonitorUserRequestsPageSchema)}
  ${print(referenceDataConfigurationPageSchema)}
  ${print(referenceDataHierarchyPageSchema)}
  ${print(referenceDataStaticDataPageSchema)}

`;

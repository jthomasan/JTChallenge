import { merge } from 'lodash';
import { gql } from '@apollo/client';
import { schema } from './index';
import * as feedMonitorConfigurationPageResolvers from '../../feed-monitor/configuration/resolvers';
import * as feedMonitorReconReportsPageResolvers from '../../feed-monitor/recon-reports/resolvers';
import * as feedMonitorRiskDataPageResolvers from '../../feed-monitor/risk-data/resolvers';
import * as feedMonitorSpecificRiskPageResolvers from '../../feed-monitor/specific-risk/resolvers';
import * as feedMonitorUserRequestsPageResolvers from '../../feed-monitor/user-requests/resolvers';
import * as referenceDataConfigurationPageResolvers from '../../reference-data/configuration/resolvers';
import * as referenceDataHierarchyPageResolvers from '../../reference-data/hierarchy/resolvers';
import * as referenceDataStaticDataPageResolvers from '../../reference-data/static-data/resolvers';


const pageRootDefaults = {
  page: {
    id: 'Page',
    __typename: 'Page',
    _selected: null,
    _componentCounter: 0,
  },
};

const pageRootResolvers = {
  Mutation: {
    setActivePage: (_, { value }, { cache }) => {
      cache.writeFragment({
        id: `Page:Page`,
        fragment: gql`
          fragment activePage on Page {
            _selected
            _componentCounter
          }
        `,
        data: {
          _selected: value,
          _componentCounter: 0,
        },
      });

      return value;
    },

    updateComponentState: (_, { page, state }, { cache }) => {
      cache.writeFragment({
        id: `ComponentState:${page}`,
        fragment: gql`
          fragment myComponentState on ComponentState {
            data
          }
        `,
        data: {
          data: state,
        },
      });

      return state;
    },

    updatePageData: (_, variables, { cache }) => {
      const { page } = variables;

      // get page type from schema
      const masterPageFields = schema.getType('Page').getFields();
      if (!masterPageFields[page]) return;
      const pageType = masterPageFields[page].type.name;

      const { data: newStateData } = variables;

      cache.writeFragment({
        id: `${pageType}:${page}`,
        fragment: gql`
            fragment myComponentStateUpdate on ${pageType} {
              ${Object.keys(newStateData).join(' ')}
            }
          `,
        data: newStateData,
      });
    },
  },
};

function isObject(o) {
  return o !== null && typeof o === 'object' && Array.isArray(o) === false;
}

const addComponentState = pageDefaults => {
  const componentStates = [];
  Object.keys(pageDefaults).forEach(key => {
    const pageDefault = pageDefaults[key];
    if (!pageDefault.id) {
      pageDefault.id = key;
      pageDefault.shouldRefresh = false;
    }

    if (isObject(pageDefault)) {
      componentStates.push({
        __typename: 'ComponentState',
        id: key,
        data: null,
      });
    }
  });

  // eslint-disable-next-line no-param-reassign
  pageDefaults.componentStates = componentStates;
  return pageDefaults;
};

export const defaults = merge(pageRootDefaults, {
  page: addComponentState(
    merge(
      {}
      , feedMonitorConfigurationPageResolvers.defaults
, feedMonitorReconReportsPageResolvers.defaults
, feedMonitorRiskDataPageResolvers.defaults
, feedMonitorSpecificRiskPageResolvers.defaults
, feedMonitorUserRequestsPageResolvers.defaults
, referenceDataConfigurationPageResolvers.defaults
, referenceDataHierarchyPageResolvers.defaults
, referenceDataStaticDataPageResolvers.defaults

    ),
  ),
});

export const resolvers = merge(
  pageRootResolvers
  , feedMonitorConfigurationPageResolvers.resolvers
, feedMonitorReconReportsPageResolvers.resolvers
, feedMonitorRiskDataPageResolvers.resolvers
, feedMonitorSpecificRiskPageResolvers.resolvers
, feedMonitorUserRequestsPageResolvers.resolvers
, referenceDataConfigurationPageResolvers.resolvers
, referenceDataHierarchyPageResolvers.resolvers
, referenceDataStaticDataPageResolvers.resolvers

);

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export default gql`
  type ReconReportsPage implements Refreshable {
    dummy: String
  }

  extend type Page {
    reconReports: ReconReportsPage
  }
`;

import { Button } from 'antd';
import React from 'react';
import { PastBusinessDatesBetweenSelector } from './PastBusinessDatesBetweenSelector';
import { ReconReportTypeStatusSelector } from './DetailsFilterSetStatusSelector';
import { ReconSystemSelector } from './DetailsFilterSetSourceSystemSelector';

export const DetailsFilterSet: React.FC<{
  from: string;
  to: string;
  reportType: string;
  showReconSourceSystems: boolean;

  value: {
    selectedDates: string[];
    selectedStatuses: string[];
    selectedSourceSystems: string[];
  };

  isPending: boolean;
  onChange: (
    state: Partial<{
      selectedDates: string[];
      selectedStatuses: string[];
      selectedSourceSystems: string[];
    }>,
  ) => void;
  onSubmit: () => void;
}> = ({
  from,
  to,
  reportType,
  showReconSourceSystems,
  value: { selectedDates, selectedStatuses, selectedSourceSystems },
  isPending,
  onChange,
  onSubmit,
}) => (
  <>
    <PastBusinessDatesBetweenSelector
      value={selectedDates}
      onChange={(values) => {
        onChange({ selectedDates: values });
      }}
      from={from}
      to={to}
    />
    <ReconReportTypeStatusSelector
      value={selectedStatuses}
      reportType={reportType}
      onChange={(values) => {
        onChange({ selectedStatuses: values });
      }}
    />
    {showReconSourceSystems && (
      <ReconSystemSelector
        value={selectedSourceSystems}
        from={from}
        to={to}
        reportType={reportType}
        onChange={(values) => {
          onChange({ selectedSourceSystems: values });
        }}
      />
    )}
    <Button
      size="small"
      type="primary"
      disabled={!isPending}
      onClick={() => {
        onSubmit();
      }}
    >
      Apply
    </Button>
  </>
);

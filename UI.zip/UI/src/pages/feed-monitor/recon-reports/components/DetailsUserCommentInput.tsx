import React from 'react';

import { Button } from 'antd';
import Search from 'antd/lib/input/Search';

import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';

export const DetailsUserCommentInput: React.FC<{
  onSubmit: (value: string) => void;
  submitDisabled: boolean;
}> = ({ onSubmit, submitDisabled }) => {
  const [{ comment }, setCommentState] = useGQLComponentState<{
    comment: string;
  }>(
    {
      comment: '',
    },
    'userCommentInput',
  );

  return (
    <>
      <Search
        value={comment}
        onChange={(value) => {
          setCommentState({ comment: value.target.value });
        }}
        size="small"
        placeholder="Type comment to apply on selected records"
        style={{ width: 325 }}
        enterButton={
          <Button type="primary" disabled={comment.length === 0 || submitDisabled}>
            Apply
          </Button>
        }
        onSearch={(value) => {
          if (value.length === 0 || submitDisabled) {
            return;
          }

          onSubmit(value);
          setCommentState({ comment: '' });
        }}
      />
    </>
  );
};

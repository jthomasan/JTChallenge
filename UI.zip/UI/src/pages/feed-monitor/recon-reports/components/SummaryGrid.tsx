import React, { useMemo } from 'react';

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import Grid, { ColumnProps } from '@/components/Grid';
import { asCell } from '@/components/SimpleTD';
import useQueryExtended from '@/hooks/useQueryExtended';
import { useRefresh } from '@/hooks/useRefresh';

import { ReconTypeConfiguration } from '../recon-type';

interface ReportSummaryQueryResponse {
  ReconReportSummary: {
    date: string;
    sourceSystem: string | null;
    valuationType: string | null;

    reviewRequired: boolean;
    review: {
      finished: boolean;
      reviewed: number;
      total: number;
    };
    statuses: {
      name: string;
      value: number;
    }[];
  }[];
}

const ReportSummaryQuery = gql`
  query ReportSummaryQuery($reportTypeId: ID!, $from: Date!, $to: Date!) {
    ReconReportSummary(from: $from, to: $to, reportType: $reportTypeId) {
      date
      sourceSystem
      valuationType

      reviewRequired
      review {
        finished
        reviewed
        total
      }

      statuses {
        name
        value
      }
    }
  }
`;

const columns: ColumnProps[] = [
  {
    field: 'date',
    title: 'COB Date',
    width: 100,
    defaultSortColumn: 'desc',
  },
  {
    field: 'review',
    title: 'Review Status (Reviewed/Total)',
    width: 200,
    cell: asCell(({ dataItem }) => {
      if (!dataItem.reviewRequired) {
        return <>Not Required</>;
      }

      const { review } = dataItem;

      return (
        <>
          {review.finished ? 'Yes' : 'No'} ({review.reviewed}/{review.total})
        </>
      );
    }),
  },
];

const sourceSystemColumn: ColumnProps = {
  field: 'sourceSystem',
  title: 'Source System',
  width: 120,
};

const valuationTypeColumn: ColumnProps = {
  field: 'valuationType',
  title: 'Valuation Type',
  width: 120,
};

export const SummaryGrid: React.FC<{
  reconTypeConfiguration: ReconTypeConfiguration;
  fromDate: string;
  toDate: string;
  reportTypeId: string;
}> = ({ reconTypeConfiguration, fromDate, toDate, reportTypeId }) => {
  const { data: queryData, loading, refetch } = useQueryExtended<ReportSummaryQueryResponse>(
    ReportSummaryQuery,
    {
      variables: {
        reportTypeId,
        from: fromDate,
        to: toDate,
      },
    },
  );

  const { refreshing } = useRefresh(() => {
    refetch();
  }, [refetch]);

  const data = queryData?.ReconReportSummary;

  const [statuses, mappedData] = useMemo(() => {
    const statusesWithValues = new Set<string>();

    return [
      statusesWithValues,
      data?.map((row) => {
        return {
          ...row,
          statuses: row.statuses.reduce((statusMap, status) => {
            if (status.value !== null) {
              statusesWithValues.add(status.name);
            }

            // eslint-disable-next-line no-param-reassign
            statusMap[status.name] = status.value;
            return statusMap;
          }, {}),
        };
      }) ?? [],
    ];
  }, [data]);

  const finalColumns = useMemo(() => {
    const pendingColumns = [...columns];

    if (reconTypeConfiguration.showValuationType) {
      pendingColumns.splice(1, 0, valuationTypeColumn);
    }

    if (reconTypeConfiguration.showReconSourceSystems) {
      pendingColumns.splice(1, 0, sourceSystemColumn);
    }

    if (data && data.length > 0) {
      data[0].statuses.forEach(({ name }) => {
        if (statuses.has(name)) {
          pendingColumns.push({
            field: `statuses.${name}`,
            title: name,
            width: 140,
          });
        }
      });
    }

    return pendingColumns;
  }, [
    data,
    reconTypeConfiguration.showReconSourceSystems,
    reconTypeConfiguration.showValuationType,
    statuses,
  ]);

  return (
    <Grid
      style={{
        height: '100%',
        border: 'none',
      }}
      loading={loading || refreshing}
      data={mappedData}
      columns={finalColumns}
    />
  );
};

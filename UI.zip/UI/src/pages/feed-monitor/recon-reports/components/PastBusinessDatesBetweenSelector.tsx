import React from 'react';

import { CalendarOutlined } from '@ant-design/icons';
import moment from 'moment';

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import MultiSelect from '@/components/MultiSelect';
import useQueryExtended from '@/hooks/useQueryExtended';
import { useRefresh } from '@/hooks/useRefresh';

import styles from './PastBusinessDatesBetweenSelector.less';

const PastBusinessDatesBetweenQuery = gql`
  query PastBusinessDatesBetweenQuery($from: Date!, $to: Date!) {
    PastBusinessDatesBetween(from: $from, to: $to)
  }
`;

interface PastBusinessDatesBetweenQueryResponse {
  PastBusinessDatesBetween: string[];
}

const dateStringToOption = (date: string) => ({
  id: date,
  text: moment(date).format('YYYY-MM-DD (dddd)'),
});

export const PastBusinessDatesBetweenSelector: React.FC<{
  from: string;
  to: string;
  value: string[];
  onChange: (values: string[]) => void;
}> = ({ from, to, value, onChange }) => {
  const { data, loading, refetch } = useQueryExtended<
    PastBusinessDatesBetweenQueryResponse,
    { from: string; to: string }
  >(PastBusinessDatesBetweenQuery, {
    variables: { from, to },
  });

  useRefresh(() => refetch(), [refetch]);

  return (
    <MultiSelect<{ id: string; text: string }>
      multiple
      className={styles.selector}
      size="small"
      style={{ width: '200px' }}
      placeholder="Dates"
      options={(data?.PastBusinessDatesBetween ?? []).map(dateStringToOption)}
      disabled={loading}
      value={value.map(dateStringToOption)}
      onChange={(dates) => {
        onChange(dates.map(({ id }) => id));
      }}
      suffixIcon={<CalendarOutlined />}
    />
  );
};

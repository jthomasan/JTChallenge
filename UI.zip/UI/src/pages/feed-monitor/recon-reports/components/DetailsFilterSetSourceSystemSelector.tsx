import React from 'react';

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import MultiSelect from '@/components/MultiSelect';
import useQueryExtended from '@/hooks/useQueryExtended';
import { useRefresh } from '@/hooks/useRefresh';

const ReconSystemQuery = gql`
  query ReconSystemQuery($from: Date!, $to: Date!, $id: ID!) {
    ReconSystems(from: $from, to: $to, reportType: $id)
  }
`;

interface ReconSystemQueryResponse {
  ReconSystems: string[];
}

const sourceSystemToOption = (sourceSystem: string) => ({
  id: sourceSystem,
  text: sourceSystem,
});

export const ReconSystemSelector: React.FC<{
  reportType: string;
  from: string;
  to: string;
  value: string[];
  onChange: (values: string[]) => void;
}> = ({ from, to, reportType, value, onChange }) => {
  const { data, loading, refetch } = useQueryExtended<
    ReconSystemQueryResponse,
    { from: string; to: string; id: string }
  >(ReconSystemQuery, {
    variables: { from, to, id: reportType },
  });

  useRefresh(() => refetch(), [refetch]);

  return (
    <MultiSelect<{ id: string; text: string }>
      multiple
      size="small"
      style={{ width: '150px' }}
      placeholder="Source"
      options={(data?.ReconSystems ?? []).map(sourceSystemToOption)}
      disabled={loading}
      value={value.map(sourceSystemToOption)}
      onChange={(values) => {
        onChange(values.map(({ id }) => id));
      }}
    />
  );
};

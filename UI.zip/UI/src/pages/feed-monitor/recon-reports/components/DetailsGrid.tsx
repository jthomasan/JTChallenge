import React, { useMemo } from 'react';

import Grid from '@/components/Grid';
import { getSelectionColumn } from '@/components/Grid/selection/getSelectionColumn';
import useDataFilter, { FilterableColumnProps } from '@/components/Grid/useDataFilter';
import useQueryExtended from '@/hooks/useQueryExtended';
import { useRefresh } from '@/hooks/useRefresh';
import GridStateCell from '@/pages/reference-data/static-data/components/StaticDataCells/GridStateCell';

import { ReconTypeConfiguration } from '../recon-type';

export const DetailsGrid: React.FC<{
  filter?: string;
  reportTypeConfiguration: ReconTypeConfiguration;
  selectedDates: string[];
  selectedStatuses: string[];
  selectedSourceSystems: string[];
  selectedReports: string[];
  onSelectReport: (reports: string[]) => void;
  onItemChange: GridProps['onItemChange'];
}> = ({
  filter,
  reportTypeConfiguration: { query, columns, showReconSourceSystems },
  selectedDates,
  selectedStatuses,
  selectedSourceSystems,
  selectedReports,
  onSelectReport,
  onItemChange,
}) => {
  const queryVars = {
    dates: selectedDates,
    statuses: selectedStatuses,
  };
  if (showReconSourceSystems) {
    queryVars['sourceSystems'] = selectedSourceSystems;
  }

  const { data, loading, refetch } = useQueryExtended(query, {
    variables: queryVars,
    skip: queryVars.dates.length === 0,
  });

  const { refreshing } = useRefresh(() => refetch(), [refetch]);

  const columnsWithSelector = useMemo<FilterableColumnProps[]>(
    () => [
      {
        field: 'modified',
        title: ' ',
        filter: 'text',
        filterable: false,
        resizable: false,
        width: '30px',
        cell: GridStateCell,
      },
      getSelectionColumn({
        identifier: 'id',
        selected: selectedReports,
        onChange: onSelectReport,
      }),
      ...columns,
    ],
    [selectedReports, onSelectReport, columns],
  );

  const filteredData = useDataFilter({
    data: data?.data,
    filter,
    columns,
  });

  return (
    <Grid
      style={{
        height: '100%',
        border: 'none',
      }}
      loading={loading || refreshing}
      data={filteredData}
      columns={columnsWithSelector}
      columnVirtualization
      editable
      onItemChange={onItemChange}
    />
  );
};

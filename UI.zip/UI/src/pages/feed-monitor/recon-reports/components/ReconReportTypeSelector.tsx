import React from 'react';

import { Select } from 'antd';
import { paramCase } from 'change-case';

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import useQueryExtended from '@/hooks/useQueryExtended';
import { useRefresh } from '@/hooks/useRefresh';

import configurations from '../recon-type';

interface ReconReportType {
  id: string;
  value: string;
  name: string;
}

interface ReconReportTypesQueryResponse {
  ReconReportTypes: ReconReportType[];
}

const ReconReportTypesQuery = gql`
  query ReconReportTypesQuery {
    ReconReportTypes {
      id
      value
      name
    }
  }
`;

interface ReconReportTypeSelectorProps {
  value?: string;
  onChange?: (newValue: string) => void;
}

export const ReconReportTypeSelector: React.FC<ReconReportTypeSelectorProps> = ({
  value,
  onChange,
}) => {
  const { data, refetch } = useQueryExtended<ReconReportTypesQueryResponse>(ReconReportTypesQuery);
  useRefresh(() => refetch(), [refetch]);

  return (
    <Select
      placeholder="Recon. Report Type"
      size="small"
      style={{ width: 220 }}
      disabled={!data?.ReconReportTypes?.length}
      dropdownMatchSelectWidth={false}
      value={value}
      onChange={onChange}
    >
      {data?.ReconReportTypes?.map((reportType) => {
        const name = paramCase(reportType.value);

        return (
          <Select.Option key={reportType.value} value={name} disabled={!(name in configurations)}>
            {reportType.name}
          </Select.Option>
        );
      })}
    </Select>
  );
};

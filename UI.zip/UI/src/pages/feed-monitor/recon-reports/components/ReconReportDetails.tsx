import React from 'react';

import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';

import { AccentGroup, CardTopBar } from '@/components/Card';
import ExportButton from '@/components/ExportButton';
import SearchField from '@/components/SearchField';
import { useRefresh } from '@/hooks/useRefresh';

import { useGroupedUpdate } from '../hooks/useGroupedUpdate';
import { useReconType } from '../hooks/useReconType';
import configurations from '../recon-type';

import { DetailsFilterSet } from './DetailsFilterSet';
import { DetailsGrid } from './DetailsGrid';
import { DetailsUserCommentInput } from './DetailsUserCommentInput';

export interface ReconReportFieldChangeEvent {
  field?: string;
  dataItem: any;
  value: any;
}

export const ReconReportDetails: React.FC<{
  from: string;
  to: string;
  reportTypeName: string;

  value: {
    selectedDates: string[];
    selectedStatuses: string[];
    selectedSourceSystems: string[];
  };

  pendingValue: {
    selectedDates: string[];
    selectedStatuses: string[];
    selectedSourceSystems: string[];
  };

  isPending: boolean;
  onChange: (state: Partial<{ selectedDates: string[]; selectedStatuses: string[] }>) => void;
  onSubmitFilter: () => void;
}> = ({ from, to, reportTypeName, value, pendingValue, isPending, onChange, onSubmitFilter }) => {
  const [{ filter, selectedReports }, setDetailsState] = useGQLComponentState<{
    filter: string;
    selectedReports: string[];
  }>({ filter: '', selectedReports: [] }, 'details');

  const { data: matchedReportType, loading } = useReconType(reportTypeName);

  const { addGroupedChange, clearAll } = useGroupedUpdate();
  useRefresh(() => {
    clearAll();
  }, [clearAll]);

  if (loading) {
    return null;
  }

  const reconTypeConfiguration = configurations[reportTypeName];

  if (!matchedReportType || !reconTypeConfiguration) {
    return null;
  }

  const { typeName } = reconTypeConfiguration;

  const updateGridItem = (ids: string[], commentValue: string) => {
    addGroupedChange({
      typeName,
      selectedIds: ids,
      field: 'userComment',
      fieldName: 'User Comment',
      value: commentValue,
      getMutationAction: () => ({
        updateReconReportComments: {
          ids,
          comment: commentValue,
          reconTypeId: matchedReportType.id,
        },
      }),
    });
  };

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        position: 'absolute',
        width: '100%',
      }}
    >
      <CardTopBar>
        <AccentGroup>
          <DetailsFilterSet
            from={from}
            to={to}
            reportType={matchedReportType.id}
            showReconSourceSystems={!!reconTypeConfiguration.showReconSourceSystems}
            value={pendingValue}
            isPending={isPending}
            onChange={onChange}
            onSubmit={onSubmitFilter}
          />
        </AccentGroup>
        <AccentGroup align="right">
          <DetailsUserCommentInput
            submitDisabled={selectedReports.length === 0}
            onSubmit={(newUserComment) => {
              // unselect all reports
              setDetailsState({ selectedReports: [] });
              updateGridItem(selectedReports, newUserComment);
            }}
          />
          <SearchField
            placeholder="Search"
            onCancel={() => {
              setDetailsState({ filter: '' });
            }}
            value={filter}
            onChange={(filterValue) => {
              setDetailsState({ filter: filterValue });
            }}
          />
          <ExportButton
            size="small"
            url={reconTypeConfiguration.exportUrl}
            params={{
              dates: value.selectedDates,
              statuses: value.selectedStatuses,
              sourceSystems: value.selectedSourceSystems,
            }}
          />
        </AccentGroup>
      </CardTopBar>
      <DetailsGrid
        filter={filter}
        reportTypeConfiguration={reconTypeConfiguration}
        selectedDates={value.selectedDates}
        selectedStatuses={value.selectedStatuses}
        selectedSourceSystems={value.selectedSourceSystems}
        selectedReports={selectedReports}
        onSelectReport={(reports) => {
          setDetailsState({ selectedReports: reports });
        }}
        onItemChange={(event: ReconReportFieldChangeEvent) => {
          updateGridItem([event?.dataItem?.id], event?.value);
        }}
      />
    </div>
  );
};

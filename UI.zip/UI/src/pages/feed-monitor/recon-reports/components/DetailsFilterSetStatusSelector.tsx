import React, { useMemo } from 'react';

import { keyBy } from 'lodash';

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import MultiSelect from '@/components/MultiSelect';
import useQueryExtended from '@/hooks/useQueryExtended';
import { useRefresh } from '@/hooks/useRefresh';

const ReconReportTypeQuery = gql`
  query ReconReportTypeQuery($id: ID!) {
    ReconReportType(id: $id) {
      statuses {
        id
        name
      }
    }
  }
`;

interface ReconReportTypeQueryResponse {
  ReconReportType: {
    statuses: {
      id: string;
      name: string;
    }[];
  };
}

const statusToOption = (
  status: ReconReportTypeQueryResponse['ReconReportType']['statuses'][number],
) => ({
  id: status.id,
  text: status.name,
});

export const ReconReportTypeStatusSelector: React.FC<{
  reportType: string;
  value: string[];
  onChange: (values: string[]) => void;
}> = ({ reportType, value, onChange }) => {
  const { data, loading, refetch } = useQueryExtended<
    ReconReportTypeQueryResponse,
    { id: string | number }
  >(ReconReportTypeQuery, {
    variables: { id: reportType },
  });

  useRefresh(() => refetch(), [refetch]);

  // eslint-disable-next-line prefer-destructuring
  const statuses = data?.ReconReportType?.statuses;
  const statusById = useMemo(() => keyBy(statuses, 'id'), [statuses]);

  return (
    <MultiSelect<{ id: string; text: string }>
      multiple
      size="small"
      style={{ width: '200px' }}
      placeholder="Status"
      options={(statuses ?? []).map(statusToOption)}
      disabled={loading}
      value={value
        .filter((id) => id in statusById)
        .map((id) => ({ id, text: statusById[id].name }))}
      onChange={(values) => {
        onChange(values.map(({ id }) => id));
      }}
    />
  );
};

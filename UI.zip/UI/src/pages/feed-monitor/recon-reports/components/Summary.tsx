import React from 'react';

import { useReconType } from '../hooks/useReconType';

import { SummaryGrid } from './SummaryGrid';

export const Summary: React.FC<{ fromDate: string; toDate: string; reportTypeName: string }> = ({
  reportTypeName,
  fromDate,
  toDate,
}) => {
  const { data: reportType, configuration, loading } = useReconType(reportTypeName);

  if (loading) {
    return <>loading</>;
  }

  if (!reportType) {
    return null;
  }

  return (
    <SummaryGrid
      reconTypeConfiguration={configuration}
      reportTypeId={reportType.id}
      fromDate={fromDate}
      toDate={toDate}
    />
  );
};

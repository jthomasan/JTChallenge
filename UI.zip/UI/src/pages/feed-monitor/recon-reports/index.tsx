import React from 'react';

import { FileSearchOutlined } from '@ant-design/icons';
import { Splitter } from '@progress/kendo-react-layout';
import { SplitterPaneProps } from '@progress/kendo-react-layout/dist/npm/splitter/SplitterPane';
import { Modal, Result } from 'antd';
import { paramCase } from 'change-case';
import { isEqual } from 'lodash';
import moment from 'moment';
import { generatePath, RouteComponentProps } from 'react-router';

import { gql, useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import { useGQLActivePage } from 'umi-plugin-apollo-anz/apolloPageState';

import withErrorBoundary from '@/HOCs/withErrorBoundary';
import Card, { AccentGroup, CardTopBar } from '@/components/Card';
import LatestCOBCardTopBar from '@/components/LatestCOBCardTopBar';
import PageLoading from '@/components/PageLoading';
import PageErrorFallback from '@/error/ErrorFallback';
import { QueryError } from '@/error/types';
import { RefreshButton } from '@/hooks/useRefresh/RefreshButton';
import useUncommittedChanges from '@/hooks/useUncommittedChanges';

import { PastBusinessDateRangePicker } from '../components/PastBusinessDateRangePicker';

import { ReconReportDetails } from './components/ReconReportDetails';
import { ReconReportTypeSelector } from './components/ReconReportTypeSelector';
import { Summary } from './components/Summary';

interface ReconReportsPageExternalProps
  extends RouteComponentProps<{
    reconType?: string;
  }> {}

const ReconReportsPage: React.FC<{
  pastBusinessDates: string[];
} & ReconReportsPageExternalProps> = ({
  pastBusinessDates,
  history,
  match: {
    path,
    params: { reconType },
  },
}) => {
  useGQLActivePage('reconReports');

  const defaultFromDate = pastBusinessDates[pastBusinessDates.length - 1];
  const defaultToDate = pastBusinessDates[0];

  const [changes, , , clearAll] = useUncommittedChanges();
  const [pageState, setPageState] = useGQLComponentState<{
    fromDate: string;
    toDate: string;
    detailsFilter: {
      current: {
        selectedDates: string[];
        selectedStatuses: string[];
        selectedSourceSystems: string[];
      };
      pending: {
        selectedDates: string[];
        selectedStatuses: string[];
        selectedSourceSystems: string[];
      };
    };
    splitter: SplitterPaneProps[];
  }>({
    fromDate: defaultFromDate,
    toDate: defaultToDate,
    detailsFilter: {
      current: {
        selectedDates: [defaultToDate],
        selectedStatuses: [],
        selectedSourceSystems: [],
      },
      pending: {
        selectedDates: [defaultToDate],
        selectedStatuses: [],
        selectedSourceSystems: [],
      },
    },
    splitter: [
      {
        size: '25%',
        collapsible: true,
      },
      {},
    ],
  });

  function withConfirm<T extends any[]>(onConfirm: (...args: T) => void) {
    return (...args: T) => {
      if (changes.length === 0) {
        onConfirm(...args);
        return;
      }

      Modal.destroyAll();
      Modal.confirm({
        title: 'Confirmation',
        content:
          'This action will remove all uncommitted changes. Are you sure you want to continue?',
        onOk: () => {
          clearAll(true);
          onConfirm(...args);
        },
      });
    };
  }

  return (
    <Card
      title="Reconciliation Reports"
      padded={false}
      fullPageCard
      actions={<LatestCOBCardTopBar />}
    >
      <Splitter
        orientation="vertical"
        style={{ flexGrow: 1 }}
        panes={reconType ? pageState.splitter : undefined}
        onChange={(e) => setPageState({ splitter: e.newState })}
      >
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            position: 'absolute',
            width: '100%',
          }}
        >
          <CardTopBar>
            <AccentGroup>
              <ReconReportTypeSelector
                value={reconType}
                onChange={withConfirm((selectedReconType) => {
                  setPageState(({ detailsFilter }) => ({
                    detailsFilter: {
                      current: {
                        ...detailsFilter.current,
                        selectedStatuses: [],
                        selectedSourceSystems: [],
                      },
                      pending: {
                        ...detailsFilter.pending,
                        selectedStatuses: [],
                        selectedSourceSystems: [],
                      },
                    },
                  }));
                  history.push(
                    generatePath(path, {
                      reconType: selectedReconType ? paramCase(selectedReconType) : undefined,
                    }),
                  );
                })}
              />
              <PastBusinessDateRangePicker
                count={5}
                fromDate={pageState.fromDate}
                toDate={pageState.toDate}
                onChange={withConfirm(([fromDate, toDate]) => {
                  setPageState(({ detailsFilter }) => {
                    const newDates = detailsFilter.current.selectedDates.filter((date) =>
                      moment(date).isBetween(fromDate, toDate, undefined, '[]'),
                    );
                    return {
                      fromDate,
                      toDate,
                      detailsFilter: {
                        current: {
                          ...detailsFilter.current,
                          selectedDates: newDates,
                        },
                        pending: {
                          ...detailsFilter.pending,
                          selectedDates: newDates,
                        },
                      },
                    };
                  });
                })}
              />
            </AccentGroup>
            <AccentGroup align="right">
              <RefreshButton size="small" disabled={changes.length > 0} />
            </AccentGroup>
          </CardTopBar>
          {reconType ? (
            <Summary
              fromDate={pageState.fromDate}
              toDate={pageState.toDate}
              reportTypeName={reconType}
            />
          ) : (
            <Result
              icon={<FileSearchOutlined />}
              title="Reconciliation Reports"
              subTitle="Select the reconciliation report type"
            />
          )}
        </div>
        {reconType ? (
          <ReconReportDetails
            value={pageState.detailsFilter.current}
            pendingValue={pageState.detailsFilter.pending}
            reportTypeName={reconType}
            isPending={!isEqual(pageState.detailsFilter.pending, pageState.detailsFilter.current)}
            onChange={(stateDelta) => {
              setPageState(({ detailsFilter }) => ({
                detailsFilter: {
                  ...detailsFilter,
                  pending: {
                    ...detailsFilter.pending,
                    ...stateDelta,
                  },
                },
              }));
            }}
            onSubmitFilter={withConfirm(() => {
              setPageState(({ detailsFilter }) => ({
                detailsFilter: {
                  ...detailsFilter,
                  current: detailsFilter.pending,
                },
              }));
            })}
            from={pageState.fromDate}
            to={pageState.toDate}
          />
        ) : null}
      </Splitter>
    </Card>
  );
};

interface PastBusinessDatesQueryResponse {
  PastBusinessDates: string[];
}

const PastBusinessDatesQuery = gql`
  query PastBusinessDatesQuery {
    PastBusinessDates(count: 5)
  }
`;

const ReconReportsPageWrapper: React.FC<ReconReportsPageExternalProps> = (props) => {
  const { data, loading, error } = useQuery<PastBusinessDatesQueryResponse>(PastBusinessDatesQuery);

  if (loading) {
    return <PageLoading />;
  }

  if (!data?.PastBusinessDates || error) {
    return (
      <PageErrorFallback
        error={new QueryError(error)}
        title="There was an issue fetching the latest COB date"
        retryText="Retry"
      />
    );
  }

  return <ReconReportsPage {...props} pastBusinessDates={data.PastBusinessDates} />;
};

export default withErrorBoundary(
  <PageErrorFallback title="Error Loading Recon Reports Page" retryText="Reload Page" />,
)(ReconReportsPageWrapper);

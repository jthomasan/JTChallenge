export const defaults = {
  reconReports: {
    __typename: 'ReconReportsPage',

    errors: [],
  },
};

export const resolvers = {};

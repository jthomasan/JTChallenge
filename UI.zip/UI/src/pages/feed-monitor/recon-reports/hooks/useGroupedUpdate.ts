import { useCallback } from 'react';

import _ from 'lodash';

import { useApolloClient, gql, ApolloClient } from 'umi-plugin-apollo-anz/apolloClient';

import useUncommittedChanges from '@/hooks/useUncommittedChanges';
import { Change, ChangeAction } from '@/types/change';

function getFragment(typeName: string, fields: string[]) {
  return gql`fragment GroupedUpdate on ${typeName} {
    ${fields.join('\n')}
  }`;
}

function identify(client: ApolloClient<object>, id: string, typeName: string) {
  return client.cache.identify({
    id,
    __typename: typeName,
  });
}

interface GroupedChange {
  typeName: string;
  selectedIds: string[];
  field: string;
  fieldName: string;
  value: any;
  getMutationAction: Change['getMutationAction'];
}

export function useGroupedUpdate() {
  const [, addChange, , clearAll] = useUncommittedChanges();
  const client = useApolloClient();

  const addGroupedChange = useCallback(
    ({ typeName, selectedIds, field, fieldName, value, getMutationAction }: GroupedChange) => {
      const readFragment = getFragment(typeName, ['id', 'modified', field]);
      const originals = selectedIds.map((id) =>
        client.readFragment({
          id: identify(client, id, typeName),
          fragment: readFragment,
        }),
      );

      const previousValues = _.chain(originals)
        .map((row) => `${row[field]}`)
        .uniq()
        .join(', ')
        .value();

      addChange({
        action: ChangeAction.UPDATE,
        sourceId: '',
        sourceType: `${selectedIds.length} record${selectedIds.length === 1 ? '' : 's'}`,
        sourceField: fieldName,
        from: previousValues,
        to: value,
        getMutationAction,
        updateCache: () => {
          const undo: {
            identifier: string;
            [field: string]: any;
            modified: boolean;
          }[] = [];

          selectedIds.forEach((id, index) => {
            const identifier = identify(client, id, typeName);
            if (!identifier) {
              return;
            }

            const previousEntry = {
              identifier,
              [field]: null,
              modified: false,
            };

            undo.push(previousEntry);

            client.cache.modify({
              id: identifier,
              broadcast: index === selectedIds.length - 1,
              fields: {
                [field]: (cached) => {
                  previousEntry[field] = cached;
                  return value;
                },
                modified: (cached) => {
                  previousEntry.modified = cached;
                  return true;
                },
              },
            });
          });

          return () => {
            undo.forEach(({ identifier, modified, [field]: prevValue }, index) => {
              client.cache.modify({
                id: identifier,
                broadcast: index === undo.length - 1,
                fields: {
                  [field]: () => prevValue,
                  modified: () => modified,
                },
              });
            });
          };
        },
      });
    },
    [addChange, client],
  );

  return {
    addGroupedChange,
    clearAll,
  };
}

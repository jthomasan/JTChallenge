import { paramCase } from 'change-case';

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import useQueryExtended from '@/hooks/useQueryExtended';

import configurations from '../recon-type';

interface ReconTypeQueryResponse {
  ReconReportTypes: {
    id: string;
    name: string;
  }[];
}

const ReconTypeQuery = gql`
  query ReconTypeQuery {
    ReconReportTypes {
      id
      name
    }
  }
`;

export function useReconType(reconTypeParamCase: string) {
  const { data, ...rest } = useQueryExtended<ReconTypeQueryResponse>(ReconTypeQuery);

  const matchedReportType = data?.ReconReportTypes?.find(
    (reportType) => paramCase(reportType.name) === reconTypeParamCase,
  );

  return {
    data: matchedReportType,
    configuration: configurations[reconTypeParamCase],
    ...rest,
  };
}

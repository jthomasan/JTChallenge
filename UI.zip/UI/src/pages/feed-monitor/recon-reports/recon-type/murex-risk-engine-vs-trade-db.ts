import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import { FilterableColumnProps } from '@/components/Grid/useDataFilter';
import GridTextboxCell from '@/pages/reference-data/static-data/components/StaticDataCells/GridTextboxCell';
import { DATE_FORMATS } from '@/utils/date';

export const exportUrl = '/export/feed-monitor/recon-reports/murex-risk-engine-vs-trade-db/csv';

export const typeName = 'MurexRiskEngineReconDetail';

export const query = gql`
  query MurexRiskEngineReconDetailsQuery($dates: [Date]!, $statuses: [String]) {
    data: MurexRiskEngineReconDetails(dates: $dates, statuses: $statuses) {
      id
      modified
      cobDate
      status
      userComment
      murexVersion
      mre {
        nb
        instrument
        trn {
          family
          group
        }
        tp {
          portfolio
          timeSystem
          cntrp
          dateDTETRN
        }
        brw {
          nom1
          nom2
        }
        pl {
          insCurrency
          fmv2
          csnfcp2
          fpnfcp2
        }
      }
      trade {
        nb
        instrument
        trn {
          family
          group
        }
        tp {
          portfolio
          timeSystem
          cntrp
          dateDTETRN
        }
        brw {
          nom1
          nom2
        }
        pl {
          insCurrency
          fmv2
          csnfcp2
          fpnfcp2
        }
      }
      added {
        by
        time
      }
      updated {
        time
      }
    }
  }
`;

export const columns: FilterableColumnProps[] = (<FilterableColumnProps[]>[
  {
    field: 'userComment',
    title: 'User Comment',
    width: 170,
    editable: true,
    cell: GridTextboxCell,
  },
  {
    field: 'added.by',
    title: 'Added By',
    width: 120,
  },
  {
    field: 'updated.time',
    title: 'Updated Time',
    filter: 'date',
    format: DATE_FORMATS.DATE_TIME,
    width: 120,
  },
  {
    field: 'cobDate',
    title: 'COB Date',
    format: DATE_FORMATS.DATE_ONLY,
    width: 80,
    defaultSortColumn: true,
  },
  {
    field: 'status',
    title: 'Status',
    width: 150,
  },
  {
    field: 'mre.nb',
    title: 'MRE_NB',
    width: 90,
  },
  {
    field: 'trade.nb',
    title: 'TRADE_NB',
    width: 90,
  },
  {
    field: 'mre.tp.portfolio',
    title: 'MRE_TP_PFOLIO',
    width: 120,
  },
  {
    field: 'trade.tp.portfolio',
    title: 'TRADE_TP_PFOLIO',
    width: 120,
  },
  {
    field: 'mre.instrument',
    title: 'MRE_INSTRUMENT',
    width: 120,
  },
  {
    field: 'trade.instrument',
    title: 'TRADE_INSTRUMENT',
    width: 120,
  },
  {
    field: 'mre.pl.insCurrency',
    title: 'MRE_PL_INSCURR',
    width: 120,
  },
  {
    field: 'trade.pl.insCurrency',
    title: 'TRADE_PL_INSCURR',
    width: 120,
  },
  {
    field: 'mre.brw.nom1',
    title: 'MRE_BRW_NOM1',
    width: 120,
  },
  {
    field: 'trade.brw.nom1',
    title: 'TRADE_BRW_NOM1',
    width: 120,
  },
  {
    field: 'mre.brw.nom2',
    title: 'MRE_BRW_NOM2',
    width: 120,
  },
  {
    field: 'trade.brw.nom2',
    title: 'TRADE_BRW_NOM2',
    width: 120,
  },
  {
    field: 'mre.pl.csnfcp2',
    title: 'MRE_PL_CSNFP2',
    width: 120,
  },
  {
    field: 'trade.pl.csnfcp2',
    title: 'TRADE_PL_CSNFP2',
    width: 120,
  },
  {
    field: 'mre.pl.fmv2',
    title: 'MRE_PL_FMV2',
    width: 120,
  },
  {
    field: 'trade.pl.fmv2',
    title: 'TRADE_PL_FMV2',
    width: 120,
  },
  {
    field: 'mre.pl.fpnfcp2',
    title: 'MRE_PL_FPNFCP2',
    width: 120,
  },
  {
    field: 'trade.pl.fpnfcp2',
    title: 'TRADE_PL_FPNFCP2',
    width: 120,
  },
  {
    field: 'mre.trn.group',
    title: 'MRE_TRN_GRP',
    width: 120,
  },
  {
    field: 'trade.trn.group',
    title: 'TRADE_TRN_GRP',
    width: 120,
  },
  {
    field: 'murexVersion',
    title: 'Murex Version',
    width: 120,
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    format: DATE_FORMATS.DATE_TIME,
    width: 120,
  },
  {
    field: 'mre.tp.timeSystem',
    title: 'MRE_TP_TIMSYS',
    width: 120,
  },
  {
    field: 'trade.tp.timeSystem',
    title: 'TRADE_TP_TIMSYS',
    width: 120,
  },
  {
    field: 'mre.tp.timeSystem',
    title: 'MRE_TP_TIMSYS',
    width: 120,
  },
  {
    field: 'trade.tp.timeSystem',
    title: 'TRADE_TP_TIMSYS',
    width: 120,
  },
  {
    field: 'mre.trn.family',
    title: 'MRE_TRN_FMLY',
    width: 120,
  },
  {
    field: 'trade.trn.family',
    title: 'TRADE_TRN_FMLY',
    width: 120,
  },
  {
    field: 'mre.tp.cntrp',
    title: 'MRE_TP_CNTRP',
    width: 120,
  },
  {
    field: 'trade.tp.cntrp',
    title: 'TRADE_TP_CNTRP',
    width: 120,
  },
  {
    field: 'mre.tp.dateDTETRN',
    title: 'MRE_TP_DTETRN',
    width: 120,
  },
  {
    field: 'trade.tp.dateDTETRN',
    title: 'TRADE_TP_DTETRN',
    width: 120,
  },
]).map((column) => ({ ...column, enableSimpleFilter: true }));

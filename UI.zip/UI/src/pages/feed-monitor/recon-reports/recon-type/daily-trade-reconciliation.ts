import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import { FilterableColumnProps } from '@/components/Grid/useDataFilter';
import GridTextboxCell from '@/pages/reference-data/static-data/components/StaticDataCells/GridTextboxCell';
import { DATE_FORMATS } from '@/utils/date';

export const exportUrl = '/export/feed-monitor/recon-reports/daily-trade-reconciliation/csv';

export const typeName = 'DailyTradeReconDetail';

export const showReconSourceSystems = true;
export const showValuationType = true;

export const query = gql`
  query DailyTradeReconDetailsQuery(
    $dates: [Date]!
    $sourceSystems: [String]
    $statuses: [String]
  ) {
    data: DailyTradeReconDetails(
      dates: $dates
      sourceSystems: $sourceSystems
      statuses: $statuses
    ) {
      id
      modified
      COBDate
      maRRSDealNumber
      MREDealNumber
      maRRSPortfolio
      MREPortfolio
      tradeFamily
      tradeGroup
      tradeType
      instrument
      effectiveMaturity
      sourceSystem
      valuationType
      status
      reason
      systemComment
      userComment
      added {
        by
      }
      updated {
        time
      }
    }
  }
`;

export const columns: FilterableColumnProps[] = (<FilterableColumnProps[]>[
  {
    field: 'userComment',
    title: 'User Comment',
    width: 170,
    editable: true,
    cell: GridTextboxCell,
  },
  {
    field: 'added.by',
    title: 'Added By',
    width: 120,
  },
  {
    field: 'updated.time',
    title: 'Updated Time',
    filter: 'date',
    format: DATE_FORMATS.DATE_TIME,
    width: 120,
  },
  {
    field: 'sourceSystem',
    title: 'Source System',
    width: 145,
  },
  {
    field: 'valuationType',
    title: 'Valuation Type',
    width: 110,
  },
  {
    field: 'COBDate',
    title: 'COB Date',
    format: DATE_FORMATS.DATE_ONLY,
    width: 80,
    defaultSortColumn: true,
  },
  {
    field: 'status',
    title: 'Recon Status',
    width: 140,
  },
  {
    field: 'reason',
    title: 'Reason',
    width: 90,
  },
  {
    field: 'systemComment',
    title: 'System Comment',
    width: 220,
  },
  {
    field: 'maRRSDealNumber',
    title: 'MaRRS Deal Number',
    width: 100,
  },
  {
    field: 'MREDealNumber',
    title: 'MRE Deal Number',
    width: 100,
  },
  {
    field: 'maRRSPortfolio',
    title: 'MaRRS Portfolio',
    width: 110,
  },
  {
    field: 'MREPortfolio',
    title: 'MRE Portfolio',
    width: 110,
  },
  {
    field: 'tradeFamily',
    title: 'Trade Family',
    width: 90,
  },
  {
    field: 'tradeGroup',
    title: 'Trade Group',
    width: 90,
  },
  {
    field: 'tradeType',
    title: 'Trade Type',
    width: 90,
  },
  {
    field: 'instrument',
    title: 'Instrument',
    width: 90,
  },
  {
    field: 'effectiveMaturity',
    title: 'Effective Maturity',
    format: DATE_FORMATS.DATE_ONLY,
    width: 80,
  },
]).map((column) => ({ ...column, enableSimpleFilter: true }));

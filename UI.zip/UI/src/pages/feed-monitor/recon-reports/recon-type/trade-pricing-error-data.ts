import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import { FilterableColumnProps } from '@/components/Grid/useDataFilter';
import GridTextboxCell from '@/pages/reference-data/static-data/components/StaticDataCells/GridTextboxCell';
import { DATE_FORMATS } from '@/utils/date';

export const exportUrl = '/export/feed-monitor/recon-reports/trade-pricing-error-data/csv';

export const typeName = 'TradePricingErrorDetail';

export const showReconSourceSystems = true;

export const query = gql`
  query TradePricingErrorDetailsQuery(
    $dates: [Date]!
    $sourceSystems: [String]
    $statuses: [String]
  ) {
    data: TradePricingErrorDetails(
      dates: $dates
      sourceSystems: $sourceSystems
      statuses: $statuses
    ) {
      id
      modified
      cobDate
      contractName
      counterParty
      error
      jobName
      portfolio
      status
      tradeType
      oos
      userComment
      mx {
        tradeID
        type
        instrument
        family
        group
      }
      report {
        name
        description
      }
      sky {
        tradeID
        type
        instrument
      }
      sourceSystem {
        name
        environment
      }
      added {
        by
      }
      updated {
        time
      }
    }
  }
`;

export const columns: FilterableColumnProps[] = (<FilterableColumnProps[]>[
  {
    field: 'userComment',
    title: 'User Comment',
    width: 170,
    editable: true,
    cell: GridTextboxCell,
  },
  {
    field: 'added.by',
    title: 'Added By',
    width: 120,
  },
  {
    field: 'updated.time',
    title: 'Updated Time',
    filter: 'date',
    format: DATE_FORMATS.DATE_TIME,
    width: 120,
  },
  {
    field: 'sourceSystem.name',
    title: 'Source System',
    width: 80,
  },
  {
    field: 'cobDate',
    title: 'COB Date',
    format: DATE_FORMATS.DATE_ONLY,
    width: 80,
    defaultSortColumn: true,
  },
  {
    field: 'status',
    title: 'Status',
    width: 200,
  },
  {
    field: 'oos',
    title: 'OOS',
    width: 50,
  },
  {
    field: 'report.name',
    title: 'Report',
    width: 90,
  },
  {
    field: 'portfolio',
    title: 'Portfolio',
    width: 120,
  },
  {
    field: 'report.description',
    title: 'Report Description',
    width: 150,
  },
  {
    field: 'sourceSystem.environment',
    title: 'Source System Environment',
    width: 120,
  },
  {
    field: 'sky.tradeID',
    title: 'Sky Trade ID',
    width: 110,
  },
  {
    field: 'mx.tradeID',
    title: 'Murex Trade ID',
    width: 90,
  },
  {
    field: 'mx.family',
    title: 'Murex Family',
    width: 90,
  },
  {
    field: 'mx.type',
    title: 'Murex Type',
    width: 90,
  },
  {
    field: 'mx.group',
    title: 'Murex Group',
    width: 90,
  },
  {
    field: 'mx.instrument',
    title: 'Murex Instrument',
    width: 115,
  },
  {
    field: 'counterParty',
    title: 'Counter Party',
    width: 125,
  },
  {
    field: 'tradeType',
    title: 'Trade Type',
    width: 150,
  },
  {
    field: 'contractName',
    title: 'Contract Name',
    width: 150,
  },
  {
    field: 'jobName',
    title: 'Job Name',
    width: 150,
  },
  {
    field: 'error',
    title: 'Error Message',
    width: 350,
  },
]).map((column) => ({ ...column, enableSimpleFilter: true }));

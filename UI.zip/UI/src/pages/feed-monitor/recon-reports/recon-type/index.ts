import { DocumentNode } from 'umi-plugin-apollo-anz/apolloClient';

import { ColumnProps } from '@/components/Grid';

import * as dailyTradeReconciliationDetail from './daily-trade-reconciliation';
import * as murexRiskEngineVsTradeDb from './murex-risk-engine-vs-trade-db';
import * as pastCashReconciliation from './past-cash-reconciliation';
import * as tradePricingErrorData from './trade-pricing-error-data';

export interface ReconTypeConfiguration {
  query: DocumentNode;
  typeName: string;
  columns: ColumnProps[];
  exportUrl: string;
  showReconSourceSystems?: boolean;
  showValuationType?: boolean;
}

export default {
  'daily-trade-reconciliation': dailyTradeReconciliationDetail,
  'murex-risk-engine-vs-trade-db': murexRiskEngineVsTradeDb,
  'past-cash-reconciliation': pastCashReconciliation,
  'trade-pricing-error-data': tradePricingErrorData,
} as Record<string, ReconTypeConfiguration>;

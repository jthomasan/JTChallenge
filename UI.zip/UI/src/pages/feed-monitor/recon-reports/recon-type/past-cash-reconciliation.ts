import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import { FilterableColumnProps } from '@/components/Grid/useDataFilter';
import GridTextboxCell from '@/pages/reference-data/static-data/components/StaticDataCells/GridTextboxCell';
import { DATE_FORMATS } from '@/utils/date';

export const exportUrl = '/export/feed-monitor/recon-reports/past-cash-reconciliation/csv';

export const typeName = 'PastCashReconDetail';

export const query = gql`
  query PastCashReconDetailsQuery($dates: [Date]!, $statuses: [String]) {
    data: PastCashReconDetails(dates: $dates, statuses: $statuses) {
      id
      status
      cobDate
      userComment
      portfolio
      currency
      modified

      added {
        by
      }
      updated {
        time
      }

      trn {
        family
        group
        type
      }

      pastCash {
        murex
        sky
      }

      difference {
        actual
        percentage
      }
    }
  }
`;

export const columns: FilterableColumnProps[] = (<FilterableColumnProps[]>[
  {
    field: 'userComment',
    title: 'User Comment',
    width: 170,
    editable: true,
    cell: GridTextboxCell,
  },
  {
    field: 'added.by',
    title: 'Added By',
    width: 120,
  },
  {
    field: 'updated.time',
    title: 'Updated Time',
    filter: 'date',
    format: DATE_FORMATS.DATE_TIME,
    width: 120,
  },
  {
    field: 'cobDate',
    title: 'COB Date',
    format: DATE_FORMATS.DATE_ONLY,
    width: 80,
    defaultSortColumn: true,
  },
  {
    field: 'status',
    title: 'Recon Status',
    width: 110,
  },
  {
    field: 'portfolio',
    title: 'TP_PFOLIO',
    width: 90,
  },
  {
    field: 'trn.family',
    title: 'TRN_FMLY',
    width: 90,
  },
  {
    field: 'trn.group',
    title: 'TRN_GRP',
    width: 90,
  },
  {
    field: 'trn.type',
    title: 'TRN_TYPE',
    width: 90,
  },
  {
    field: 'currency',
    title: 'Currency',
    width: 90,
  },
  {
    field: 'pastCash.murex',
    title: 'MUREX Past Cash',
    width: 120,
  },
  {
    field: 'pastCash.sky',
    title: 'SKY Past Cash',
    width: 120,
  },
  {
    field: 'difference.actual',
    title: 'Difference Actual',
    width: 120,
  },
  {
    field: 'difference.percentage',
    title: 'Difference Percentage',
    width: 145,
  },
]).map((column) => ({ ...column, enableSimpleFilter: true }));

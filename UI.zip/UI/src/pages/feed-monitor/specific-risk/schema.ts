import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export default gql`
  type SpecificRiskPage implements Refreshable {
    dummy: String
  }

  extend type Page {
    specificRisk: SpecificRiskPage
  }
`;

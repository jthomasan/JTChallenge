export const defaults = {
  specificRisk: {
    __typename: 'SpecificRiskPage',

    errors: [],
  },
};

export const resolvers = {};

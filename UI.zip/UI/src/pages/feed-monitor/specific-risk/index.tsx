import React from 'react';

import { Splitter } from '@progress/kendo-react-layout';
import { SplitterPaneProps } from '@progress/kendo-react-layout/dist/npm/splitter/SplitterPane';
import { generatePath, RouteComponentProps } from 'react-router';

import { gql, useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import { useGQLActivePage } from 'umi-plugin-apollo-anz/apolloPageState';

import withErrorBoundary from '@/HOCs/withErrorBoundary';
import Card, { AccentGroup, CardTopBar } from '@/components/Card';
import LatestCOBCardTopBar from '@/components/LatestCOBCardTopBar';
import PageLoading from '@/components/PageLoading';
import PageErrorFallback from '@/error/ErrorFallback';
import { QueryError } from '@/error/types';
import { RefreshButton } from '@/hooks/useRefresh/RefreshButton';

import { PastBusinessDateRangePicker } from '../components/PastBusinessDateRangePicker';

import { MeasureTypeSelector } from './components/MeasureTypeSelector';
import { SpecificRiskSummary } from './components/SpecificRiskSummary';

interface ReconReportsPageExternalProps
  extends RouteComponentProps<{
    measureType?: string;
  }> {}

const defaultMeasureType = 'record-count';

const SpecificRiskPage: React.FC<{
  pastBusinessDates: string[];
} & ReconReportsPageExternalProps> = ({
  pastBusinessDates,
  history,
  match: {
    path,
    params: { measureType },
  },
}) => {
  useGQLActivePage('specificRisk');

  const defaultFromDate = pastBusinessDates[pastBusinessDates.length - 1];
  const defaultToDate = pastBusinessDates[0];

  const [pageState, setPageState] = useGQLComponentState<{
    fromDate: string;
    toDate: string;
    splitter: SplitterPaneProps[];
  }>({
    fromDate: defaultFromDate,
    toDate: defaultToDate,
    splitter: [{}, { size: '300px', collapsible: true }],
  });

  return (
    <Card
      title="Reconciliation Reports"
      padded={false}
      fullPageCard
      actions={<LatestCOBCardTopBar />}
    >
      <CardTopBar>
        <AccentGroup>
          <PastBusinessDateRangePicker
            count="all"
            fromDate={pageState.fromDate}
            toDate={pageState.toDate}
            onChange={([fromDate, toDate]) => {
              setPageState({
                fromDate,
                toDate,
              });
            }}
          />
          <MeasureTypeSelector
            value={measureType ?? defaultMeasureType}
            onChange={(selectedMeasureType) => {
              history.push(
                generatePath(path, {
                  measureType: selectedMeasureType,
                }),
              );
            }}
          />
        </AccentGroup>
        <AccentGroup align="right">
          <RefreshButton size="small" />
        </AccentGroup>
      </CardTopBar>
      <Splitter
        orientation="horizontal"
        style={{ flexGrow: 1 }}
        panes={pageState.splitter}
        onChange={(e) => setPageState({ splitter: e.newState })}
      >
        <div
          style={{
            height: '100%',
            position: 'absolute',
            width: '100%',
          }}
        >
          <SpecificRiskSummary
            from={pageState.fromDate}
            to={pageState.toDate}
            measureType={measureType ?? defaultMeasureType}
          />
        </div>
        <div>Placeholder</div>
      </Splitter>
    </Card>
  );
};

interface PastBusinessDatesQueryResponse {
  PastBusinessDates: string[];
}

const PastBusinessDatesQuery = gql`
  query PastBusinessDatesQuery {
    PastBusinessDates(count: 10)
  }
`;

const SpecificRiskPageWrapper: React.FC<ReconReportsPageExternalProps> = (props) => {
  const { data, loading, error } = useQuery<PastBusinessDatesQueryResponse>(PastBusinessDatesQuery);

  if (loading) {
    return <PageLoading />;
  }

  if (!data?.PastBusinessDates || error) {
    return (
      <PageErrorFallback
        error={new QueryError(error)}
        title="There was an issue fetching the latest COB date"
        retryText="Retry"
      />
    );
  }

  return <SpecificRiskPage {...props} pastBusinessDates={data.PastBusinessDates} />;
};

export default withErrorBoundary(
  <PageErrorFallback title="Error Loading Recon Reports Page" retryText="Reload Page" />,
)(SpecificRiskPageWrapper);

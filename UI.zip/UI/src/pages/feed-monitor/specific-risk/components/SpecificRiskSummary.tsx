import React, { useMemo } from 'react';

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import Grid, { ColumnProps } from '@/components/Grid';
import useQueryExtended from '@/hooks/useQueryExtended';
import { useRefresh } from '@/hooks/useRefresh';
import { DATE_FORMATS } from '@/utils/date';

interface SpecificRiskSummaryQueryResponse {
  SpecificRiskAudit: {
    date: string;
    tenDayVaR: string;
    stressVaR: string;
    specRiskIR: string;
    specRiskEQ: string;
    specRiskSec: string;
    economicalCap: string;
    tenDayVaRAssetType: string;
    stressVaRAssetType: string;
  }[];
}

const SpecificRiskSummaryQuery = gql`
  query SpecificRiskSummaryQuery($from: Date!, $to: Date!, $measureType: ID!) {
    SpecificRiskAudit(from: $from, to: $to, measureType: $measureType) {
      date
      tenDayVaR
      stressVaR
      specRiskIR
      specRiskEQ
      specRiskSec
      economicalCap
      tenDayVaRAssetType
      stressVaRAssetType
    }
  }
`;

const measureTypeMap = {
  'record-count': 'Record Count',
  'start-time': 'Start Time',
  'end-time': 'End Time',
  'duration-in-seconds': 'Duration',
};

type MeasureType = keyof typeof measureTypeMap;
type DataType = 'dateTime' | 'date' | 'number';

const measureTypeDataTypes: Record<MeasureType, DataType> = {
  'record-count': 'number',
  'start-time': 'dateTime',
  'end-time': 'dateTime',
  'duration-in-seconds': 'number',
};

const dataTypeToFormat: Partial<Record<DataType, string>> = {
  date: DATE_FORMATS.DATE_ONLY,
  dateTime: DATE_FORMATS.DATE_TIME_SECONDS,
};

const getColumnExtension = (measureType: MeasureType): Partial<ColumnProps> => {
  const mappedType = measureTypeDataTypes[measureType];

  return {
    filter: mappedType === 'date' || mappedType === 'dateTime' ? 'date' : undefined,
    format: dataTypeToFormat[mappedType],
  };
};

const getColumns = (measureType: MeasureType) => {
  const columnExtension = getColumnExtension(measureType);
  const width = 120;

  return [
    {
      title: 'COB Date',
      field: 'date',
      format: DATE_FORMATS.DATE_ONLY,
      width: 100,
    },
    {
      title: '10 Day VaR',
      field: 'tenDayVaR',
      width,
      ...columnExtension,
    },
    {
      title: 'Stress VaR',
      field: 'stressVaR',
      width,
      ...columnExtension,
    },
    {
      title: 'Spec Risk IR',
      field: 'specRiskIR',
      width,
      ...columnExtension,
    },
    {
      title: 'Spec Risk EQ',
      field: 'specRiskEQ',
      width,
      ...columnExtension,
    },
    {
      title: 'Spec Risk Sec',
      field: 'specRiskSec',
      width,
      ...columnExtension,
    },
    {
      title: 'Economical Cap',
      field: 'economicalCap',
      width,
      ...columnExtension,
    },
    {
      title: '10 Day VaR (Asset Type)',
      field: 'tenDayVaRAssetType',
      width: width + 50,
      ...columnExtension,
    },
    {
      title: 'Stress VaR (Asset Type)',
      field: 'stressVaRAssetType',
      width: width + 50,
      ...columnExtension,
    },
  ];
};

export const SpecificRiskSummary: React.FC<{
  from: string;
  to: string;
  measureType: string;
}> = ({ from, to, measureType }) => {
  const { data, loading, refetch } = useQueryExtended<SpecificRiskSummaryQueryResponse>(
    SpecificRiskSummaryQuery,
    {
      variables: {
        from,
        to,
        measureType: measureTypeMap[measureType as MeasureType],
      },
    },
  );

  const { refreshing } = useRefresh(() => refetch(), [refetch]);

  const columns = useMemo(() => getColumns(measureType as MeasureType), [measureType]);

  return (
    <Grid
      style={{
        height: '100%',
        border: 'none',
      }}
      loading={loading || refreshing}
      data={data?.SpecificRiskAudit ?? []}
      columns={columns}
    />
  );
};

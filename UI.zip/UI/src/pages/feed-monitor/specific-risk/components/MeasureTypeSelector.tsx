import React from 'react';

import { Select } from 'antd';
import { paramCase } from 'change-case';

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import useQueryExtended from '@/hooks/useQueryExtended';
import { useRefresh } from '@/hooks/useRefresh';

interface Option {
  id: string;
  text: string;
}

interface SpecificRiskAuditMeasureTypesQueryResponse {
  SpecificRiskAuditMeasureTypes: Option[];
}

const SpecificRiskAuditMeasureTypesQuery = gql`
  query SpecificRiskAuditMeasureTypesQuery {
    SpecificRiskAuditMeasureTypes {
      id
      text
    }
  }
`;

interface MeasureTypeSelectorProps {
  value?: string;
  onChange?: (newValue: string) => void;
}

export const MeasureTypeSelector: React.FC<MeasureTypeSelectorProps> = ({ value, onChange }) => {
  const { data, refetch } = useQueryExtended<SpecificRiskAuditMeasureTypesQueryResponse>(
    SpecificRiskAuditMeasureTypesQuery,
  );
  useRefresh(() => refetch(), [refetch]);

  return (
    <Select
      placeholder="Measure Type"
      size="small"
      style={{ width: 150 }}
      disabled={!data?.SpecificRiskAuditMeasureTypes?.length}
      dropdownMatchSelectWidth={false}
      value={value}
      onChange={onChange}
    >
      {data?.SpecificRiskAuditMeasureTypes?.map((measureType) => {
        const name = paramCase(measureType.text);

        return (
          <Select.Option key={measureType.text} value={name}>
            {measureType.text}
          </Select.Option>
        );
      })}
    </Select>
  );
};

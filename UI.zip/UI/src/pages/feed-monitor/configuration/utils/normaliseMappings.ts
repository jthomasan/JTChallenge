import { staticDataSets, StaticDataColumn, SelectorVariable } from '../mappings/staticDataSet';
import { selectors, Selector } from '../mappings/selectors';
import { staticDataCategory } from '../mappings/staticData';

export function getStaticDataColumns(typeId: string): StaticDataColumn[] {
  return staticDataSets[typeId].columns;
}

export function getStaticDataMutationAction(typeId: string): string {
  return staticDataSets[typeId]?.mutationAction || '';
}

export function getStaticDataPreSaveCallback(typeId: string): Function | null {
  return staticDataSets[typeId]?.preSaveCallback || null;
}

export function getStaticDataPostSaveCallback(typeId: string): Function | null {
  return staticDataSets[typeId]?.postSaveCallback || null;
}

export function getStaticDataMutationAddAction(typeId: string): string {
  return staticDataSets[typeId]?.mutationAddAction || '';
}

export function getStaticDataExportUrl(typeId: string, params: any): string {
  return staticDataSets[typeId].exportUrl(params);
}

export function getStaticDataCanAddNew(typeId: string): boolean {
  return staticDataSets[typeId]?.canAddNew || false;
}

export function getStaticDataCanShowAuditHistory(typeId: string): boolean {
  return staticDataSets[typeId]?.canShowAuditHistory || false;
}

export function getStaticDataCanShowLog(typeId: string): boolean {
  return staticDataSets[typeId]?.canShowLog || false;
}

export function getStaticDataHierarchyMapAuditTypeSystemId(typeId: string): string | undefined {
  return (
    staticDataCategory
      .find((category) => category.name === 'All')
      ?.list.find((item) => item.id === typeId)?.hierarchyMapAuditTypeSystemId || undefined
  );
}

export function getStaticDataCanBulkUpdate(typeId: string): boolean {
  return staticDataSets[typeId]?.canBulkUpdate || false;
}

export function getStaticDataWarningMsgWhenExport(typeId: string): JSX.Element | null {
  return staticDataSets[typeId]?.warningMsgWhenExport || null;
}

export function getStaticDataWarningMsgWhenBulkUpdate(typeId: string): JSX.Element | null {
  return staticDataSets[typeId]?.warningMsgWhenBulkUpdate || null;
}

export function getStaticDatasetName(typeId: string): string {
  return (
    staticDataCategory
      .find((category) => category.name === 'All')
      ?.list.find((item) => item.id === typeId || item.hierarchyMapAuditTypeSystemId === typeId)
      ?.name || ''
  );
}

export function getStaticDatasetExportName(typeId: string): string {
  return getStaticDatasetName(typeId)
    .split(/[:&|-]|\s/g)
    .filter((s) => s !== '')
    .join('_');
}

export function getfmConfigDatasetExportName(typeId: string): string {
  return getStaticDatasetName(typeId)
    .split(/[:&|-]|\s/g)
    .filter((s) => s !== '')
    .join('_');
}

export function getStaticDataQueryName(typeId: string): string {
  return staticDataSets[typeId]?.queryName;
}

export function getStaticDataQuery(typeId: string, additionalParams?: any): string {
  if (typeof staticDataSets[typeId]?.query === 'string') {
    return staticDataSets[typeId]?.query;
  }
  return staticDataSets[typeId]?.query(additionalParams);
}

export function getSelectorQuery(name: Selector): string {
  return selectors[name].query;
}

export function getSelectorTitle(name: string): string {
  return selectors[name].title;
}

export function isObject(value: any): boolean {
  return Object.prototype.toString.call(value) === '[object Object]';
}

export function getStaticDataType(category: string, typeId: string): string {
  const types = staticDataCategory.find((item) => item.name === category)?.list;
  if (types) {
    return types.find((item) => item.id === typeId)?.name || '';
  }

  return '';
}

export function getStaticDataAdditionalParams(category: string, typeId: string): string[] {
  const types = staticDataCategory.find((item) => item.name === category)?.list;
  if (types) {
    return types.find((item) => item.id === typeId)?.additionalParams || [];
  }

  return [];
}

export function getStaticDataAdditionalDataForSave(category: string, typeId: string): any {
  const types = staticDataCategory.find((item) => item.name === category)?.list;
  if (types) {
    return types.find((item) => item.id === typeId)?.additionalDataForSave || {};
  }

  return {};
}

export function getColumnFieldTitle(typeId: string, field: string): string {
  const columns = getStaticDataColumns(typeId);
  return columns.find((item) => item.field === field)?.title || '';
}

export function getColumnDisplayRenderer(typeId: string, field: string): any {
  const columns = getStaticDataColumns(typeId);
  const displayRenderer = columns.find((item) => item.field === field)?.extras?.displayRenderer;

  return displayRenderer;
}

export function getColumnMutationFormatter(typeId: string, field: string): any {
  const columns = getStaticDataColumns(typeId);
  const mutationFormatter = columns.find((item) => item.field === field)?.extras?.mutationFormatter;

  return mutationFormatter;
}

export function getColumnArrayObjectKeys(typeId: string, field: string): any {
  const columns = getStaticDataColumns(typeId);
  return columns.find((item) => item.field === field)?.extras?.arrayObjectKeys;
}

export function getPrimaryField(typeId: string): string {
  const columns = getStaticDataColumns(typeId);
  return columns.find((item) => item.extras?.isPrimaryField)?.field || '';
}

export function getMutationActionByFields(typeId: string, field: string): string {
  const columns = getStaticDataColumns(typeId);
  return columns.find((item) => item.field === field)?.extras?.mutationAction || '';
}

export function getDependenciesFromColumn(column: StaticDataColumn): Set<string> {
  const set = new Set<string>();

  const selectorVariables = column?.extras?.selectorVariables;
  if (selectorVariables) {
    Object.values(selectorVariables).forEach((item) => {
      const { path } = item as SelectorVariable;
      if (path) {
        set.add(path);
      } else {
        set.add(item as string);
      }
    });
  }

  return set;
}

export function capitaliseSelector(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

/* eslint-disable no-plusplus */
/* eslint-disable no-restricted-syntax */
import { get, isEmpty } from 'lodash';
import { ChangeErrorType } from '@/types/change';
import { dataChangeErrorMessages } from '@/constants/messages';
import { StaticDataColumn } from '../mappings/staticDataSet';

interface FieldInfo {
  field: string;
  value: any;
}

export interface ValidatorArgs {
  existingDataSet: Map<any, any>;
  id: string;
  field: string;
  fieldValue: string;
  dataItem: any;
  columns: StaticDataColumn[];
}

export type ValidationResponse = [boolean, string?];

export type Validator = (args: ValidatorArgs) => ValidationResponse;

const dataTrim = (val: any) => (typeof val === 'string' ? val.trim().toUpperCase() : val);

const checkAreValuesUnique = (
  dataSet: Map<any, any>,
  currentDataId: string,
  fieldInfoList: FieldInfo[],
) => {
  let seen = false;

  for (const data of dataSet) {
    const dataValues = data[1]; // since dataSet is a Map

    if (seen) {
      return false;
    }

    if (dataValues.id !== currentDataId) {
      seen = fieldInfoList.every(
        (item) => dataTrim(get(dataValues, item.field)) === dataTrim(item.value),
      );
    }
  }

  return true;
};

const replaceStringsOnMsg = (msg: string, str: string): string => msg.replace(/{(.*?)}/, str);

const getValidationMessage = (
  value: string | string[],
  changeErrorType: ChangeErrorType,
): string => {
  const errorMsg = dataChangeErrorMessages[changeErrorType];
  let modifiedValue = value as string;

  if (Array.isArray(value)) {
    modifiedValue = value.reduce((acc, curr, index) => {
      if (index === modifiedValue.length - 1) {
        return `${acc} and ${curr}`;
      }

      return `${acc}, ${curr}`;
    });
  }

  return replaceStringsOnMsg(errorMsg, modifiedValue);
};

export function isUnique({
  existingDataSet,
  id,
  field,
  fieldValue,
}: ValidatorArgs): ValidationResponse {
  const isValueUnique = checkAreValuesUnique(existingDataSet, id, [{ field, value: fieldValue }]);
  const validationMsg = !isValueUnique ? dataChangeErrorMessages[ChangeErrorType.NOT_UNIQUE] : '';

  return [isValueUnique, validationMsg];
}

export function isUniqueBetweenFields({
  field: currentField,
  dataItem,
  columns,
}: ValidatorArgs): ValidationResponse {
  const fieldList = columns.filter(
    (item) =>
      item.field !== currentField && item.extras?.validators?.includes(isUniqueBetweenFields),
  );
  const currentValue = get(dataItem, currentField);
  const matchedValueInfo = fieldList.find(
    (item) => get(dataItem, item.field || '') === currentValue,
  );
  const isValuePreselected = !!matchedValueInfo;
  const validationMsg = isValuePreselected
    ? getValidationMessage(matchedValueInfo?.title || '', ChangeErrorType.NOT_UNIQUE_BETWEEN_FIELDS)
    : '';

  return [!isValuePreselected, validationMsg];
}

/**
 * @function isUniqueCompoundField
 * @param {Args} {existingDataSet, id, field, dataItem, columns}
 * @returns {ValidationResponse}
 * @description Check whether the combination does exist in the existing record.
 */
export function isUniqueCompoundField({
  existingDataSet,
  id,
  dataItem,
  columns,
}: ValidatorArgs): ValidationResponse {
  const fieldList = columns.filter((item) =>
    item.extras?.validators?.includes(isUniqueCompoundField),
  );
  const compositeMapValues: FieldInfo[] = [
    ...fieldList.map(
      (item) =>
        ({
          field: item.field,
          value: get(dataItem, item.field || ''),
        } as FieldInfo),
    ),
  ];
  const isUniqueAsACombination = checkAreValuesUnique(existingDataSet, id, compositeMapValues);
  const compositeFields = [...fieldList.map((item) => `[${item.title}]`)] as string[];
  const validationMsg = !isUniqueAsACombination
    ? getValidationMessage(compositeFields, ChangeErrorType.NOT_UNIQUE_AS_A_COMPOSITE_FIELD)
    : '';

  return [isUniqueAsACombination, validationMsg];
}

export function minLimit(num: number): Validator {
  return ({ fieldValue }: ValidatorArgs) => {
    const isValid = Number(fieldValue) >= num;
    const validationMsg = !isValid
      ? getValidationMessage(num.toString(), ChangeErrorType.MIN_LIMIT)
      : '';

    return [isValid, validationMsg];
  };
}

export function maxLimit(num: number) {
  return ({ fieldValue }: ValidatorArgs) => {
    const isValid = Number(fieldValue) <= num;
    const validationMsg = !isValid
      ? getValidationMessage(num.toString(), ChangeErrorType.MAX_LIMIT)
      : '';

    return [isValid, validationMsg];
  };
}

export function minLimitBy(field: string, title: string): Validator {
  return ({ fieldValue, dataItem }: ValidatorArgs) => {
    const isValid = Number(fieldValue) >= Number(dataItem[field]);
    const validationMsg = !isValid ? getValidationMessage(title, ChangeErrorType.MIN_LIMIT_BY) : '';

    return [isValid, validationMsg];
  };
}

export function maxLimitBy(field: string, title: string): Validator {
  return ({ fieldValue, dataItem }: ValidatorArgs) => {
    const isValid = Number(fieldValue) <= Number(dataItem[field]);
    const validationMsg = !isValid ? getValidationMessage(title, ChangeErrorType.MAX_LIMIT_BY) : '';

    return [isValid, validationMsg];
  };
}

export function minLength(length: number) {
  return ({ fieldValue }: ValidatorArgs) => {
    const isValid = length <= fieldValue?.length;
    const validationMsg = !isValid
      ? getValidationMessage(length.toString(), ChangeErrorType.MIN_LENGTH)
      : '';

    return [isValid, validationMsg];
  };
}

export function maxLength(length: number): Validator {
  return ({ fieldValue }: ValidatorArgs) => {
    const isValid = length >= fieldValue?.length;
    const validationMsg = !isValid
      ? getValidationMessage(length.toString(), ChangeErrorType.MAX_LENGTH)
      : '';

    return [isValid, validationMsg];
  };
}

export function requiredLength(length: number): Validator {
  return ({ fieldValue }: ValidatorArgs) => {
    const isValid = length === fieldValue?.length;
    const validationMsg = !isValid
      ? getValidationMessage(length.toString(), ChangeErrorType.REQUIRED_LENGTH)
      : '';

    return [isValid, validationMsg];
  };
}

interface ParamsForWhenFieldRequired {
  fieldForValidation: string;
  accumulator: (value: string | boolean | number | object) => boolean;
}

export function isRequiredWhenGivenConditionsAreMet(params: ParamsForWhenFieldRequired): Validator {
  const constructMsg = (...args: string[]): string =>
    args.reduce((acc, curr) => {
      const [value] = curr.toString().split('.');
      return replaceStringsOnMsg(acc, value);
    }, dataChangeErrorMessages[ChangeErrorType.REQUIRED_FIELD]);

  return ({ dataItem, field, fieldValue, columns }: ValidatorArgs) => {
    const value = dataItem[params.fieldForValidation];
    const isConditionsMet = params.accumulator(value);
    const isValid = (isConditionsMet && !isEmpty(fieldValue)) || !isConditionsMet;
    const currentColumnTitle = columns.find((item) => item.field === field)?.title ?? '';
    const columnTitleForValidation =
      columns.find((item) => item.field === params.fieldForValidation)?.title ?? '';
    const message = isValid
      ? ''
      : constructMsg(currentColumnTitle, columnTitleForValidation, value);

    return [isValid, message];
  };
}

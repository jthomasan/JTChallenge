/* eslint-disable no-param-reassign */
/* eslint-disable no-await-in-loop */
/* eslint-disable no-restricted-syntax */
import { gql, useApolloClient, ApolloClient } from 'umi-plugin-apollo-anz/apolloClient';
import { isEmpty, get, keyBy, mapValues, isEqual } from 'lodash';
import moment from 'moment';
import Papa from 'papaparse';
import useUncommittedChanges from '@/hooks/useUncommittedChanges';
import uuid from 'uuid-random';
import { ChangeAction } from '@/types/change';
import { FieldHelperProps } from '@/components/Grid';
import {
  StaticDataColumn,
  StaticDataHelperProps,
  SelectorVariable,
} from '../mappings/staticDataSet';
import {
  getStaticDataColumns,
  getSelectorQuery,
  getStaticDataType,
  getStaticDataMutationAction,
  getStaticDataAdditionalDataForSave,
  getStaticDataMutationAddAction,
  getStaticDataCanAddNew,
  getDependenciesFromColumn,
} from '../utils/normaliseMappings';
import { StaticDataAccessors } from '../index';
import { StaticDataAction } from './types';
import { isUniqueCompoundField } from '../utils/validators';
import { Selector } from '../mappings/selectors';
import {
  isColumnEditable,
  validateUsingColumnSpecificValidations,
  removeInvalidChanges,
} from './bulkUpdateHelper';

interface IDValuePair {
  id: string;
  text: string;
}

interface ColumnDependancy {
  [field: string]: StaticDataColumn[];
}

export interface ChangeProp {
  id: string;
  name: string;
  field?: string;
  value?: any;
  changeAction?: ChangeAction;
  newRow?: any;
  isChangeValid?: boolean;
  reason?: string;
}

interface DependancyColumnValidationOutput {
  isValidationFailed: boolean;
  newData: any;
  invalidFieldList: ChangeProp[];
}

export interface ColumnChange {
  changes: ChangeProp;
  isSelectorListRequired: boolean;
}

type FileContent = Promise<[any[], any[], Map<string, any>, Map<string, ChangeProp>]>;

const validationMessages = {
  invalidValue: 'Invalid value provided',
  invalidDate: 'Invalid date provided',
  emptyValue: 'Value cannot be empty',
  subsetValueDoesntMatchSupersetValue: (superset: string, subset: string) =>
    `[${subset}] column value is not a subset of [${superset}] column value`,
};

const selectorMap = new Map();

const capitaliseSelector = (value: string): string =>
  value.charAt(0).toUpperCase() + value.slice(1);

const getMappedValues = (dataItem: any) => (mappedKey: string | SelectorVariable) => {
  const { path, valueFormatter } = mappedKey as SelectorVariable;
  const value = get(dataItem, path ?? mappedKey);

  if (valueFormatter) {
    return valueFormatter(value);
  }

  return value;
};

const getSelectorVariableName = (
  selector: string,
  variables = {} as any,
  existingDataItem: any,
): string =>
  `${selector}${btoa(JSON.stringify(mapValues(variables, getMappedValues(existingDataItem))))}`;

// Track the invalid field on newly added row.
const addInvalidValueInfoToRequiredList = (
  listOfChangesObj: ChangeProp,
  field: string,
  value: any,
  msg: string,
) => {
  listOfChangesObj.field = field;
  listOfChangesObj.value = value;
  listOfChangesObj.isChangeValid = false;
  listOfChangesObj.reason = msg;
};

const mapValueToIdFromSelectorList = (
  field: string,
  value: string,
  extras: StaticDataHelperProps,
  existingDataItem: any,
) => {
  const selector = extras.selector || '';
  const selectorField = extras.selectorField || '';
  const selectorOptions: any[] = selectorMap.get(
    getSelectorVariableName(selector, extras.selectorVariables, existingDataItem),
  );
  if (!selectorOptions) {
    return selectorOptions;
  }

  const selectorOption = selectorOptions.find(
    (item) => item[selectorField].toUpperCase() === value.toUpperCase(),
  );

  if (!selectorOption) {
    return selectorOption;
  }

  const res = { id: selectorOption.id, [field || selectorField]: selectorOption[selectorField] };

  if (Array.isArray(extras.additionalFieldsFromSelectorDuringBulkUpdate)) {
    extras.additionalFieldsFromSelectorDuringBulkUpdate.forEach((item) => {
      res[item] = selectorOption[item];
    });
  }

  if (extras?.fullPath) {
    res.fullPath = selectorOption.fullPath;
  }

  return extras.transformTo ? extras.transformTo(res) : res;
};

const getIdValuePairsFromSelectorList = (
  field: string,
  value: string,
  extras: StaticDataHelperProps,
  existingDataItem: any,
): IDValuePair | IDValuePair[] => {
  if (extras.enableMultiSelect && extras.bulkUpdateRenderer) {
    const values = extras.bulkUpdateRenderer(value) as string[];
    return values.reduce((acc, curr): IDValuePair[] => {
      const selectorValue = mapValueToIdFromSelectorList(field, curr, extras, existingDataItem);

      if (selectorValue) {
        return [...acc, selectorValue];
      }

      return acc;
    }, [] as IDValuePair[]);
  }

  return mapValueToIdFromSelectorList(field, value, extras, existingDataItem);
};

const fetchValuesFromApiBySelector = async (
  client: ApolloClient<any>,
  selector: Selector,
  variables: Record<string, string | SelectorVariable>,
  dataItem: any,
) => {
  const query = gql`
    ${getSelectorQuery(selector)}
  `;

  const { data } = await client.query({
    query,
    variables: mapValues(variables, getMappedValues(dataItem)),
  });
  return data?.[capitaliseSelector(selector)] || [];
};

const getDefaultSelectorValueWhenEmpty = (prop: string, isAList: boolean): any => {
  if (isAList) {
    return [];
  }

  return { id: '', [prop]: '' };
};

const validateNewChange = (fieldType: string, value: any): boolean =>
  // eslint-disable-next-line valid-typeof
  typeof value === fieldType;

const validateMandatoryFields = (column: StaticDataColumn, value: any) => {
  if (column.extras?.isOptional) {
    return true;
  }
  return value != null && value !== '';
};

const getRowIndexingKey = (columns: StaticDataColumn[]): [number[], string[]] => {
  const keyIndexes: number[] = [];
  const keys: string[] = [];

  if (columns.some((item) => item.extras?.validators?.includes(isUniqueCompoundField))) {
    columns.forEach((column, index) => {
      if (column.extras?.validators?.includes(isUniqueCompoundField)) {
        keyIndexes.push(index);
        keys.push(column.field || '');
      }
    });
  } else {
    const primaryFieldIndex = columns.findIndex((item) => item.extras?.isPrimaryField);
    const primaryField = columns.find((item) => item.extras?.isPrimaryField)?.field || '';

    keyIndexes.push(primaryFieldIndex);
    keys.push(primaryField);
  }

  return [keyIndexes, keys];
};

const getExistingDataObj = (existingDataList: any[], primaryFields: string[]) => {
  const existingDataObj = {};

  existingDataList.forEach((item) => {
    const rowIndex = primaryFields.reduce(
      (primaryFieldStr, currStr, index) =>
        `${primaryFieldStr}${index ? ' - ' : ''}${get(item, currStr)
          ?.toString()
          ?.toUpperCase()}`,
      '',
    );

    existingDataObj[rowIndex] = item;
  });

  return existingDataObj;
};

/**
 * Convert csv strings to proper types
 * @param {string} type - data type
 * @param {string} value
 */
const convertDataToProperTypes = (type: string, value: string, ignoreFormatting = false): any => {
  if (ignoreFormatting) {
    return value ?? '';
  }

  const refinedValue = (typeof value === 'string' && value.trim().toUpperCase()) || value;

  switch (type) {
    case 'boolean': {
      if (refinedValue === 'TRUE') {
        return true;
      }

      if (refinedValue === 'FALSE') {
        return false;
      }

      if (refinedValue === '') {
        return null;
      }

      return value;
    }

    case 'number': {
      return Number(value);
    }

    case 'date': {
      if (isEmpty(refinedValue)) {
        return '';
      }

      const isSlashFormat = moment.parseZone(refinedValue, 'DD/MM/YYYY').isValid();
      if (isSlashFormat) {
        return moment.parseZone(refinedValue, 'DD/MM/YYYY').format('YYYY-MM-DD');
      }

      return refinedValue;
    }

    default: {
      return value != null ? value : '';
    }
  }
};

const formatStringValuesForComparison = (
  existingData: any,
  column: StaticDataColumn,
  existingRow: any,
): any | any[] => {
  let newData = existingData;

  if (column.extras?.displayRenderer && !column.extras?.ignoreDisplayRendererOnBulkUpdate) {
    newData = column.extras?.displayRenderer(existingData, '', existingRow);
  }

  return newData;
};

const areValuesDifferent = (
  existingData: any,
  newData: any,
  type: string,
  column: StaticDataColumn,
  existingRow: any,
): boolean => {
  switch (type) {
    case 'number': {
      const existingNum = Number(existingData).toPrecision(9);
      const newNum = Number(newData).toPrecision(9);

      return existingNum !== newNum;
    }

    default: {
      const existingValue = formatStringValuesForComparison(existingData, column, existingRow);

      return !isEqual(existingValue, newData);
    }
  }
};

const getDependantColumns = (typeId: string): ColumnDependancy => {
  const columns = getStaticDataColumns(typeId);
  const columnsByField = keyBy(columns, 'field');
  return columns.reduce((acc, curr) => {
    if (curr.extras?.selectorVariables) {
      const columnList = Array.from(getDependenciesFromColumn(curr)) as string[];
      const parentColumns = columnList.map((item) => columnsByField[item]);

      return {
        ...acc,
        [curr.field || '']: parentColumns,
      };
    }
    return acc;
  }, {} as ColumnDependancy);
};

const anyParentColumnDataModified = (columns: StaticDataColumn[], newDataItem: any): boolean => {
  for (const column of columns) {
    const isDataModified = newDataItem[column.field || ''];

    if (isDataModified) {
      return true;
    }
  }

  return false;
};

const validateWhetherValueExistedOnTheList = (
  selectorValueList: IDValuePair[],
  data: IDValuePair | IDValuePair[],
): boolean => {
  const selectorValueById = keyBy(selectorValueList, 'id');

  if (Array.isArray(data)) {
    return data.every((o) => !!selectorValueById[o.id]);
  }

  return !!selectorValueById[data.id];
};

const validateDataByDependancies = async (
  client: ApolloClient<any>,
  childColumnData: IDValuePair | IDValuePair[],
  childColumn: StaticDataColumn,
  dataItem: any,
): Promise<boolean> => {
  const { selector = '', selectorVariables = {} } = childColumn.extras as Partial<
    StaticDataHelperProps
  >;

  let selectorValueList = selectorMap.get(
    getSelectorVariableName(selector, selectorVariables, dataItem),
  ) as IDValuePair[];

  if (!selectorValueList?.length) {
    selectorValueList = await fetchValuesFromApiBySelector(
      client,
      selector as Selector,
      selectorVariables,
      dataItem,
    );

    selectorMap.set(
      getSelectorVariableName(selector, selectorVariables, dataItem),
      selectorValueList,
    );
  }

  return validateWhetherValueExistedOnTheList(selectorValueList, childColumnData);
};

const undoNewlyCommittedChanges = (
  item: StaticDataColumn,
  newDataItem: any,
  newDataAfterValidation: any,
  invalidFieldList: ChangeProp[],
  primaryValue: string,
  childColumnTitle: string,
) => {
  const field = item.field || '';
  const isThisColumnDataModifed = newDataItem[field];

  if (isThisColumnDataModifed) {
    const [initProp] = field.split('.');
    const changeProp = {
      name: primaryValue,
      changeAction: ChangeAction.UPDATE,
      field,
      value: get(newDataItem, field),
      isChangeValid: false,
      reason: validationMessages.subsetValueDoesntMatchSupersetValue(
        item.title || '',
        childColumnTitle,
      ),
    } as ChangeProp;

    invalidFieldList.push(changeProp);

    delete newDataAfterValidation[initProp];
  }
};

const validateAndResolveDependantColumnData = async (
  client: ApolloClient<any>,
  typeId: string,
  dependantColumnByField: ColumnDependancy,
  existingDataItem: any,
  newDataItem: any,
  primaryValue: string,
): Promise<DependancyColumnValidationOutput> => {
  const invalidFieldList: ChangeProp[] = [];
  const newDataAfterValidation = { ...newDataItem };
  const columns = getStaticDataColumns(typeId);
  const columnsByField = keyBy(columns, 'field');
  const columnsKeys = Object.keys(dependantColumnByField);

  for (const key of columnsKeys) {
    const dataItemWithNewData = { ...existingDataItem, ...newDataItem };
    const childColumnData = get(dataItemWithNewData, key.split('.')[0]);

    if (!newDataItem[key] && !isEmpty(childColumnData)) {
      const dependantColumns = dependantColumnByField[key];
      const isDataModified = anyParentColumnDataModified(dependantColumns, newDataItem);

      if (isDataModified) {
        if (!isEmpty(childColumnData)) {
          const isDataStillValid = await validateDataByDependancies(
            client,
            childColumnData,
            columnsByField[key],
            dataItemWithNewData,
          );

          if (!isDataStillValid) {
            dependantColumns.forEach((item) =>
              undoNewlyCommittedChanges(
                item,
                newDataItem,
                newDataAfterValidation,
                invalidFieldList,
                primaryValue,
                columnsByField[key].title || '',
              ),
            );
          }
        }
      }
    }
  }

  return {
    isValidationFailed: invalidFieldList.length > 0,
    invalidFieldList,
    newData: newDataAfterValidation,
  } as DependancyColumnValidationOutput;
};

/**
 * Fetch updated fields from file and expose the detected data on a callback function.
 *
 * @param  {ApolloClient<any>}  client - static data options
 * @param  {string}  typeId - static data type id
 * @param  {any}  existingDataList
 * @returns {FileContent} updated fields
 */
async function retrieveMutatedRecords(
  client: ApolloClient<any>,
  typeId: string,
  content: any,
  existingDataMap: Map<string, any>,
): FileContent {
  const existingDataList = [...existingDataMap.values()];
  const newlyUpdatedDataList = [];
  const newlyAddedDataList = [];
  const existingDataByPrimaryValueMap = new Map();
  const [, ...newDataItemsList] = Papa.parse(content, {
    skipEmptyLines: 'greedy',
  }).data as [string, string[]];

  const [, ...columns] = getStaticDataColumns(typeId);
  const listOfChangesByIdColumnMap = new Map<string, ChangeProp>();
  const [columnKeys, columnFields] = getRowIndexingKey(columns);
  const existingDataByPrimaryValueObj = getExistingDataObj(existingDataList, columnFields);
  const dependantColumnByField = getDependantColumns(typeId);

  for (const dataItems of newDataItemsList) {
    if (dataItems.length > 1) {
      /**
       * Find the primary value based on the composite keys
       * @example column name is treated as primary column,
       * which will decide whether the row needs to be treated as new or updated
       */

      const primaryValue = columnKeys
        .map((columnIndex) => {
          const typeOf = columns[columnIndex]?.extras?.typeOf;
          let value = get(dataItems, columnIndex);

          if (typeOf !== undefined) {
            value = convertDataToProperTypes(typeOf, value);
          }

          return value?.toString()?.toUpperCase();
        })
        .join(' - ');

      const existingRecord = existingDataByPrimaryValueObj[primaryValue];

      /**
       * This block will only handle updated fields
       */
      if (existingRecord) {
        let newData = await retrieveUpdatedRecordsInRow(
          client,
          dataItems,
          existingRecord,
          columns,
          primaryValue,
          listOfChangesByIdColumnMap,
        );

        const invalidRecords = validateUsingColumnSpecificValidations(
          { ...existingRecord, ...newData },
          newData,
          existingDataMap,
          columns,
        );

        if (invalidRecords.length) {
          newData = removeInvalidChanges(newData, invalidRecords);

          invalidRecords.forEach((item) => {
            const mappingId = `${primaryValue}-${item.field}`;

            listOfChangesByIdColumnMap.set(mappingId, {
              id: existingRecord.id,
              name: primaryValue,
              field: item.field,
              value: item.value,
              reason: item.errorMsg,
              isChangeValid: false,
            });
          });
        }

        let dependancyValidationInfo = {} as DependancyColumnValidationOutput;

        if (!isEmpty(dependantColumnByField) && !isEmpty(newData)) {
          dependancyValidationInfo = await validateAndResolveDependantColumnData(
            client,
            typeId,
            dependantColumnByField,
            existingRecord,
            newData,
            primaryValue,
          );

          if (dependancyValidationInfo.isValidationFailed) {
            ({ newData } = dependancyValidationInfo);
            dependancyValidationInfo.invalidFieldList.forEach((item) => {
              const mappingId = `${primaryValue}-${item.field}`;

              listOfChangesByIdColumnMap.set(mappingId, { id: existingRecord.id, ...item });
            });
          }
        }

        if (!isEmpty(newData)) {
          newData.id = existingRecord.id;
          newData.modified = true;
          newlyUpdatedDataList.push(newData);
          existingDataByPrimaryValueMap.set(existingRecord.id, existingRecord);
        }
      } else if (!listOfChangesByIdColumnMap.has(primaryValue) && getStaticDataCanAddNew(typeId)) {
        const newData = await retrieveNewlyAddedRow(client, dataItems, columns, primaryValue);

        if (newData.isChangeValid) {
          const [invalidChange] = validateUsingColumnSpecificValidations(
            newData.newRow,
            newData.newRow,
            existingDataMap,
            columns,
          );

          if (invalidChange) {
            newData.isChangeValid = false;
            newData.field = invalidChange.field;
            newData.value = invalidChange.value;
            newData.reason = invalidChange.errorMsg;
          }
        }

        if (newData.isChangeValid) {
          newlyAddedDataList.push({
            id: uuid(),
            ...newData.newRow,
            isNew: true,
            modified: null,
          });
        }

        listOfChangesByIdColumnMap.set(primaryValue, newData);
      }
    }
  }

  return [
    newlyUpdatedDataList,
    newlyAddedDataList,
    existingDataByPrimaryValueMap,
    listOfChangesByIdColumnMap,
  ];
}

async function retrieveUpdatedRecordsInRow(
  client: ApolloClient<void>,
  dataItems: any[],
  existingRecord: any,
  columns: StaticDataColumn[],
  primaryValue: string,
  listOfChangesByIdColumnMap: Map<string, any>,
) {
  const newDataItem: any = {};
  for (const index in dataItems) {
    if (dataItems.hasOwnProperty(index)) {
      const dataItem = dataItems[index];
      const { id } = existingRecord;
      const column = columns[index] as StaticDataColumn;
      const field = column.field || '';
      const mappingId = `${primaryValue}-${field}`;
      const variableType = column.extras?.typeOf || '';
      const { transformFrom } = column.extras || ({} as StaticDataHelperProps);

      if (!listOfChangesByIdColumnMap.has(mappingId)) {
        const tempExistingData = get(existingRecord, field);
        let existingData = convertDataToProperTypes(
          variableType,
          tempExistingData as string,
          variableType === 'date',
        );
        existingData = transformFrom ? transformFrom(existingData) : existingData;

        let newData = convertDataToProperTypes(variableType, dataItem as string);
        newData = transformFrom ? transformFrom(newData) : newData;

        // eslint-disable-next-line prefer-const
        let changes = {} as ChangeProp;
        let isSelectorListRequired = false;

        const editable = isColumnEditable(column, existingRecord, field, newData);

        if (
          areValuesDifferent(existingData, newData, variableType, column, existingRecord) &&
          editable
        ) {
          ({ changes, isSelectorListRequired } = extractUpdatedValueInAColumn(id, newData, column, {
            ...existingRecord,
            ...newDataItem,
          }));

          if (isSelectorListRequired) {
            changes = await mapValueToIdByFetchingSelectorList(client, changes, newData, column, {
              ...existingRecord,
              ...newDataItem,
            });
            changes.changeAction = ChangeAction.UPDATE;
          }

          if (!isEmpty(changes)) {
            addRetrievedDataToRequiredLists(
              changes,
              primaryValue,
              listOfChangesByIdColumnMap,
              mappingId,
              newDataItem,
            );
          }
        }
      }
    }
  }

  return newDataItem;
}

function addRetrievedDataToRequiredLists(
  changes: ChangeProp,
  primaryValue: string,
  listOfChangesByIdColumnMap: Map<string, ChangeProp>,
  mappingId: string,
  newDataItem: any,
) {
  const data = { ...changes, name: primaryValue };
  listOfChangesByIdColumnMap.set(mappingId, data);
  if (changes.isChangeValid) {
    const [valueHolder] = data.field?.split('.') || [];

    newDataItem[valueHolder] = data.value;
  }
}

/**
 * Extract updated field by doing a comparison between new data and old data.
 *
 * @param  {ApolloClient<any>}  client - fetching selectors from network or cache
 * @param  {string}  id - row id
 * @param  {any}  newData field
 * @param  {any}  existingData field
 * @param  {StaticDataColumn}  Column info
 * @returns  {Promise<ChangeProp>}  returns the changed field and value info
 */
function extractUpdatedValueInAColumn(
  id: string,
  newData: any,
  column: StaticDataColumn,
  existingDataItem: any,
): ColumnChange {
  const changes = {
    id,
    field: column.field || '',
    value: newData,
  } as ChangeProp;

  const { typeOf } = column.extras as StaticDataHelperProps;
  const variableTypes = typeOf === 'date' ? 'string' : typeOf;

  if (typeOf === 'date' && newData === 'Invalid date') {
    changes.reason = validationMessages.invalidDate;
    return { changes, isSelectorListRequired: false };
  }

  const isChangeValid = validateNewChange(variableTypes ?? '', newData);
  if (!isChangeValid) {
    changes.reason = validationMessages.invalidValue;
    return { changes, isSelectorListRequired: false };
  }

  // Get id for selector values
  const selector = column.extras?.selector;
  if (selector && column.field) {
    const [, prop] = column.field.split('.');
    if (!newData && column.extras?.isOptional) {
      const { selectorField, enableMultiSelect = false } = column.extras;
      changes.value = getDefaultSelectorValueWhenEmpty(prop ?? selectorField, enableMultiSelect);
    } else {
      const { selectorField, enableMultiSelect } = column.extras as StaticDataHelperProps;

      const selectorValue = getIdValuePairsFromSelectorList(
        prop ?? selectorField,
        newData,
        column.extras || ({} as StaticDataHelperProps),
        existingDataItem,
      );

      if (
        newData &&
        ((!enableMultiSelect && !selectorValue) ||
          (enableMultiSelect && (selectorValue as IDValuePair[])?.length === 0))
      ) {
        return { changes, isSelectorListRequired: true };
      }

      if (!newData) {
        changes.reason = validationMessages.emptyValue;
        return { changes, isSelectorListRequired: false };
      }
      changes.value = selectorValue;
    }
  }

  changes.changeAction = ChangeAction.UPDATE;
  changes.isChangeValid = true;
  return { changes, isSelectorListRequired: false };
}

/**
 * Validate and form the object as required by useStaticData hook
 * @param {ApolloClient<any>} client
 * @param {string[]} dataItems
 * @param {StaticDataColumn[]} columns
 * @returns {ChangeProp}  returns the newly added details
 */
async function retrieveNewlyAddedRow(
  client: ApolloClient<any>,
  dataItems: string[],
  columns: StaticDataColumn[],
  primaryValue: string,
): Promise<ChangeProp> {
  const id = `new-${Math.floor(Math.random() * Math.floor(100000000))}`;
  let newRow = { id };
  let index = 0;
  let listOfChangesObj = {
    id,
    changeAction: ChangeAction.ADD,
    name: primaryValue,
  } as ChangeProp;

  for (const dataItem of dataItems) {
    const column = columns[index] as StaticDataColumn;
    const { typeOf = 'string' } = column.extras || ({} as StaticDataHelperProps);
    const variableType = typeOf === 'date' ? 'string' : typeOf;
    let newData = convertDataToProperTypes(typeOf, dataItem);
    newData = column.extras?.transformFrom ? column.extras?.transformFrom(newData) : newData;
    const field = column.field || '';
    const [referrer, prop] = field.split('.');
    const editable = isColumnEditable(column, newRow, field, newData);
    let data = {};

    if (column.extras?.defaultValueWhenAddNew != null) {
      data = {
        [referrer]: column.extras?.defaultValueWhenAddNew,
      };
    }

    if (editable && field) {
      if (typeOf === 'date' && newData === 'Invalid date') {
        addInvalidValueInfoToRequiredList(
          listOfChangesObj,
          field,
          newData,
          validationMessages.invalidDate,
        );
      }

      let isChangeValid = validateMandatoryFields(column, newData);

      if (!isChangeValid && !column.extras?.defaultValueWhenAddNew) {
        addInvalidValueInfoToRequiredList(
          listOfChangesObj,
          field,
          newData,
          validationMessages.emptyValue,
        );
      }

      isChangeValid = validateNewChange(variableType, newData);

      if (!isChangeValid) {
        addInvalidValueInfoToRequiredList(
          listOfChangesObj,
          field,
          newData,
          validationMessages.invalidValue,
        );
      }

      if (listOfChangesObj.isChangeValid !== false) {
        const selector = column.extras?.selector;

        if (selector) {
          const selectorValue = getIdValuePairsFromSelectorList(
            prop,
            newData,
            column.extras || ({} as FieldHelperProps),
            newRow,
          );

          const { enableMultiSelect } = column.extras as StaticDataHelperProps;

          if (selectorValue && ((enableMultiSelect && selector.length > 0) || !enableMultiSelect)) {
            data = {
              [referrer]: selectorValue,
            };
          } else {
            const newChanges = await mapValueToIdByFetchingSelectorList(
              client,
              listOfChangesObj,
              newData,
              column,
              newRow,
            );

            if (newChanges.isChangeValid) {
              data = {
                [referrer]: newChanges.value,
              };
            } else {
              listOfChangesObj = {
                ...listOfChangesObj,
                ...newChanges,
              };
            }
          }
        } else {
          data = {
            [referrer]: newData,
          };
        }
      }
    }

    newRow = {
      ...newRow,
      ...data,
    };

    // eslint-disable-next-line no-plusplus
    index++;
  }

  if (listOfChangesObj.isChangeValid !== false) {
    listOfChangesObj.isChangeValid = true;
  }

  return { ...listOfChangesObj, newRow };
}

async function mapValueToIdByFetchingSelectorList(
  client: ApolloClient<any>,
  changes: ChangeProp,
  newData: any,
  column: StaticDataColumn,
  existingDataItem: any,
): Promise<ChangeProp> {
  const newChanges = { ...changes };
  const [, prop] = column.field?.split('.') || '';
  const { selector = '', selectorVariables = {} } = column.extras as StaticDataHelperProps;
  const selectorList = await fetchValuesFromApiBySelector(
    client,
    selector as Selector,
    selectorVariables,
    existingDataItem,
  );

  selectorMap.set(
    getSelectorVariableName(selector, selectorVariables, existingDataItem),
    selectorList,
  );

  const selectorValue = getIdValuePairsFromSelectorList(
    prop,
    newData,
    column.extras || ({} as FieldHelperProps),
    existingDataItem,
  );

  if (newData && !selectorValue) {
    newChanges.field = column.field;
    newChanges.reason = validationMessages.invalidValue;
    newChanges.isChangeValid = false;
    return newChanges;
  }

  newChanges.value = selectorValue;
  newChanges.isChangeValid = true;

  return newChanges;
}

const updateCache = (
  newlyUpdatedDataList: any[],
  newlyAddedDataList: any[],
  existingDataByPrimaryValueMap: Map<string, any>,
  staticDataAccessors: StaticDataAccessors,
) => {
  staticDataAccessors.bulkUpdateRecords(newlyUpdatedDataList, true);
  staticDataAccessors.bulkAddRecords(newlyAddedDataList);

  const undo = async () => {
    const newlyAddedDataIds = newlyAddedDataList.map((item) => item.id);

    staticDataAccessors.bulkDeleteRecords(newlyAddedDataIds, true);
    staticDataAccessors.bulkUpdateRecords(
      Array.from(existingDataByPrimaryValueMap.values()),
      false,
    );
  };

  return undo;
};

const removeRedundantProps = ({ modified, isNew, ...rest }: any) => rest;

/**
 * @todo Have to add additionalParams and compositeKeyMap implementation when saving records.
 */
const createBulkMutationActions = (
  category: string,
  typeId: string,
  newlyUpdatedDataList: any[],
  newlyAddedDataList: any[],
  additionalParams: any,
): StaticDataAction[] => {
  const mutationActionList: StaticDataAction[] = [];
  const additionalDataForSave = getStaticDataAdditionalDataForSave(category, typeId);
  let mutationActionName = getStaticDataMutationAction(typeId);

  newlyUpdatedDataList.forEach((item) => {
    const mutationAction: StaticDataAction = {
      [mutationActionName]: {
        ...removeRedundantProps(item),
        ...additionalDataForSave,
        ...additionalParams,
      },
    };

    mutationActionList.push(mutationAction);
  });

  mutationActionName = getStaticDataMutationAddAction(typeId);

  newlyAddedDataList.forEach((item) => {
    const mutationAction: StaticDataAction = {
      [mutationActionName]: {
        ...removeRedundantProps(item),
        ...additionalDataForSave,
      },
    };

    mutationActionList.push(mutationAction);
  });

  return mutationActionList;
};

const updateUncommittedChanges = async (
  addChange: (params: any) => Promise<void>,
  type: string,
  category: string,
  typeId: string,
  newlyUpdatedDataList: any[],
  newlyAddedDataList: any[],
  existingDataByPrimaryValueMap: Map<string, any>,
  staticDataAccessors: StaticDataAccessors,
  additionalParams: any,
) =>
  addChange({
    action: ChangeAction.BULK_UPDATE,
    sourceId: uuid(),
    sourceType: type,
    sourceField: '-',
    from: [],
    to: [],
    details: 'Updated from a file',
    updateCache: () =>
      updateCache(
        newlyUpdatedDataList,
        newlyAddedDataList,
        existingDataByPrimaryValueMap,
        staticDataAccessors,
      ),
    getMutationAction: createBulkMutationActions.bind(
      {},
      category,
      typeId,
      newlyUpdatedDataList,
      newlyAddedDataList,
      additionalParams,
    ),
  });

export default () => {
  const client = useApolloClient();
  const [, addChange] = useUncommittedChanges();

  let onCompleteCallBack: Function;
  const onCompleteBulkUpdate = (callback: (params: ChangeProp[]) => void) => {
    onCompleteCallBack = callback;
  };

  const onStartBulkUpdate = async (
    category: string,
    typeId: string,
    fileContent: any,
    staticDataAccessors: StaticDataAccessors,
    additionalParams?: any,
  ) => {
    const [
      newlyUpdatedDataList,
      newlyAddedDataList,
      existingDataByPrimaryValueMap,
      listOfChangesObj,
    ] = await retrieveMutatedRecords(client, typeId, fileContent, staticDataAccessors.getAllData());

    selectorMap.clear();

    if (newlyUpdatedDataList.length || newlyAddedDataList.length) {
      await updateUncommittedChanges(
        addChange,
        getStaticDataType(category, typeId),
        category,
        typeId,
        newlyUpdatedDataList,
        newlyAddedDataList,
        existingDataByPrimaryValueMap,
        staticDataAccessors,
        additionalParams,
      );
    }

    if (onCompleteCallBack) {
      onCompleteCallBack(Array.from(listOfChangesObj.values()));
    }

    return listOfChangesObj;
  };

  return { onStartBulkUpdate, onCompleteBulkUpdate };
};

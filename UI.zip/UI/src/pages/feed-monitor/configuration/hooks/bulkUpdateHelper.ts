/* eslint-disable no-restricted-syntax */
import { keyBy, get } from 'lodash';
import {
  Validator,
  ValidatorArgs,
  ValidationResponse,
  isUnique,
  isUniqueCompoundField,
} from '../utils/validators';
import { StaticDataColumn, StaticDataHelperProps } from '../mappings/staticDataSet';

export const isColumnEditable = (
  column: StaticDataColumn,
  dataItems: object,
  field: string,
  value: string | number | boolean | object,
): boolean => {
  const { editable, onlyEditableOnNew, enableEditableMode, extras = {} } = column;
  const { canActivate, canReviewRecord } = extras as StaticDataHelperProps;

  return !!(
    editable ||
    onlyEditableOnNew ||
    canActivate ||
    canReviewRecord ||
    (enableEditableMode && enableEditableMode(dataItems, field, value))
  );
};

const isDataValid = (validators: Validator[], args: ValidatorArgs): ValidationResponse => {
  const validatorsNotRequired: Validator[] = [isUnique, isUniqueCompoundField];

  for (const validator of validators) {
    if (!validatorsNotRequired.includes(validator)) {
      const [isChangeValid, errorMsg] = validator(args);

      if (!isChangeValid) {
        return [false, errorMsg];
      }
    }
  }

  return [true];
};

interface InvalidChange {
  field: string;
  value: string | number | boolean | object;
  errorMsg: string;
}

interface StaticDataEntities {
  [field: string]: StaticDataColumn;
}

const validateParentColumnDataIfTouched = (
  parentColumns: string[],
  columnByField: StaticDataEntities,
  mutatedDataItem: object,
  errorMsg: string,
): InvalidChange[] =>
  parentColumns.reduce((acc, curr) => {
    if (get(mutatedDataItem, curr) !== undefined) {
      let invalidChanges: InvalidChange[] = [
        ...acc,
        {
          field: curr,
          value: mutatedDataItem[curr],
          errorMsg,
        },
      ];

      if (Array.isArray(columnByField[curr].extras?.parentColumns)) {
        const { parentColumns: dependantColumns = [] } = columnByField[curr]
          .extras as StaticDataHelperProps;

        invalidChanges = [
          ...invalidChanges,
          ...validateParentColumnDataIfTouched(
            dependantColumns,
            columnByField,
            mutatedDataItem,
            errorMsg,
          ),
        ];
      }

      return invalidChanges;
    }

    return acc;
  }, [] as InvalidChange[]);

const validateDataIfTouched = (
  mutatedDataItem: object,
  field: string,
  value: string | number | boolean | object,
  errorMsg: string,
  parentColumns: string[],
  columnByField: StaticDataEntities,
): InvalidChange[] => {
  let invalidChanges: InvalidChange[] = [];

  if (get(mutatedDataItem, field) !== undefined) {
    invalidChanges.push({
      field,
      value,
      errorMsg,
    });
  }

  if (parentColumns.length) {
    invalidChanges = [
      ...invalidChanges,
      ...validateParentColumnDataIfTouched(parentColumns, columnByField, mutatedDataItem, errorMsg),
    ];
  }

  return invalidChanges;
};

export const validateUsingColumnSpecificValidations = (
  latestRecord: any,
  mutatedDataItem: object,
  existingDataSet: Map<string, any>,
  columns: StaticDataColumn[],
): InvalidChange[] => {
  let invalidChanges: InvalidChange[] = [];
  const columnByField = keyBy(columns, 'field');

  for (const column of columns) {
    const { field = '' } = column;
    const value = get(latestRecord, field);
    const editable = isColumnEditable(column, latestRecord, field, value);

    const { validators, parentColumns = [] } = column.extras || ({} as StaticDataHelperProps);

    if (editable && Array.isArray(validators)) {
      const [valid, errorMsg = ''] = isDataValid(validators, {
        existingDataSet,
        columns,
        dataItem: latestRecord,
        field,
        fieldValue: value,
        id: latestRecord.id,
      });

      if (!valid) {
        invalidChanges = [
          ...invalidChanges,
          ...validateDataIfTouched(
            mutatedDataItem,
            field,
            value,
            errorMsg,
            parentColumns,
            columnByField,
          ),
        ];
      }
    }
  }

  return invalidChanges;
};

export const removeInvalidChanges = (record: object, invalidChanges: InvalidChange[]): object => {
  const newRecord = new Map(Object.entries(record));

  invalidChanges.forEach((change) => {
    newRecord.delete(change.field);
  });

  return Object.fromEntries(newRecord);
};

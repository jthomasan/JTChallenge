export interface StaticDataAction extends BatchAction {
  [action: string]: {
    id: string;
    [field: string]: any;
  };
}

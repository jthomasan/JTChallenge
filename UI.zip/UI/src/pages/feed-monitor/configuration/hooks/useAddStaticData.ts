import uuid from 'uuid-random';
import useUncommittedChanges from '@/hooks/useUncommittedChanges';

import { ChangeAction, ChangeErrorType } from '@/types/change';
import { StaticDataAction } from './types';
import {
  getStaticDataType,
  getStaticDataMutationAddAction,
  getStaticDataColumns,
} from '../utils/normaliseMappings';
import { ChangeProp } from './useBulkUpdate';
import { StaticDataAccessors } from '../index';

const ERROR_SOURCE_TYPE = 'StaticData';

export interface StaticDataAdd {
  category: string;
  typeId: string;
  change?: ChangeProp;
  staticDataAccessors: StaticDataAccessors;
}

export const removeRedundantProps = ({ __typename, text, ...args }: any) => args;

const updateCache = async (
  typeId: string,
  newData: any,
  clearAllErrorsForId: (id: string) => void,
  staticDataAccessors: StaticDataAccessors,
) => {
  const { addRecord, deleteRecordById } = staticDataAccessors;

  const toAdd = {
    ...newData,
    isNew: true,
    modified: null,
  };

  addRecord(toAdd);

  // return undo function
  return async function undo() {
    deleteRecordById(newData.id);

    clearAllErrorsForId(newData.id);
  };
};

export default () => {
  const [, addChange, , , , , addError, replaceAllErrorsForSourceId] = useUncommittedChanges();

  const clearAllErrorsForId = (id: string) => {
    replaceAllErrorsForSourceId(ERROR_SOURCE_TYPE, id, []);
  };

  const addNewStaticData = async (params: StaticDataAdd) => {
    const { category, typeId, change, staticDataAccessors } = params;

    const columns = getStaticDataColumns(typeId);
    const primaryField = (columns.find((c) => c.extras && c.extras.isPrimaryField) || {}).field;
    const defaultValue = columns.reduce((acc, cur) => {
      if (cur.extras && cur.extras.defaultValueWhenAddNew !== undefined) {
        return {
          ...acc,
          [cur.field || '']: cur.extras.defaultValueWhenAddNew,
        };
      }
      // default isActive to false if isActive field exists in static data type
      if (cur.field === 'isActive') {
        return { ...acc, isActive: false };
      }
      return acc;
    }, {});

    const staticDataName = getStaticDataType(category, typeId);

    const newId = uuid();

    const newData = {
      id: newId,
      ...defaultValue,
      ...(change?.newRow || {}),
    };

    await addChange({
      action: ChangeAction.ADD,
      sourceId: newId,
      sourceType: `[${staticDataName}] ${change?.name || ''}`,
      sourceField: '',
      from: '',
      to: '',
      details: '',
      updateCache: () => updateCache(typeId, newData, clearAllErrorsForId, staticDataAccessors),
      getMutationAction: (): StaticDataAction => ({
        [getStaticDataMutationAddAction(params.typeId)]: {
          ...newData,
        },
      }),
    });

    if (primaryField && !change) {
      await addError({
        sourceId: newId,
        sourceType: ERROR_SOURCE_TYPE,
        sourceField: primaryField,
        errorType: ChangeErrorType.EMPTY,
      });
    }
  };

  return [addNewStaticData];
};

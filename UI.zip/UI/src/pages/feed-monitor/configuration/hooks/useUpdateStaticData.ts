import useUncommittedChanges from '@/hooks/useUncommittedChanges';
import { ChangeAction, ChangeError, ChangeErrorType } from '@/types/change';
import { get } from 'lodash';
import { useCallback } from 'react';
import { StaticDataAction } from './types';
import {
  getColumnFieldTitle,
  isObject,
  getStaticDataMutationAction,
  getStaticDataColumns,
  getPrimaryField,
  getStaticDataAdditionalDataForSave,
  getStaticDataType,
  getColumnDisplayRenderer,
  getColumnMutationFormatter,
  getMutationActionByFields,
} from '../utils/normaliseMappings';

import { StaticDataAccessors } from '../index';

export interface StaticDataUpdate {
  category: string;
  typeId: string;
  entityName: string;
  id: string;
  field: string;
  value: any;
  staticDataAccessors: StaticDataAccessors;
  undoNext?: boolean;
}

const ERROR_SOURCE_TYPE = 'StaticData';

const attachToExistingData = (
  existingData: { [key: string]: any },
  referrer: string,
  value: any,
): any => {
  const { modified } = existingData;

  return {
    ...existingData,
    modified: modified === null ? null : true,
    [referrer]: isObject(value) ? { ...existingData[referrer], ...value } : value,
  };
};

export const removeRedundantProps = ({ __typename, text, ...args }: any) => args;

const isEmpty = (value: any) => value === '' || value === null || typeof value === 'undefined';

const createNewError = (
  sourceId: string,
  sourceField: string,
  errorType?: ChangeErrorType,
  errorMsg?: string,
): ChangeError => ({
  sourceId,
  sourceField,
  sourceType: ERROR_SOURCE_TYPE,
  errorType,
  errorMsg,
});

/**
 * @param compositeKey
 * @param dataItem
 * @returns any
 * @description this function will return the composite key object from the provided compositeKey array.
 */
export const getCompositeKeyMap = (compositeKey: string[], dataItem: any): any =>
  compositeKey.reduce((acc, curr) => {
    const [firstField, ...rest] = curr.split('.');

    if (rest?.length > 0) {
      return {
        ...acc,
        [firstField]: getCompositeKeyMap(rest, dataItem[firstField]),
      };
    }

    return { ...acc, [curr]: dataItem[curr] };
  }, {});

const validateData = async (
  typeId: string,
  data: any,
  staticDataAccessors: StaticDataAccessors,
) => {
  if (data.modified === false) {
    return [];
  }

  const { getAllData, getDataById } = staticDataAccessors;
  const columns = getStaticDataColumns(typeId);
  const errors: ChangeError[] = [];
  const isNew = data.modified === null;

  const existingDataSet: Map<string, any> = getAllData();
  const existingRow = getDataById(data.id);

  columns.forEach((col) => {
    const { field = '', editable, onlyEditableOnNew, enableEditableMode, extras } = col;
    const { isOptional, validators, typeOf } = extras || {};
    const fieldValue = get(existingRow, field || '', '');
    const isEditable =
      editable || (enableEditableMode && enableEditableMode(existingRow, field, fieldValue));

    if (!field) return;

    if (isEditable || (isNew && onlyEditableOnNew)) {
      if (!isOptional && isEmpty(fieldValue) && typeOf !== 'boolean') {
        errors.push(createNewError(data.id, field, ChangeErrorType.EMPTY));
      }

      if (validators && Array.isArray(validators)) {
        // eslint-disable-next-line no-restricted-syntax
        for (const validate of validators) {
          const [isValid, msg] = validate({
            existingDataSet,
            id: data.id,
            field,
            fieldValue,
            dataItem: existingRow,
            columns,
          });

          if (!isValid) {
            errors.push(createNewError(data.id, field, undefined, msg));
          }
        }
      }
    }
  });

  return errors;
};

const updateCache = async (
  existingData: any,
  newData: any,
  staticDataAccessors: StaticDataAccessors,
  replaceAllErrorsForSourceId: (
    sourceType: string,
    sourceId: string,
    errors: ChangeError[],
  ) => void,
  undoNext = false,
) => {
  const { updateRecordById } = staticDataAccessors;
  updateRecordById(newData.id, newData);

  const undo = () => {
    updateRecordById(existingData.id, existingData);
    if (existingData.modified === false) {
      replaceAllErrorsForSourceId(ERROR_SOURCE_TYPE, existingData.id, []);
    }

    return { shouldUndoAgain: undoNext };
  };

  return undo;
};

export default () => {
  const [, addChange, , , , , , replaceAllErrorsForSourceId] = useUncommittedChanges();

  const updateStaticData = useCallback(async (params: StaticDataUpdate, additionalParams?: any) => {
    const { field, category, typeId, id, value, staticDataAccessors, undoNext } = params;
    const [referrer] = field.split('.');

    const staticDataName = getStaticDataType(category, typeId);
    const primaryField = getPrimaryField(typeId);
    const existingData = staticDataAccessors.getDataById(id);
    const newData = attachToExistingData(existingData, referrer, value);
    const sourceField = getColumnFieldTitle(typeId, field);
    const valueFrom = get(existingData, params.field);
    const valueTo = get(newData, params.field);
    const additionalDataForSave = getStaticDataAdditionalDataForSave(
      params.category,
      params.typeId,
    );

    let displayValueFrom;
    let displayValueTo;
    let mutatedData: any;

    if (Array.isArray(params.value)) {
      const displayReferer = getColumnDisplayRenderer(params.typeId, params.field);
      const mutationFormatter = getColumnMutationFormatter(params.typeId, params.field);

      displayValueFrom = displayReferer && displayReferer(existingData[referrer]);
      displayValueTo = displayReferer && displayReferer(newData[referrer]);

      mutatedData =
        (mutationFormatter && mutationFormatter(newData[referrer])) || newData[referrer];
    } else {
      displayValueFrom = valueFrom;
      displayValueTo = valueTo;

      mutatedData = isObject(params.value) ? removeRedundantProps(params.value) : params.value;
    }

    const mutationActionName =
      getMutationActionByFields(params.typeId, params.field) ||
      getStaticDataMutationAction(params.typeId);

    let compositeKeyMap = {};

    if (newData.compositeKey && Array.isArray(newData.compositeKey)) {
      compositeKeyMap = getCompositeKeyMap(newData.compositeKey, newData);
    }

    await addChange({
      action: ChangeAction.UPDATE,
      sourceId: params.id,
      sourceType: newData[primaryField] || staticDataName,
      sourceField: [sourceField],
      from: [displayValueFrom ?? ''],
      to: [displayValueTo ?? ''],
      details: '',
      updateCache: () =>
        updateCache(
          existingData,
          newData,
          staticDataAccessors,
          replaceAllErrorsForSourceId,
          undoNext,
        ),
      getMutationAction: (): StaticDataAction => ({
        [mutationActionName]: {
          id: params.id,
          [referrer]: mutatedData,
          ...additionalParams,
          ...additionalDataForSave,
          ...compositeKeyMap,
        },
      }),
    });

    const errors = await validateData(params.typeId, newData, staticDataAccessors);

    replaceAllErrorsForSourceId(ERROR_SOURCE_TYPE, params.id, errors);
  }, []);

  return [updateStaticData];
};

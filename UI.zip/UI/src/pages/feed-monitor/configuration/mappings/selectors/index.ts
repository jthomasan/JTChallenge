// end import -- DO NOT REMOVE

export interface SelectorProp {
  query: string;
  title: string;
  variables?: Record<string, string>;
  transformTo?: (params: any) => any;
}

export interface SelectorPropEntities {
  [name: string]: SelectorProp;
}

export enum Selector {}
// end enum -- DO NOT REMOVE

export const selectors: SelectorPropEntities = {
  // end export -- DO NOT REMOVE
};

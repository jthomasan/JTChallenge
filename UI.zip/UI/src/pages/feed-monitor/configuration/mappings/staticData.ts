import { ENV } from '@/types/env';
import { StaticData } from './staticDataSet';

interface List {
  id: StaticData;
  hierarchyMapAuditTypeSystemId?: string;
  name: string;
  additionalParams?: string[];
  additionalDataForSave?: any;
  /**
   * Hide the option given specified ENV_LEVEL
   * Eg. hideOnEnv: [ENV.PRE_PROD, ENV.PROD],
   */
  hideOnEnv?: ENV[];
}

interface StaticDataCategory {
  name: string;
  list: List[];

  /**
   * Hide the option given specified ENV_LEVEL
   * Eg. hideOnEnv: [ENV.PRE_PROD, ENV.PROD],
   */
  hideOnEnv?: ENV[];
}

const ungrouped = [
  {
    id: StaticData.CsvJobSetting,
    name: 'CSV Jobs Setting',
  },
  {
    id: StaticData.NotificationJobSetting,
    name: 'Notification Jobs Setting',
  },
  {
    id: StaticData.ReconThresholdSetting,
    name: 'Recon Threshold Setting',
    additionalParams: ['reconType'],
  },
  {
    id: StaticData.SystemConfiguration,
    name: 'System Configuration',
  },
];
// end listings -- DO NOT REMOVE

const allCategories: StaticDataCategory[] = [
  {
    name: 'Ungrouped',
    list: ungrouped,
  },
];

const environmentLevel = window.env?.ENV_LEVEL || ENV.PROD;
const filteredCategories = allCategories
  .filter((category) => !category.hideOnEnv?.includes(environmentLevel))
  .map((c) => ({
    ...c,
    list: c.list.filter((o) => !o?.hideOnEnv?.includes(environmentLevel)),
  }));

export const staticDataCategory: StaticDataCategory[] = [
  {
    name: 'All',
    list: [...filteredCategories.map((item) => item.list).flat()],
  },
  ...filteredCategories,
];

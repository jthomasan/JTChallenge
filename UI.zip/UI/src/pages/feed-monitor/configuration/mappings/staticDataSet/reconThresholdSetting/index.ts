export * from './column';
export * from './query';
export const canShowAuditHistory: boolean = true;
export const canAddNew: boolean = true;
export const canBulkUpdate: boolean = false;
export const canShowLog: boolean = false;

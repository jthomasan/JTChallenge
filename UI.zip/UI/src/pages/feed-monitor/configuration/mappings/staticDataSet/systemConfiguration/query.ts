export const queryName = 'SystemConfiguration';
export const mutationAction = 'replaceSystemConfiguration';
export const exportUrl = () => '/export/feed-monitor/configuration/system-config/csv';
export const query = `
  {
    ${queryName} {
        id
        modified
        name
        value
        added {
          by
          time
        }
    }
  }
`;

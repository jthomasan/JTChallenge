export const queryName = 'NotificationConfiguration';
export const mutationAction = 'replaceNotificationConfiguration';
export const mutationAddAction = 'addNotificationConfiguration';
export const exportUrl = () => '/export/feed-monitor/configuration/notification-config/csv';
export const query = `
  {
    ${queryName} {
        id
        modified
        name
        description
        assemblyName
        typeName
        isActive
        pollIntervalInMinute
        sqlStatement
        isEmailEnabled
        email {
          templateName
          toList
          ccList
          subjectText
          bodyText
        }
        event {
          id
          logName
          logSource 
          eventText
        }
        isEventEnabled
        moduleName
        additional {
          param1
          param2
          param3
        }
        allowManualTrigger
        scheduleStart
        scheduleEnd
        workingDayOnly        
        added {
          by
          time
        }
    }
  }
`;

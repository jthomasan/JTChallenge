import { ColumnProps, FieldHelperProps } from '@/components/Grid';
import { Header } from '@/components/MultiSelect/MultiSelectPopup';

import { Validator } from '../../utils/validators';
import { Selector } from '../selectors';

import * as csvJobSetting from './csvJobSetting';
import * as notificationJobSetting from './notificationJobSetting';
import * as reconThresholdSetting from './reconThresholdSetting';
import * as systemConfiguration from './systemConfiguration';

// end import -- DO NOT REMOVE

export interface SelectorVariable {
  path: string;
  valueFormatter: (params: any) => any;
}

export interface StaticDataHelperProps extends FieldHelperProps {
  isPrimaryField?: boolean;
  selector?: Selector;
  selectorField?: string;
  selectorVariables?: Record<string, string | SelectorVariable>;
  setDefaultValue?: boolean;
  typeOf?: string;
  canActivate?: boolean;
  defaultValueWhenAddNew?: any;
  disableClear?: boolean;
  validators?: Validator[];
  enableMultiSelect?: boolean;
  isOptional?: boolean;
  additionalFieldsFromSelectorDuringBulkUpdate?: string[];
  isUnique?: boolean;
  parentColumns?: string[];
  canReviewRecord?: boolean;
  transformTo?: (params: any) => any;
  displayRenderer?: (params: any, field: string, dateItem: any) => string | number | boolean;
  ignoreDisplayRendererOnBulkUpdate?: boolean;
  mutationFormatter?: (params: any) => any;
  bulkUpdateRenderer?: (params: string) => any;
  arrayObjectKeys?: string[];
  mutationAction?: string;
  headers?: Header[];
  transformFrom?: (params: any) => any;
  decimalPlaces?: number;
  showFormatByDefault?: boolean;
  minLimit?: number;
  minLimitBy?: string;
  maxLimit?: number;
  maxLimitBy?: string;
  [name: string]: any;
}

export interface StaticDataColumn extends ColumnProps {
  extras?: StaticDataHelperProps;
}

export enum StaticData {
  CsvJobSetting = '2',
  NotificationJobSetting = '1',
  ReconThresholdSetting = '3',
  SystemConfiguration = '4',
  // end enum -- DO NOT REMOVE
}

export interface StaticDataSet {
  hierarchyMapAuditTypeSystemId?: string;
  canShowAuditHistory?: boolean;
  mutationAddAction?: string;
  columns: StaticDataColumn[];
  queryName: string;
  mutationAction?: string;
  query: any;
  exportUrl: (params?: any) => string;
  canAddNew?: boolean;
  canBulkUpdate?: boolean;
  warningMsgWhenExport?: JSX.Element;
  warningMsgWhenBulkUpdate?: JSX.Element;
  preSaveCallback?: Function;
  postSaveCallback?: Function;
  canShowLog?: boolean;
}

export interface StaticDataSetEntities {
  [id: string]: StaticDataSet;
}

export const staticDataSets: StaticDataSetEntities = {
  [StaticData.CsvJobSetting]: csvJobSetting,
  [StaticData.NotificationJobSetting]: notificationJobSetting,
  [StaticData.ReconThresholdSetting]: reconThresholdSetting,
  [StaticData.SystemConfiguration]: systemConfiguration,
  // end export -- DO NOT REMOVE
};

export enum ReconTypeOptions {
  DailyTradeReconciliation = '3',
  MurexRiskEnginevsTradeDB = '1',
  PastCashReconciliation = '4',
  TradePricingErrorData = '5',
}

export const ReconTypeOptionNames = {
  [ReconTypeOptions.DailyTradeReconciliation]: 'Daily Trade Reconciliation',
  [ReconTypeOptions.MurexRiskEnginevsTradeDB]: 'Murex Risk Engine vs Trade DB',
  [ReconTypeOptions.PastCashReconciliation]: 'Past Cash Reconciliation',
  [ReconTypeOptions.TradePricingErrorData]: 'Trade Pricing Error Data',
};

export const ReconTypeExportFileNames = {
  [ReconTypeOptions.DailyTradeReconciliation]: 'daily_trade',
  [ReconTypeOptions.MurexRiskEnginevsTradeDB]: 'MRE_DB',
  [ReconTypeOptions.PastCashReconciliation]: 'past_cash',
  [ReconTypeOptions.TradePricingErrorData]: 'pricing_error',
};

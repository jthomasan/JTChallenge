import { DATE_FORMATS } from '@/utils/date';
import { StaticDataColumn } from '../index';
import GridStateCell from '../../../components/StaticDataCells/GridStateCell';
import GridBooleanCell from '../../../components/StaticDataCells/GridBooleanCell';
import GridTextboxCell from '../../../components/StaticDataCells/GridTextboxCell';
import GridCheckboxCell from '../../../components/StaticDataCells/GridCheckboxCell';
import { isUnique } from '../../../utils/validators';

export const columns: StaticDataColumn[] = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: GridStateCell,
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    width: '250px',
    onlyEditableOnNew: true,
    cell: GridTextboxCell,
    extras: {
      isPrimaryField: true,
      validators: [isUnique],
      typeOf: 'string',
    },
    defaultSortColumn: true,
  },
  {
    field: 'description',
    title: 'Description',
    filter: 'text',
    width: '250px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'assemblyName',
    title: 'Assembly Name',
    filter: 'text',
    width: '250px',
    editable: true,
    cell: GridTextboxCell,
  },
  {
    field: 'typeName',
    title: 'Type Name',
    filter: 'text',
    width: '250px',
    editable: true,
    cell: GridTextboxCell,
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: GridBooleanCell,
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: DATE_FORMATS.DATE_TIME,
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'pollIntervalInMinute',
    title: 'Poll Interval In Minute',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'workingDayOnly',
    title: 'Working Day Only',
    filter: 'boolean',
    cell: GridCheckboxCell,
    width: '90px',
    editable: true,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'scheduleStart',
    title: 'Schedule Start',
    filter: 'text',
    width: '90px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'scheduleEnd',
    title: 'Schedule End',
    filter: 'text',
    width: '90px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'sqlStatement',
    title: 'SQL Statement',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'isEmailEnabled',
    title: 'Is Email enabled',
    filter: 'boolean',
    cell: GridCheckboxCell,
    width: '90px',
    editable: true,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'email.templateName',
    title: 'Email Template Name',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'email.toList',
    title: 'Email To List',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'email.ccList',
    title: 'Email Cc List',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'email.subjectText',
    title: 'Email Subject Text',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'email.bodyText',
    title: 'Email Body Text',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'isEventEnabled',
    title: 'Is Event Enabled',
    filter: 'boolean',
    cell: GridCheckboxCell,
    width: '90px',
    editable: true,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'allowManualTrigger',
    title: 'Allow Manual Trigger',
    filter: 'boolean',
    cell: GridCheckboxCell,
    width: '90px',
    editable: true,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'event.logName',
    title: 'Event Log Name',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'event.logSource',
    title: 'Event Log Source',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'event.id',
    title: 'Event ID',
    filter: 'numeric',
    width: '90px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'event.eventText',
    title: 'Event Text',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
      typeOf: 'string',
    },
  },
  {
    field: 'moduleName',
    title: 'Module Name',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'additional.param1',
    title: 'Additional Param 1',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'additional.param2',
    title: 'Additional Param 2',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
  {
    field: 'additional.param3',
    title: 'Additional Param 3',
    filter: 'text',
    width: '150px',
    editable: true,
    cell: GridTextboxCell,
    extras: {
      isOptional: true,
    },
  },
];

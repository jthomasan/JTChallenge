export const queryName = 'CsvConfiguration';
export const mutationAction = 'replaceCsvConfiguration';
export const mutationAddAction = 'addCsvConfiguration';
export const exportUrl = () => '/export/feed-monitor/configuration/csv-config/csv';
export const query = `
  {
    ${queryName} {
        id
        modified
        name
        description
        isActive
        pollIntervalInMinute
        folderPath
        fileNamePattern
        tableName
        columnsMapping
        preUploadSqlStatement
        postUploadSqlStatement
        etlJobTypeId
        enableFileWatcher
        bulkUploadBatchSize
        bulkUploadTimeOutInSeconds
        startFooterLineText
        skipFooterLineCount
        specialQuoteHandler
        hasHeader
        columnDelimiter
        textQualifier
        escapeCharactor
        sendCompleteEmailToOwner
        sendErrorEmailToOwner
        completeEmailToList
        completeEmailCcList
        errorEmailToList
        errorEmailCcList 
        added {
          by
          time
        }
    }
  }
`;

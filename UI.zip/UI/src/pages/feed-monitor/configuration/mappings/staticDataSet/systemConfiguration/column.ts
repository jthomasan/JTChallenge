import { DATE_FORMATS } from '@/utils/date';

import GridStateCell from '../../../components/StaticDataCells/GridStateCell';
import GridTextboxCell from '../../../components/StaticDataCells/GridTextboxCell';
import GridTooltipTextBoxCell from '../../../components/StaticDataCells/GridTooltipTextBoxCell';
import { StaticDataColumn } from '../index';

export const columns: StaticDataColumn[] = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: GridStateCell,
  },
  {
    field: 'name',
    title: 'Name',
    filter: 'text',
    width: '250px',
    defaultSortColumn: true,
    cell: GridTextboxCell,
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
    },
  },
  {
    field: 'value',
    title: 'Value',
    filter: 'text',
    width: '450px',
    editable: true,
    cell: GridTooltipTextBoxCell,
    extras: {
      isOptional: true,
      multiple: true,
    },
  },
  {
    field: 'added.by',
    title: 'Last Edited By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'added.time',
    title: 'Last Edited Time',
    filter: 'date',
    width: '150px',
    format: DATE_FORMATS.DATE_TIME,
  },
];

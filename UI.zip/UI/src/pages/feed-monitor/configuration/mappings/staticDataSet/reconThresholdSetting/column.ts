import { DATE_FORMATS } from '@/utils/date';
import { maxLength } from '@/pages/reference-data/static-data/utils/validators';
import { StaticDataColumn } from '../index';
import GridStateCell from '../../../components/StaticDataCells/GridStateCell';
import GridCheckboxCell from '../../../components/StaticDataCells/GridCheckboxCell';
import GridBooleanCell from '../../../components/StaticDataCells/GridBooleanCell';
import GridTextboxCell from '../../../components/StaticDataCells/GridTextboxCell';

export const columns: StaticDataColumn[] = [
  {
    field: 'modified',
    title: 'State',
    filter: 'text',
    width: '80px',
    cell: GridStateCell,
  },
  {
    field: 'statusName',
    title: 'Status',
    filter: 'text',
    width: '250px',
    defaultSortColumn: true,
    cell: GridTextboxCell,
    editable: true,
    extras: {
      isPrimaryField: true,
      typeOf: 'string',
    },
  },
  {
    field: 'range',
    title: 'Range Value',
    filter: 'numeric',
    width: '150px',
    cell: GridTextboxCell,
    editable: true,
    extras: {
      typeOf: 'number',
      isOptional: true,
    },
  },
  {
    field: 'added.time',
    title: 'Added Time',
    filter: 'date',
    width: '150px',
    format: DATE_FORMATS.DATE_TIME,
  },
  {
    field: 'added.by',
    title: 'Added By',
    filter: 'text',
    width: '150px',
  },
  {
    field: 'isActive',
    title: 'Is Active',
    filter: 'boolean',
    width: '90px',
    cell: GridBooleanCell,
    extras: {
      typeOf: 'boolean',
      canActivate: true,
    },
  },
];

import { ReconTypeExportFileNames } from '../index';

export const queryName = 'ReconThresholdSetting';
export const mutationAction = 'replaceReconThresholdSetting';
export const mutationAddAction = 'addReconThresholdSetting';
export const exportUrl = ({ reconType }: any) =>
  `/export/feed-monitor/configuration/recon-threshold-setting-config/csv?reconType=${reconType}`;
export const query = ({ reconType }: any) => `
  {
    ${queryName} (reconType: "${reconType}") {
        id
        modified
        statusName
        range
        isActive
        reconType {
          id
          value          
        }
        added {
          by
          time
        }
    }
  }
`;

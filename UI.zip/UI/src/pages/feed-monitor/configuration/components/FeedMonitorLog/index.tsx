import React from 'react';
import Window from '@/components/Window';
import { gql } from 'umi-plugin-apollo-anz/apolloClient';
import useQuery from '@/hooks/useQueryExtended';

import Grid, { ColumnProps, GridExternalState } from '@/components/Grid';
import { useMergedState } from '@/hooks/useMergedState';
import { Button } from 'antd';
import ErrorBoundary from '@/error/ErrorBoundary';

import styles from './index.less';
import { getfmConfigDatasetExportName } from '../../utils/normaliseMappings';
import { DATE_FORMATS } from '@/utils/date';
import GridMultiLineCell from '../StaticDataCells/GridMultiLineCell';

export interface FeedMonitorLogProps {
  logId: string;
  fmConfigTypeId: string;
  onFeedMonitorLogDismiss: () => void;
}

export const hierarchyAuditMapDefaultGroup = 'HierarchyType';

const FeedMonitorLog: React.FC<FeedMonitorLogProps> = (props: FeedMonitorLogProps) => {
  const { logId, fmConfigTypeId } = props;

  const { loading, data } = useQuery(
    gql`
      query getFeedMonitorLog($fmConfigTypeId: ID, $logId: ID) {
        FeedMonitorLog(fmConfigTypeId: $fmConfigTypeId, logId: $logId) {
          jobName
          startTime
          endTime
          resultMessage
          errorMessage
        }
      }
    `,
    {
      variables: { logId, fmConfigTypeId },
      notifyOnNetworkStatusChange: true,
    },
  );
  const currentStateWatcher = `${fmConfigTypeId}-${logId}-${loading}`;
  const [externalState, setExternalState] = useMergedState({
    gridStateTracker: `${fmConfigTypeId}-${logId}-true`,
  } as GridExternalState);

  const feedMonitorLog = data?.FeedMonitorLog || null;

  const columnsWithCustomCells: ColumnProps[] = [
    {
      field: 'jobName',
      title: 'Job Name',
      filter: 'text',
      width: '150px',
    },
    {
      field: 'startTime',
      title: 'Start Time',
      filter: 'date',
      width: '100px',
      format: DATE_FORMATS.DATE_TIME,
    },
    {
      field: 'endTime',
      title: 'End Time',
      filter: 'date',
      width: '100px',
      format: DATE_FORMATS.DATE_TIME,
    },
    {
      field: 'resultMessage',
      title: 'Result Message',
      filter: 'text',
      width: '315px',
      cell: GridMultiLineCell,
    },
    {
      field: 'errorMessage',
      title: 'Error Message',
      filter: 'text',
      width: '440px',
      cell: GridMultiLineCell,
    },
  ];

  const onExportAuditHistory = () => {
    window.location.href = `/export/feed-monitor/log/csv?fmConfigTypeId=${fmConfigTypeId}&logId=${logId}&datasetName=${getfmConfigDatasetExportName(
      fmConfigTypeId,
    )}`;
  };

  return (
    <div className={styles.feedMonitorLog}>
      <div className={styles.feedMonitorLogToolbar}>
        <Button
          type="default"
          disabled={feedMonitorLog?.length === 0}
          onClick={onExportAuditHistory}
        >
          Export
        </Button>
      </div>
      <div className={styles.feedMonitorLogGrid}>
        <Grid
          data={feedMonitorLog}
          style={{ height: '100%' }}
          loading={loading}
          columns={columnsWithCustomCells}
          columnVirtualization={false}
          currentStateWatcher={currentStateWatcher}
          dataRefreshWatcher="0"
          externalState={externalState}
          setExternalState={setExternalState}
          groupOptions={{ fixedGroupColumns: [hierarchyAuditMapDefaultGroup] }}
          useStandardCellsUnlessEditing
          disableVirtualScroll
        />
      </div>
    </div>
  );
};

const FeedMonitorLogWindow: React.FC<FeedMonitorLogProps> = (props: FeedMonitorLogProps) => {
  const { onFeedMonitorLogDismiss } = props;
  return (
    <Window title="Log" initialHeight={500} initialWidth={700} onClose={onFeedMonitorLogDismiss}>
      <ErrorBoundary errorTitle="Error Loading Log">
        <FeedMonitorLog {...props} />
      </ErrorBoundary>
    </Window>
  );
};

export default FeedMonitorLogWindow;

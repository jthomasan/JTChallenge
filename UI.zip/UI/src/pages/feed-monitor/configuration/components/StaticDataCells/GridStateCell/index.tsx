const GridStateCell: any = {};

GridStateCell.cellName = 'GridStateCell';

export default GridStateCell;

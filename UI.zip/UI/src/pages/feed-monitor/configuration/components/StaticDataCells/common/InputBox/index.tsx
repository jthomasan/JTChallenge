import React, { SyntheticEvent, useState, useRef, RefObject, useEffect } from 'react';

import { Input } from 'antd';

import { isEmptyValue } from '@/utils/utils';

const formatNumber = (
  value: number,
  decimalPlaces: number,
  showFormatByDefault: boolean,
): number | string => {
  let data: number | string = value;
  if (decimalPlaces != null) {
    if (showFormatByDefault) {
      data = parseFloat(data.toString()).toFixed(decimalPlaces);
    } else {
      data = Number(data.toFixed(decimalPlaces));
    }
  }

  return data;
};

const InputBox: React.FC<any> = (props) => {
  const {
    value,
    onChange,
    field,
    dataItem,
    decimalPlaces,
    showFormatByDefault,
    type,
    toStringOnCommit,
    mustBeUppercased,
    disabledDefaultFocus,
    multiple,
  } = props;

  const defaultValue =
    !isEmptyValue(value) && type === 'number'
      ? formatNumber(Number(value), decimalPlaces, showFormatByDefault)
      : value;
  const [editableValue, setEditableValue] = useState(defaultValue);
  const inputRef = useRef<Input>();

  useEffect(() => {
    if (inputRef.current && !disabledDefaultFocus) {
      inputRef.current.input.focus({
        preventScroll: true,
      });
    }
  }, [inputRef.current]);

  const onChangeInput = (event: SyntheticEvent) => {
    let numValue;
    let latestValue;

    if (type === 'number' && !isEmptyValue(editableValue)) {
      numValue = formatNumber(Number(editableValue), decimalPlaces, showFormatByDefault);
      setEditableValue(numValue);
      latestValue = Number(numValue);
    } else {
      latestValue = editableValue;
    }

    if (onChange && value !== (toStringOnCommit ? latestValue?.toString() : latestValue)) {
      let updatedData: any = '';
      // default empty to 0 only when change number back to empty
      if (type === 'number' && isEmptyValue(latestValue)) {
        latestValue = 0;
      }
      const fieldArr = field.split('.');
      if (fieldArr.length > 1) {
        updatedData = { [fieldArr[fieldArr.length - 1]]: latestValue };
      } else {
        updatedData = latestValue;
      }
      const data: any = {
        dataItem,
        field,
        syntheticEvent: event,
        value: toStringOnCommit ? updatedData.toString() : updatedData,
      };
      onChange(data);
    } else if (onChange) {
      onChange({ dataItem, syntheticEvent: {} as SyntheticEvent, field, value: undefined });
    }
  };

  const onKeyPress = (e: SyntheticEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (!multiple && (e.nativeEvent as KeyboardEvent).key === 'Enter') {
      onChangeInput(e);
    }
  };

  const onInputChange = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    let data: any = event.target.value;
    const { value: inputValue } = event.target;

    if (mustBeUppercased) {
      data = inputValue.toUpperCase();
    }

    setEditableValue(data);
  };

  const onClick = (event: React.MouseEvent<HTMLInputElement | HTMLTextAreaElement, MouseEvent>) => {
    event.stopPropagation();
  };

  const { TextArea } = Input;

  return (
    <>
      {multiple ? (
        <TextArea
          value={editableValue}
          onBlur={onChangeInput}
          autoSize={{ minRows: 1, maxRows: 9 }}
          onKeyPress={onKeyPress}
          onChange={onInputChange}
          onClick={onClick}
        />
      ) : (
        <Input
          ref={inputRef as RefObject<Input>}
          value={editableValue}
          onKeyPress={onKeyPress}
          onChange={onInputChange}
          onClick={onClick}
          onBlur={onChangeInput}
          type={type || 'string'}
        />
      )}
    </>
  );
};

export default InputBox as any;

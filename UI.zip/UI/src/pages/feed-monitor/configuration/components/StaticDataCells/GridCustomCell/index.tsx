import React, { useMemo } from 'react';
import { CellProps } from '@/components/Grid';

const tdProps = ({
  selectionChange,
  dataIndex,
  rowType,
  columnsCount,
  dataItem,
  render,
  columnIndex,
  ...rest
}: CellProps) => rest;

export type TransformTo = (dataItem: any, field: string, value: any) => string;

const GridCustomCell: React.FC<CellProps> | any = (props: CellProps) => {
  const { dataItem, field = '', extras = {} } = props;
  const { transformTo } = extras;
  const displayField: string = extras.displayField || field;
  const value = useMemo(
    () => displayField.split('.').reduce((acc, curr) => acc?.[curr], dataItem),
    [dataItem],
  );

  return (
    <td {...(tdProps(props) as any)}>
      {transformTo ? (transformTo(dataItem, field, value) as TransformTo) : value}
    </td>
  );
};

GridCustomCell.displayCustomCell = true;

export default GridCustomCell;

import React, { useMemo } from 'react';
import { CellProps } from '@/components/Grid';
import SimpleTD from '@/components/SimpleTD';
import InputBox from '../common/InputBox';

import styles from './index.less';

const GridTextboxCell: React.FC<CellProps> = (props) => {
  const { dataItem, field = '', className, onChange, extras } = props;
  const { typeOf, toStringOnCommit, mustBeUppercased, decimalPlaces, multiple } = extras || {};
  const value = useMemo(() => field.split('.').reduce((acc, curr) => acc?.[curr], dataItem), [
    dataItem,
  ]);

  const cell = (
    <SimpleTD
      {...props}
      key={field}
      tabIndex={-1}
      className={`${dataItem.inEdit === field && styles.gridTextboxCell} ${className}`}
    >
      {dataItem.inEdit === field ? (
        <>
          <InputBox
            value={value}
            onChange={onChange}
            field={field}
            dataItem={dataItem}
            type={typeOf || 'string'}
            toStringOnCommit={toStringOnCommit}
            decimalPlaces={decimalPlaces}
            mustBeUppercased={mustBeUppercased}
            multiple={multiple}
          />
          {Array.isArray(props.children) && props.children[1]}
        </>
      ) : (
        value
      )}
    </SimpleTD>
  );

  return cell;
};

export default GridTextboxCell as any;

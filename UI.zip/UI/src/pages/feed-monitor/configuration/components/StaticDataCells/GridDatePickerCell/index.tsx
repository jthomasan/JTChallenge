import React, { SyntheticEvent } from 'react';
import { GridCellProps } from '@progress/kendo-react-grid';
import { get } from 'lodash';
import { DatePicker } from 'antd';
import moment, { Moment } from 'moment';

import styles from './index.less';

interface GridDatePickerCellProps extends GridCellProps {
  extras: any;
}

const GridDatePickerCell: React.FC<GridDatePickerCellProps> = (props) => {
  const { dataItem, field = '', className, onChange, children, extras } = props;
  const { allowClear, datePickerType } = extras;
  const value = get(dataItem, field);

  const format = extras.format ?? 'YYYY-MM-DD';

  const onDatePickerValueChange = (date: Moment | null, dateString: string) => {
    let dateValue = date?.format(format);
    if (datePickerType && datePickerType === 'MonthPicker') {
      dateValue = date?.set('date', 1).format(format);
    }
    const data: any = {
      dataItem,
      field,
      syntheticEvent: {} as SyntheticEvent,
      value: dateString ? dateValue : '',
    };

    if (onChange) {
      onChange(data);
    }
  };

  const renderDatePicker = (type: string) => {
    if (type && type === 'MonthPicker') {
      return (
        <DatePicker.MonthPicker
          placeholder="Select Month"
          value={value ? moment(value) : null}
          onChange={onDatePickerValueChange}
        />
      );
    }
    return (
      <DatePicker
        allowClear={allowClear}
        showToday={false}
        value={value ? moment(value) : null}
        onChange={onDatePickerValueChange}
      />
    );
  };

  const cell = (
    <td
      key={field}
      tabIndex={-1}
      className={`${dataItem.inEdit === field && styles.gridDatePickerCell} ${className}`}
    >
      {dataItem.inEdit === field ? (
        <>
          {renderDatePicker(datePickerType)}
          {Array.isArray(children) && children[1]}
        </>
      ) : (
        value
      )}
    </td>
  );

  return cell;
};

export default GridDatePickerCell as any;

const GridBooleanCell: any = {};

GridBooleanCell.cellName = 'GridBooleanCell';

export default GridBooleanCell;

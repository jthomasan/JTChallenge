import React, {
  MutableRefObject,
  RefObject,
  SyntheticEvent,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useQuery, gql } from 'umi-plugin-apollo-anz/apolloClient';
import { get, mapValues, sortBy, cloneDeep } from 'lodash';
import { CellProps } from '@/components/Grid';
import ComboBox from '@/components/ComboBox';
import SimpleTD from '@/components/SimpleTD';

import { getSelectorQuery } from '../../../utils/normaliseMappings';
import { SelectorVariable } from '../../../mappings/staticDataSet';

import styles from './index.less';

interface OptionProps {
  id: string;
  text: string;
}

interface DropdownComponentProps extends CellProps {
  tdRef: RefObject<HTMLTableDataCellElement | undefined>;
  additionalProps: any;
}

const capitaliseSelector = (value: string): string =>
  value.charAt(0).toUpperCase() + value.slice(1);

const getMappedValues = (dataItem: any) => (mappedKey: string | SelectorVariable) => {
  const { path, valueFormatter } = mappedKey as SelectorVariable;
  const value = get(dataItem, path ?? mappedKey);

  if (valueFormatter) {
    return valueFormatter(value);
  }

  return value;
};

const DropdownComponent: React.FC<DropdownComponentProps> = (props) => {
  const { dataItem, field = '', extras = {}, tdRef, onChange, additionalProps = {} } = props;
  const [isDropDownOpen, setIsDropDownOpen] = useState(false);
  const {
    selectorVariables,
    setDefaultValue,
    selector,
    isOptional,
    transformTo,
    uniqueOptionsOnly,
  } = extras;

  const { loading, data } = useQuery(
    gql`
      ${getSelectorQuery(selector)}
    `,
    {
      skip: dataItem.inEdit !== field,
      variables: selectorVariables && mapValues(selectorVariables, getMappedValues(dataItem)),
      onCompleted: onCompletedFetch,
    },
  );

  const sortedOptions = useMemo(() => {
    if (!data) {
      return [];
    }

    return sortBy(data[capitaliseSelector(selector)], 'text');
  }, [data, selector]);

  const uniqueOptions: OptionProps[] = useMemo(() => {
    if (uniqueOptionsOnly && sortedOptions) {
      const datafieldValues = additionalProps?.fullData?.values();
      const selectedData = [...datafieldValues]?.map((c: any) => get(c, field));
      const selectedDataSet = new Set(selectedData);
      const value = get(dataItem, field);
      return sortedOptions.filter((c: any) => c.text === value || !selectedDataSet.has(c.text));
    }
    return sortedOptions;
  }, [additionalProps, field, dataItem, uniqueOptionsOnly, sortedOptions]);

  const options = useMemo(() => {
    // add blank option to dropwdown options if field is optional, and if a blank options doesn't already exist in list
    if (isOptional && !uniqueOptions.find((o) => o.text.trim() === '')) {
      const blankOption: any = uniqueOptions.length ? cloneDeep(uniqueOptions[0]) : {}; // use existing option as template as some options contain more than id/text

      Object.keys(blankOption).forEach((option) => {
        blankOption[option] = '';
      });

      uniqueOptions.unshift(blankOption);
    }

    return uniqueOptions;
  }, [isOptional, uniqueOptions]);

  const fieldName = get(dataItem, field.split(/\.(?=[^.]+$)/)[0]);

  const selectedItem = useMemo(
    () =>
      options.find(
        (o) =>
          fieldName?.id?.toString() === o?.id?.toString() ||
          fieldName?.toString() === o?.text?.toString(),
      ),
    [options, fieldName],
  );

  const timer = useRef(0 as any);
  const position: MutableRefObject<DOMRect | undefined> = useRef();

  const clearTimer = () => {
    if (timer.current) {
      clearInterval(timer.current);
    }
  };

  const onBlurSelector = () => {
    if (onChange) {
      onChange({
        dataItem,
        syntheticEvent: {} as SyntheticEvent,
        field,
        value: undefined,
      } as any);
    }
  };

  useEffect(() => {
    if (tdRef && tdRef.current) {
      if (isDropDownOpen) {
        position.current = tdRef.current.getBoundingClientRect();
        clearTimer();
        timer.current = setInterval(() => {
          if (tdRef && tdRef.current) {
            const currentPos = tdRef.current.getBoundingClientRect();

            if ((position.current || {}).x !== currentPos.x) {
              clearTimer();
              setIsDropDownOpen(false);
              onBlurSelector();
            }
          }
        }, 200);
      } else {
        clearTimer();
      }
    }
    return clearTimer;
  }, [isDropDownOpen]);

  const onChangeSelector = (event: any) => {
    if (!event.value) {
      return;
    }

    if (onChange) {
      onChange({
        dataItem,
        field,
        syntheticEvent: event.syntheticEvent,
        value: transformTo ? transformTo(event.value) : event.value,
      } as any);
    }
  };

  function onCompletedFetch(list: any[]) {
    if (setDefaultValue && !selectedItem) {
      const [value] = list[capitaliseSelector(selector)];
      onChangeSelector({ value });
    }
  }

  return !loading ? (
    <div className={styles.gridDropdownSelector}>
      <ComboBox
        data={options}
        disabled={options.length === 0}
        dataItemKey="id"
        textField="text"
        value={selectedItem}
        clearButton={false}
        opened={isDropDownOpen}
        popupSettings={{
          animate: false,
          height: '250px',
          className: styles.gridDropdownMenu,
        }}
        onFocus={() => setIsDropDownOpen(true)}
        onOpen={() => setIsDropDownOpen(true)}
        onClose={() => setIsDropDownOpen(false)}
        onChange={onChangeSelector}
        onBlur={onBlurSelector}
      />
    </div>
  ) : (
    <div className={styles.gridDropdownLoading}>Loading...</div>
  );
};

const GridDropdownCell: React.FC<CellProps> = (props) => {
  const { dataItem, field = '', className } = props;
  const value = get(dataItem, field);
  const tdRef = useRef<HTMLTableDataCellElement>();

  // hack to get around dropdown requiring clicking twice on validation error
  useEffect(() => {
    if (dataItem.inEdit === field && tdRef.current) {
      tdRef.current.click();
    }
  }, [tdRef.current, dataItem.inEdit]);

  const cell = (
    <SimpleTD
      {...props}
      key={field}
      ref={tdRef as RefObject<HTMLTableDataCellElement>}
      tabIndex={-1}
      className={`${dataItem.inEdit === field && styles.gridDropdownCell} ${className}`}
    >
      {dataItem.inEdit === field ? (
        <>
          <DropdownComponent tdRef={tdRef} {...props} />
          {Array.isArray(props.children) && props.children[1]}
        </>
      ) : (
        value
      )}
    </SimpleTD>
  );

  return cell;
};

export default GridDropdownCell;

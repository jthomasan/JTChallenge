import { CellProps } from '@/components/Grid';
import SimpleTD from '@/components/SimpleTD';
import React, { useMemo, SyntheticEvent } from 'react';
import styles from './index.less';

interface GridCheckboxCellProps extends CellProps {
  children?: any[];
}

const GridCheckboxCell: React.FC<GridCheckboxCellProps> | any = (props: GridCheckboxCellProps) => {
  const { dataItem, field = '', className, onChange } = props;

  const isChecked = useMemo(() => field.split('.').reduce((acc, curr) => acc?.[curr], dataItem), [
    dataItem,
  ]) as boolean;

  const { inEdit } = dataItem;
  const isValueBoolean = typeof isChecked === 'boolean';
  const isEditing = inEdit === field;

  const setValue = (checked: boolean, event: SyntheticEvent | null = null) => {
    if (onChange) {
      let updatedData: any = '';
      const fieldArr = field.split('.');
      if (fieldArr.length > 1) {
        updatedData = { [fieldArr[fieldArr.length - 1]]: checked };
      } else {
        updatedData = checked;
      }
      const data: any = {
        dataItem,
        field,
        syntheticEvent: event,
        value: updatedData,
      };

      onChange(data);
    }
  };

  const onChangeInput = (event: SyntheticEvent) => {
    event.persist();
    const { checked } = event.target as HTMLInputElement;

    setValue(checked, event);
  };

  // set the value to false on blur if the value was null to begin with
  const onBlur = (event: SyntheticEvent) => {
    if (!isValueBoolean && isEditing) {
      setValue(false, event);
    }
  };
  const cell = (
    <SimpleTD
      {...props}
      tabIndex={-1}
      className={`${styles.gridCheckboxCell} ${className}`}
      onBlur={onBlur}
    >
      <div>
        {isValueBoolean || isEditing ? (
          <>
            <input
              type="checkbox"
              checked={!!isChecked}
              onChange={onChangeInput}
              disabled={dataItem.inEdit !== field}
            />
            {Array.isArray(props.children) && props.children[1]}
          </>
        ) : (
          ''
        )}
      </div>
    </SimpleTD>
  );

  return cell;
};

GridCheckboxCell.cellName = 'GridCheckboxCell';

export default GridCheckboxCell;

import React, { useMemo } from 'react';
import { Tooltip } from '@progress/kendo-react-tooltip';
import { CellProps } from '@/components/Grid';
import SimpleTD from '@/components/SimpleTD';
import InputBox from '../common/InputBox';

import styles from './index.less';

const GridTooltipTextBoxCell: any = (props: CellProps) => {
  const { dataItem, field = '', className, onChange, extras } = props;
  const { typeOf, toStringOnCommit, mustBeUppercased, decimalPlaces, multiple } = extras || {};
  const value = useMemo(() => field.split('.').reduce((acc, curr) => acc?.[curr], dataItem), [
    dataItem,
  ]);
  const toolTipContent = useMemo(() => {
    return (
      <div className={styles.toolTipCustom}>
        {dataItem ? (
          <p key={`${dataItem?.id}-${field}`} className={styles.toolTipCustom}>
            {dataItem[field]}
          </p>
        ) : (
          ''
        )}
      </div>
    );
  }, [dataItem, field]);

  const cell = (
    <SimpleTD
      {...props}
      key={field}
      tabIndex={-1}
      className={`${dataItem.inEdit === field && styles.gridTextboxCell} ${className}`}
    >
      {dataItem.inEdit === field ? (
        <>
          <InputBox
            value={value}
            onChange={onChange}
            field={field}
            dataItem={dataItem}
            type={typeOf || 'string'}
            toStringOnCommit={toStringOnCommit}
            decimalPlaces={decimalPlaces}
            mustBeUppercased={mustBeUppercased}
            multiple={multiple}
          />
          {Array.isArray(props.children) && props.children[1]}
        </>
      ) : (
        <Tooltip content={() => toolTipContent} anchorElement="target">
          <div title="title" className={styles.toolTipParent}>
            {value}
          </div>
        </Tooltip>
      )}
    </SimpleTD>
  );

  return cell;
};

GridTooltipTextBoxCell.displayCustomCell = true;

export default GridTooltipTextBoxCell as any;

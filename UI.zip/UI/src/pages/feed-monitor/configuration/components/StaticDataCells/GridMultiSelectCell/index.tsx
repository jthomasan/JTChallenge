/* eslint-disable react/no-array-index-key */
import React, { useRef, useState, SyntheticEvent, useEffect } from 'react';
import { gql, useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import { get, mapValues } from 'lodash';
import { Popup } from '@progress/kendo-react-popup';
import { CellProps } from '@/components/Grid';
import SimpleTD from '@/components/SimpleTD';

import MultiSelectPopup, {
  MultiSelectPopupProps,
  OptionProp,
} from '@/components/MultiSelect/MultiSelectPopup';

import { SelectorVariable } from '../../../mappings/staticDataSet';

import { getSelectorQuery, capitaliseSelector } from '../../../utils/normaliseMappings';

function MultiSelectPopupWrapped<T extends OptionProp>({
  onBlur,
  anchor,
  hideHeaderTitle,
  headers,
  options,
  isChipEnabled,
  showCellOnMultiSelectCell,
  enableMultiSelect,
  defaultValue,
  showSearch,
  isOptional = false,
}: {
  defaultValue?: T[];
  anchor?: HTMLTableDataCellElement;
  onBlur: (values: T[]) => void;
  selector: null;
} & Omit<MultiSelectPopupProps<T>, 'onBlur' | 'value' | 'onChange'>) {
  const [selectedItems, setSelectedItems] = useState<T[]>(defaultValue ?? []);

  const onClose = () => {
    onBlur(selectedItems);
  };

  return (
    <Popup anchor={anchor} animate={false} show onClose={onClose}>
      <MultiSelectPopup<T>
        onChange={(value) => {
          setSelectedItems(value);
        }}
        onBlur={onClose}
        value={selectedItems}
        hideHeaderTitle={hideHeaderTitle}
        headers={headers}
        options={options}
        isChipEnabled={isChipEnabled}
        enableMultiSelect={enableMultiSelect}
        showCellOnMultiSelectCell={showCellOnMultiSelectCell}
        showSearch={showSearch}
        isOptional={isOptional}
      />
    </Popup>
  );
}

/**
 * Only calls setState when enabled, but will call setState when enabled is toggled on,
 * with the current value
 * helps reduce the number of unnecessary renders while still ensuring downstream users
 * of the ref are re-rendered
 * when the ref changes value
 * @param startValue
 * @param enabled
 */
function useToggledStatefulRef<T>(
  startValue: T,
  enabled: boolean,
): [T | undefined, React.Dispatch<T | undefined>] {
  const [value, setValue] = useState<T | undefined>(startValue);
  const ref = useRef<T>();

  useEffect(() => {
    if (enabled) {
      setValue(ref.current);
    }
  }, [enabled]);

  return [
    value,
    (newValue: T | undefined) => {
      ref.current = newValue;
    },
  ];
}

const getMappedValues = (dataItem: any) => (mappedKey: string | SelectorVariable) => {
  const { path, valueFormatter } = mappedKey as SelectorVariable;
  const value = get(dataItem, path ?? mappedKey);

  if (valueFormatter) {
    return valueFormatter(value);
  }

  return value;
};

interface ShowCellWhenValueIs {
  path: string;
  value: string;
}

const validateWhetherShowCellsOnMultiSelectCell = (
  showCellWhenValueIs: ShowCellWhenValueIs,
  dataItem: any,
): boolean => {
  if (!showCellWhenValueIs) {
    return false;
  }

  const { path, value } = showCellWhenValueIs;
  const dataFromDataItem = get(dataItem, path);

  return dataFromDataItem.toString() === value;
};

const GridMultiSelectCell: React.FC<CellProps> | any = ({
  children,
  dataItem,
  field = '',
  extras = {},
  onChange,
  ...props
}: CellProps) => {
  const {
    displayRenderer,
    valueFormatter,
    hideHeaderTitle,
    headers = [],
    selector,
    selectorVariables,
    transformTo,
    enableMultiSelect,
    showCellWhenValueIs,
    isOptional,
  } = extras;
  const optionsCached = useRef([]);

  let value = '';

  if (displayRenderer) {
    value = displayRenderer(dataItem[field]);
  } else {
    value = get(dataItem, field);
  }

  const { loading, data } = useQuery(
    gql`
      ${getSelectorQuery(selector)}
    `,
    {
      skip: dataItem.inEdit !== field,
      variables: selectorVariables && mapValues(selectorVariables, getMappedValues(dataItem)),
    },
  );

  optionsCached.current = (data && data[capitaliseSelector(selector)]) || [];

  const { inEdit } = dataItem;
  const isEditing = inEdit === field;
  const [tdEl, setTdEl] = useToggledStatefulRef<HTMLTableDataCellElement | null>(null, isEditing);

  const onBlur = (event: any[]) => {
    const newValue = enableMultiSelect ? event : event[0] || { id: '', text: '' };

    if (onChange) {
      onChange({
        dataItem,
        syntheticEvent: {} as SyntheticEvent,
        field,
        value: transformTo ? transformTo(newValue) : newValue,
      } as any);
    }
  };

  let selectedItems = dataItem[field];

  if (!enableMultiSelect) {
    let currentValue = get(dataItem, field);
    if (valueFormatter) {
      currentValue = valueFormatter(currentValue);
    }

    const selectedItem = optionsCached.current.find((item: any) => item.text === currentValue);

    selectedItems = selectedItem ? [selectedItem] : [];
  }

  const showCellOnMultiSelectCell =
    isEditing && validateWhetherShowCellsOnMultiSelectCell(showCellWhenValueIs, dataItem);

  const cell = (
    <SimpleTD {...props} ref={setTdEl} key={field} tabIndex={-1}>
      {loading ? (
        'Loading...'
      ) : (
        <>
          {value}
          {isEditing && (
            <>
              <MultiSelectPopupWrapped
                {...props}
                anchor={tdEl ?? undefined}
                hideHeaderTitle={hideHeaderTitle}
                headers={headers}
                defaultValue={selectedItems}
                options={optionsCached.current}
                selector={selector}
                isChipEnabled={extras?.isChipEnabled}
                enableMultiSelect={enableMultiSelect}
                showCellOnMultiSelectCell={showCellOnMultiSelectCell}
                onBlur={onBlur}
                showSearch
                isOptional={isOptional}
              />
              {Array.isArray(children) && children[1]}
            </>
          )}
        </>
      )}
    </SimpleTD>
  );

  return cell;
};

GridMultiSelectCell.displayCustomCell = true;

export default GridMultiSelectCell;

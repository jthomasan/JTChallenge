import React, { useMemo } from 'react';

import { CellProps } from '@/components/Grid';

import styles from './index.less';

const GridMultiLineCell: React.FC<CellProps> | any = (props: CellProps) => {
  const { dataItem, field = '', extras = {} } = props;
  const displayField: string = extras.displayField || field;
  const value = useMemo(
    () => displayField.split('.').reduce((acc, curr) => acc?.[curr], dataItem),
    [dataItem, displayField],
  );

  return <td className={styles.multiLineCell}>{value}</td>;
};

GridMultiLineCell.displayCustomCell = true;

export default GridMultiLineCell;

import React, { useMemo, useCallback, SyntheticEvent } from 'react';
import { keyBy, isEmpty } from 'lodash';
import { useQuery, gql } from 'umi-plugin-apollo-anz/apolloClient';
import { TreeSelect } from 'antd';
import SimpleTD from '@/components/SimpleTD';
import { CellProps } from '@/components/Grid';
import { getSelectorQuery, getSelectorTitle } from '../../../utils/normaliseMappings';

import styles from './index.less';

interface Node {
  id: string;
  title: string;
  fullPath: string;
  parent: string;
  children: string[];
}

const capitaliseSelector = (value: string): string =>
  value.charAt(0).toUpperCase() + value.slice(1);

const GridTreeSelectCell: React.FC<CellProps> = (props) => {
  const { dataItem, field = '', extras = {}, onChange, className } = props;
  const [referrer, prop] = field.split('.');
  const selectedId: string = dataItem[referrer]?.id ?? '';
  const value = dataItem[referrer]?.[prop] ?? '';
  const { loading, data } = useQuery(
    gql`
      ${getSelectorQuery(extras?.selector)}
    `,
    {
      skip: dataItem.inEdit !== field,
    },
  );

  const nodeFormat = useCallback(
    (item: Node) => ({
      id: item.id,
      value: `${item.title} ${item.id}`,
      title: item.title,
      fullPath: item.fullPath,
      children: item.children,
    }),
    [data, extras?.selector],
  );

  let parentNode = {} as Node;
  let selectedValue: string = '';
  const expandedKeys: string[] = [];

  const treeObj = useMemo(
    () =>
      keyBy(data?.[capitaliseSelector(extras?.selector)] || [], (item) => {
        if (item.parent === '') {
          parentNode = item;
        }

        if (item.title === value) {
          selectedValue = `${item.title} ${item.id}`;
        }

        return item.id;
      }),
    [data, extras?.selector],
  );

  const createNodeTree = useCallback(
    (node: Node): any => {
      if (node.children.length === 0) {
        return nodeFormat(node);
      }

      const depth = node.children.reduce(
        (acc, curr): any => [...acc, createNodeTree(treeObj[curr])],
        [],
      );

      return nodeFormat({ ...node, children: [...depth] });
    },
    [data, extras?.selector],
  );

  const treeData = useMemo(() => (!isEmpty(parentNode) && [createNodeTree(parentNode)]) || [], [
    data,
    extras?.selector,
  ]);

  const getParentDepth = useCallback(
    (node: Node): any => {
      if (!node) {
        return null;
      }

      if (node) {
        expandedKeys.push(`${node.title} ${node.id}`);
      }

      return getParentDepth(treeObj[node.parent]);
    },
    [data, extras?.selector],
  );

  const [cachedSelectedValue, cachedExpandedKeys] = useMemo(() => {
    if (expandedKeys.length === 0 && !isEmpty(treeObj[selectedId])) {
      getParentDepth(treeObj[selectedId]);
    }
    return [selectedValue, expandedKeys];
  }, [data, extras?.selector]);

  const onChangeSelector = (event: string, label: any, { triggerNode }: any) => {
    const { id, title, fullPath } = triggerNode.props;

    if (onChange) {
      const savingData: any = {
        id,
        value: title,
      };

      if (extras?.fullPath) {
        savingData.fullPath = fullPath;
      }

      onChange({
        dataItem,
        field,
        syntheticEvent: {} as SyntheticEvent,
        value: savingData,
      } as any);
    }
  };

  const treeSelectElement = !loading ? (
    <div className={styles.gridTreeSelect}>
      <TreeSelect
        showSearch
        style={{ width: '100%' }}
        treeData={treeData}
        disabled={loading}
        placeholder={!loading ? `Select ${getSelectorTitle(extras?.selector)}` : 'Loading...'}
        value={cachedSelectedValue}
        dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
        treeDataSimpleMode
        treeDefaultExpandedKeys={cachedExpandedKeys}
        dropdownClassName={styles.gridDropdownMenu}
        onChange={onChangeSelector}
      />
    </div>
  ) : (
    'Loading...'
  );

  const cell = (
    <SimpleTD
      {...props}
      tabIndex={-1}
      className={`${dataItem.inEdit === field && styles.gridTreeSelectCell} ${loading &&
        styles.gridTreeSelectLoading} ${className}`}
    >
      {dataItem.inEdit === field ? (
        <>
          {treeSelectElement} {Array.isArray(props.children) && props.children[1]}
        </>
      ) : (
        value
      )}
    </SimpleTD>
  );

  return cell;
};

export default GridTreeSelectCell;

import React, { useMemo } from 'react';
import uuid from 'uuid-random';
import { GridCellProps } from '@progress/kendo-react-grid';
import { Button } from 'antd';
import Modal from '@/components/Modal';
import Grid from '@/components/Grid';
import { ChangeAction } from '@/types/change';
import {
  isObject,
  getColumnFieldTitle,
  getColumnDisplayRenderer,
} from '../../utils/normaliseMappings';

import styles from './index.less';

interface StaticDataBulkUpdateProps {
  showBulkUpdateSummary: boolean;
  staticDataTypeId: string;
  data?: any[];
  setShowBulkUpdateSummary: (show: boolean) => void;
}

const StaticDataBulkUpdate: React.FC<StaticDataBulkUpdateProps> = (props) => {
  const { showBulkUpdateSummary, staticDataTypeId, data = [], setShowBulkUpdateSummary } = props;

  const gridActionCell = ({ dataItem }: GridCellProps) => {
    const { field = '' } = dataItem;
    const [, prop] = field.split('.');

    if (dataItem.changeAction === ChangeAction.ADD) {
      return (
        <td>
          [New Record]{' '}
          {!dataItem.isChangeValid && (
            <span>[{getColumnFieldTitle(staticDataTypeId, dataItem.field)}]</span>
          )}
        </td>
      );
    }

    let value = isObject(dataItem.value) ? dataItem.value[prop] : dataItem.value;

    if (getColumnDisplayRenderer(staticDataTypeId, dataItem.field)) {
      value = getColumnDisplayRenderer(staticDataTypeId, dataItem.field)(value);
    }

    return (
      <td>
        [{getColumnFieldTitle(staticDataTypeId, dataItem.field)}] {value?.toString()}
      </td>
    );
  };

  gridActionCell.displayCustomCell = true;

  const gridResultCell = ({ dataItem }: GridCellProps) => (
    <td className={dataItem.isChangeValid ? styles.successMessage : styles.errorMessage}>
      <span
        className={`k-icon ${dataItem.isChangeValid ? 'k-i-checkmark-outline' : 'k-i-error'}`}
      />
      <span style={{ marginLeft: '5px' }}>
        {dataItem.isChangeValid ? 'valid' : dataItem.reason}
      </span>
    </td>
  );

  gridResultCell.displayCustomCell = true;

  const succeededUpdates = useMemo(() => data.filter((item) => item.isChangeValid).length, [data]);
  const failedUpdates = useMemo(() => data.filter((item) => !item.isChangeValid).length, [data]);

  const onClose = () => {
    setShowBulkUpdateSummary(false);
  };

  const gridData = data.map((item) => ({ ...item, id: `${item.id}-${uuid()}` }));

  return (
    <Modal
      visible={showBulkUpdateSummary}
      title="Bulk Update Summary"
      className={styles.modal}
      width={875}
      footer={
        <Button type="primary" onClick={onClose}>
          OK
        </Button>
      }
      onCancel={onClose}
    >
      <div>
        <div className={styles.result}>
          {succeededUpdates > 0 && (
            <span className={styles.resultWrapper}>
              <span className={`k-icon k-i-checkmark-outline ${styles.successResult}`} />
              <span className={styles.successResult}>
                {succeededUpdates} valid field(s) found and added to the uncommitted changes.
              </span>
            </span>
          )}
          {failedUpdates > 0 && (
            <span className={styles.resultWrapper}>
              <span className={`k-icon k-i-error ${styles.errorResult}`} />
              <span className={styles.errorResult}>{failedUpdates} invalid field(s) found.</span>
            </span>
          )}
        </div>

        <Grid
          loading={false}
          data={gridData}
          columns={[
            {
              field: 'name',
              title: 'Name',
              filter: 'text',
              width: '200px',
              defaultSortColumn: true,
            },
            {
              field: 'changeAction',
              title: 'Action',
              filter: 'text',
              width: '245px',
              cell: gridActionCell,
            },
            {
              field: 'reason',
              title: 'Result',
              filter: 'text',
              width: '365px',
              cell: gridResultCell,
            },
          ]}
          style={{ height: '285px' }}
          currentStateWatcher="result"
          showColumnVisibility
          useStandardCellsUnlessEditing
        />
      </div>
    </Modal>
  );
};

export default StaticDataBulkUpdate;

import React, { useRef, useCallback, SyntheticEvent, useEffect, useMemo } from 'react';

import { Select as AntSelect, Row, Col, Button } from 'antd';
import { sortBy } from 'lodash';

import ExportButton from '@/components/ExportButton';
import Select from '@/components/Select';

import { staticDataCategory } from '../../mappings/staticData';
import {
  getStaticDataAdditionalParams,
  getStaticDataExportUrl,
} from '../../utils/normaliseMappings';

import { ReconTypeOptions, ReconTypeOptionNames } from '../../mappings/staticDataSet';

import styles from './index.less';

const { Option } = AntSelect;

interface StaticDataSearchProps {
  category: string;
  staticDataTypeId: string;
  additionalParams: any;
  isDataLoading: boolean;
  onSelectCategory: (name: string) => void;
  onSelectStaticDataTypeId: (type: string) => void;
  onSelectAdditionalParams: (param: any) => void;
  onSelectRefreshData: () => void;
  onAddNew: () => void;
  canAddNew: boolean;
  canBulkUpdate: boolean;
  onFileUpload: (event: SyntheticEvent) => void;
  onExportCsv: () => void;
}

const StaticDataSearch: React.FC<StaticDataSearchProps> = (props) => {
  const {
    category,
    staticDataTypeId,
    additionalParams,
    isDataLoading,
    onSelectStaticDataTypeId,
    onSelectAdditionalParams,
    onSelectRefreshData,
    onAddNew,
    canAddNew,
    canBulkUpdate,
    onExportCsv,
    onFileUpload,
  } = props;
  const types = staticDataCategory.find((item) => item.name === category)?.list || [];
  const staticDataType = types.find((item) => item.id === staticDataTypeId)?.name || null;
  const paramList = getStaticDataAdditionalParams(category, staticDataTypeId);

  const fileUpload = useRef({} as any);

  const onSelectStaticDataType = (name: string, option: React.ReactElement<any>) => {
    onSelectStaticDataTypeId(option.key?.toString() || '');
  };

  const onAddNewClick = useCallback(() => {
    onAddNew();
  }, [onAddNew]);

  const onOpenFileUpload = () => {
    fileUpload.current.click();
  };

  const onSelectReconType = useCallback(
    (reconType: string) => {
      onSelectAdditionalParams({ reconType });
    },
    [onSelectAdditionalParams],
  );

  const disableActionButtons = !staticDataType || isDataLoading;

  const reconType = additionalParams.reconType || ReconTypeOptions.DailyTradeReconciliation;

  const typeList = useMemo(() => sortBy(types, 'name'), [types]);

  useEffect(() => {
    if (reconType && paramList.includes('reconType')) {
      onSelectReconType(reconType);
    }
  }, [staticDataTypeId, reconType, paramList, onSelectReconType]);

  return (
    <div className={styles.staticDataSearchWrapper}>
      <Row>
        <Col span={5}>
          <Select
            showSearch
            value={staticDataType || undefined}
            placeholder="Select Category"
            onSelect={onSelectStaticDataType}
            disabled={typeList.length === 0}
          >
            {typeList.map((item) => (
              <Option key={item.id} value={item.name}>
                {item.name}
              </Option>
            ))}
          </Select>
        </Col>
        <Col span={4}>
          {paramList.includes('reconType') && (
            <Select value={reconType} onSelect={onSelectReconType}>
              {Object.keys(ReconTypeOptions).map((key) => (
                <Option key={ReconTypeOptions[key]} value={ReconTypeOptions[key]}>
                  {ReconTypeOptionNames[ReconTypeOptions[key]]}
                </Option>
              ))}
            </Select>
          )}
        </Col>
        <Col span={3} />

        <Col span={12} style={{ textAlign: 'right', paddingRight: 0 }}>
          <Button type="default" disabled={disableActionButtons} onClick={onSelectRefreshData}>
            Refresh
          </Button>
          <ExportButton
            icon={undefined}
            onExport={onExportCsv}
            url={
              staticDataTypeId
                ? getStaticDataExportUrl(staticDataTypeId, additionalParams)
                : undefined
            }
            disabled={
              disableActionButtons || !getStaticDataExportUrl(staticDataTypeId, additionalParams)
            }
          >
            Export
          </ExportButton>

          <input
            ref={fileUpload}
            type="file"
            accept=".csv"
            value=""
            onChange={onFileUpload}
            hidden
          />
          {canBulkUpdate && (
            <Button type="default" onClick={onOpenFileUpload} disabled={disableActionButtons}>
              Bulk Update
            </Button>
          )}

          {canAddNew && (
            <Button type="default" disabled={disableActionButtons} onClick={onAddNewClick}>
              Add New
            </Button>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default StaticDataSearch;

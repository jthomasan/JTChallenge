import React from 'react';
import classNames from 'classnames';
import { CellProps } from '@/components/Grid';

import styles from './index.less';
import { hierarchyAuditMapDefaultGroup } from '..';

interface AuditHistoryCell extends CellProps {
  auditHistoryData: any[];
}

const AuditHistoryCell: React.FC<AuditHistoryCell> = (props) => {
  const { dataItem, field = '', dataIndex, auditHistoryData } = props;

  const isHighlighted =
    auditHistoryData.length - 1 > dataIndex &&
    dataItem[field] !== auditHistoryData[dataIndex + 1][field] &&
    dataItem[hierarchyAuditMapDefaultGroup] ===
      auditHistoryData[dataIndex + 1][hierarchyAuditMapDefaultGroup];

  const cell = (
    <td
      className={classNames({
        [styles.diffHighlight]: isHighlighted,
      })}
    >
      {dataItem[field]}
    </td>
  );

  return cell;
};

export default AuditHistoryCell;

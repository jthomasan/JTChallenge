import React, { useMemo } from 'react';
import Window from '@/components/Window';
import { gql } from 'umi-plugin-apollo-anz/apolloClient';
import useQuery from '@/hooks/useQueryExtended';

import Grid, { GridExternalState } from '@/components/Grid';
import { useMergedState } from '@/hooks/useMergedState';
import { DATE_FORMATS } from '@/utils/date';
import { Button } from 'antd';
import { groupByWithOrder } from '@/utils/dataUtils';
import ErrorBoundary from '@/error/ErrorBoundary';
import AuditHistoryCell from './AuditHistoryCell';

import styles from './index.less';
import GridBooleanCell from '../StaticDataCells/GridBooleanCell';
import GridCheckboxCell from '../StaticDataCells/GridCheckboxCell';
import { getStaticDatasetExportName } from '../../utils/normaliseMappings';

export interface AuditHistoryProps {
  auditId: string;
  configTypeId: string;
  auditHistoryAdditionalParams?: any;
  onAuditHistoryDismiss: () => void;
  isHierarchyMapAudit?: boolean;
}

export const hierarchyAuditMapDefaultGroup = 'HierarchyType';

const AuditHistory: React.FC<AuditHistoryProps> = (props: AuditHistoryProps) => {
  const { auditId, configTypeId, isHierarchyMapAudit } = props;

  const { loading, data } = useQuery(
    gql`
      query getFMConfigAuditHistory($configTypeId: ID!, $auditId: ID!) {
        FMConfigAuditHistory(configTypeId: $configTypeId, auditId: $auditId) {
          columns {
            field
            title
            type
          }
          rows
        }
      }
    `,
    {
      variables: { auditId, configTypeId },
      notifyOnNetworkStatusChange: true,
    },
  );
  const currentStateWatcher = `${configTypeId}-${auditId}-${loading}`;
  const [externalState, setExternalState] = useMergedState({
    gridStateTracker: `${configTypeId}-${auditId}-true`,
  } as GridExternalState);

  const auditHistory = data?.FMConfigAuditHistory || null;

  const processedAuditHistoryData = useMemo(() => {
    let processedData = [];
    if (auditHistory) {
      processedData = externalState.groupColumns
        ? groupByWithOrder(auditHistory.rows, externalState.groupColumns)
        : auditHistory.rows;
    }
    // flattern the data if it is grouped or just return data
    return processedData[0]?.aggregates
      ? processedData.reduce(
          (fList: any[], group: any) =>
            fList.concat(group.items.reduce((acc: any[], cur: any) => acc.concat(cur), [])),
          [],
        )
      : processedData;
  }, [auditHistory, externalState.groupColumns]);

  const columnsWithCustomCells = useMemo(
    () =>
      auditHistory?.columns.map((c: { field: string; title: string; type: string }) => {
        let cell: any;

        if (c.field && c.field.toLowerCase() === 'isactive') {
          cell = GridBooleanCell;
        } else if (c.type === 'boolean') {
          cell = GridCheckboxCell;
        } else if (c.type === 'date') {
          cell = undefined;
        } else {
          cell = (cellProps: any) => (
            <AuditHistoryCell {...cellProps} auditHistoryData={processedAuditHistoryData} />
          );

          cell.displayCustomCell = true;
        }

        let column = {
          ...c,
          format: c.type === 'date' ? DATE_FORMATS.DATE_TIME : '',
          filter: c.type === 'date' ? 'date' : 'text',
          width: c.field.toLowerCase() === 'isactive' ? '90px' : '150px',
          sortDisabled: true,
          cell,
          extras: { typeOf: c.type },
        };
        if (c.type === 'date') {
          column = { ...column, ...{ format: DATE_FORMATS.DATE_TIME } };
        }

        // default group on HierarchyType
        if (c.field === hierarchyAuditMapDefaultGroup) {
          column = { ...column, ...{ defaultGroupColumn: true } };
        }
        return column;
      }) || [],
    [auditHistory, processedAuditHistoryData],
  );
  const rows = auditHistory?.rows || [];

  const onExportAuditHistory = () => {
    window.location.href = `/export/feed-monitor/configuration/audit-history/csv?configTypeId=${configTypeId}&auditId=${auditId}&datasetName=${getStaticDatasetExportName(
      configTypeId,
    )}`;
  };

  return (
    <div className={styles.auditHistory}>
      <div className={styles.auditHistoryToolbar}>
        <Button type="default" disabled={rows.length === 0} onClick={onExportAuditHistory}>
          Export
        </Button>
      </div>
      <div className={styles.auditHistoryGrid}>
        <Grid
          data={rows}
          style={{ height: '100%' }}
          loading={loading}
          columns={columnsWithCustomCells}
          columnVirtualization={false}
          currentStateWatcher={currentStateWatcher}
          dataRefreshWatcher="0"
          externalState={externalState}
          setExternalState={setExternalState}
          groupOptions={{ fixedGroupColumns: [hierarchyAuditMapDefaultGroup] }}
          groupable={isHierarchyMapAudit}
          useStandardCellsUnlessEditing
        />
      </div>
    </div>
  );
};

const AuditHistoryWindow: React.FC<AuditHistoryProps> = (props: AuditHistoryProps) => {
  const { onAuditHistoryDismiss } = props;
  return (
    <Window
      title="Audit History"
      initialHeight={500}
      initialWidth={700}
      onClose={onAuditHistoryDismiss}
    >
      <ErrorBoundary errorTitle="Error Loading Audit History">
        <AuditHistory {...props} />
      </ErrorBoundary>
    </Window>
  );
};

export default AuditHistoryWindow;

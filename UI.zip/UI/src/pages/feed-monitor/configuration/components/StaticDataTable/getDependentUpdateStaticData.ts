import { get } from 'lodash';
import { DepGraph } from 'dependency-graph';

import { StaticDataFieldChangeEvent } from '.';
import { StaticDataColumn } from '../../mappings/staticDataSet';
import { getDependenciesFromColumn } from '../../utils/normaliseMappings';

export interface UseDependentUpdateStaticDataParams {
  updateStaticData: (event: StaticDataFieldChangeEvent) => Promise<void>;
  columns: StaticDataColumn[];
  includeParents?: boolean;
}

export const getDotPathRoot = (dotPath: string): string => {
  const i = dotPath.indexOf('.');
  return i >= 0 ? dotPath.substr(0, i) : dotPath;
};

type StaticDataColumnWithField = Omit<StaticDataColumn, 'field'> &
  Required<Pick<StaticDataColumn, 'field'>>;

export const getDependentsFromColumns = (
  columns: StaticDataColumn[],
  includeParents: boolean,
): Record<string, string[]> => {
  const graph = new DepGraph();
  const fieldColumns = columns.filter((column) => !!column.field) as StaticDataColumnWithField[];
  const fields = new Set<string>();

  // Add all fields (and their root) to graph
  fieldColumns.forEach((column) => {
    fields.add(column.field);

    const fieldName = includeParents ? getDotPathRoot(column.field) : column.field;
    graph.addNode(fieldName);

    if (includeParents && column.field !== fieldName) {
      graph.addNode(column.field);
      // Add a dependency from the root to the child field
      graph.addDependency(fieldName, column.field);
    }
  });

  // Add any defined dependencies to the graph
  fieldColumns.forEach((column) => {
    getDependenciesFromColumn(column).forEach((dependency) =>
      graph.addDependency(column.field, includeParents ? getDotPathRoot(dependency) : dependency),
    );
  });

  // Build a map of actual fields -> fields that depend on that field's value
  const dependentMap = {};
  fieldColumns.forEach((column) => {
    dependentMap[column.field] = graph.dependantsOf(
      includeParents ? getDotPathRoot(column.field) : column.field,
    );

    if (includeParents) {
      dependentMap[column.field] = dependentMap[column.field].filter(fields.has.bind(fields));
    }
  });
  return dependentMap;
};

export const getDependentUpdateStaticData = ({
  updateStaticData,
  columns,
  includeParents = true,
}: UseDependentUpdateStaticDataParams) => {
  const dependentMap = getDependentsFromColumns(columns, includeParents);
  const dependentUpdateStaticData = async (event: StaticDataFieldChangeEvent) => {
    await updateStaticData(event);

    if (event.field && dependentMap[event.field]) {
      const promises: Promise<void>[] = [];
      dependentMap[event.field].forEach((dependent) => {
        if (typeof get(event.dataItem, dependent) !== 'undefined') {
          promises.push(
            updateStaticData({
              ...event,
              field: dependent,
              value: undefined,
              undoNext: true,
            }),
          );
        }
      });

      await Promise.all(promises);
    }
  };

  return [dependentUpdateStaticData];
};

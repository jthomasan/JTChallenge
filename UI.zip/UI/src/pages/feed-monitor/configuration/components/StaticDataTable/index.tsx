/* eslint-disable no-param-reassign */
import React, { useMemo, useState, useEffect, useCallback, useRef } from 'react';
import { some, isEqual, isEmpty } from 'lodash';
import uuid from 'uuid-random';
import { gql, useApolloClient, ApolloClient } from 'umi-plugin-apollo-anz/apolloClient';
import useRefreshNotification from '@/hooks/useRefreshNotification';
import usePrevious from '@/hooks/usePrevious';
import Grid, { GridExternalState } from '@/components/Grid';
import { SortDescriptor } from '@progress/kendo-data-query';
import { ChangeError } from '@/types/change';
import { CTXMenuSelectEvent } from '@/components/ContextMenu';
import { ExternalisedStateProps } from '@/types/externalised-state';
import { QueryError } from '@/error/types';
import useAsyncError from '@/hooks/useAsyncError';
import {
  getStaticDataColumns,
  getStaticDataQuery,
  getStaticDataQueryName,
  getStaticDataAdditionalParams,
} from '../../utils/normaliseMappings';
import { StaticDataAccessors } from '../../index';

import styles from './index.less';
import { getDependentUpdateStaticData } from './getDependentUpdateStaticData';

interface StaticDataTableProps<K> extends ExternalisedStateProps<K> {
  category: string;
  staticDataTypeId: string;
  additionalParams: any;
  showIndicator: boolean;
  updateStaticDataStatus: (loading: boolean, accessors: StaticDataAccessors) => void;
  updateStaticData: (event: StaticDataFieldChangeEvent) => Promise<void>;
  stateTracker: number;
  changeErrors: ChangeError[];
  editable: boolean;
  showAuditHistory: (id: string, additionalParams: any) => void;
  showHierarchyMapAudit: (params: any) => void;
  canShowAuditHistory: boolean;
  hierarchyMapAuditTypeSystemId?: string;
  showLog: (id: string, additionalParams: any) => void;
  canShowLog: boolean;
  manualJobTrigger: (id: string, jobName: string) => void;
}

export interface StaticDataExternalState extends GridExternalState {
  fetchInfo: any;
}

export interface StaticDataFieldChangeEvent {
  field?: string;
  dataItem: any;
  value: any;
  undoNext?: boolean;
}

const preSort: SortDescriptor[] = [
  {
    dir: 'desc',
    field: 'isNew',
  },
];

const gridPageSize = 50;
let staticData: Map<string, any>;
let lastStaticDataTypeId = '';

const StaticDataTable: React.FC<StaticDataTableProps<StaticDataExternalState>> = (props) => {
  const {
    category,
    staticDataTypeId,
    externalState,
    setExternalState,
    additionalParams,
    showIndicator,
    updateStaticDataStatus,
    updateStaticData,
    stateTracker,
    changeErrors,
    editable,
    showAuditHistory,
    showHierarchyMapAudit,
    canShowAuditHistory,
    hierarchyMapAuditTypeSystemId,
    showLog,
    canShowLog,
    manualJobTrigger,
  } = props;

  const columns = useMemo(() => getStaticDataColumns(staticDataTypeId), [staticDataTypeId]);
  const [dependentUpdateStaticData] = useMemo(
    () => getDependentUpdateStaticData({ columns, updateStaticData }),
    [columns, updateStaticData],
  );
  const isAdditionalParamRequired = useMemo(
    () => getStaticDataAdditionalParams(category, staticDataTypeId).length > 0,
    [staticDataTypeId],
  );
  const [shouldRefresh, updateShouldRefresh] = useRefreshNotification();
  const [resetCounter, setResetCounter] = useState(0);
  const [errorMap, setErrorMap] = useState({});
  const prevErrorMap = usePrevious(errorMap);

  const query = useMemo(() => getStaticDataQuery(staticDataTypeId, additionalParams), [
    staticDataTypeId,
    additionalParams,
  ]);
  const prevAdditionalParams = useRef();
  const [dataFetchCounter, setDataFetchCounter] = useState('0');
  const [isFetching, setIsFetching] = useState(false);
  const editMode = useRef(false);
  const client = useApolloClient();

  // useAsyncError will capture any async error and propagate to Error boundary
  const throwAsyncError = useAsyncError();

  const fetchDataFromNetwork = async (apolloClient: ApolloClient<object>, queryString: string) => {
    const graphQlQuery = gql`
      ${queryString}
    `;

    const { data } = await apolloClient.query({
      query: graphQlQuery,
      fetchPolicy: 'no-cache',
      errorPolicy: 'none',
    });
    return data;
  };

  const staticDataAccessors: StaticDataAccessors = {
    getAllData: () => staticData,
    getDataById: (id: string) => staticData.get(id.toString()),
    updateRecordById: (id: string, newData: any) => {
      staticData.set(id.toString(), newData);
      editMode.current = true;
      setDataFetchCounter(uuid());
    },
    bulkUpdateRecords: (data: any[], mergeToExistingData: boolean, ignoreRerendering?: boolean) => {
      data.forEach((item) => {
        const id = item.id.toString();
        if (!mergeToExistingData) {
          staticData.set(id, item);
        } else {
          const existingData = staticData.get(id) || {};
          staticData.set(id, { ...existingData, ...item });
        }
      });

      if (!ignoreRerendering) {
        setDataFetchCounter(uuid());
      }
    },
    addRecord: (newData: any) => {
      staticData.set(newData.id.toString(), newData);
      editMode.current = true;
      setDataFetchCounter(uuid());
    },
    bulkAddRecords: (data: any[], ignoreRerendering?: boolean) => {
      data.forEach((item) => {
        staticData.set(item.id.toString(), item);
      });

      if (!ignoreRerendering) {
        setDataFetchCounter(uuid());
      }
    },
    deleteRecordById: (id: string) => {
      staticData.delete(id.toString());
      editMode.current = true;
      setDataFetchCounter(uuid());
    },
    bulkDeleteRecords: (ids: string[], ignoreRerendering?: boolean) => {
      ids.forEach((id) => {
        staticData.delete(id.toString());
      });

      if (!ignoreRerendering) {
        setDataFetchCounter(uuid());
      }
    },
  };

  const resetFetchProgress = () => {
    setDataFetchCounter(dataFetchCounter + 1);

    updateShouldRefresh(false);
    setIsFetching(false);
  };

  const onFetchComplete = async (data: any) => {
    const newStaticData = (data?.[getStaticDataQueryName(staticDataTypeId)] ?? []) as any[];

    staticData = new Map();
    newStaticData.forEach((d: any) => {
      let { id } = d;
      if (id == null) {
        id = uuid();
      }
      staticData.set(id.toString(), { id, inEdit: null, ...d });
    });
    lastStaticDataTypeId = staticDataTypeId;
    resetFetchProgress();
  };

  const fetchStaticData = async (forceRefetch: boolean = false) => {
    setIsFetching(true);

    if (!forceRefetch && staticData && lastStaticDataTypeId === staticDataTypeId) {
      resetFetchProgress();
    } else {
      try {
        const data = await fetchDataFromNetwork(client, query);
        onFetchComplete(data);
      } catch (err) {
        onFetchComplete(null);
        throwAsyncError(new QueryError(err));
      }
    }
  };

  const refetchStaticData = () => {
    staticData = new Map();
    setResetCounter(resetCounter + 1);
    fetchStaticData(true);
  };

  useEffect(() => {
    if (!isAdditionalParamRequired) {
      fetchStaticData();
    }
  }, [staticDataTypeId]);

  useEffect(() => {
    if (
      isAdditionalParamRequired &&
      !isEqual(prevAdditionalParams.current, additionalParams) &&
      !isEmpty(additionalParams)
    ) {
      prevAdditionalParams.current = additionalParams;
      fetchStaticData(true);
    }
  }, [additionalParams]);

  useEffect(() => {
    if (shouldRefresh) {
      refetchStaticData();
    }
  }, [shouldRefresh]);

  useEffect(() => {
    setErrorMap(
      changeErrors.reduce((acc, curr) => {
        const { sourceId, sourceField } = curr;
        acc[sourceId] = acc[sourceId] || {};
        acc[sourceId][sourceField] = curr;

        return acc;
      }, {}),
    );
  }, [changeErrors]);

  useEffect(() => {
    let hasSetInEdit = false;

    if (staticData && editMode.current) {
      const errorIds = Object.keys(errorMap);

      errorIds.forEach((errorId) => {
        const errors: { [key: string]: ChangeError } = errorMap[errorId] || {};

        if (errors) {
          let inEdit = null;
          Object.keys(errors).forEach((field) => {
            if (!hasSetInEdit) {
              hasSetInEdit = true;
              inEdit = field;
            }
          });

          if (staticData.has(errorId)) {
            const data = staticData.get(errorId);

            data.inEdit = inEdit;
            data.errors = errors;
          }
        }
      });

      // remove old errors
      const prevErrorIds = Object.keys(prevErrorMap || {});
      prevErrorIds.forEach((errorId) => {
        if (!errorMap[errorId] && staticData.has(errorId)) {
          const data = staticData.get(errorId);
          data.inEdit = null;
          data.errors = null;
        }
      });
    }
  }, [dataFetchCounter, columns, errorMap]);

  const gridColumns: any[] = useMemo(() => {
    const newColumns = columns.map((c) => ({
      ...c,
      editable: (c.editable || c.onlyEditableOnNew) && editable,
    }));

    // create isNew column that is only used internally for sorting
    if (some(newColumns, { field: 'modified' })) {
      newColumns.push({
        field: 'isNew',
        width: '0px',
        internalUseOnly: true,
        editable: false,
      });
    }
    return newColumns;
  }, [columns]);

  const canActivate = useMemo(
    () => !!gridColumns.find((c) => c.field && c.field === 'isActive')?.extras?.canActivate,
    [gridColumns],
  );

  const canAllowManualTrigger = useMemo(
    () => !!gridColumns.find((c) => c.field && c.field === 'allowManualTrigger'),
    [gridColumns],
  );

  const canReviewRecord = useMemo(
    () => !!gridColumns.find((c) => c.field && c.field === 'isReviewed')?.extras?.canReviewRecord,
    [gridColumns],
  );

  const contextMenuItems = useCallback(
    ({ selectedRowData }: any) => {
      const menuItems = [];

      if (canActivate) {
        if (selectedRowData.isActive) {
          menuItems.push({
            value: 'deactivate',
            text: 'Deactivate',
            shouldCloseMenuAfterSelect: true,
          });
        } else {
          menuItems.push({
            value: 'activate',
            text: 'Activate',
            shouldCloseMenuAfterSelect: true,
          });
        }
      }

      if (canAllowManualTrigger) {
        menuItems.push({
          value: 'triggerManually',
          text: 'Trigger Manually',
          shouldCloseMenuAfterSelect: true,
          disabled: !selectedRowData.allowManualTrigger,
        });
      }

      if (canReviewRecord) {
        menuItems.push({
          value: 'reviewed',
          text: 'Acknowledge Is Reviewed',
          shouldCloseMenuAfterSelect: true,
        });
      }

      if (canShowAuditHistory) {
        menuItems.push({
          value: 'showAuditHistory',
          text: 'Show Audit History',
          shouldCloseMenuAfterSelect: true,
        });
      }

      if (canShowLog) {
        menuItems.push({
          value: 'showLog',
          text: 'Show Log',
          shouldCloseMenuAfterSelect: true,
        });
      }
      return menuItems;
    },
    [canActivate, canReviewRecord, canShowAuditHistory, canShowLog, canAllowManualTrigger],
  );

  const onContextMenuSelect = (event: CTXMenuSelectEvent, selectedRowData: any) => {
    switch (event.itemId) {
      case 'activate':
      case 'deactivate':
        dependentUpdateStaticData({
          dataItem: selectedRowData,
          field: 'isActive',
          value: event.itemId === 'activate',
        });
        break;

      case 'reviewed':
        dependentUpdateStaticData({
          dataItem: selectedRowData,
          field: 'isReviewed',
          value: true,
        });
        break;

      case 'showAuditHistory':
        showAuditHistory(
          selectedRowData.auditId || selectedRowData.id,
          selectedRowData.additionalParamsForAuditHistory,
        );
        break;

      case 'showLog':
        showLog(
          selectedRowData.auditId || selectedRowData.id,
          selectedRowData.additionalParamsForAuditHistory,
        );
        break;

      case 'showHierarchyMapAudit':
        showHierarchyMapAudit(selectedRowData.id);
        break;

      case 'triggerManually':
        manualJobTrigger(selectedRowData.id, selectedRowData.name);
        break;

      default:
        break;
    }
  };

  useEffect(() => {
    updateStaticDataStatus(isFetching, staticDataAccessors);
  }, [isFetching, dataFetchCounter]);

  return (
    <div className={styles.staticDataTableWrapper}>
      <Grid
        editable={editable}
        className={styles.staticDataTable}
        data={staticData}
        dataRefreshWatcher={dataFetchCounter}
        style={{ height: '100%' }}
        editField="inEdit"
        currentStateWatcher={`${resetCounter} ${staticDataTypeId} ${stateTracker}`}
        showColumnVisibility
        externalState={externalState}
        setExternalState={setExternalState}
        loading={isFetching || shouldRefresh || showIndicator}
        columns={gridColumns}
        onItemChange={dependentUpdateStaticData}
        preSortColumns={preSort}
        contextMenuItems={contextMenuItems}
        onContextMenuSelect={onContextMenuSelect}
        pageSize={gridPageSize}
        useStandardCellsUnlessEditing
      />
      {props.children}
    </div>
  );
};

export default StaticDataTable;

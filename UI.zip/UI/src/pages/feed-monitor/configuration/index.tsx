import React, { SyntheticEvent, useRef, useState, useCallback, useContext, useMemo } from 'react';

import { Result, Modal } from 'antd';
import { paramCase } from 'change-case';
import { isEqual } from 'lodash';
import { generatePath } from 'react-router';
import router from 'umi/router';

import {
  gql,
  clearCacheOfType,
  useMutation,
  useApolloClient,
} from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import { useGQLActivePage } from 'umi-plugin-apollo-anz/apolloPageState';

import withErrorBoundary from '@/HOCs/withErrorBoundary';
import Card from '@/components/Card';
import RefreshContext from '@/contexts/RefreshContext';
import ErrorBoundary from '@/error/ErrorBoundary';
import ErrorFallback from '@/error/ErrorFallback';
import useRefreshNotification from '@/hooks/useRefreshNotification';
import useUncommittedChanges from '@/hooks/useUncommittedChanges';
import { getAuthority, isAuthorized } from '@/utils/authority';

import FeedMonitorLogWindow from './components/FeedMonitorLog';
import AuditHistoryWindow from './components/StaticDataAuditHistory';
import StaticDataBulkUpdate from './components/StaticDataBulkUpdate';
import StaticDataSearch from './components/StaticDataSearch';
import StaticDataTable, { StaticDataFieldChangeEvent } from './components/StaticDataTable';
import useAddStaticData from './hooks/useAddStaticData';
import useBulkUpdate, { ChangeProp } from './hooks/useBulkUpdate';
import useUpdateStaticData from './hooks/useUpdateStaticData';
import styles from './index.less';
import { staticDataCategory } from './mappings/staticData';
import {
  getStaticDataQueryName,
  getStaticDataCanAddNew,
  getStaticDataCanBulkUpdate,
  getStaticDataAdditionalParams,
  getStaticDataCanShowAuditHistory,
  getStaticDataHierarchyMapAuditTypeSystemId,
  getStaticDatasetName,
  getStaticDataWarningMsgWhenExport,
  getStaticDataWarningMsgWhenBulkUpdate,
  getStaticDataPostSaveCallback,
  getStaticDataPreSaveCallback,
  getStaticDataType,
  getStaticDataCanShowLog,
} from './utils/normaliseMappings';

export interface StaticDataAccessors {
  getAllData: () => Map<string, any>;
  getDataById: (id: string) => any;
  updateRecordById: (id: string, newData: any) => void;
  bulkUpdateRecords: (
    data: any[],
    mergeToExistingData: boolean,
    ignoreRerendering?: boolean,
  ) => void;
  addRecord: (newData: any) => void;
  bulkAddRecords: (data: any[], ignoreRerendering?: boolean) => void;
  deleteRecordById: (id: string) => void;
  bulkDeleteRecords: (ids: string[], ignoreRerendering?: boolean) => void;
}

const showConfirm = (callback: Function) => {
  Modal.destroyAll();
  Modal.confirm({
    title: 'Confirmation',
    content: 'This action will remove all uncommitted changes. Are you sure you want to continue?',
    onOk: () => {
      callback();
    },
  });
};

const showConfirmManualTrigger = (jobName: string, callback: Function) => {
  Modal.destroyAll();
  Modal.confirm({
    title: 'Confirm Trigger',
    content: `Confirm to trigger job "${jobName}"`,
    onOk: () => {
      callback();
    },
  });
};

const showSuccess = (msg: string) => {
  Modal.destroyAll();
  Modal.success({
    title: `${msg}!`,
  });
};

const showError = (msg: string) => {
  Modal.destroyAll();
  Modal.error({
    title: 'Error',
    content: msg,
  });
};

const showWarning = (msg: JSX.Element | string, callback: any = () => {}) => {
  Modal.destroyAll();
  Modal.warning({
    title: 'Warning',
    content: msg,
    onOk: callback,
  });
};

const QUERY = gql`
  mutation batch($actions: [BatchActions!]!) {
    batchChange(actions: $actions) {
      success
      actions
    }
  }
`;

const StaticData: React.FC<any> = (props) => {
  useGQLActivePage('feedMonitorConfiguration');
  const client = useApolloClient();
  const triggerRefresh = useContext(RefreshContext);

  const { path: routePath, params: routeParams } = props.match;

  const convertRouteParams = (value: string): string => {
    if (value == null) return '';

    return paramCase(value.toLowerCase());
  };

  const getStaticDataInfoFromParams = useMemo(() => {
    if (routeParams?.category && routeParams.dataset) {
      const categoryList = staticDataCategory.find(
        (item) => convertRouteParams(item.name) === routeParams.category.toLowerCase(),
      );

      const typeId = categoryList?.list.find(
        (item) => convertRouteParams(item.name) === routeParams.dataset.toLowerCase(),
      )?.id;

      if (categoryList?.name && typeId) {
        return {
          category: categoryList?.name,
          staticDataTypeId: typeId,
        };
      }

      router.push({
        pathname: generatePath(routePath),
      });
    }

    return { category: 'All', staticDataTypeId: '' };
  }, [routeParams, routePath]);

  const [externalState, setExternalState] = useGQLComponentState({
    ...getStaticDataInfoFromParams,
    auditId: '',
    auditHistoryAdditionalParams: null,
    hierarchyMapAuditId: '',
    additionalParams: {},
    logId: '',
  });
  const { category, staticDataTypeId, auditId, additionalParams, logId } = externalState;
  const [
    changes,
    ,
    ,
    clearAll,
    ,
    changeErrors,
    ,
    ,
    setPostSaveCallback,
    setPreSaveCallback,
  ] = useUncommittedChanges();
  const [updateStaticData] = useUpdateStaticData();
  const [addStaticData] = useAddStaticData();
  const { onStartBulkUpdate, onCompleteBulkUpdate } = useBulkUpdate();
  const [isDataLoading, setIsDataLoading] = useState(false);
  const staticDataAccessors = useRef<StaticDataAccessors>();
  const staticDataBulkUpdateSummary = useRef([] as any[]);
  const [showIndicator, setShowIndicator] = useState(false);
  const [showBulkUpdateSummary, setShowBulkUpdateSummary] = useState(false);
  const [tableState, setTableState] = useState(1);
  const [shouldRefresh] = useRefreshNotification();
  const { writeAuthority } = props.route;
  const isWriteAuthorized = useMemo(() => isAuthorized(writeAuthority, getAuthority()), [
    writeAuthority,
  ]);
  const staticDatasetName = getStaticDatasetName(staticDataTypeId);
  const canShowAuditHistory = getStaticDataCanShowAuditHistory(staticDataTypeId);
  const canShowLog = getStaticDataCanShowLog(staticDataTypeId);
  const hierarchyMapAuditTypeSystemId = useMemo(
    () => getStaticDataHierarchyMapAuditTypeSystemId(staticDataTypeId),
    [staticDataTypeId],
  );

  const onSetCategory = (value: string) => {
    setExternalState({
      category: value,
    });
  };

  const [sendNotificationJobRequest] = useMutation(QUERY);

  const onStaticDataRefresh = (callback: () => void) => {
    const refreshStaticData = (shouldClearUncommittedChanges: boolean = false) => {
      if (shouldClearUncommittedChanges) {
        clearAll();
      }
      clearCacheOfType(client, getStaticDataQueryName(staticDataTypeId));
      callback();
    };

    if (changes?.length > 0) {
      showConfirm(() => {
        refreshStaticData(true);
      });
    } else {
      refreshStaticData(false);
    }
  };

  const updateRouteParams = (value: string) => {
    const typeName = getStaticDataType(category, value);

    const pathname = generatePath(routePath, {
      category: paramCase(category.toLowerCase()),
      dataset: paramCase(typeName.toLowerCase()),
    });

    router.push({
      pathname,
    });
  };

  const onSetStaticDataTypeId = (value: string) => {
    onStaticDataRefresh(() => {
      setExternalState({
        staticDataTypeId: value,
        additionalParams: {},
        auditId: '',
        auditHistoryAdditionalParams: null,
        hierarchyMapAuditId: '',
        logId: '',
      });

      if (value && value !== '0') {
        const postSaveCallback = getStaticDataPostSaveCallback(value);
        setPostSaveCallback(postSaveCallback);
        const preSaveCallback = getStaticDataPreSaveCallback(value);
        setPreSaveCallback(preSaveCallback);

        updateRouteParams(value);
      }
    });
  };

  const onSetAdditionalParams = (params: any) => {
    if (!isEqual(params, additionalParams)) {
      onStaticDataRefresh(() =>
        setExternalState({
          additionalParams: {
            ...additionalParams,
            ...params,
          },
        }),
      );
    }
  };

  const updateStaticDataStatus = (loading: boolean, accessors: StaticDataAccessors) => {
    if (isDataLoading !== loading) {
      setIsDataLoading(loading);
    }
    staticDataAccessors.current = accessors;
  };

  const handleFileData = (file: Blob) => {
    const reader = new FileReader();
    reader.onload = async (content) => {
      const { result } = content.target;
      if (result) {
        await onStartBulkUpdate(
          category,
          staticDataTypeId,
          result,
          staticDataAccessors.current as StaticDataAccessors,
          additionalParams,
        );
      }
    };

    reader.readAsBinaryString(file);
  };

  const onExportCsv = () => {
    const warningMsg = getStaticDataWarningMsgWhenExport(staticDataTypeId);

    if (warningMsg) {
      showWarning(warningMsg);
    }
  };

  const processFile = async (file: any) => {
    setShowIndicator(true);
    onCompleteBulkUpdate((params: ChangeProp[]) => {
      staticDataBulkUpdateSummary.current = params;
      setShowIndicator(false);
      setShowBulkUpdateSummary(true);
    });

    if (file) {
      const fileExtension = file.name.split('.').pop();
      if (fileExtension === 'csv') {
        handleFileData(file);
      } else {
        showError('Only csv files are allowed.');
      }
    }
  };

  const onFileUpload = (event: SyntheticEvent) => {
    const warningMsg = getStaticDataWarningMsgWhenBulkUpdate(staticDataTypeId);

    const file = (event.target as any).files[0];

    if (warningMsg) {
      showWarning(warningMsg, () => queueMicrotask(() => processFile(file)));
    } else {
      processFile(file);
    }
  };

  const onRefresh = () => {
    if (changes?.length > 0) {
      showConfirm(() => {
        triggerRefresh();
      });
    } else {
      triggerRefresh();
    }
  };

  const onUpdateStaticData = useCallback(
    (data: StaticDataFieldChangeEvent) => {
      const { dataItem, value, field } = data;
      const { id, __typename: entityName } = dataItem;

      return updateStaticData(
        {
          staticDataAccessors: staticDataAccessors.current as StaticDataAccessors,
          category,
          typeId: staticDataTypeId,
          id,
          entityName,
          field: field ?? '',
          value,
          undoNext: data.undoNext,
        },
        additionalParams,
      );
    },
    [updateStaticData, category, staticDataTypeId, additionalParams],
  );

  const onShowAuditHistory = useCallback(
    (rowId: string, additionalParamsForAuditHistory: any) => {
      setExternalState({
        auditId: rowId,
        auditHistoryAdditionalParams: additionalParamsForAuditHistory,
      });
    },
    [setExternalState],
  );

  const onManualJobTrigger = useCallback(
    (rowId: number, jobName: string) => {
      const actionName = 'sendNotificationJobRequest';
      const createMutationActionForOverrideRequest = (jobRequest: string, jobId: number) => ({
        [jobRequest]: {
          jobId,
        },
      });

      const triggerNotificationJob = async () => {
        const actions = createMutationActionForOverrideRequest(actionName, Number(rowId));
        try {
          await sendNotificationJobRequest({
            variables: {
              actions,
            },
          });
          showSuccess('Request sent');
        } catch (e) {
          showError('Failed to sent request.');
        }
      };
      showConfirmManualTrigger(jobName, triggerNotificationJob);
    },
    [sendNotificationJobRequest],
  );

  const onShowLog = useCallback(
    (rowId: string) => {
      setExternalState({
        logId: rowId,
      });
    },
    [setExternalState],
  );

  const onShowHierarchyMapAudit = useCallback(
    (rowId: string) => {
      setExternalState({ hierarchyMapAuditId: rowId });
    },
    [setExternalState],
  );

  const onAuditHistoryDismiss = () => {
    clearCacheOfType(client, 'FMConfigAuditHistory');
    setExternalState({ auditId: '', hierarchyMapAuditId: '', auditHistoryAdditionalParams: null });
  };

  const onLogDismiss = () => {
    clearCacheOfType(client, 'FeedMonitorLog');
    setExternalState({ logId: '' });
  };

  const onAddNewStaticData = useCallback(async () => {
    await addStaticData({
      staticDataAccessors: staticDataAccessors.current as StaticDataAccessors,
      category,
      typeId: staticDataTypeId,
    });

    setTableState(tableState + 1);
  }, [addStaticData, category, staticDataTypeId, tableState]);

  const isAddParamsRequired = useMemo(
    () => getStaticDataAdditionalParams(category, staticDataTypeId).length > 0,
    [category, staticDataTypeId],
  );

  const areAddParamsExist = useMemo(() => {
    if (isAddParamsRequired) {
      const paramList = getStaticDataAdditionalParams(category, staticDataTypeId);
      const existingParams = paramList.filter((item) => additionalParams[item]);

      return existingParams.length === paramList.length;
    }

    return false;
  }, [isAddParamsRequired, category, staticDataTypeId, additionalParams]);

  return (
    <Card className={styles.staticDataWrapper} title="Configuration">
      <StaticDataBulkUpdate
        showBulkUpdateSummary={showBulkUpdateSummary}
        staticDataTypeId={staticDataTypeId}
        data={staticDataBulkUpdateSummary.current}
        setShowBulkUpdateSummary={setShowBulkUpdateSummary}
      />

      <StaticDataSearch
        category={category}
        staticDataTypeId={staticDataTypeId}
        additionalParams={additionalParams}
        isDataLoading={isDataLoading}
        onSelectCategory={onSetCategory}
        onSelectStaticDataTypeId={onSetStaticDataTypeId}
        onSelectRefreshData={onRefresh}
        onSelectAdditionalParams={onSetAdditionalParams}
        onFileUpload={onFileUpload}
        onAddNew={onAddNewStaticData}
        canAddNew={getStaticDataCanAddNew(staticDataTypeId) && isWriteAuthorized}
        canBulkUpdate={getStaticDataCanBulkUpdate(staticDataTypeId) && isWriteAuthorized}
        onExportCsv={onExportCsv}
      />

      {(staticDataTypeId && !isAddParamsRequired) ||
      (staticDataTypeId && isAddParamsRequired && areAddParamsExist) ? (
        <ErrorBoundary
          errorTitle={`Error Loading ${staticDatasetName}`}
          retryWatcher={staticDataTypeId + shouldRefresh}
        >
          <StaticDataTable
            category={category}
            staticDataTypeId={staticDataTypeId}
            externalState={externalState}
            additionalParams={additionalParams}
            showIndicator={showIndicator}
            setExternalState={setExternalState}
            updateStaticDataStatus={updateStaticDataStatus}
            updateStaticData={onUpdateStaticData}
            showAuditHistory={onShowAuditHistory}
            showHierarchyMapAudit={onShowHierarchyMapAudit}
            manualJobTrigger={onManualJobTrigger}
            stateTracker={tableState}
            changeErrors={changeErrors}
            editable={isWriteAuthorized}
            canShowAuditHistory={canShowAuditHistory}
            canShowLog={canShowLog}
            showLog={onShowLog}
            hierarchyMapAuditTypeSystemId={hierarchyMapAuditTypeSystemId}
          >
            {canShowAuditHistory && auditId && staticDataTypeId && (
              <AuditHistoryWindow
                auditId={auditId}
                configTypeId={staticDataTypeId}
                onAuditHistoryDismiss={onAuditHistoryDismiss}
              />
            )}
            {canShowLog && logId && staticDataTypeId && (
              <FeedMonitorLogWindow
                logId={logId}
                fmConfigTypeId={staticDataTypeId}
                onFeedMonitorLogDismiss={onLogDismiss}
              />
            )}
          </StaticDataTable>
        </ErrorBoundary>
      ) : (
        <Result
          icon={<span className={`k-icon k-i-gear ${styles.searchIndicatorIcon}`} />}
          title="Configuration"
          subTitle="(For configuration maintenance)"
          extra={<span>Select a category</span>}
        />
      )}
    </Card>
  );
};

export default withErrorBoundary(
  <ErrorFallback title="Error Loading Static Data Page" retryText="Reload Page" />,
)(StaticData);

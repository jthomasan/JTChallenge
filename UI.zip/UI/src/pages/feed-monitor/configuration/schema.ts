import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export default gql`
  type FeedMonitorConfigurationPage implements ChangeRegistry & Refreshable {
    selectedCategory: String
  }

  extend type Page {
    feedMonitorConfiguration: FeedMonitorConfigurationPage
  }
`;

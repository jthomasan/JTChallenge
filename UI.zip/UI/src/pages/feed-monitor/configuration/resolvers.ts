export const defaults = {
  feedMonitorConfiguration: {
    __typename: 'FeedMonitorConfigurationPage',
    selectedCategory: null,
    changes: [],
    errors: [],
  },
};

export const resolvers = {};

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export interface RiskDataPageDataQueryResponse {
  PortfolioHierarchiesWithDate?: {
    date: string;
    nodes: {
      id: string;
      nodeId: string;
      name: string;

      parent?: {
        id: string;
        nodeId: string;
      };
    }[];
  };
}

export const RiskDataPageDataQuery = gql`
  query RiskDataPageDataQuery {
    PortfolioHierarchiesWithDate {
      date
      nodes {
        id
        nodeId
        name

        parent {
          id
          nodeId
        }
      }
    }
  }
`;

import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import { isEqual, keyBy } from 'lodash';
import {
  useQuery,
  NetworkStatus,
  clearCacheOfType,
  useApolloClient,
} from 'umi-plugin-apollo-anz/apolloClient';
import Card from '@/components/Card';
import { Splitter, SplitterPaneProps } from '@progress/kendo-react-layout';
import ProgressIndicator, { ActionType } from '@/components/ProgressIndicator';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import { useGQLActivePage } from 'umi-plugin-apollo-anz/apolloPageState';

import PageLoading from '@/components/PageLoading';
import PageErrorFallback from '@/error/ErrorFallback';
import { QueryError } from '@/error/types';

import { AUTO_REFRESH_INTERVAL } from '@/constants/refresh';

import FeedStatusContainer from './components/FeedStatusContainer';

import RiskContainerStatusTable, {
  RiskContainerStatusTableExternalState,
  RiskContainerStatusTableProps,
} from './components/RiskContainerStatusTable';

import { FeedStatusAction } from './components/FeedStatusContainer/types';
import {
  GQL_RISK_CONTAINER_STATUSES,
  RiskContainerStatusesQueryResponse,
} from './components/RiskContainerStatusTable/query';
import { FormState, Node, RiskDataPageExternalState } from './types';
import RiskDataInputBar from './components/RiskDataInputBar';
import RiskDataCardTopBar from './components/RiskDataCardTopBar';
import { RiskDataPageDataQuery, RiskDataPageDataQueryResponse } from './query';

import styles from './index.less';

interface PageSettingsProps {
  autoRefresh: boolean;
}

// Attempts to reduce extra renders to other elements of RD page from external state changes
const RiskContainersWrapper: React.FC<{
  selectedContainerIds: FormState['selectedContainerIds'];
  loading: boolean;
  nodeName: string;
  data?: RiskContainerStatusesQueryResponse;
  onChange: RiskContainerStatusTableProps['onChange'];
}> = ({ selectedContainerIds, nodeName, data, loading, onChange }) => {
  const [externalState, setExternalState] = useGQLComponentState<
    RiskContainerStatusTableExternalState
  >({}, 'risk-data-containers');

  return (
    <RiskContainerStatusTable
      nodeName={nodeName}
      loading={loading}
      data={data?.RiskContainerStatuses}
      externalState={externalState}
      setExternalState={setExternalState}
      value={selectedContainerIds ?? []}
      onChange={onChange}
    />
  );
};

const RiskDataPageContent: React.FC<{ cobDate: string; rootNode: Node }> = ({
  cobDate,
  rootNode,
}) => {
  useGQLActivePage('riskData');
  const client = useApolloClient();

  const [splitterPanes, setSplitterPanes] = useState<SplitterPaneProps[]>([
    { size: '345px', min: '10%', collapsible: true, resizable: false },
    {},
  ]);
  const [pageSettingsExternalState, setPageSettingsExternalState] = useGQLComponentState<
    PageSettingsProps
  >({ autoRefresh: false });

  const initialFormState: FormState = {
    node: rootNode,
    date: cobDate,
    snapshot: 'EOD',
    selectedContainerIds: [],
    reportTypeIds: [],
    sourceSystemIds: [],
    sourceSystemEnvironments: [],
  };

  const [inputExternalState, setInputExternalState] = useGQLComponentState<
    RiskDataPageExternalState
  >(
    {
      parameters: {
        pending: initialFormState,
        current: initialFormState,
      },
    },
    'risk-data-input-bar',
  );
  const intervalRef = useRef<Record<string, NodeJS.Timeout>>({});
  const backgroundRefreshTriggered = useRef(false);
  const [progressIndicator, setProgressIndicator] = useState<{
    action: ActionType;
    message: string;
    title?: string;
  }>({
    action: ActionType.none,
    message: '',
  });

  const {
    loading: riskContainerLoading,
    data: riskContainerData,
    refetch,
    networkStatus: riskContainerNetworkStatus,
  } = useQuery<RiskContainerStatusesQueryResponse>(GQL_RISK_CONTAINER_STATUSES, {
    errorPolicy: 'none',
    variables: {
      nodeId: inputExternalState.parameters.current.node.id,
      date: inputExternalState.parameters.current.date,
      snapshot: inputExternalState.parameters.current.snapshot,
      reportTypeIds: inputExternalState.parameters.current.reportTypeIds,
      sourceSystemIds: inputExternalState.parameters.current.sourceSystemIds,
      sourceSystemEnvironments: inputExternalState.parameters.current.sourceSystemEnvironments,
    },
    notifyOnNetworkStatusChange: true,
  });
  const containersById = useMemo(() => {
    if (riskContainerData?.RiskContainerStatuses) {
      return keyBy(riskContainerData?.RiskContainerStatuses, 'containerId');
    }

    return {};
  }, [riskContainerData]);

  const selectedContainers = useMemo(
    () =>
      (inputExternalState.parameters.pending.selectedContainerIds ?? []).map(
        (id) => containersById[id],
      ),
    [containersById, inputExternalState.parameters.pending.selectedContainerIds],
  );

  const updatePendingParameters = (
    toMerge: Partial<RiskDataPageExternalState['parameters']['pending']>,
  ) => {
    setInputExternalState((currentState) => ({
      parameters: {
        ...currentState.parameters,
        pending: {
          ...currentState.parameters.pending,
          ...toMerge,
        },
      },
    }));
  };

  const updateCurrentParameters = (
    toMerge: Partial<RiskDataPageExternalState['parameters']['current']>,
  ) => {
    setInputExternalState((currentState) => ({
      parameters: {
        ...currentState.parameters,
        current: {
          ...currentState.parameters.current,
          ...toMerge,
        },
      },
    }));
  };

  const fireRefreshEvent = (backgroundRefresh: boolean) => {
    window.dispatchEvent(
      new CustomEvent('feedStatusActions', {
        detail: backgroundRefresh ? FeedStatusAction.BackgroundRefresh : FeedStatusAction.Refresh,
      }),
    );
  };

  const refreshData = (backgroundRefresh = false) => {
    refetch();
    clearCacheOfType(client, 'RiskDataHierarchyFeedStatuses');
    clearCacheOfType(client, 'RiskDataPortfolioFeedStatuses');

    fireRefreshEvent(backgroundRefresh);
  };

  const clearIntervals = () => {
    clearInterval(intervalRef.current.riskDataRefresh);
    clearInterval(intervalRef.current.businessDateRefresh);
  };

  const showRefreshPopup = () => {
    setProgressIndicator({
      action: ActionType.inProgress,
      message: 'Refreshing',
    });

    setTimeout(() => {
      setProgressIndicator({
        action: ActionType.none,
        message: '',
      });
    }, 1000);
  };

  const setAutoRefresh = useCallback((value: boolean) => {
    setPageSettingsExternalState({
      autoRefresh: value,
    });
  }, []);

  useEffect(() => {
    if (pageSettingsExternalState.autoRefresh) {
      intervalRef.current.riskDataRefresh = setInterval(() => {
        backgroundRefreshTriggered.current = true;
        showRefreshPopup();
        refreshData(true);
      }, AUTO_REFRESH_INTERVAL);
    }

    return () => {
      clearIntervals();
    };
  }, [pageSettingsExternalState.autoRefresh]);

  return (
    <>
      <ProgressIndicator
        title={progressIndicator.title ?? ''}
        action={progressIndicator.action}
        actionMessage={progressIndicator.message}
        hideOverlay
      />
      <Card
        className={styles.feedMonitor}
        title="Risk Data"
        padded={false}
        fullPageCard
        actions={
          <RiskDataCardTopBar
            nodeId={inputExternalState.parameters.current.node.id}
            date={inputExternalState.parameters.current.date}
            snapshot={inputExternalState.parameters.current.snapshot}
          />
        }
      >
        <RiskDataInputBar
          value={inputExternalState.parameters.pending ?? inputExternalState.parameters.current}
          isAutoRefreshOn={pageSettingsExternalState.autoRefresh}
          onChange={(value) => {
            updatePendingParameters(value);
          }}
          onSetAutoRefresh={setAutoRefresh}
          onRefresh={() => {
            backgroundRefreshTriggered.current = false;
            refreshData();
          }}
          onSubmit={() => {
            setInputExternalState({
              parameters: {
                ...inputExternalState.parameters,
                current: inputExternalState.parameters.pending,
              },
            });
          }}
          date={inputExternalState.parameters.current.date}
          isPending={
            !isEqual(inputExternalState.parameters.pending, inputExternalState.parameters.current)
          }
        />
        <Splitter
          style={{ flexGrow: 1, overflow: 'hidden' }}
          panes={splitterPanes}
          onChange={({ newState }) => setSplitterPanes(newState)}
        >
          <RiskContainersWrapper
            loading={
              (riskContainerLoading || riskContainerNetworkStatus !== NetworkStatus.ready) &&
              !backgroundRefreshTriggered.current
            }
            selectedContainerIds={inputExternalState.parameters.pending.selectedContainerIds ?? []}
            onChange={(value) => {
              updatePendingParameters({
                selectedContainerIds: value,
              });
            }}
            nodeName={inputExternalState.parameters.current.node.name}
            data={riskContainerData}
          />
          <div className={styles.feedStatusViewer}>
            <FeedStatusContainer
              nodeName={inputExternalState.parameters.current.node.name}
              nodeId={inputExternalState.parameters.current.node.id}
              date={inputExternalState.parameters.current.date}
              snapshot={inputExternalState.parameters.current.snapshot}
              containerIds={inputExternalState.parameters.current.selectedContainerIds}
              reportTypeIds={inputExternalState.parameters.current.reportTypeIds}
              onSetDefaultNode={(value) => {
                updatePendingParameters(value);
                updateCurrentParameters(value);
              }}
              sourceSystemIds={inputExternalState.parameters.current.sourceSystemIds}
              sourceSystemEnvironments={
                inputExternalState.parameters.current.sourceSystemEnvironments
              }
              selectedContainers={selectedContainers}
            />
          </div>
        </Splitter>
      </Card>
    </>
  );
};

const RiskDataPage = () => {
  const { data, loading, error } = useQuery<RiskDataPageDataQueryResponse>(RiskDataPageDataQuery);

  if (loading) {
    return <PageLoading />;
  }

  const rootNode = data?.PortfolioHierarchiesWithDate?.nodes?.find((node) => !node.parent);

  if (!data?.PortfolioHierarchiesWithDate?.date || !rootNode || error) {
    return (
      <PageErrorFallback
        error={new QueryError(error)}
        title="There was an issue fetching the latest COB date"
        retryText="Retry"
      />
    );
  }

  return (
    <RiskDataPageContent
      cobDate={data?.PortfolioHierarchiesWithDate?.date}
      rootNode={{
        id: Number(rootNode.nodeId),
        name: rootNode.name,
      }}
    />
  );
};

export default RiskDataPage;

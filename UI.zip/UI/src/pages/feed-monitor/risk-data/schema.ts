import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export default gql`
  type RiskDataPage implements Refreshable {
    dummy: String
  }

  extend type Page {
    riskData: RiskDataPage
  }
`;

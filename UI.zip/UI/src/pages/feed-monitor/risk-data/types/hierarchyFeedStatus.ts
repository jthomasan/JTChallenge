import { Status } from './status';
import { NodeType } from '../components/FeedStatusContainer/types';

export interface HierarchyFeedStatus {
  id: string;
  nodeId: string;
  name: string;
  type: NodeType;
  level: number;
  isSignOffAllowed: boolean;
  isRerunEnabled: boolean;
  overallStatus: string;
  feed: Feed;
  parent: Parent;
  counts: FeedCount;
}

export interface Parent {
  id: string;
  nodeId: string;
  name: string;
}

export interface Feed {
  businessDate: string;
  reportName: string;
  containerId: number;
  containerName: string;
  portfolioName: string;
  portfolioId: number;
  sourceSystemEnvironment: string;
  hasSourceSystemError: boolean;
  isEmpty: boolean;
  isRerun: boolean;
  isExclusion: boolean;
  isProxy: boolean;
  isReload: boolean;
  isFmFeed: boolean;
  isStale: boolean;
  hasQuarantine: boolean;
  cubeVersion: number;
  subCubeVersion: number;
  cubeLoadId: number;
  cubeLoadTime: string;
  feedId: number;
  status: FeedLoadStatus;
  additionalInfo: string;
}

interface FeedLoadStatus {
  riskEngine: Status;
  download: Status;
  rdw: Status;
  signOff: Status;
  errorDownload: Status;
  overall: Status;
  cubeQueue: Status;
  cubeLoad: Status;
  cubeTradeEtl: Status;
  subCubeQueue: Status;
  subCubeLoadStatus: Status;
  subCubePositionEtl: Status;
  subCubeOverall: Status;
  fvaCubeLoad: Status;
  fvaCubeTradeEtl: Status;
  fvaSubcubeLoad: Status;
  fvaSubcubePositionEtl: Status;
}

export interface FeedCount {
  riskEngine: FeedCountDetail;
  riskEngineError: FeedCountDetail;
  download: FeedCountDetail;
  rdw: FeedCountDetail;
  signOff: FeedCountDetail;
  overall: FeedCountDetail;
  cubeQueue: FeedCountDetail;
  cubeLoad: FeedCountDetail;
  cubeTradeEtl: FeedCountDetail;
  subCubeLoad: FeedCountDetail;
  subCubePositionEtl: FeedCountDetail;
  fvaCubeLoad: FeedCountDetail;
  fvaCubeTradeEtl: FeedCountDetail;
  fvaSubcubeLoad: FeedCountDetail;
  fvaSubcubePositionEtl: FeedCountDetail;
}

export interface FeedCountDetail {
  notStarted: number;
  processing: number;
  completed: number;
  failed: number;
  noData: number;
  aborted: number;
  total: number;
  completedPercentage: number;
}

import { Status } from './status';

export interface PortfolioFeedStatus {
  id: string;
  feedId: string;
  additionalInfo: string;
  businessDate: number;
  container: Container;
  cubeVersion: number;
  cubeLoadID: number;
  cubeLoadTime: string | null;
  isEmpty: boolean;
  isExclusion: boolean;
  isFmFeed: boolean;
  isReload: boolean;
  isRerun: boolean;
  isStale: boolean;
  hasSourceSystemError: boolean;
  portfolio: Portfolio;
  reportName: string;
  sourceSystemEnvironment: string;
  status: StatusDetails;
  subCubeVersion: number;
}

interface Container {
  id: number;
  name: string;
}

interface Portfolio {
  id: number;
  name: string;
}

interface StatusDetails {
  cubeLoad: Status;
  cubeQueue: Status;
  cubeTradeEtl: Status;
  download: Status;
  errorDownload: Status;
  fvaCubeLoad: Status;
  fvaCubeTradeEtl: Status;
  fvaSubcubeLoad: Status;
  fvaSubcubePositionEtl: Status;
  overall: Status;
  rdw: Status;
  riskEngine: Status;
  signOff: Status;
  subCubeLoad: Status;
  subCubeQueue: Status;
  subCubePositionEtl: Status;
  subCubeOverall: Status;
}

export enum Status {
  'NOT_STARTED' = 'Not Started',
  'REMOVING' = 'Removing',
  'PROCESSING' = 'Processing',
  'COMPLETE' = 'Complete',
  'FAILED' = 'Failed',
  'ABORTED' = 'Aborted',
  'NO_DATA' = 'No Data',
  'SKIPPED_RERUN' = 'Skipped Rerun',
  'QUARANTINED' = 'Quarantined',
  'SKIPPED' = 'Skipped',
  'EXCLUDED' = 'Excluded',
  'EXPIRED' = 'Expired',
  'REMOVED' = 'Removed',
  'PENDING' = 'Pending',
  'UNKNOWN' = 'Unknown',
}

export const StatusNameColorPalette = {
  [Status.NOT_STARTED]: 'inherit',
  [Status.PROCESSING]: 'inherit',
  [Status.COMPLETE]: 'green',
  [Status.FAILED]: 'red',
  [Status.NO_DATA]: 'gray',
};

export const StatusColorPalette = {
  [Status.NOT_STARTED]: 'gray',
  [Status.REMOVING]: 'red',
  [Status.PROCESSING]: 'yellow',
  [Status.COMPLETE]: 'green',
  [Status.FAILED]: 'red',
  [Status.ABORTED]: 'orange',
  [Status.NO_DATA]: 'green',
  [Status.SKIPPED_RERUN]: 'green',
  [Status.QUARANTINED]: 'yellow',
  [Status.SKIPPED]: 'green',
  [Status.EXCLUDED]: 'green',
  [Status.EXPIRED]: 'red',
  [Status.REMOVED]: 'red',
  [Status.PENDING]: 'yellow',
  [Status.UNKNOWN]: 'red',
};

export interface RiskDataReport {
  id: string;
  description: string;
  name: string;
  type: number;
  container: string;
  containers: Containers;
  exclusionEnabled: boolean;
  hasIntradayFeed: boolean | null;
  isActive: boolean;
  isCCYRateDependent: boolean;
  isComVolCurveDependent: boolean;
  isFmProcessing: boolean;
  isMreDependent: boolean;
  isRefDependent: boolean;
  proxyEnabled: boolean;
  rerunEnabled: boolean;
  valuationType: string;
  sourceSystem: SourceSystem;
}

interface Containers {
  cube: string;
  publish: string;
}

interface SourceSystem {
  id: string;
  value: string;
}

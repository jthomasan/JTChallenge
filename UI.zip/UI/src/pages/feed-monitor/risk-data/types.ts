export interface Node {
  id: number;
  name: string;
}

export interface FormState {
  node: Node;
  date: string;
  snapshot: string;
  selectedContainerIds: string[];
  reportTypeIds: number[];
  sourceSystemIds: number[];
  sourceSystemEnvironments: string[];
}

export interface RiskDataPageExternalState {
  parameters: {
    pending: FormState;
    current: FormState;
  };
}

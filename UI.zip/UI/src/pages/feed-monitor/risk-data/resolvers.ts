export const defaults = {
  riskData: {
    __typename: 'RiskDataPage',

    errors: [],
  },
};

export const resolvers = {};

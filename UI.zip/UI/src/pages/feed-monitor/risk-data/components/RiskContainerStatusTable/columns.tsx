import React from 'react';
import get from 'lodash/get';
import { asCell } from '@/components/SimpleTD';
import { CellProps, ColumnProps } from '@/components/Grid';
import { TooltipChildWrapper } from '@/components/Tooltip';

import StatusProgress from '../common/StatusProgress';
import { withStatusSummaryTooltip } from '../common/Tooltips/StatusSummaryTooltip';
import { withContainerOverallStatusSummaryTooltip } from '../common/Tooltips/ContainerOverallStatusSummaryTooltip';

const RiskContainerStatusProgress: React.FC<CellProps> = ({ field, dataItem, ...props }) => {
  if (!field) {
    return null;
  }

  const percentage = get(dataItem, field) as number;
  const rootStatus = get(dataItem, field.replace(/\..+$/, ''));
  const hasError = rootStatus?.hasFailures || !!rootStatus?.failed;

  return <StatusProgress percentage={percentage} hasError={hasError} {...props} />;
};

const RiskContainerSignOffStatusProgress: React.FC<CellProps> = ({
  dataItem,
  children,
  ...props
}) => {
  if (!dataItem.isSignOffRequired && dataItem.signOff.completedPercent < 0) {
    return null;
  }

  return <RiskContainerStatusProgress dataItem={dataItem} {...props} />;
};

export enum CONTAINER_STATUS_FIELD {
  OVERALL = 'overall',
  CUBE = 'cube',
  SUBCUBE = 'subCube',
  RDW = 'rdw',
}

export const StatusNameMap = {
  [CONTAINER_STATUS_FIELD.OVERALL]: {
    short: 'Overall',
    long: 'Overall',
  },
  [CONTAINER_STATUS_FIELD.CUBE]: {
    short: 'Cube',
    long: 'Cube',
  },
  [CONTAINER_STATUS_FIELD.SUBCUBE]: {
    short: 'SubCube',
    long: 'SubCube',
  },
  [CONTAINER_STATUS_FIELD.RDW]: {
    short: 'RDW',
    long: 'Risk Data Warehouse',
  },
};

export const columns: ColumnProps[] = [
  {
    field: 'name',
    title: 'Container',
    filter: 'text',
    defaultSortColumn: true,
    width: '140px',
    cell: asCell(
      withContainerOverallStatusSummaryTooltip(TooltipChildWrapper, {
        nameField: 'detailedName',
      }),
    ),
    extras: {
      typeOf: 'string',
    },
  },
  {
    field: `${CONTAINER_STATUS_FIELD.OVERALL}.completedPercent`,
    title: StatusNameMap[CONTAINER_STATUS_FIELD.OVERALL].short,
    width: '80px',
    filter: 'numeric',
    cell: asCell(
      withContainerOverallStatusSummaryTooltip(RiskContainerStatusProgress, {
        nameField: 'detailedName',
      }),
    ),
    hidden: false,
  },
  {
    field: `${CONTAINER_STATUS_FIELD.CUBE}.completedPercent`,
    title: StatusNameMap[CONTAINER_STATUS_FIELD.CUBE].short,
    width: '80px',
    filter: 'numeric',
    cell: asCell(
      withStatusSummaryTooltip(RiskContainerStatusProgress, {
        statusName: 'Cube Load Status',
        countField: 'cube',
        fvaCountField: 'fvaCube',
        nameField: 'detailedName',
      }),
    ),
    hidden: true,
  },
  {
    field: `${CONTAINER_STATUS_FIELD.SUBCUBE}.completedPercent`,
    title: StatusNameMap[CONTAINER_STATUS_FIELD.SUBCUBE].short,
    width: '80px',
    filter: 'numeric',
    cell: asCell(
      withStatusSummaryTooltip(RiskContainerStatusProgress, {
        statusName: 'Subcube Load Status',
        countField: 'subCube',
        fvaCountField: 'fvaSubCube',
        nameField: 'detailedName',
      }),
    ),
    hidden: true,
  },
  {
    field: `${CONTAINER_STATUS_FIELD.RDW}.completedPercent`,
    title: StatusNameMap[CONTAINER_STATUS_FIELD.RDW].short,
    width: '80px',
    filter: 'numeric',
    cell: asCell(
      withStatusSummaryTooltip(RiskContainerStatusProgress, {
        statusName: 'Risk Data Warehouse Status',
        countField: 'rdw',
        nameField: 'detailedName',
      }),
    ),
    hidden: true,
  },
  {
    field: 'signOff.completedPercent',
    title: 'Sign Off',
    width: '80px',
    filter: 'numeric',
    cell: asCell(
      withStatusSummaryTooltip(RiskContainerSignOffStatusProgress, {
        statusName: 'Signoff Status',
        countField: 'signOff',
        nameField: 'detailedName',
      }),
    ),
  },
];

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export interface StatusSummary {
  completed: number;
  completedPercent: number;
  processing: number;
  pending?: number;
  notStarted: number;
  noData: number;
  failed: number;
  total: number;
}

type OverallStatusSummary = Pick<StatusSummary, 'completed' | 'completedPercent' | 'total'>;
export type SignOffStatusSummary = Required<
  Pick<StatusSummary, 'completed' | 'completedPercent' | 'total' | 'noData' | 'pending'>
>;

export interface RiskContainerStatus {
  id: string;
  containerId: string;
  name: string;
  isSignOffRequired: boolean;

  cube: StatusSummary;
  subCube: StatusSummary;
  fvaCube: StatusSummary;
  fvaSubCube: StatusSummary;
  rdw: StatusSummary;

  overall: OverallStatusSummary;
  signOff: SignOffStatusSummary;
}

export interface RiskContainerStatusesQueryResponse {
  RiskContainerStatuses: RiskContainerStatus[];
}

export const GQL_RISK_CONTAINER_STATUSES = gql`
  query RiskContainerStatuses(
    $nodeId: ID!
    $date: Date!
    $snapshot: String!
    $reportTypeIds: [ID]
    $sourceSystemIds: [ID]
    $sourceSystemEnvironments: [String]
  ) {
    RiskContainerStatuses(
      nodeId: $nodeId
      date: $date
      snapshot: $snapshot
      reportTypeIds: $reportTypeIds
      sourceSystemIds: $sourceSystemIds
      sourceSystemEnvironments: $sourceSystemEnvironments
    ) {
      id
      containerId
      name
      isSignOffRequired

      cube {
        ...StatusSummary
      }
      subCube {
        ...StatusSummary
      }
      fvaCube {
        ...StatusSummary
      }
      fvaSubCube {
        ...StatusSummary
      }
      rdw {
        ...StatusSummary
      }

      overall {
        hasFailures
        completed
        completedPercent
        total
      }

      signOff {
        completed
        completedPercent
        pending
        noData
        total
      }
    }
  }

  fragment StatusSummary on StatusSummary {
    completed
    completedPercent
    processing
    notStarted
    noData
    failed
    total
  }
`;

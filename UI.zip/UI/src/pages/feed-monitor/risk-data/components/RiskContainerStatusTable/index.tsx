import React, { useMemo, useState } from 'react';
import Grid, { ColumnProps, GridExternalState } from '@/components/Grid';

import { getSelectionColumn } from '@/components/Grid/selection/getSelectionColumn';
import SearchField from '@/components/SearchField';
import { CardTopBar, AccentGroup } from '@/components/Card/CardAccents';
import SimpleDropdown from '@/components/SimpleDropdown';
import { Button, Icon, Menu } from 'antd';
import { ExternalisedStateProps } from '@/types/externalised-state';
import classNames from 'classnames';
import { debounce } from 'lodash';

import { RiskContainerStatus, RiskContainerStatusesQueryResponse } from './query';
import { columns, CONTAINER_STATUS_FIELD, StatusNameMap } from './columns';
import styles from './RiskContainerStatusTable.less';

const switchListOrder = [
  CONTAINER_STATUS_FIELD.OVERALL,
  CONTAINER_STATUS_FIELD.CUBE,
  CONTAINER_STATUS_FIELD.SUBCUBE,
  CONTAINER_STATUS_FIELD.RDW,
];

enum Filter {
  HideEmpty = 'hideEmpty',
  HidePending = 'hidePending',
  HideCompleted = 'hideCompleted',
}

export interface RiskContainerStatusTableExternalState extends GridExternalState {
  searchValue?: string;
  selectedFilters?: Filter[];
  selectedColumn?: CONTAINER_STATUS_FIELD;
}

export interface RiskContainerStatusTableProps
  extends ExternalisedStateProps<RiskContainerStatusTableExternalState> {
  loading: boolean;
  nodeName: string;
  data?: RiskContainerStatusesQueryResponse['RiskContainerStatuses'];
  value?: string[];
  onChange: (value: string[]) => void;
  disabled?: boolean;
}

type RiskContainerFilterFunction = (
  data: RiskContainerStatus[],
  statusField: CONTAINER_STATUS_FIELD,
) => RiskContainerStatus[];

const filters: Record<Filter, RiskContainerFilterFunction> = {
  [Filter.HideEmpty]: (data, statusField) => data.filter((row) => row[statusField].total > 0),
  [Filter.HidePending]: (data, statusField) =>
    data.filter((row) => row[statusField].completed === row[statusField].total),
  [Filter.HideCompleted]: (data, statusField) =>
    data.filter(
      (row) =>
        row[statusField].completed !== row[statusField].total || row[statusField].total === 0,
    ),
};

const RiskContainerStatusTable: React.FC<RiskContainerStatusTableProps> = ({
  nodeName,
  data,
  loading,
  externalState,
  setExternalState,
  value,
  onChange,
  disabled,
}) => {
  const {
    selectedFilters = [Filter.HideEmpty],
    selectedColumn = CONTAINER_STATUS_FIELD.OVERALL,
    searchValue = '',
  } = externalState;

  const switchedColumns = useMemo<ColumnProps[]>(
    () =>
      columns.map((column) => ({
        ...column,
        hidden:
          typeof column.hidden === 'undefined'
            ? undefined
            : column.field?.split('.')[0] !== selectedColumn,
      })),
    [selectedColumn],
  );

  const extendedData = useMemo(() => {
    if (!data) {
      return [];
    }

    return data.map((container) => ({
      detailedName: `${nodeName} - ${container.name}`,
      ...container,
      signOff: {
        ...container.signOff,
        completedPercent:
          !container.isSignOffRequired && container.signOff.completedPercent === 0
            ? -1
            : container.signOff.completedPercent,
      },
    }));
  }, [data, nodeName]);

  const statusFilteredData = useMemo(
    () =>
      selectedFilters
        .map((selectedFilter) => filters[selectedFilter])
        .reduce<RiskContainerStatus[]>(
          (filteredData, filter) => filter(filteredData, selectedColumn),
          extendedData,
        ),
    [extendedData, selectedFilters, selectedColumn],
  );

  const upperCaseSearchValue = searchValue.toUpperCase();
  const nameFilteredData = useMemo(
    () =>
      !upperCaseSearchValue
        ? statusFilteredData
        : statusFilteredData.filter((container) =>
            container.name.toUpperCase().includes(upperCaseSearchValue),
          ),
    [upperCaseSearchValue, statusFilteredData],
  );

  const columnsWithSelector = useMemo<ColumnProps[]>(
    () => [
      getSelectionColumn({
        identifier: 'containerId',
        selected: value,
        onChange,
        disabled,
      }),
      ...switchedColumns,
    ],
    [switchedColumns, value, onChange, disabled],
  );

  const [filterMenuOpen, setFilterMenuOpen] = useState(false);
  const [columnSelectMenuOpen, setColumnSelectMenuOpen] = useState(false);

  const filterMenu = (
    <div
      style={{
        overflow: 'auto',
        transform: 'translateZ(0)',
      }}
    >
      <Menu
        className={styles.slimMenu}
        selectable
        multiple
        selectedKeys={selectedFilters}
        onSelect={({ key }) => {
          setExternalState({
            selectedFilters: [...selectedFilters, key as Filter],
          });
        }}
        onDeselect={({ key }) => {
          setExternalState({
            selectedFilters: selectedFilters.filter((storedKey) => storedKey !== key),
          });
        }}
      >
        <Menu.Item key={Filter.HideEmpty}>
          <Icon type={selectedFilters.includes(Filter.HideEmpty) ? 'check' : 'none'} />
          Hide containers without data
        </Menu.Item>
        <Menu.Item key={Filter.HidePending}>
          <Icon type={selectedFilters.includes(Filter.HidePending) ? 'check' : 'none'} />
          Hide pending containers
        </Menu.Item>
        <Menu.Item key={Filter.HideCompleted}>
          <Icon type={selectedFilters.includes(Filter.HideCompleted) ? 'check' : 'none'} />
          Hide completed containers
        </Menu.Item>
      </Menu>
    </div>
  );

  const columnSelectMenu = (
    <div
      style={{
        overflow: 'auto',
        transform: 'translateZ(0)',
      }}
    >
      <Menu
        className={styles.slimMenu}
        selectable
        selectedKeys={selectedFilters}
        onSelect={({ key }) => {
          setExternalState({
            selectedColumn: key as CONTAINER_STATUS_FIELD,
          });
          setColumnSelectMenuOpen(false);
        }}
      >
        {switchListOrder.map((field) => (
          <Menu.Item key={field}>
            <Icon type={selectedColumn === field ? 'check' : 'none'} />
            Show {StatusNameMap[field].long.toLowerCase()} load status
          </Menu.Item>
        ))}
      </Menu>
    </div>
  );

  return (
    <div className={styles.riskContainerStatusTable}>
      <CardTopBar>
        <AccentGroup style={{ marginRight: '5px' }}>
          <SimpleDropdown
            menu={columnSelectMenu}
            open={columnSelectMenuOpen}
            onOpenChange={(open) => {
              setColumnSelectMenuOpen(open);
            }}
          >
            <Button size="small" title="Switch visible status" type="default">
              <Icon type="file-text" />
              <Icon
                type="down"
                className={classNames(styles.dropdownIcon, {
                  [styles.dropdownIconOpen]: columnSelectMenuOpen,
                })}
              />
            </Button>
          </SimpleDropdown>
          <SimpleDropdown
            menu={filterMenu}
            multiple
            open={filterMenuOpen}
            onOpenChange={(open) => {
              setFilterMenuOpen(open);
            }}
          >
            <Button
              size="small"
              title="Filter containers"
              type={selectedFilters.length ? 'primary' : 'default'}
            >
              <Icon type="filter" />
              <Icon
                type="down"
                className={classNames(styles.dropdownIcon, {
                  [styles.dropdownIconOpen]: filterMenuOpen,
                })}
              />
            </Button>
          </SimpleDropdown>
        </AccentGroup>
        <AccentGroup style={{ flex: '1 1 75px' }} align="right">
          <SearchField
            className={{
              searchField: styles.searchField,
              searchControls: styles.searchControls,
              searchInput: styles.searchInput,
            }}
            value={searchValue}
            onChange={debounce((searchText) => setExternalState({ searchValue: searchText }), 300)}
            disabled={loading}
            placeholder="Search"
            onCancel={() => {
              setExternalState({ searchValue: '' });
            }}
            cancelDisabled={!searchValue?.length}
          />
        </AccentGroup>
      </CardTopBar>
      <Grid
        loading={loading}
        data={nameFilteredData ?? []}
        idField="containerId"
        columns={columnsWithSelector}
        externalState={externalState}
        setExternalState={setExternalState}
        style={{ height: '100%' }}
        rowHeight={26}
      />
    </div>
  );
};

export default RiskContainerStatusTable;

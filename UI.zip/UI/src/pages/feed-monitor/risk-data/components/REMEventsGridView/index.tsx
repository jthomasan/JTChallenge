import React from 'react';
import { useQuery, gql } from 'umi-plugin-apollo-anz/apolloClient';
import Window from '@/components/Window';
import Grid from '@/components/Grid';
import { columns } from './column';
import { REMEvent } from './types';

import styles from './index.less';

const QUERY = gql`
  query FeedREMEvents($feedIDs: [ID]!) {
    FeedREMEvents(feedIDs: $feedIDs) {
      id
      feedID
      historyID
      payloadID
      sourceSystemEnvironment
      returnCode
      stateCode
      statusLog
      exceptionLog
      addedTime
    }
  }
`;

interface REMEventsGridViewProps {
  ids: string[];
  onClose: () => void;
}

const REMEventsGridView: React.FC<REMEventsGridViewProps> = ({ ids, onClose }) => {
  const { loading, data } = useQuery<{ FeedREMEvents: REMEvent[] }>(QUERY, {
    variables: {
      feedIDs: ids,
    },
    fetchPolicy: 'no-cache',
  });

  const remEventsData = data?.FeedREMEvents ?? [];

  return (
    <Window
      title={`Rem Event Details - ${ids.join(', ')}`}
      initialHeight={600}
      initialWidth={1100}
      minHeight={550}
      minWidth={550}
      onClose={onClose}
    >
      <div className={styles.remEventsGridViewHolder}>
        <Grid
          loading={loading}
          data={remEventsData}
          groupable
          columns={columns}
          style={{ height: '100%' }}
          showColumnVisibility
          rowHeight={26}
        />
      </div>
    </Window>
  );
};

export default REMEventsGridView;

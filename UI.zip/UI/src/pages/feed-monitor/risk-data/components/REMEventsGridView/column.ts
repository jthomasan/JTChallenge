import { ColumnProps } from '@/components/Grid';
import { DATE_FORMATS } from '@/utils/date';

export const columns: ColumnProps[] = [
  {
    field: 'id',
    title: 'Event Detail ID',
    filter: 'text',
    width: '130px',
  },
  {
    field: 'historyID',
    title: 'History ID',
    filter: 'text',
    width: '100px',
  },
  {
    field: 'sourceSystemEnvironment',
    title: 'Source System',
    filter: 'text',
    width: '120px',
  },
  {
    field: 'stateCode',
    title: 'State Code',
    filter: 'text',
    width: '120px',
  },
  {
    field: 'returnCode',
    title: 'Return Code',
    filter: 'text',
    width: '120px',
  },
  {
    field: 'statusLog',
    title: 'Status Log',
    filter: 'text',
    width: '140px',
  },
  {
    field: 'exceptionLog',
    title: 'Exception Log',
    filter: 'text',
    width: '200px',
  },
  {
    field: 'addedTime',
    title: 'Added Time',
    filter: 'date',
    defaultSortColumn: true,
    width: '150px',
    format: DATE_FORMATS.DATE_TIME,
  },
  {
    field: 'payloadID',
    title: 'Payload ID',
    filter: 'text',
    width: '220px',
  },
  {
    field: 'feedID',
    title: 'Feed ID',
    filter: 'text',
    width: '100px',
    defaultGroupColumn: true,
  },
];

export interface REMEvent {
  id: string;
  feedID: string;
  historyID: string;
  payloadID: string;
  sourceSystemEnvironment: string;
  returnCode: string;
  stateCode: string;
  statusLog: string;
  exceptionLog: string;
  addedTime: string;
}

import React from 'react';

import { get } from 'lodash';
import Divider from '@/components/Divider';
import { TreeListCellProps } from '@/components/TreeList';
import Tooltip, { Title, Subtitle, CountTable, CountRow, CountCell } from '../RiskDataTooltip';

import styles from './OverallStatusSummaryTooltip.less';

import { FeedCount } from '../../../../types/hierarchyFeedStatus';

export const twoDP = (n: number) => Number(n).toFixed(2);

export const OverallStatusSummaryTooltip: React.FC<{
  counts: FeedCount;
  nodeName: string;
  statusName: string;
  version?: number;
}> = ({ counts, nodeName, statusName, version }) => {
  if (!counts) {
    return null;
  }

  return (
    <>
      <Title>{nodeName}</Title>
      <Subtitle>{statusName} </Subtitle>
      <div className={styles.percentage}>
        {twoDP(counts.overall.completedPercentage)}% feeds completed.
      </div>
      <div>
        {counts.overall.completed}/{counts.overall.total} feeds completed.
      </div>
      {version !== undefined ? (
        <div className={styles.version}>Latest version {version}</div>
      ) : null}
      <Divider orientation="horizontal" />
      <CountTable numberOfColumns={2}>
        <CountRow>
          <CountCell className={styles.countSystemName}>Risk Engine</CountCell>
          <CountCell>
            {counts.riskEngine ? <>{twoDP(counts.riskEngine.completedPercentage)}%</> : '-'}
          </CountCell>
        </CountRow>
        <CountRow>
          <CountCell className={styles.countSystemName}>Download</CountCell>
          <CountCell>
            {counts.download ? <>{twoDP(counts.download.completedPercentage)}%</> : '-'}
          </CountCell>
        </CountRow>
        <CountRow>
          <CountCell className={styles.countSystemName}>ETL</CountCell>
          <CountCell>
            {counts.cubeTradeEtl ? <>{twoDP(counts.cubeTradeEtl.completedPercentage)}%</> : '-'}
          </CountCell>
        </CountRow>
        <CountRow>
          <CountCell className={styles.countSystemName}>Cube</CountCell>
          <CountCell>
            {counts.cubeLoad ? <>{twoDP(counts.cubeLoad.completedPercentage)}%</> : '-'}
          </CountCell>
        </CountRow>
        <CountRow>
          <CountCell className={styles.countSystemName}>Subcube</CountCell>
          <CountCell>
            {counts.subCubeLoad ? <>{twoDP(counts.subCubeLoad.completedPercentage)}%</> : '-'}
          </CountCell>
        </CountRow>
        <CountRow>
          <CountCell className={styles.countSystemName}>RDW</CountCell>
          <CountCell>{counts.rdw ? <>{twoDP(counts.rdw.completedPercentage)}%</> : '-'}</CountCell>
        </CountRow>
      </CountTable>
    </>
  );
};

export const withOverallStatusSummaryTooltip = (
  Component: React.ComponentType<TreeListCellProps>,
  {
    countField,
    nameField,
    statusName,
    versionField,
  }: {
    countField: string;
    nameField: string;
    versionField?: string;
    statusName: string;
  },
): React.FC<TreeListCellProps> => (props) => {
  const counts = get(props.dataItem, countField) as FeedCount;
  const nodeName = get(props.dataItem, nameField) as string;
  const version = versionField ? (get(props.dataItem, versionField) as number) : undefined;

  return (
    <Tooltip
      title={
        counts?.overall ? (
          <OverallStatusSummaryTooltip
            counts={counts}
            nodeName={nodeName}
            statusName={statusName}
            version={version}
          />
        ) : null
      }
    >
      <Component {...props} />
    </Tooltip>
  );
};

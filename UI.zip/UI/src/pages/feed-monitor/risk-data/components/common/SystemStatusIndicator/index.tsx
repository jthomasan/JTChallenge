import React from 'react';
import { filterTooltipProps } from '@/components/Tooltip';
import { StatusColorPalette } from '../../../types/status';

import styles from './index.less';

interface SystemStatusIndicatorProps {
  value: string;
}

const SystemStatusIndicator: React.FC<SystemStatusIndicatorProps> = ({ value, ...props }) => (
  <div {...filterTooltipProps(props)} className={styles.container}>
    <div className={styles.label} style={{ backgroundColor: StatusColorPalette[value] }} />
    <div className={styles.content}>{value}</div>
  </div>
);

export default SystemStatusIndicator;

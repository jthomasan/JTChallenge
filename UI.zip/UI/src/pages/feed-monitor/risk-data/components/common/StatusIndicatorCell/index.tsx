import React from 'react';
import { get } from 'lodash';
import { CellProps } from '@/components/Grid';
import { TreeListCellProps } from '@/components/TreeList';
import { asCell } from '@/components/SimpleTD';
import { Status } from '../../../types/status';
import SystemStatusIndicator from '../SystemStatusIndicator';

export function StatusIndicatorCellInner<P extends CellProps | TreeListCellProps>(props: P) {
  const { dataItem, field = '' } = props;
  const value = Status[get(dataItem, field)];

  return value ? <SystemStatusIndicator {...(props as any)} value={value} /> : null;
}

const StatusIndicatorCell = asCell<any>(StatusIndicatorCellInner) as React.ComponentType<any>;
export default StatusIndicatorCell;

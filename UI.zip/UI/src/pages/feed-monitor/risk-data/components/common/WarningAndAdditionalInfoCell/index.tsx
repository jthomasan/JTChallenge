import React from 'react';
import SimpleTD from '@/components/SimpleTD';
import get from 'lodash/get';
import { CellProps } from '@/components/Grid';
import { ExclamationCircleFilled } from '@ant-design/icons';
import { TreeListCellProps } from '@/components/TreeList';
import Tooltip, { Subtitle, Title } from '../Tooltips/RiskDataTooltip';

import styles from './WarningAndAdditionalInfoCell.less';

export const generateWarningAndAdditionalInfoCell: (extraProperties: {
  additionalInfoField: string;
  additionalInfoShortRegex?: string | RegExp;
  nameField: string;
  tooltipSubtitle: string;
}) => React.FC<Pick<CellProps | TreeListCellProps, 'field' | 'dataItem'>> = ({
  additionalInfoField,
  additionalInfoShortRegex,
  nameField,
  tooltipSubtitle,
}) =>
  function WarningAndAdditionalInfoCell({ field, dataItem, children: _, ...props }) {
    if (!field) {
      return <SimpleTD {...props} />;
    }

    const value = get(dataItem, field) as boolean;
    if (!value) {
      return <SimpleTD {...props} />;
    }

    const additionalInfo: string = get(dataItem, additionalInfoField);
    const shortAdditionalInfo =
      additionalInfo && additionalInfoShortRegex
        ? additionalInfo.match(additionalInfoShortRegex)?.[1] ?? additionalInfo
        : additionalInfo;

    return (
      <SimpleTD {...props}>
        <Tooltip
          title={
            <>
              <Title>{get(dataItem, nameField)}</Title>
              <Subtitle>{tooltipSubtitle}</Subtitle>
              <div>{additionalInfo}</div>
            </>
          }
        >
          <div>
            <ExclamationCircleFilled className={styles.icon} />
            {shortAdditionalInfo}
          </div>
        </Tooltip>
      </SimpleTD>
    );
  };

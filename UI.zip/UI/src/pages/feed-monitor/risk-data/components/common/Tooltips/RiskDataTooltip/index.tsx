import React from 'react';
import classNames from 'classnames';
import Tooltip, { TooltipProps } from '@/components/Tooltip';

import styles from './RiskDataTooltip.less';

export const Title = 'h1';
export const Subtitle = 'h2';
export const CountRow = 'tr';
export const CountCell = 'td';
export const CountTable: React.FC<{ className?: string; numberOfColumns: number }> = ({
  children,
  className,
  numberOfColumns,
  ...props
}) => {
  const cols = [];
  for (let i = 0; i < numberOfColumns; i += 1) {
    cols.push(<col key={i} />);
  }

  return (
    <table className={classNames(styles.count, className)} {...props}>
      <colgroup>{cols}</colgroup>
      <tbody>{children}</tbody>
    </table>
  );
};

const RiskDataTooltip: React.FC<TooltipProps> = ({ children, title, ...props }) => (
  <Tooltip title={<div className={styles.riskDataTooltip}>{title}</div>} {...props}>
    {children}
  </Tooltip>
);

export default RiskDataTooltip;

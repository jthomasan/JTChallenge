import React from 'react';
import classnames from 'classnames';
import { get } from 'lodash';
import SimpleTD from '@/components/SimpleTD';
import { CellProps } from '@/components/Grid';
import { TreeListCellProps } from '@/components/TreeList';

import styles from './index.less';

const CheckboxCell: React.FC<CellProps | TreeListCellProps> = (props) => {
  const { dataItem, field = '' } = props;
  const value = get(dataItem, field);

  return (
    <SimpleTD {...props} className={styles.checkboxCell}>
      <span className={classnames(styles.selectableCell, { [styles.selected]: value })}></span>
    </SimpleTD>
  );
};

export default CheckboxCell;

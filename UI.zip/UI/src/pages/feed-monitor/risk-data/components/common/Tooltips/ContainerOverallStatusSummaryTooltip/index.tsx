import React from 'react';

import { get } from 'lodash';
import { CellProps } from '@/components/Grid';
import Tooltip, { Title, Subtitle } from '../RiskDataTooltip';

import styles from './ContainerOverallStatusSummaryTooltip.less';
import {
  RiskContainerStatus,
  StatusSummary,
  SignOffStatusSummary,
} from '../../../RiskContainerStatusTable/query';
import { twoDP } from '../OverallStatusSummaryTooltip';
import { CountsSummary } from '../StatusSummaryTooltip';

const OverallSummarySection: React.FC<{
  name: string;
  counts: StatusSummary | SignOffStatusSummary;
  fvaCounts?: StatusSummary | SignOffStatusSummary;
}> = ({ name, counts, fvaCounts }) => (
  <>
    <Subtitle>
      {`${name} `}
      <span className={styles.percentage}>{twoDP(counts.completedPercent)}%</span>
    </Subtitle>
    <CountsSummary counts={counts} fvaCounts={fvaCounts} />
  </>
);

export const ContainerOverallStatusSummaryTooltip: React.FC<{
  counts: RiskContainerStatus;
  nodeName: string;
}> = ({ counts, nodeName }) => {
  if (!counts) {
    return null;
  }

  return (
    <>
      <Title>{nodeName}</Title>
      <OverallSummarySection
        name="Cube Load Status"
        counts={counts.cube}
        fvaCounts={counts.fvaCube}
      />
      <OverallSummarySection
        name="Subcube Load Status"
        counts={counts.subCube}
        fvaCounts={counts.fvaSubCube}
      />
      <OverallSummarySection name="Risk Data Warehouse Load Status" counts={counts.rdw} />
      {counts.isSignOffRequired || counts.signOff.completedPercent >= 0 ? (
        <OverallSummarySection name="Signoff Status" counts={counts.signOff} />
      ) : null}
    </>
  );
};

export const withContainerOverallStatusSummaryTooltip = (
  Component: React.ElementType<CellProps | any>,
  {
    nameField,
  }: {
    nameField: string;
  },
): React.FC<CellProps> => (props) => {
  const nodeName = get(props.dataItem, nameField) as string;

  return (
    <Tooltip
      title={
        props.dataItem?.overall ? (
          <ContainerOverallStatusSummaryTooltip counts={props.dataItem} nodeName={nodeName} />
        ) : null
      }
    >
      <Component {...props} />
    </Tooltip>
  );
};

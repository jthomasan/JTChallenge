import React from 'react';
import { ExclamationCircleFilled } from '@ant-design/icons';
import { CellProps } from '@/components/Grid';
import { TreeListCellProps } from '@/components/TreeList';
import { asCell } from '@/components/SimpleTD';
import { SourceSystemError } from '../../FeedStatusContainer';
import Tooltip from '../Tooltips/RiskDataTooltip';
import { NodeType } from '../../FeedStatusContainer/types';
import { StatusIndicatorCellInner } from '../StatusIndicatorCell';
import { StatusSummaryTooltipInner } from '../Tooltips/StatusSummaryTooltip';

import styles from './index.less';

export interface SourceSystemStatusCellProps {
  onSelectSourceSystemError: (params: Omit<SourceSystemError, 'cob' | 'snapshot'>) => void;
}

interface SourceSystemErrorDownloadProps {
  onSelect: () => void;
}

const SourceSystemErrorDownload: React.FC<SourceSystemErrorDownloadProps & { dataItem: any }> = ({
  dataItem,
  onSelect,
}) => {
  let title: React.ReactNode = 'Pricing Error';

  if (dataItem.counts) {
    title = (
      <StatusSummaryTooltipInner
        counts={dataItem.counts.riskEngineError}
        nodeName={dataItem.name}
        statusName="Pricing Error Status"
      />
    );
  }

  return (
    <Tooltip title={title}>
      <div className={styles.sourceSystemErrorDownloadContainer} onClick={onSelect}>
        <ExclamationCircleFilled />
      </div>
    </Tooltip>
  );
};

export const withSourceSystemErrorDownload = <P extends CellProps | TreeListCellProps>(
  Component: React.ComponentType<P>,
  {
    onSelectSourceSystemError,
  }: {
    onSelectSourceSystemError: (params: Omit<SourceSystemError, 'cob' | 'snapshot'>) => void;
  },
): React.FC<P & JSX.IntrinsicAttributes> => (props) => {
  const { dataItem } = props;
  const { type, feed, portfolio, reportName } = dataItem;
  const isPortfolioNode = type === NodeType.PORTFOLIO_NODE;
  const hasSourceSystemError = feed?.hasSourceSystemError ?? dataItem.hasSourceSystemError;
  const portfolioName = portfolio?.name ?? dataItem.name;

  return (
    <div className={styles.sourceSystemStatusCell}>
      <Component {...props} />
      {hasSourceSystemError && (
        <SourceSystemErrorDownload
          dataItem={dataItem}
          onSelect={() => {
            onSelectSourceSystemError({
              isPortfolioNode,
              portfolioNode: portfolioName,
              reportName,
            });
          }}
        />
      )}
    </div>
  );
};

const generateSourceSystemStatusCell = <P extends CellProps | TreeListCellProps>({
  onSelectSourceSystemError,
}: SourceSystemStatusCellProps) =>
  asCell(
    withSourceSystemErrorDownload<P>(StatusIndicatorCellInner, {
      onSelectSourceSystemError,
    }),
  );

export default generateSourceSystemStatusCell;

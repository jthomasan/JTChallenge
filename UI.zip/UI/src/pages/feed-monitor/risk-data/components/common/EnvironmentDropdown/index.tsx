import React, { useEffect, useRef } from 'react';
import { isEqual } from 'lodash';
import MultiSelect from '@/components/MultiSelect';
import Tooltip from '../Tooltips/RiskDataTooltip';
import useGetSourceSystems from '../../UserRequest/hooks/useGetSourceSystems';

export interface EnvironmentOptions {
  id: string;
  text: string;
}

interface EnvironmentDropdownProps {
  disabled: boolean | undefined;
  sourceSystem: number | number[];
  snapshot: string;
  value: EnvironmentOptions[] | null;
  placeholder?: string;
  style?: React.CSSProperties;
  onChange: (value: EnvironmentOptions[] | null) => void;
}

const EnvironmentDropdown: React.FC<EnvironmentDropdownProps> = ({
  disabled,
  placeholder,
  style = { width: '100%' },
  sourceSystem,
  snapshot,
  value,
  onChange,
}) => {
  const { loading, getSourceSystemEnvironments } = useGetSourceSystems();
  const options = getSourceSystemEnvironments(sourceSystem, snapshot);
  const sourceSystemRef = useRef<number | number[]>();
  const snapshotRef = useRef<string>('');

  useEffect(() => {
    if (!isEqual(sourceSystem, sourceSystemRef.current) || snapshot !== snapshotRef.current) {
      sourceSystemRef.current = sourceSystem;
      snapshotRef.current = snapshot;
      onChange(null);
    }
  }, [sourceSystem, snapshot]);

  return (
    <Tooltip
      title={value?.map((item) => (
        <div>{item.id}</div>
      ))}
    >
      <MultiSelect<EnvironmentOptions>
        disabled={disabled || loading}
        multiple
        style={style}
        placeholder={!loading ? placeholder ?? 'All Environments' : 'Loading...'}
        size="small"
        dropdownMatchSelectWidth={false}
        options={options}
        value={value ?? []}
        onChange={onChange}
      />
    </Tooltip>
  );
};

export default EnvironmentDropdown;

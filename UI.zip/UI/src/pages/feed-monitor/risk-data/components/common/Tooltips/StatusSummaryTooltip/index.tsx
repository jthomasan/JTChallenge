import React from 'react';

import Divider from '@/components/Divider';
import { TreeListCellProps } from '@/components/TreeList';
import { get } from 'lodash';
import { CellProps } from '@/components/Grid';

import styles from './StatusSummaryTooltip.less';
import Tooltip, { Title, Subtitle, CountTable, CountRow, CountCell } from '../RiskDataTooltip';

import { StatusNameColorPalette, Status } from '../../../../types/status';
import { FeedCountDetail } from '../../../../types/hierarchyFeedStatus';
import { twoDP } from '../OverallStatusSummaryTooltip';
import { StatusSummary, SignOffStatusSummary } from '../../../RiskContainerStatusTable/query';

type Counts = FeedCountDetail | StatusSummary | SignOffStatusSummary;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type CountsKeys = KeysOfUnion<Counts>;

type StatusesForDisplay =
  | Status.COMPLETE
  | Status.PENDING
  | Status.NO_DATA
  | Status.NOT_STARTED
  | Status.PROCESSING
  | Status.FAILED;

const statusToName: Record<StatusesForDisplay, string> = {
  [Status.COMPLETE]: 'Completed',
  [Status.PENDING]: 'Pending',
  [Status.NO_DATA]: 'No Data',
  [Status.NOT_STARTED]: 'Not Started',
  [Status.PROCESSING]: 'Processing',
  [Status.FAILED]: 'Failed',
};

const statusToCount: Record<StatusesForDisplay, CountsKeys> = {
  [Status.COMPLETE]: 'completed',
  [Status.PENDING]: 'pending',
  [Status.NO_DATA]: 'noData',
  [Status.NOT_STARTED]: 'notStarted',
  [Status.PROCESSING]: 'processing',
  [Status.FAILED]: 'failed',
};

const StatusSpan: React.FC<{ status: Status }> = ({ status, children }) => (
  <span style={{ color: StatusNameColorPalette[status] }}>{children}</span>
);

const CountsSummaryRow: React.FC<{
  status: Status;
  counts: Counts;
  fvaCounts?: Counts;
}> = ({ status, counts, fvaCounts }) => {
  const count = counts[statusToCount[status]];
  if (count === null || count === undefined) {
    return null;
  }

  return (
    <CountRow>
      <CountCell className={styles.countSystemName}>
        <StatusSpan status={status}>{statusToName[status]}:</StatusSpan>
      </CountCell>
      <CountCell>{count}</CountCell>
      {fvaCounts !== undefined ? (
        <CountCell>{`(FVA: ${fvaCounts[statusToCount[status]]})`}</CountCell>
      ) : null}
    </CountRow>
  );
};

export const CountsSummary: React.FC<{
  counts: Counts;
  fvaCounts?: Counts;
}> = ({ counts, fvaCounts }) => (
  <CountTable numberOfColumns={fvaCounts === undefined ? 2 : 3}>
    <CountsSummaryRow status={Status.COMPLETE} counts={counts} fvaCounts={fvaCounts} />
    <CountsSummaryRow status={Status.PENDING} counts={counts} fvaCounts={fvaCounts} />
    <CountsSummaryRow status={Status.NO_DATA} counts={counts} fvaCounts={fvaCounts} />
    <CountsSummaryRow status={Status.NOT_STARTED} counts={counts} fvaCounts={fvaCounts} />
    <CountsSummaryRow status={Status.PROCESSING} counts={counts} fvaCounts={fvaCounts} />
    <CountsSummaryRow status={Status.FAILED} counts={counts} fvaCounts={fvaCounts} />
  </CountTable>
);

export const StatusSummaryTooltipInner: React.FC<{
  counts: Counts;
  fvaCounts?: Counts;
  nodeName: string;
  statusName: string;
  version?: number;
}> = ({ counts, fvaCounts, nodeName, statusName, version }) => {
  if (!counts) {
    return null;
  }

  return (
    <>
      <Title>{nodeName}</Title>
      <Subtitle>{statusName}</Subtitle>
      <div className={styles.percentage}>
        {twoDP(counts['completedPercentage'] ?? counts['completedPercent'])}% done.
      </div>
      <div>
        {counts.completed}/{counts.total} feeds completed.
      </div>
      {version !== undefined ? (
        <div className={styles.version}>Latest version {version}</div>
      ) : null}
      <Divider orientation="horizontal" />
      <CountsSummary counts={counts} fvaCounts={fvaCounts} />
    </>
  );
};

export const withStatusSummaryTooltip = <P extends CellProps | TreeListCellProps>(
  Component: React.ElementType<P | any>,
  {
    nameField,
    countField,
    fvaCountField,
    statusName,
    versionField,
  }: {
    nameField: string;
    countField: string;
    fvaCountField?: string;
    versionField?: string;
    statusName: string;
  },
): React.FC<P & JSX.IntrinsicAttributes> => (props) => {
  const counts = get(props.dataItem, countField) as Counts;
  const fvaCounts = fvaCountField ? (get(props.dataItem, fvaCountField) as Counts) : undefined;
  const nodeName = get(props.dataItem, nameField) as string;
  const version = versionField ? (get(props.dataItem, versionField) as number) : undefined;

  return (
    <Tooltip
      title={
        counts ? (
          <StatusSummaryTooltipInner
            nodeName={nodeName}
            counts={counts}
            fvaCounts={fvaCounts}
            statusName={statusName}
            version={version}
          />
        ) : null
      }
    >
      <Component {...props} />
    </Tooltip>
  );
};

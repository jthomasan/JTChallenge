import React from 'react';
import { get } from 'lodash';
import { TreeListCellProps } from '@progress/kendo-react-treelist';
import { asCell } from '@/components/SimpleTD';
import StatusProgress from '../StatusProgress';

export const ProgressIndicator: React.FC<TreeListCellProps> = ({
  dataItem,
  field = '',
  ...props
}) => {
  const { feed } = dataItem;
  const percentage = get(dataItem, field);

  return feed ? <StatusProgress percentage={percentage} {...props} /> : null;
};

export default asCell(ProgressIndicator);

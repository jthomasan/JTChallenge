import React, { useCallback } from 'react';
import classNames from 'classnames';
import { ArrowRightOutlined } from '@ant-design/icons';
import { AntdIconProps } from '@ant-design/icons/lib/components/AntdIcon';

import { CellProps } from '@/components/Grid';
import { TreeListCellProps } from '@/components/TreeList';

import Tooltip from '@/components/Tooltip';
import styles from './SelectionArrow.less';

export const SelectionArrow: React.FC<{ onSelect: () => void; title?: string } & Omit<
  AntdIconProps,
  'onClick' | 'ref'
>> = ({ onSelect, title = 'Select', className, ...props }) => (
  <Tooltip title={title} mouseEnterDelay={0.4}>
    <ArrowRightOutlined
      {...props}
      onClick={onSelect}
      className={classNames(className, styles.selectionArrow)}
    />
  </Tooltip>
);

export const withSelectionArrow = <P extends CellProps | TreeListCellProps>(
  Component: React.ComponentType<P>,
  {
    onSelect,
  }: {
    onSelect: (dataItem: P['dataItem']) => void;
  },
): React.FC<P & JSX.IntrinsicAttributes> => (props) => {
  const { dataItem } = props;
  const onSelectWithData = useCallback(() => onSelect(dataItem), [dataItem]);

  return (
    <div className={styles.selectionArrowCellWrapper}>
      <Component {...props} />
      <SelectionArrow onSelect={onSelectWithData} />
    </div>
  );
};

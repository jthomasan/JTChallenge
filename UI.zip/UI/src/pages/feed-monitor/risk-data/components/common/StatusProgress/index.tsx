import React from 'react';
import classnames from 'classnames';
import { filterTooltipProps } from '@/components/Tooltip';

import styles from './index.less';

export interface StatusProgressProps {
  percentage: number;
  hasError?: boolean;
}

const StatusProgress: React.FC<StatusProgressProps> = ({
  percentage,
  hasError = false,
  ...props
}) => (
  <div
    {...filterTooltipProps(props)}
    className={classnames(styles.statusPercentage, { [styles.hasError]: hasError })}
  >
    <span className={styles.bar} style={{ width: `${percentage}%` }} />
    {Math.round((percentage ?? 0) * 100) / 100}%
  </div>
);

export default StatusProgress;

import React, { useState, useEffect, useRef } from 'react';
import { isEqual } from 'lodash';
import classnames from 'classnames';
import { ExclamationCircleFilled } from '@ant-design/icons';

import styles from './index.less';

export interface ErrorEntities {
  [name: string]: boolean;
}

interface ValidatorResponse {
  message: string;
  hasErrors: boolean;
}

type Validator<T> = (params: T) => ValidatorResponse;

interface FormValidatorProps<T> {
  name: string;
  data: T;
  validators: Validator<T>[];
  children: React.ReactNode;
  showMessage: boolean;
  onUpdateErrors: (params: ErrorEntities) => void;
}

const FormValidator: <T>(props: FormValidatorProps<T>) => React.ReactElement<T> = ({
  name,
  data,
  validators,
  showMessage,
  onUpdateErrors,
  children,
}) => {
  const [validationInfo, setValidationInfo] = useState<ValidatorResponse | undefined>(
    validators.map((validator) => validator(data)).find((item) => item.hasErrors),
  );
  const cachedDataRef = useRef<unknown>(null);

  useEffect(() => {
    if (!isEqual(cachedDataRef.current, data)) {
      cachedDataRef.current = data;
      setValidationInfo(
        validators.map((validator) => validator(data)).find((item) => item.hasErrors),
      );
    }
  }, [data]);

  useEffect(() => {
    onUpdateErrors({ [name]: !!validationInfo?.hasErrors });
  }, [validationInfo]);

  return (
    <div
      className={classnames(styles.container, {
        [styles.hasError]: !!validationInfo?.hasErrors && showMessage,
      })}
    >
      {children}
      {!!validationInfo?.hasErrors && showMessage && (
        <div className={styles.errorMsgContainer}>
          <ExclamationCircleFilled />
          <span>{validationInfo.message}</span>
        </div>
      )}
    </div>
  );
};

export default FormValidator;

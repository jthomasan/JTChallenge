import { filterTooltipProps } from '@/components/Tooltip';
import React from 'react';
import styles from './index.less';

const StatusIndicator: React.FC<{ color: string }> = ({ color, children, ...props }) => (
  <span {...filterTooltipProps(props)} className={styles.statusIndicator}>
    {children}
    <span className={styles.statusBulb} style={{ backgroundColor: color }} />
  </span>
);

export default StatusIndicator;

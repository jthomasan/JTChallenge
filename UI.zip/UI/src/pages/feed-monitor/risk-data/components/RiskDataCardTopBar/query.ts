import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export interface SourceSystemStatusSummary {
  completed: number;
  completedPercent: number;

  notStarted: number;
  processing: number;
  failed: number;

  total: number;
}

export interface SourceSystemFeedStatus {
  id: string;
  sourceSystemId: string;
  name: string;
  allFeedsScheduled: boolean;

  cube: SourceSystemStatusSummary;
  subCube: SourceSystemStatusSummary;
  rdw: SourceSystemStatusSummary;

  cubeStatus: string;
  overallStatus: string;
}

export interface RiskDataTopBarQueryResponse {
  SourceSystemFeedStatuses: SourceSystemFeedStatus[];
}

export const RiskDataTopBarQuery = gql`
  query RiskDataTopBarQuery($nodeId: ID!, $cob: Date!, $snapshot: String) {
    SourceSystemFeedStatuses(nodeId: $nodeId, cob: $cob, snapshots: [$snapshot]) {
      id
      sourceSystemId
      name

      allFeedsScheduled

      cube {
        ...SourceSystemStatusSummary
      }

      subCube {
        ...SourceSystemStatusSummary
      }

      rdw {
        ...SourceSystemStatusSummary
      }

      cubeStatus
      overallStatus
    }
  }

  fragment SourceSystemStatusSummary on SourceSystemStatusSummary {
    completed
    completedPercent

    notStarted
    processing
    failed

    total
  }
`;

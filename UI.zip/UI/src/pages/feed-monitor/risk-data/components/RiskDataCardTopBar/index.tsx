import { useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import React from 'react';

import Divider from '@/components/Divider';
import LatestCOBCardTopBar from '@/components/LatestCOBCardTopBar';

import { RiskDataTopBarQuery, RiskDataTopBarQueryResponse } from './query';
import styles from './RiskDataCardTopBar.less';
import StatusIndicator from '../StatusIndicator';
import Tooltip from '../common/Tooltips/RiskDataTooltip';
import { Status, StatusColorPalette } from '../../types/status';
import { StatusSummaryTooltipInner } from '../common/Tooltips/StatusSummaryTooltip';

const RiskDataCardTopBar: React.FC<{
  nodeId: number;
  date: string;
  snapshot: string;
}> = ({ nodeId, date, snapshot }) => {
  const { data } = useQuery<RiskDataTopBarQueryResponse>(RiskDataTopBarQuery, {
    variables: {
      nodeId,
      cob: date,
      snapshot,
    },
  });

  return (
    <>
      <LatestCOBCardTopBar className={styles.cobDate} />
      {data?.SourceSystemFeedStatuses.map((sourceSystemFeedStatus) => (
        <React.Fragment key={sourceSystemFeedStatus.sourceSystemId}>
          <Divider />
          <Tooltip
            title={
              <StatusSummaryTooltipInner
                counts={sourceSystemFeedStatus.cube}
                nodeName={sourceSystemFeedStatus.name}
                statusName="Cube Load Status"
              />
            }
          >
            <StatusIndicator color={StatusColorPalette[Status[sourceSystemFeedStatus.cubeStatus]]}>
              {sourceSystemFeedStatus.name}
            </StatusIndicator>
          </Tooltip>
        </React.Fragment>
      ))}
    </>
  );
};

export default RiskDataCardTopBar;

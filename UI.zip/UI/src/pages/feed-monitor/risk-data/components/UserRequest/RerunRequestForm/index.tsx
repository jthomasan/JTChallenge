import React, { useEffect } from 'react';
import { Input } from 'antd';
import { isEmpty } from 'lodash';
import { SelectValue } from 'antd/lib/select';
import { FormProps, DefaultFormData } from '../UserRequestWindow';
import SnapshotDropdown from '../dropdowns/SnapshotDropdown';
import SourceSystemDropdown from '../dropdowns/SourceSystemDropdown';
import EnvironmentDropdown, { EnvironmentOptions } from '../../common/EnvironmentDropdown';
import FormValidator from '../../common/FormValidator';

import styles from './index.less';
import SelectedPortfolioList from '../SelectedPortfolioList';

export interface RerunRequestFormDataProps extends DefaultFormData {
  snapshot: string;
  sourceSystemId: number;
  sourceSystemEnvironments: string[] | null;
  comment?: string;
}

export interface RerunRequestFormProps extends FormProps<RerunRequestFormDataProps> {}

const RerunRequestForm: React.FC<RerunRequestFormProps> = ({
  showErrors,
  formData,
  selectedPortfolios,
  disabled,
  onSetFormData,
  onUpdateErrors,
}) => {
  useEffect(() => {
    if (isEmpty(formData)) {
      onSetFormData({
        snapshot: 'EOD',
        sourceSystemEnvironments: null,
      } as RerunRequestFormDataProps);
    }
  }, []);

  const onChangeSnapshot = (value: SelectValue) => {
    onSetFormData({
      snapshot: value as string,
    } as RerunRequestFormDataProps);
  };

  const onChangeSourceSystem = (value: SelectValue) => {
    onSetFormData({
      sourceSystemId: value,
    } as RerunRequestFormDataProps);
  };

  const onChangeEnvironments = (value: EnvironmentOptions[] | null) => {
    onSetFormData({
      sourceSystemEnvironments: value?.map((item) => item.id) ?? null,
    } as RerunRequestFormDataProps);
  };

  const onChangeUserComment = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    onSetFormData({
      comment: event.target.value,
    } as RerunRequestFormDataProps);
  };

  return (
    <div className={styles.rerunRequestForm}>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>Snapshot</span>
        </div>
        <div>
          <SnapshotDropdown
            disabled={disabled}
            value={formData.snapshot}
            onChange={onChangeSnapshot}
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>Source System</span>
        </div>
        <div>
          <SourceSystemDropdown
            disabled={disabled}
            value={formData.sourceSystemId}
            onChange={onChangeSourceSystem}
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>Environments</span>
        </div>
        <div>
          <EnvironmentDropdown
            disabled={disabled}
            sourceSystem={formData.sourceSystemId}
            snapshot={formData.snapshot}
            value={
              formData.sourceSystemEnvironments?.map((item) => ({ id: item, text: item })) ?? null
            }
            onChange={onChangeEnvironments}
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>User Comment</span>
        </div>
        <div>
          <FormValidator<string>
            name="comment"
            data={formData.comment ?? ''}
            showMessage={showErrors}
            validators={[
              (params) => {
                const isValid = params != null && params !== '';
                return { message: 'Please enter comment.', hasErrors: !isValid };
              },
            ]}
            onUpdateErrors={onUpdateErrors}
          >
            <Input.TextArea
              disabled={disabled}
              value={formData.comment}
              onChange={onChangeUserComment}
            />
          </FormValidator>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>Selected Portfolios ({selectedPortfolios.length})</span>
        </div>
        <div>
          <SelectedPortfolioList data={selectedPortfolios} />
        </div>
      </div>
    </div>
  );
};

export default RerunRequestForm;

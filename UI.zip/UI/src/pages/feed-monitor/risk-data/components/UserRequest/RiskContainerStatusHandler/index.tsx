import React, { useEffect, useMemo } from 'react';
import { keyBy } from 'lodash';
import { useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import RiskContainerStatusTable from '../../RiskContainerStatusTable';
import { GridProp } from '../UserRequestWindow';
import { SignOffRequestFormDataProps } from '../SignOffRequestForm';
import {
  RiskContainerStatusesQueryResponse,
  GQL_RISK_CONTAINER_STATUSES,
} from '../../RiskContainerStatusTable/query';

import styles from './index.less';
import FormValidator from '../../common/FormValidator';

export interface RiskContainerStatusExternalState
  extends GridProp<RiskContainerStatusExternalState, SignOffRequestFormDataProps> {
  selectedContainerIDs: string[];
}

export interface RiskContainerSelectionParams {
  containers: string[];
}

const RiskContainerStatusHandler: React.FC<RiskContainerStatusExternalState> = ({
  riskDataProps,
  showErrors,
  onUpdateErrors,
  selectedContainers,
  onDataReady,
  externalState,
  setExternalState,
  onChange,
}) => {
  const {
    nodeName,
    nodeId,
    date,
    snapshot,
    reportTypeIds,
    sourceSystemIds,
    sourceSystemEnvironments,
  } = riskDataProps;

  const { loading, data } = useQuery<RiskContainerStatusesQueryResponse>(
    GQL_RISK_CONTAINER_STATUSES,
    {
      fetchPolicy: 'no-cache',
      errorPolicy: 'none',
      variables: {
        nodeId,
        date,
        snapshot,
        reportTypeIds,
        sourceSystemIds,
        sourceSystemEnvironments,
      },
    },
  );
  const allContainers = data?.RiskContainerStatuses.filter((o) => o.isSignOffRequired) ?? [];
  const containersById = useMemo(() => keyBy(allContainers, 'containerId'), [allContainers]);
  const containers = useMemo(() => {
    if (!selectedContainers.length) {
      return allContainers;
    }

    return selectedContainers.filter((item) => containersById[item.id]);
  }, [containersById, selectedContainers]);

  useEffect(() => {
    onDataReady(!loading);
  }, [loading]);

  return (
    <div className={styles.riskContainerStatusHandler}>
      <div className={styles.gridTitle}>Select Containers</div>
      <FormValidator<string[]>
        showMessage={showErrors && !loading}
        name="containerGrid"
        data={externalState?.selectedContainerIDs ?? []}
        validators={[
          (params) => {
            const isValid = !!params?.length;
            return { hasErrors: !isValid, message: 'Please select at least one container.' };
          },
          (params) => {
            const isValid = !!params
              ?.map((i) => containersById[i])
              .every((i) => i.cube.completed && i.rdw.completed && i.subCube.completed);
            return {
              hasErrors: !isValid,
              message:
                'Cannot publish containers with pending data load. Please review your selection.',
            };
          },
        ]}
        onUpdateErrors={onUpdateErrors}
      >
        <RiskContainerStatusTable
          loading={loading}
          nodeName={nodeName}
          data={containers}
          externalState={externalState}
          setExternalState={setExternalState}
          value={externalState.selectedContainerIDs ?? []}
          onChange={(value) => {
            onChange({
              containers: value.map((item) => containersById[item].name),
            });
            setExternalState({
              selectedContainerIDs: value,
            });
          }}
        />
      </FormValidator>
    </div>
  );
};

export default RiskContainerStatusHandler;

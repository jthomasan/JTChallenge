import { useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import { SourceSystem } from '../../RiskDataInputBar/query';
import { sourceSystemQuery } from './query';

export default () => {
  const { loading, data } = useQuery<{ RiskDataSourceSystems: SourceSystem[] }>(sourceSystemQuery);
  const list = data?.RiskDataSourceSystems || [];

  const getSourceSystems = () =>
    list.map((i) => ({
      id: Number(i.id),
      text: i.name,
    }));

  const getSourceSystemEnvironments = (
    sourceSystemId: number | number[] | undefined,
    snapshot: string,
  ) => {
    const sourceSystemIdCopy = Array.isArray(sourceSystemId)
      ? sourceSystemId.map((i) => i.toString())
      : sourceSystemId?.toString();

    const isSourceSystemIdExist = (item: SourceSystem) => {
      if (Array.isArray(sourceSystemIdCopy)) {
        return (
          sourceSystemIdCopy.length === 0 ||
          sourceSystemIdCopy.includes(item.id.toString()) ||
          (item.id.toString() === '1' && sourceSystemIdCopy.includes('4'))
        );
      }

      return (
        item.id.toString() === sourceSystemIdCopy ||
        (item.id.toString() === '1' && sourceSystemIdCopy === '4')
      );
    };

    return list
      .filter(isSourceSystemIdExist)
      .flatMap((item) =>
        item.environments
          .filter((i) => i.snapshot === snapshot)
          .map((o) => ({ id: o.name, text: o.name })),
      );
  };

  const getSourceSystemBySourceEnvironment = (sourceEnvironment: string) =>
    list.find((i) => i.environments.find((o) => o.name === sourceEnvironment));

  return {
    loading,
    getSourceSystems,
    getSourceSystemEnvironments,
    getSourceSystemBySourceEnvironment,
  };
};

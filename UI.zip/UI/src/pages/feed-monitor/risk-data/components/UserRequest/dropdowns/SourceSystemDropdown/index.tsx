import React, { useEffect } from 'react';
import Select, { Option } from '@/components/Select';
import { SelectProps, SelectValue } from 'antd/es/select';
import useGetSourceSystems from '../../hooks/useGetSourceSystems';

interface SourceSystemDropdownProps extends SelectProps<SelectValue> {
  onChange: (value: SelectValue) => void;
}

const SourceSystemDropdown: React.FC<SourceSystemDropdownProps> = (props) => {
  const { value, onChange } = props;
  const { loading, getSourceSystems } = useGetSourceSystems();
  const options = getSourceSystems();

  const onChangeItem = (event: SelectValue) => {
    onChange(event);
  };

  useEffect(() => {
    if (options.length && value == null) {
      onChange(options[0].id);
    }
  }, [options]);

  return (
    <Select
      {...props}
      onChange={onChangeItem}
      disabled={loading}
      placeholder={!loading ? 'All Source Systems' : 'Loading...'}
      size="small"
    >
      {options.map((item) => (
        <Option key={item.id} value={item.id}>
          {item.text}
        </Option>
      ))}
    </Select>
  );
};

export default SourceSystemDropdown;

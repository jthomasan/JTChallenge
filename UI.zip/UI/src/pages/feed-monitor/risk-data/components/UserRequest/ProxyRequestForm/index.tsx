import React, { useEffect } from 'react';
import { Input, DatePicker } from 'antd';
import moment from 'moment';
import { isEmpty } from 'lodash';
import { SelectValue } from 'antd/lib/select';
import { FormProps, DefaultFormData } from '../UserRequestWindow';
import SnapshotDropdown from '../dropdowns/SnapshotDropdown';
import SourceSystemDropdown from '../dropdowns/SourceSystemDropdown';
import FormValidator from '../../common/FormValidator';

import styles from './index.less';
import SelectedPortfolioList from '../SelectedPortfolioList';

export interface ProxyRequestFormDataProps extends DefaultFormData {
  sourceBusinessDate: string | undefined;
  snapshot: string;
  sourceSystemId: number;
  comment?: string;
}

export interface ProxyRequestFormProps extends FormProps<ProxyRequestFormDataProps> {}

const ProxyRequestForm: React.FC<ProxyRequestFormProps> = ({
  date,
  showErrors,
  formData,
  selectedPortfolios,
  disabled,
  onSetFormData,
  onUpdateErrors,
}) => {
  useEffect(() => {
    if (isEmpty(formData)) {
      onSetFormData({
        snapshot: 'EOD',
      } as ProxyRequestFormDataProps);
    }
  }, []);

  const onChangeSourceCOBDate = (value: moment.Moment | null) => {
    onSetFormData({
      sourceBusinessDate: value?.format('YYYY-MM-DD') as string,
    } as ProxyRequestFormDataProps);
  };

  const onChangeSnapshot = (value: SelectValue) => {
    onSetFormData({
      snapshot: value as string,
    } as ProxyRequestFormDataProps);
  };

  const onChangeSourceSystem = (value: SelectValue) => {
    onSetFormData({
      sourceSystemId: value,
    } as ProxyRequestFormDataProps);
  };

  const onChangeUserComment = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    onSetFormData({
      comment: event.target.value,
    } as ProxyRequestFormDataProps);
  };

  return (
    <div className={styles.proxyRequestForm}>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>Source COB Date</span>
        </div>
        <div>
          <FormValidator<string>
            name="sourceBusinessDate"
            data={formData.sourceBusinessDate ?? ''}
            showMessage={showErrors}
            validators={[
              (params) => {
                const isValid = params != null && params !== '';
                return {
                  message: 'Please select source COB Date.',
                  hasErrors: !isValid,
                };
              },
              (params) => {
                const isValid = moment(params) < moment(date);
                return {
                  message: `The selected Source COB Date is invalid. Please select a date prior to ${moment(
                    date,
                  ).format('YYYY-MM-DD')}`,
                  hasErrors: !isValid,
                };
              },
            ]}
            onUpdateErrors={onUpdateErrors}
          >
            <DatePicker
              style={{ width: '100%' }}
              allowClear={false}
              showToday={false}
              size="small"
              value={
                formData.sourceBusinessDate
                  ? moment(formData.sourceBusinessDate, 'YYYY-MM-DD')
                  : undefined
              }
              onChange={onChangeSourceCOBDate}
            />
          </FormValidator>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>Snapshot</span>
        </div>
        <div>
          <SnapshotDropdown
            disabled={disabled}
            value={formData.snapshot}
            onChange={onChangeSnapshot}
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>Source System</span>
        </div>
        <div>
          <SourceSystemDropdown
            disabled={disabled}
            value={formData.sourceSystemId}
            onChange={onChangeSourceSystem}
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>User Comment</span>
        </div>
        <div>
          <FormValidator<string>
            name="comment"
            data={formData.comment ?? ''}
            showMessage={showErrors}
            validators={[
              (params) => {
                const isValid = params != null && params !== '';
                return { message: 'Please enter comment.', hasErrors: !isValid };
              },
            ]}
            onUpdateErrors={onUpdateErrors}
          >
            <Input.TextArea
              disabled={disabled}
              value={formData.comment}
              onChange={onChangeUserComment}
            />
          </FormValidator>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>Selected Portfolios ({selectedPortfolios.length})</span>
        </div>
        <div>
          <SelectedPortfolioList data={selectedPortfolios} />
        </div>
      </div>
    </div>
  );
};

export default ProxyRequestForm;

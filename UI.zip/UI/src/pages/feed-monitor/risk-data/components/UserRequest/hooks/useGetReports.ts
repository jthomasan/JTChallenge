import { gql, useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import { RiskDataReport } from '../../../types/riskDataReport';

const GQL_QUERY = gql`
  query RiskDataReports($selectedContainers: [String]!, $sourceSystemId: ID!) {
    RiskDataReports(selectedContainers: $selectedContainers, sourceSystemId: $sourceSystemId) {
      id
      reportId
      name
      description
      container
    }
  }
`;

interface RiskDataReportsProp {
  selectedContainers: string[];
  sourceSystemId: number;
}

export default (props: RiskDataReportsProp) => {
  const queryResponse = useQuery<{ RiskDataReports: RiskDataReport[] }, RiskDataReportsProp>(
    GQL_QUERY,
    {
      variables: props,
      notifyOnNetworkStatusChange: true,
      fetchPolicy: 'no-cache',
    },
  );

  return { ...queryResponse, data: queryResponse.data?.RiskDataReports ?? [] };
};

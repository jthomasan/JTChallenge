import { useQuery, gql } from 'umi-plugin-apollo-anz/apolloClient';

const QUERY = gql`
  query GetCubeVersions(
    $cob: String
    $portfolios: [String]
    $snapshot: String
    $sourceSystemId: ID
    $reports: [String]
  ) {
    CubeVersions(
      cob: $cob
      portfolios: $portfolios
      snapshot: $snapshot
      sourceSystemId: $sourceSystemId
      reports: $reports
    ) {
      id
      text
    }
  }
`;

interface CubeVersions {
  id: string;
  text: string;
}

export interface GetCubeVersionsProp {
  cob: string;
  portfolios: string[];
  snapshot: string;
  sourceSystemId: number;
  reports: string[];
}

export default ({ cob, reports, portfolios, snapshot, sourceSystemId }: GetCubeVersionsProp) => {
  const { loading, data } = useQuery<{ CubeVersions: CubeVersions[] }, GetCubeVersionsProp>(QUERY, {
    variables: {
      cob,
      portfolios,
      reports,
      snapshot,
      sourceSystemId,
    },
  });

  return { loading, data: data?.CubeVersions ?? [] };
};

import React from 'react';
import { List } from 'react-virtualized';
import { useResizeDetector } from 'react-resize-detector';
import { HierarchyFeedStatus } from '../../../types/hierarchyFeedStatus';

import styles from './index.less';

interface SelectedPortfolioListProps {
  data: HierarchyFeedStatus[];
}

const SelectedPortfolioList: React.FC<SelectedPortfolioListProps> = ({ data = [] }) => {
  const { width, ref: listContainerRef } = useResizeDetector<HTMLDivElement>();

  return (
    <div ref={listContainerRef} className={styles.listContainer}>
      <List
        width={width ?? 0}
        height={150}
        rowCount={data.length}
        rowHeight={20}
        rowRenderer={(props) => (
          <div key={props.key} style={props.style}>
            {data[props.index].name}
          </div>
        )}
      />
    </div>
  );
};

export default SelectedPortfolioList;

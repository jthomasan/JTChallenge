import React, { useState, useRef } from 'react';
import { useMutation, gql } from 'umi-plugin-apollo-anz/apolloClient';
import { Row, Col, Button } from 'antd';
import Window from '@/components/Window';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import ProgressIndicator, { ActionType } from '@/components/ProgressIndicator';
import { ExternalisedStateProps } from '@/types/externalised-state';
import { ErrorEntities } from '../../common/FormValidator';
import { RiskContainerStatus } from '../../RiskContainerStatusTable/query';
import { HierarchyFeedStatus } from '../../../types/hierarchyFeedStatus';
import { ReportSelectionParams, ReportExternalState } from '../SelectReportGrid';
import {
  RiskContainerStatusExternalState,
  RiskContainerSelectionParams,
} from '../RiskContainerStatusHandler';
import { RerunRequestFormDataProps } from '../RerunRequestForm';
import { ProxyRequestFormDataProps } from '../ProxyRequestForm';
import { ExcludeRequestFormDataProps } from '../ExcludeRequestForm';
import { ReloadRequestFormDataProps } from '../ReloadRequestForm';
import { SignOffRequestFormDataProps } from '../SignOffRequestForm';
import { RiskDataProps } from '../../FeedStatusContainer';
import { PortfolioFeedStatus } from '../../../types/portfolioFeedStatus';
import { FeedStatusAction } from '../../FeedStatusContainer/types';

import styles from './index.less';

export interface DefaultFormData {
  date: string;
  portfolios: string[];
}

export interface UserRequestWindowExternalState<T, C> {
  gridState: T;
  formState: C;
}

export interface GridProp<T, C> extends ExternalisedStateProps<T> {
  userRequestType: UserRequestType;
  riskDataProps: RiskDataProps;
  selectedContainers: RiskContainerStatus[];
  selectedPortfolios: HierarchyFeedStatus[];
  formData: C;
  disabled?: boolean;
  showErrors: boolean;
  onDataReady: (loaded: boolean) => void;
  onChange: (params: ReportSelectionParams | RiskContainerSelectionParams) => void;
  onUpdateErrors: (params: ErrorEntities) => void;
}

export interface FormProps<T> {
  riskDataProps: RiskDataProps;
  selectedContainers: RiskContainerStatus[];
  selectedPortfolios: HierarchyFeedStatus[];
  selectedPortfolioFeeds: PortfolioFeedStatus[];
  reportsFromSelectedPortfolioFeeds: string[];
  date: string;
  showErrors: boolean;
  formData: T;
  disabled?: boolean;
  onSetFormData: (formData: T) => void;
  onUpdateErrors: (params: ErrorEntities) => void;
}

interface AdditionalProps {
  formErrors: ErrorEntities;
}

interface UserRequestWindowProps<T, C> {
  riskDataProps: RiskDataProps;
  title: string;
  date: string;
  userRequestType: UserRequestType;
  selectedContainers: RiskContainerStatus[];
  selectedPortfolios: HierarchyFeedStatus[];
  selectedPortfolioFeeds: PortfolioFeedStatus[];
  sendPortfolioFeeds?: boolean;
  reportsFromSelectedPortfolioFeeds: string[];
  gridComponent?: React.FC<GridProp<T, C>>;
  formComponent: React.FC<FormProps<C>>;
  onClose: () => void;
}

export type UserRequestForm =
  | ReportSelectionParams
  | RiskContainerSelectionParams
  | RerunRequestFormDataProps
  | ProxyRequestFormDataProps
  | ExcludeRequestFormDataProps
  | ReloadRequestFormDataProps
  | SignOffRequestFormDataProps;

export enum UserRequestType {
  RerunRequest = 'RerunRequest',
  ProxyRequest = 'ProxyRequest',
  ExcludeRequest = 'ExcludeRequest',
  ReloadRequest = 'ReloadRequest',
  SignOffRequest = 'SignOffRequest',
  None = 'none',
}

const mutationQuery = {
  [UserRequestType.RerunRequest]: 'sendRerunRequest',
  [UserRequestType.ProxyRequest]: 'sendProxyRequest',
  [UserRequestType.ExcludeRequest]: 'sendExcludeRequest',
  [UserRequestType.ReloadRequest]: 'sendReloadRequest',
  [UserRequestType.SignOffRequest]: 'sendSignOffRequest',
};

const QUERY = gql`
  mutation batch($actions: [BatchActions!]!) {
    batchChange(actions: $actions) {
      success
      actions
    }
  }
`;

const UserRequestWindow: React.FC<UserRequestWindowProps<
  ReportExternalState | RiskContainerStatusExternalState,
  UserRequestForm
>> = (props) => {
  const {
    riskDataProps,
    title,
    date,
    selectedContainers,
    selectedPortfolios,
    selectedPortfolioFeeds,
    reportsFromSelectedPortfolioFeeds,
    sendPortfolioFeeds,
    userRequestType,
    gridComponent: GridComponent,
    formComponent: FormComponent,
    onClose,
  } = props;
  const [gridExternalState, setGridExternalState] = useGQLComponentState<
    ReportExternalState | RiskContainerStatusExternalState
  >({}, 'UserRequestWindowGrid');

  const isGridExist = !!GridComponent;

  const [formExternalState, setFormExternalState] = useGQLComponentState<UserRequestForm>(
    {},
    'UserRequestWindowForm',
  );
  const [isDataReady, setIsDataReady] = useState(!isGridExist);
  const [progressIndicator, setProgressIndicator] = useState<{
    action: ActionType;
    message: string;
    title?: string;
  }>({
    action: ActionType.none,
    message: '',
  });
  const [showErrors, setShowErrors] = useState(false);
  const [formDataValidation, setFormDataValidation] = useState({});
  const [sendUserRequest] = useMutation(QUERY);
  const cachedWindowStateRef = useRef({} as AdditionalProps);

  const fireClearSelectionEvent = () => {
    window.dispatchEvent(
      new CustomEvent('feedStatusActions', {
        detail: FeedStatusAction.Clear,
      }),
    );
  };

  const onUpdateErrors = (params: ErrorEntities) => {
    cachedWindowStateRef.current = {
      ...cachedWindowStateRef.current,
      ...params,
    };

    setFormDataValidation(cachedWindowStateRef.current);
  };

  const onCloseWindow = () => {
    setGridExternalState({} as ReportExternalState | RiskContainerStatusExternalState, true);
    setFormExternalState({} as UserRequestForm, true);

    onClose();
  };

  const processUserRequest = async () => {
    setProgressIndicator({ action: ActionType.inProgress, message: 'Sending...' });

    const params = {
      date,
      ...formExternalState,
    };

    if (sendPortfolioFeeds) {
      params.portfolios = selectedPortfolioFeeds.map((i) => i.portfolio.name);
    } else {
      params.portfolios = selectedPortfolios.map((portfolio) => portfolio.name);
    }

    try {
      await sendUserRequest({
        variables: {
          actions: [
            {
              [mutationQuery[userRequestType]]: params,
            },
          ],
        },
      });
      setProgressIndicator({ action: ActionType.completed, message: 'Sent' });
      fireClearSelectionEvent();
      onCloseWindow();
    } catch (e) {
      setProgressIndicator({
        action: ActionType.error,
        message: 'Failed to process the request',
        title: 'User Request',
      });
    }
  };

  const onSubmit = () => {
    const isFormDataInvalid = Object.values(formDataValidation).some((i) => !!i);

    if (isFormDataInvalid) {
      setShowErrors(true);
    } else {
      processUserRequest();
    }
  };

  return (
    <Window
      title={title}
      initialHeight={isGridExist ? 600 : 500}
      initialWidth={isGridExist ? 900 : 350}
      minHeight={isGridExist ? 600 : 500}
      minWidth={isGridExist ? 550 : 300}
      onClose={onCloseWindow}
    >
      <ProgressIndicator
        title={progressIndicator.title ?? ''}
        action={progressIndicator.action}
        actionMessage={progressIndicator.message}
      />
      <Row className={styles.userRequestWindow}>
        {isGridExist && (
          <Col span={16}>
            {GridComponent && (
              <GridComponent
                userRequestType={userRequestType}
                riskDataProps={riskDataProps}
                formData={formExternalState}
                showErrors={showErrors}
                selectedContainers={selectedContainers}
                selectedPortfolios={selectedPortfolios}
                onDataReady={setIsDataReady}
                externalState={gridExternalState}
                setExternalState={setGridExternalState}
                onChange={setFormExternalState}
                onUpdateErrors={onUpdateErrors}
              />
            )}
          </Col>
        )}
        <Col
          span={isGridExist ? 8 : 24}
          className={styles.formItems}
          style={{ paddingRight: isGridExist ? '0' : '5px' }}
        >
          <div className={styles.formHolder}>
            <div className={styles.formTitle}>Enter Details</div>
            <FormComponent
              riskDataProps={riskDataProps}
              selectedContainers={selectedContainers}
              selectedPortfolios={selectedPortfolios}
              selectedPortfolioFeeds={selectedPortfolioFeeds}
              reportsFromSelectedPortfolioFeeds={reportsFromSelectedPortfolioFeeds}
              date={date}
              showErrors={showErrors}
              formData={formExternalState}
              disabled={!isDataReady}
              onSetFormData={setFormExternalState}
              onUpdateErrors={onUpdateErrors}
            />
          </div>
          <div className={styles.actionPanel}>
            <Button size="small" disabled={!isDataReady} onClick={onCloseWindow}>
              Cancel
            </Button>
            <Button type="primary" disabled={!isDataReady} size="small" onClick={onSubmit}>
              Send Request
            </Button>
          </div>
        </Col>
      </Row>
    </Window>
  );
};

export default UserRequestWindow;

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export const sourceSystemQuery = gql`
  {
    RiskDataSourceSystems(isRiskDataSource: true) {
      id
      name
      environments {
        name
        snapshot
      }
    }
  }
`;

import React from 'react';
import Select, { Option } from '@/components/Select';
import { SelectProps, SelectValue } from 'antd/lib/select';

interface SnapshotDropdownProps extends SelectProps<SelectValue> {}

const SnapshotDropdown: React.FC<SnapshotDropdownProps> = (props) => (
  <Select {...props} size="small">
    <Option value="NZ_ID">NZ_ID</Option>
    <Option value="AU_ID">AU_ID</Option>
    <Option value="Murex_ID">Murex_ID</Option>
    <Option value="SG_ID">SG_ID</Option>
    <Option value="GB_ID">GB_ID</Option>
    <Option value="EOD">EOD</Option>
    <Option value="LON_EOD">LON_EOD</Option>
    <Option value="EOD_TEST">EOD_TEST</Option>
    <Option value="EOD_NEW">EOD_NEW</Option>
  </Select>
);

export default SnapshotDropdown;

import React, { useEffect } from 'react';
import { union } from 'lodash';
import { SelectProps, SelectValue } from 'antd/lib/select';
import Select, { Option } from '@/components/Select';
import { PortfolioFeedStatus } from '@/pages/feed-monitor/risk-data/types/portfolioFeedStatus';
import useGetCubeVersions from '../../hooks/useGetCubeVersions';
import { RiskContainerStatus } from '../../../RiskContainerStatusTable/query';
import { RiskDataProps } from '../../../FeedStatusContainer';

interface CubeVersionDropdownProps extends SelectProps<SelectValue> {
  riskDataProps: RiskDataProps;
  selectedContainers: RiskContainerStatus[];
  selectedPortfolios: PortfolioFeedStatus[];
  snapshot: string;
  sourceSystemId: number;
  reports: string[];
  onChange: (value: SelectValue | undefined) => void;
}

const CubeVersionDropdown: React.FC<CubeVersionDropdownProps> = ({
  riskDataProps,
  selectedPortfolios,
  selectedContainers,
  snapshot,
  sourceSystemId,
  reports,
  onChange,
  ...props
}) => {
  const { loading, data } = useGetCubeVersions({
    cob: riskDataProps.date,
    portfolios: union(selectedPortfolios.map((i) => i.portfolio.name)),
    snapshot,
    sourceSystemId,
    reports,
  });

  useEffect(() => {
    if (data.length === 0 && props.value) {
      onChange(undefined);
    }
  }, [data, props.value]);

  return (
    <Select
      {...props}
      size="small"
      disabled={loading || props.disabled}
      placeholder={loading ? 'Loading...' : 'Select Version'}
      onChange={(value) => {
        onChange(Number(value));
      }}
    >
      {data.map((item) => (
        <Option key={item.id} value={item.id}>
          {item.text}
        </Option>
      ))}
    </Select>
  );
};

export default CubeVersionDropdown;

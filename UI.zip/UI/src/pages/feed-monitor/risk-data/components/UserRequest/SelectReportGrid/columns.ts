import { ColumnProps } from '@/components/Grid';

export const columns: ColumnProps[] = [
  {
    field: 'name',
    title: 'Report',
    width: '150px',
  },
  {
    field: 'container',
    title: 'Container',
    width: '150px',
    defaultSortColumn: true,
    defaultGroupColumn: true,
    filter: 'text',
  },
  {
    field: 'description',
    title: 'Description',
    width: '200px',
  },
];

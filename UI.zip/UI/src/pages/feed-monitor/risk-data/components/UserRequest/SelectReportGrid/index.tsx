import React, { useMemo, useEffect, useState } from 'react';
import debounce from 'lodash/debounce';
import { NetworkStatus } from 'umi-plugin-apollo-anz/apolloClient';
import { keyBy } from 'lodash';
import Grid, { ColumnProps, GridExternalState } from '@/components/Grid';
import { getSelectionColumn } from '@/components/Grid/selection/getSelectionColumn';
import SearchField from '@/components/SearchField';
import { GridProp } from '../UserRequestWindow';
import { RerunRequestFormDataProps } from '../RerunRequestForm';
import FormValidator from '../../common/FormValidator';
import { columns } from './columns';
import useGetReports from '../hooks/useGetReports';

import styles from './index.less';

export interface ReportExternalState extends GridExternalState {
  selectedReports: string[];
}

export interface ReportSelectionParams {
  reports: string[];
}

export interface SelectReportGridProps
  extends GridProp<ReportExternalState, RerunRequestFormDataProps> {}

const SelectReportGrid: React.FC<SelectReportGridProps> = (props) => {
  const {
    formData,
    disabled,
    showErrors,
    selectedContainers,
    onDataReady,
    externalState = {} as ReportExternalState,
    setExternalState,
    onChange,
    onUpdateErrors,
  } = props;
  const [searchText, setSearchText] = useState('');
  const { loading, data: reportData, networkStatus } = useGetReports({
    selectedContainers: selectedContainers.map((o) => o.name),
    sourceSystemId: (formData.sourceSystemId && formData.sourceSystemId) ?? 1,
  });
  const reportDataById = useMemo(() => keyBy(reportData, 'id'), [reportData]);
  const filteredReportData = useMemo(() => {
    const isValueFound = (value: string) => value.toUpperCase().includes(searchText.toUpperCase());

    return reportData.filter(
      (i) => isValueFound(i.container) || isValueFound(i.name) || isValueFound(i.description),
    );
  }, [searchText, reportData]);

  useEffect(() => {
    onDataReady(!loading);
  }, [loading]);

  useEffect(() => {
    if (networkStatus === NetworkStatus.ready) {
      onChange({
        reports: [],
      } as ReportSelectionParams);

      setExternalState({
        selectedReports: [] as string[],
      } as ReportExternalState);

      onDataReady(true);
    }
  }, [networkStatus]);

  const columnsWithSelector = useMemo<ColumnProps[]>(
    () => [
      getSelectionColumn({
        disabled,
        identifier: 'id',
        selected: externalState.selectedReports ?? [],
        onChange: (value) => {
          onChange({
            reports: value.map((id) => reportDataById[id].name),
          });

          setExternalState({
            selectedReports: value,
          } as ReportExternalState);
        },
      }),
      ...columns,
    ],
    [columns, externalState.selectedReports],
  );

  return (
    <div className={styles.reportGrid}>
      <div className={styles.gridTitle}>Select Reports</div>
      <div className={styles.gridContainer}>
        <SearchField
          className={{
            searchField: styles.searchField,
            searchControls: styles.searchControls,
            searchInput: styles.searchInput,
          }}
          key="search reports"
          value={searchText}
          onChange={debounce(setSearchText, 300)}
          disabled={loading}
          placeholder="Report Search"
          onCancel={() => {
            setSearchText('');
          }}
          cancelDisabled={!searchText?.length}
        />
        <FormValidator<string[]>
          showMessage={showErrors && !loading}
          name="reportGrid"
          data={externalState?.selectedReports ?? []}
          validators={[
            (params) => {
              const isValid = !!params?.length;
              return {
                message: 'Please select at least one report.',
                hasErrors: !isValid,
              };
            },
          ]}
          onUpdateErrors={onUpdateErrors}
        >
          <Grid
            loading={loading}
            data={filteredReportData}
            groupable
            columns={columnsWithSelector}
            externalState={externalState}
            setExternalState={setExternalState}
            style={{ height: '100%' }}
            showColumnVisibility
            rowHeight={26}
          />
        </FormValidator>
      </div>
    </div>
  );
};

export default SelectReportGrid;

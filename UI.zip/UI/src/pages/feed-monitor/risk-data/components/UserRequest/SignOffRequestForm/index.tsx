import React, { useEffect } from 'react';
import { isEmpty } from 'lodash';
import { Input } from 'antd';
import { FormProps, DefaultFormData } from '../UserRequestWindow';
import FormValidator from '../../common/FormValidator';
import { RiskDataProps } from '../../FeedStatusContainer';
import { HierarchyFeedStatus } from '../../../types/hierarchyFeedStatus';
import useGetSourceSystems from '../hooks/useGetSourceSystems';

import styles from './index.less';

export interface SignOffRequestFormDataProps extends DefaultFormData, RiskDataProps {
  isPortfolioNode: boolean;
  sourceSystemIds: number[];
  comment: string;
  selectedNodeForSignOff: HierarchyFeedStatus;
}

export interface SignOffRequestFormProps extends FormProps<SignOffRequestFormDataProps> {}

const SignOffRequestForm: React.FC<SignOffRequestFormProps> = ({
  riskDataProps,
  showErrors,
  formData,
  disabled,
  onSetFormData,
  onUpdateErrors,
}) => {
  const { getSourceSystems } = useGetSourceSystems();

  useEffect(() => {
    const sourceSystemIds = riskDataProps.sourceSystemIds?.length
      ? riskDataProps.sourceSystemIds
      : getSourceSystems().map((o) => o.id);

    if (isEmpty(formData)) {
      onSetFormData({
        date: riskDataProps.date,
        nodeId: riskDataProps.nodeId,
        isPortfolioNode: true,
        sourceSystemIds,
        snapshot: riskDataProps.snapshot,
      } as SignOffRequestFormDataProps);
    }
  }, []);

  const onChangeUserComment = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    onSetFormData({
      comment: event.target.value,
    } as SignOffRequestFormDataProps);
  };

  return (
    <div className={styles.signOffRequestForm}>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>User Comment</span>
        </div>
        <div>
          <FormValidator<string>
            name="comment"
            data={formData.comment ?? ''}
            showMessage={showErrors}
            validators={[
              (params) => {
                const isValid = params != null && params !== '';
                return {
                  hasErrors: !isValid,
                  message: 'Please enter comment.',
                };
              },
            ]}
            onUpdateErrors={onUpdateErrors}
          >
            <Input.TextArea
              disabled={disabled}
              value={formData.comment}
              onChange={onChangeUserComment}
            />
          </FormValidator>
        </div>
      </div>
    </div>
  );
};

export default SignOffRequestForm;

import React, { useEffect, useMemo } from 'react';
import { isEmpty } from 'lodash';
import { Input } from 'antd';
import { SelectValue } from 'antd/lib/select';
import CubeVersionDropdown from '../dropdowns/CubeVersionDropdown';
import { FormProps, DefaultFormData } from '../UserRequestWindow';
import FormValidator from '../../common/FormValidator';

import styles from './index.less';
import useGetSourceSystems from '../hooks/useGetSourceSystems';

export interface ReloadRequestFormDataProps extends DefaultFormData {
  snapshot: string;
  sourceSystemId: number;
  version: number;
  comment?: string;
  reports: string[];
}

export interface ReloadRequestFormProps extends FormProps<ReloadRequestFormDataProps> {}

const ReloadRequestForm: React.FC<ReloadRequestFormProps> = ({
  riskDataProps,
  selectedContainers,
  selectedPortfolioFeeds,
  reportsFromSelectedPortfolioFeeds,
  showErrors,
  formData,
  disabled,
  onSetFormData,
  onUpdateErrors,
}) => {
  const { getSourceSystemBySourceEnvironment } = useGetSourceSystems();
  const { sourceSystemEnvironment } = selectedPortfolioFeeds?.[0] ?? {};
  const sourceSystemDetails = useMemo(
    () => getSourceSystemBySourceEnvironment(sourceSystemEnvironment),
    [sourceSystemEnvironment],
  );
  const sourceSystemId = sourceSystemDetails?.id ?? 0;

  useEffect(() => {
    if (isEmpty(formData)) {
      onSetFormData({
        snapshot: riskDataProps.snapshot,
        sourceSystemId,
        reports: reportsFromSelectedPortfolioFeeds,
      } as ReloadRequestFormDataProps);
    }
  }, []);

  const onChangeVersion = (value: SelectValue | undefined) => {
    onSetFormData({
      version: value,
    } as ReloadRequestFormDataProps);
  };

  const onChangeUserComment = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    onSetFormData({
      comment: event.target.value,
    } as ReloadRequestFormDataProps);
  };

  return (
    <div className={styles.reloadRequestForm}>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>Select Version</span>
        </div>
        <div>
          <FormValidator<number>
            name="version"
            data={formData.version}
            showMessage={showErrors}
            validators={[
              (params) => {
                const isValid = params != null;
                return {
                  message: 'Please select a version.',
                  hasErrors: !isValid,
                };
              },
            ]}
            onUpdateErrors={onUpdateErrors}
          >
            <CubeVersionDropdown
              selectedContainers={selectedContainers}
              selectedPortfolios={selectedPortfolioFeeds}
              snapshot={formData.snapshot}
              sourceSystemId={formData.sourceSystemId ?? 1}
              reports={reportsFromSelectedPortfolioFeeds}
              disabled={disabled}
              riskDataProps={riskDataProps}
              value={formData.version}
              onChange={onChangeVersion}
            />
          </FormValidator>
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.label}>
          <span>User Comment</span>
        </div>
        <div>
          <FormValidator<string>
            name="comment"
            data={formData.comment ?? ''}
            showMessage={showErrors}
            validators={[
              (params) => {
                const isValid = params != null && params !== '';
                return { message: 'Please enter comment.', hasErrors: !isValid };
              },
            ]}
            onUpdateErrors={onUpdateErrors}
          >
            <Input.TextArea
              disabled={disabled}
              value={formData.comment}
              onChange={onChangeUserComment}
            />
          </FormValidator>
        </div>
      </div>
    </div>
  );
};

export default ReloadRequestForm;

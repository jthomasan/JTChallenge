import React, { useMemo } from 'react';
import { Button, TreeSelect, Switch } from 'antd';
import { AccentGroup, CardTopBar } from '@/components/Card';
import _, { keyBy, uniq } from 'lodash';
import MultiSelect from '@/components/MultiSelect';
import { useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import { COBDatePicker } from '@/pages/feed-monitor/components/COBDatePicker';
import Tooltip from '../common/Tooltips/RiskDataTooltip';

import EnvironmentDropdown from '../common/EnvironmentDropdown';
import { FormState } from '../../types';
import {
  RiskDataInputBarQuery,
  RiskDataInputBarQueryResponse,
  RiskDataInputBarQueryVariables,
  SourceSystem,
} from './query';

import styles from './RiskDataInputBar.less';

export interface RiskDataInputBarProps {
  onChange: (value: Partial<FormState>) => void;
  value: FormState;
  isPending: boolean;
  date: string;
  isAutoRefreshOn: boolean;
  onSubmit: () => void;
  onSetAutoRefresh: (value: boolean) => void;
  onRefresh: () => void;
}

const RiskDataInputBar: React.FC<RiskDataInputBarProps> = ({
  onChange,
  value: formValue,
  isPending,
  isAutoRefreshOn,
  onSubmit,
  onSetAutoRefresh,
  onRefresh,
  date,
}) => {
  const {
    data: {
      SourceSystems: dataSourceSystems,
      PortfolioHierarchies: dataPortfolioHierarchies,
      Snapshots: dataSnapshots,
    } = {},
    loading,
  } = useQuery<RiskDataInputBarQueryResponse, RiskDataInputBarQueryVariables>(
    RiskDataInputBarQuery,
    {
      variables: {
        date: formValue.date ?? date,
      },
    },
  );

  const sourceSystemEnvironments = useMemo(
    () =>
      uniq(dataSourceSystems?.flatMap(({ environments }) => environments)).filter(
        ({ snapshot }) => formValue.snapshot === snapshot,
      ),
    [dataSourceSystems, formValue.snapshot],
  );
  const sourceSystemEnvironmentsById = useMemo(() => keyBy(sourceSystemEnvironments, 'id'), [
    sourceSystemEnvironments,
  ]);

  const remappedTreeData = useMemo(
    () =>
      dataPortfolioHierarchies?.map((node) => ({
        ...node,
        id: node.nodeId,
        value: node.nodeId,
        pId: node.parent?.nodeId,
        title: node.name,
        key: node.id,
      })) ?? [],
    [dataPortfolioHierarchies],
  );

  const nodeIdToNodeValue = useMemo(
    () =>
      _.chain(dataPortfolioHierarchies)
        .map((node) => ({ id: Number(node.nodeId), name: node.name }))
        .keyBy('id')
        .value(),
    [dataPortfolioHierarchies],
  );

  const getSelectedDataItems: <T, S>(
    list: T[],
    listComparedWith: S[],
    getValueComparedWith: (data: T) => S,
    fieldMapped: string,
  ) => React.ReactNode = (list, listComparedWith, getValueComparedWith, fieldMapped) =>
    list
      ?.filter((item) => listComparedWith.includes(getValueComparedWith(item)))
      .map((item) => <div style={{ marginBottom: '5px' }}>{item[fieldMapped]}</div>);

  return (
    <CardTopBar style={{ flexWrap: 'nowrap' }}>
      <AccentGroup style={{ flexGrow: 1 }}>
        <TreeSelect
          disabled={loading}
          size="small"
          style={{ width: 250 }}
          value={formValue.node.id}
          onChange={(value) => {
            onChange({
              node: nodeIdToNodeValue[value],
            });
          }}
          treeData={remappedTreeData}
          treeDataSimpleMode
          dropdownClassName={styles.treeSelectDropdown}
        />
        <COBDatePicker
          disabled={loading}
          value={formValue.date}
          onChange={(value) => {
            onChange({
              date: value,
            });
          }}
        />
        <MultiSelect
          disabled={loading}
          style={{ width: 100 }}
          value={{ id: formValue.snapshot, text: formValue.snapshot }}
          multiple={false}
          onChange={(value) => {
            const newValue = value?.id ?? 'EOD';
            onChange({
              snapshot: newValue,
              sourceSystemEnvironments: formValue.sourceSystemEnvironments.filter(
                (id) => sourceSystemEnvironmentsById[id].snapshot === newValue,
              ),
            });
          }}
          size="small"
          dropdownMatchSelectWidth={false}
          options={dataSnapshots?.map((snapshot) => ({ id: snapshot, text: snapshot }))}
        />
        <Tooltip
          title={getSelectedDataItems<SourceSystem, number>(
            dataSourceSystems ?? [],
            formValue.sourceSystemIds,
            (item) => Number(item.id),
            'name',
          )}
        >
          <MultiSelect
            disabled={loading}
            multiple
            style={{ width: 155 }}
            placeholder="All Source Systems"
            size="small"
            dropdownMatchSelectWidth={false}
            options={dataSourceSystems?.map((source) => ({
              id: Number(source.id),
              text: source.name,
            }))}
            value={formValue.sourceSystemIds.map((id) => ({ id })) ?? []}
            onChange={(values) => {
              onChange({
                sourceSystemIds: values.map((value) => value.id),
              });
            }}
          />
        </Tooltip>

        <Tooltip
          title={getSelectedDataItems<{ id: number; text: string }, number>(
            [
              { id: 0, text: 'Non Official' },
              { id: 1, text: 'Official' },
            ],
            formValue.reportTypeIds,
            (item) => Number(item.id),
            'text',
          )}
        >
          <MultiSelect
            disabled={loading}
            multiple
            style={{ width: 138 }}
            placeholder="All Report Types"
            size="small"
            dropdownMatchSelectWidth={false}
            options={[
              { id: 0, text: 'Non Official' },
              { id: 1, text: 'Official' },
            ]}
            value={formValue.reportTypeIds.map((id) => ({ id })) ?? []}
            onChange={(values) => {
              onChange({
                reportTypeIds: values.map((value) => value.id),
              });
            }}
          />
        </Tooltip>

        <EnvironmentDropdown
          disabled={loading}
          sourceSystem={formValue.sourceSystemIds.map((id) => id) ?? []}
          style={{ width: 175 }}
          placeholder="All Source Envs."
          snapshot={formValue.snapshot}
          value={formValue.sourceSystemEnvironments.map((id) => ({ id, text: id })) ?? []}
          onChange={(values) => {
            onChange({
              sourceSystemEnvironments: values ? values.map((value) => value.id) : [],
            });
          }}
        />

        <Button size="small" type="primary" disabled={!isPending || loading} onClick={onSubmit}>
          Submit
        </Button>
      </AccentGroup>
      <AccentGroup style={{ flexShrink: 1 }} align="right">
        <div className={styles.autoRefreshContainer}>
          <small>Auto Refresh</small>
          <Switch size="small" checked={isAutoRefreshOn} onChange={onSetAutoRefresh} />
        </div>
        <Button.Group size="small" style={{ display: 'flex' }}>
          <Button size="small" icon="reload" onClick={onRefresh} />
        </Button.Group>
      </AccentGroup>
    </CardTopBar>
  );
};

export default RiskDataInputBar;

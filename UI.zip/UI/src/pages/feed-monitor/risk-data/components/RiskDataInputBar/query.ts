import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export interface SourceSystemEnvironment {
  id: string;
  name: string;
  snapshot: string;
}

export interface SourceSystem {
  id: string;
  name: string;
  environments: SourceSystemEnvironment[];
}

export interface ReportType {
  id: string;
  name: string;
}

export interface PortfolioHierarchy {
  id: string;
  nodeId: string;
  name: string;
  parent: {
    id: string;
    nodeId: string;
  };
}

export interface RiskDataInputBarQueryResponse {
  Snapshots: string[];
  CurrentBusinessDate: string;
  SourceSystems: SourceSystem[];
  ReportTypes: ReportType[];
  PortfolioHierarchies: PortfolioHierarchy[];
}

export interface RiskDataInputBarQueryVariables {
  date: string;
}

export const RiskDataInputBarQuery = gql`
  query RiskDataInputBarQuery($date: Date!) {
    PortfolioHierarchies(date: $date) {
      id
      nodeId
      name
      parent {
        nodeId
        id
      }
    }

    CurrentBusinessDate

    Snapshots

    SourceSystems: RiskDataSourceSystems(isRiskDataSource: true) {
      id
      name
      environments {
        id
        name
        snapshot
      }
    }

    ReportTypes {
      id
      name
    }
  }
`;

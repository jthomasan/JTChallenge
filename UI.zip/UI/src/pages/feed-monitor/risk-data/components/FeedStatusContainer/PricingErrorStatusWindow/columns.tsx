import React from 'react';
import { get } from 'lodash';
import SimpleTD from '@/components/SimpleTD';
import { ColumnProps, CellProps } from '@/components/Grid';

const ReportCell: React.FC<CellProps> = (props) => {
  const { dataItem, field = '' } = props;
  const report = get(dataItem, field);
  const reportDescription = get(dataItem, 'reportDescription');

  return <SimpleTD {...props}>{`${report} - ${reportDescription}`}</SimpleTD>;
};

export const columns: ColumnProps[] = [
  {
    title: 'Portfolio',
    field: 'portfolio',
    width: '120px',
  },
  {
    title: 'Business Date',
    field: 'businessDate',
    width: '120px',
  },
  {
    title: 'Report',
    field: 'report',
    width: '200px',
    cell: ReportCell,
  },
  {
    title: 'Skylib TradeID',
    field: 'skyTradeID',
    width: '120px',
  },
  {
    title: 'Murex TradeID',
    field: 'murexTradeID',
    width: '120px',
  },
  {
    title: 'Mx Family',
    field: 'mxFamily',
    width: '120px',
  },
  {
    title: 'Mx Type',
    field: 'mxType',
    width: '120px',
  },
  {
    title: 'Mx Group',
    field: 'mxGroup',
    width: '120px',
  },
  {
    title: 'Mx Instrument',
    field: 'mxInstrument',
    width: '120px',
  },
  {
    title: 'Counterparty',
    field: 'counterParty',
    width: '120px',
  },
  {
    title: 'Contract Name',
    field: 'contractName',
    width: '120px',
  },
  {
    title: 'Job Name',
    field: 'jobName',
    width: '200px',
  },
  {
    title: 'Error Message',
    field: 'errorMessage',
    width: '800px',
  },
];

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

const query = gql`
  query RiskDataHierarchyFeedStatuses(
    $isRootPortfolioNode: Boolean
    $nodeId: ID
    $cob: String
    $snapshot: String
    $containerIds: [ID]
    $sourceSystemIds: [ID]
    $sourceSystemEnvironments: [String]
    $reportTypeIds: [ID]
    $statuses: String
  ) {
    RiskDataHierarchyFeedStatuses(
      nodeId: $nodeId
      cob: $cob
      snapshot: $snapshot
      isRootPortfolioNode: $isRootPortfolioNode
      containerIds: $containerIds
      sourceSystemIds: $sourceSystemIds
      sourceSystemEnvironments: $sourceSystemEnvironments
      reportTypeIds: $reportTypeIds
      statuses: $statuses
    ) {
      id
      nodeId
      name
      type
      level
      isSignOffAllowed
      isRerunEnabled
      overallStatus
      parent {
        id
        nodeId
      }
      feed {
        feedId
        businessDate
        reportName
        containerId
        containerName
        portfolioId
        portfolioName
        sourceSystemEnvironment
        hasSourceSystemError
        isEmpty
        isRerun
        isExclusion
        isProxy
        isReload
        isFmFeed
        isStale
        hasQuarantine
        cubeVersion
        subCubeVersion
        cubeLoadId
        cubeLoadTime
        status {
          riskEngine
          download
          rdw
          signOff
          errorDownload
          overall
          cubeQueue
          cubeLoad
          cubeTradeEtl
          subCubeQueue
          subCubeLoad
          subCubePositionEtl
          subCubeOverall
          fvaCubeLoad
          fvaSubcubeLoad
          fvaCubeTradeEtl
          fvaSubcubePositionEtl
        }
        additionalInfo
      }
      counts {
        riskEngine {
          ...FeedCountDetails
        }
        riskEngineError {
          ...FeedCountDetails
        }
        download {
          ...FeedCountDetails
        }
        rdw {
          ...FeedCountDetails
        }
        signOff {
          ...FeedCountDetails
        }
        overall {
          ...FeedCountDetails
        }
        cubeQueue {
          ...FeedCountDetails
        }
        cubeLoad {
          ...FeedCountDetails
        }
        cubeTradeEtl {
          ...FeedCountDetails
        }
        subCubeLoad {
          ...FeedCountDetails
        }
        subCubePositionEtl {
          ...FeedCountDetails
        }
        fvaCubeLoad {
          ...FeedCountDetails
        }
        fvaSubcubeLoad {
          ...FeedCountDetails
        }
        fvaCubeTradeEtl {
          ...FeedCountDetails
        }
        fvaSubcubePositionEtl {
          ...FeedCountDetails
        }
      }
    }
  }

  fragment FeedCountDetails on FeedCountDetail {
    notStarted
    processing
    completed
    failed
    noData
    aborted
    total
    completedPercentage
  }
`;

export default query;

import React from 'react';
import Window from '@/components/Window';
import Grid from '@/components/Grid';
import { gql, useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import { columns } from './columns';

const QUERY = gql`
  query PreviousCubeVersions($cubeLoadId: ID!) {
    PreviousCubeVersions(cubeLoadId: $cubeLoadId) {
      id
      cubeVersion
      cubeLoadTime
      isRerun
      isExclusion
      isProxy
      isReload
    }
  }
`;

interface PreviousCubeVersion {
  id: string;
  cubeVersion: string;
  cubeLoadTime: string;
  isRerun: boolean;
  isExclusion: boolean;
  isProxy: boolean;
  isReload: boolean;
}

interface PreviousCubeVersionsWindowProps {
  cubeLoadId: string | null;
  onCloseWindow: () => void;
}

const PreviousCubeVersionsWindow: React.FC<PreviousCubeVersionsWindowProps> = ({
  cubeLoadId,
  onCloseWindow,
}) => {
  const [externalState, setExternalState] = useGQLComponentState({}, 'PreviousCubeVersionsWindow');
  const { loading, data } = useQuery<Record<'PreviousCubeVersions', PreviousCubeVersion[]>>(QUERY, {
    variables: {
      cubeLoadId,
    },
    fetchPolicy: 'no-cache',
  });

  const previousCubeVersions = data?.PreviousCubeVersions ?? [];

  return (
    <Window
      title="Previous Cube Versions"
      initialHeight={400}
      initialWidth={700}
      minHeight={400}
      minWidth={700}
      onClose={onCloseWindow}
    >
      <div style={{ height: '100%', padding: '5px' }}>
        <Grid
          loading={loading}
          data={previousCubeVersions}
          columns={columns}
          externalState={externalState}
          setExternalState={setExternalState}
          style={{ height: '100%' }}
          showColumnVisibility
          rowHeight={26}
        />
      </div>
    </Window>
  );
};

export default PreviousCubeVersionsWindow;

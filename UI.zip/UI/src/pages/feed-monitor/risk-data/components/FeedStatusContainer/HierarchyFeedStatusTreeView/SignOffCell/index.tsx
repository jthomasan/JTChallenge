import React from 'react';
import { FileDoneOutlined } from '@ant-design/icons';
import { Tooltip } from 'antd';
import { TreeListCellProps } from '@progress/kendo-react-treelist';
import Authorized from '@/utils/Authorized';

import styles from './index.less';

interface SignOffPortfolioProps {
  onClick: () => void;
}

const SignOffPortfolio: React.FC<SignOffPortfolioProps> = ({ onClick }) => (
  <Tooltip placement="top" title="Signoff data for this node">
    <div className={styles.signOffContainer} onClick={onClick}>
      <FileDoneOutlined />
    </div>
  </Tooltip>
);

export const withSignOff = (
  Component: React.ComponentType<TreeListCellProps>,
  {
    onClick,
  }: {
    onClick: (id: string) => void;
  },
): React.FC<TreeListCellProps> => (props) => {
  const { dataItem } = props;
  const { nodeId, feed, isSignOffAllowed } = dataItem;

  if (!feed) {
    return null;
  }

  return (
    <div className={styles.signOffCell}>
      <Component {...props} />
      <Authorized authority={['FEED_MONITOR.RISK_DATA.WRITE']}>
        {isSignOffAllowed && <SignOffPortfolio onClick={() => onClick(nodeId)} />}
      </Authorized>
    </div>
  );
};

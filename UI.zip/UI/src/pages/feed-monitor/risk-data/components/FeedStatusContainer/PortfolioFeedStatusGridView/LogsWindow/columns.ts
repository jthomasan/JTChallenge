import { ColumnProps } from '@/components/Grid';

export const columns: ColumnProps[] = [
  {
    field: 'feedID',
    title: 'Feed ID',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'reportName',
    title: 'Report Name',
    width: '150px',
  },
  {
    field: 'portfolio',
    title: 'Portfolio',
    width: '150px',
  },
  {
    field: 'message',
    title: 'Message',
    width: '200px',
  },
];

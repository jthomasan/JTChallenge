import { ColumnProps, CellProps } from '@/components/Grid';
import StatusIndicatorCell from '../../common/StatusIndicatorCell';
import CheckboxCell from '../../common/CheckboxCell';
import { generateWarningAndAdditionalInfoCell } from '../../common/WarningAndAdditionalInfoCell';
import generateSourceSystemStatusCell, {
  SourceSystemStatusCellProps,
} from '../../common/SourceSystemStatusCell';
import generateCubeVersionCell, { CubeVersionCellInitialProps } from './CubeVersionCell';

interface ColumnInitProps extends SourceSystemStatusCellProps, CubeVersionCellInitialProps {}

export const generateColumns = ({
  onSelectSourceSystemError,
  onSelectPreviousCubeVersion,
}: ColumnInitProps): ColumnProps[] => [
  {
    field: 'portfolio.name',
    title: 'Portfolio',
    width: '150px',
    defaultSortColumn: true,
  },
  {
    field: 'reportName',
    title: 'Report',
    width: '100px',
  },
  {
    field: 'container.name',
    title: 'Container',
    width: '150px',
  },
  {
    field: 'status.riskEngine',
    title: 'Risk Engine',
    width: '100px',
    cell: generateSourceSystemStatusCell({ onSelectSourceSystemError }),
  },
  {
    field: 'isStale',
    title: 'Stale',
    filter: 'boolean',
    width: '100px',
    cell: generateWarningAndAdditionalInfoCell({
      additionalInfoField: 'additionalInfo',
      nameField: 'portfolio.name',
      tooltipSubtitle: 'Stale Reason',
    }),
  },
  {
    field: 'isProxy',
    title: 'Proxy',
    filter: 'boolean',
    width: '100px',
    cell: generateWarningAndAdditionalInfoCell({
      additionalInfoField: 'additionalInfo',
      additionalInfoShortRegex: /\{proxyReason : ([^\s]+)/,
      nameField: 'portfolio.name',
      tooltipSubtitle: 'Proxy Reason',
    }),
  },
  {
    field: 'status.download',
    title: 'Download',
    width: '100px',
    cell: StatusIndicatorCell,
    hidden: true,
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'status.cubeTradeEtl',
    title: 'Trade ETL',
    width: '100px',
    cell: StatusIndicatorCell,
    hidden: true,
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'status.subCubePositionEtl',
    title: 'Position ETL',
    width: '100px',
    cell: StatusIndicatorCell,
    hidden: true,
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'status.cubeLoad',
    title: 'Cube',
    width: '100px',
    cell: StatusIndicatorCell,
  },
  {
    field: 'status.subCubeLoad',
    title: 'Subcube',
    width: '100px',
    cell: StatusIndicatorCell,
  },
  {
    field: 'status.fvaCubeTradeEtl',
    title: 'Trade ETL (FVA)',
    width: '110px',
    cell: StatusIndicatorCell,
    hidden: true,
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'status.fvaSubcubePositionEtl',
    title: 'Position ETL (FVA)',
    width: '120px',
    cell: StatusIndicatorCell,
    hidden: true,
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'status.fvaCubeLoad',
    title: 'Cube (FVA)',
    width: '100px',
    cell: StatusIndicatorCell,
    hidden: true,
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'status.fvaSubcubeLoad',
    title: 'Subcube (FVA)',
    width: '110px',
    cell: StatusIndicatorCell,
    hidden: true,
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'status.rdw',
    title: 'RDW',
    width: '100px',
    cell: StatusIndicatorCell,
  },
  {
    field: 'status.signOff',
    title: 'Signoff',
    width: '100px',
    cell: StatusIndicatorCell,
  },
  {
    field: 'cubeVersion',
    title: 'Version',
    width: '80px',
    cell: generateCubeVersionCell({
      onSelectPreviousCubeVersion,
    }),
  },
  {
    field: 'isRerun',
    title: 'Rerun',
    width: '80px',
    cell: CheckboxCell as React.FC<CellProps>,
  },
  {
    field: 'isExclusion',
    title: 'Exclude',
    width: '80px',
    cell: CheckboxCell as React.FC<CellProps>,
  },
  {
    field: 'isReload',
    title: 'Reload',
    width: '80px',
    cell: CheckboxCell as React.FC<CellProps>,
  },
  {
    field: 'sourceSystemEnvironment',
    title: 'Source',
    width: '80px',
  },
];

import { NodeType } from '../types';
import { getSelectedPortfolios } from './getSelectedPortfolios';

const hierarchies = [
  {
    id: '1',
    nodeId: '1',
    parent: {
      id: '0',
      nodeId: '0',
    },
    type: NodeType.PORTFOLIO_NODE,
  },
  {
    id: '2',
    nodeId: '2',
    parent: {
      id: '1',
      nodeId: '1',
    },
    type: NodeType.PORTFOLIO_LEAF,
  },
  {
    id: '3',
    nodeId: '3',
    parent: {
      id: '1',
      nodeId: '1',
    },
    type: NodeType.PORTFOLIO_NODE,
  },
  {
    id: '4',
    nodeId: '4',
    parent: {
      id: '3',
      nodeId: '3',
    },
    type: NodeType.PORTFOLIO_LEAF,
  },
] as any;

const hierarchiesById = {
  '1': {
    id: '1',
    nodeId: '1',
    parent: {
      id: '0',
      nodeId: '0',
    },
    type: NodeType.PORTFOLIO_NODE,
  },
  '2': {
    id: '2',
    nodeId: '2',
    parent: {
      id: '1',
      nodeId: '1',
    },
    type: NodeType.PORTFOLIO_LEAF,
  },
  '3': {
    id: '3',
    nodeId: '3',
    parent: {
      id: '1',
      nodeId: '1',
    },
    type: NodeType.PORTFOLIO_NODE,
  },
  '4': {
    id: '4',
    nodeId: '4',
    parent: {
      id: '3',
      nodeId: '3',
    },
    type: NodeType.PORTFOLIO_LEAF,
  },
} as any;

describe('getSelectedPortfolios Tests', () => {
  it('should return leafs of selected nodes', () => {
    let res = getSelectedPortfolios(hierarchies, hierarchiesById, ['1']);
    expect(res).toEqual([hierarchies[1], hierarchies[3]]);

    res = getSelectedPortfolios(hierarchies, hierarchiesById, ['1', '3']);
    expect(res).toEqual([hierarchies[1], hierarchies[3]]);

    res = getSelectedPortfolios(hierarchies, hierarchiesById, ['1', '2']);
    expect(res).toEqual([hierarchies[1], hierarchies[3]]);
  });
});

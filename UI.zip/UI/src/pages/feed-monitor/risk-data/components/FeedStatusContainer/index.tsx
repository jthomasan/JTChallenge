import React, { useState, useEffect, useCallback } from 'react';
import { Modal } from 'antd';
import {
  gql,
  useMutation,
  clearCacheOfType,
  useApolloClient,
} from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import ProgressIndicator, { ActionType } from '@/components/ProgressIndicator';
import useTreeSearch from '@/components/TreeList/useTreeSearch';
import {
  FeedStatusView,
  UserRequestType,
  PortfolioFeedAction,
  OverrideStatus,
  SendRetryRequestEntities,
  SendOverrideStatusRequestEntities,
  RetryRequest,
  FeedStatusAction,
  NodeType,
} from './types';
import HierarchyFeedStatusTreeView from './HierarchyFeedStatusTreeView';
import { PortfolioFeedStatus } from '../../types/portfolioFeedStatus';
import PortfolioFeedStatusGridView from './PortfolioFeedStatusGridView';
import FeedStatusSubHeader from './FeedStatusSubHeader';
import { HierarchyFeedStatus } from '../../types/hierarchyFeedStatus';
import { RiskContainerStatus } from '../RiskContainerStatusTable/query';
import { UserRequestRenderer } from './UserRequestRenderer';
import REMEventsGridView from '../REMEventsGridView';
import PricingErrorStatusWindow from './PricingErrorStatusWindow';
import LogsWindow from './PortfolioFeedStatusGridView/LogsWindow';

import styles from './index.less';
import { FormState } from '../../types';

export interface FeedStatusContainerExternalState {
  selectedPortfolios: HierarchyFeedStatus[];
  feedStatusCurrentView?: FeedStatusView;
  selectedUserRequestType?: UserRequestType;
  showDetailedStatus?: boolean;
  selectedNodeId?: string;
  selectedNode: HierarchyFeedStatus;
  showPendingFeedsOnly: boolean;
}

export interface RiskDataProps {
  nodeName: string;
  nodeId: number;
  date: string;
  snapshot: string;
  onSetDefaultNode: (value: Pick<FormState, 'node'>) => void;
  containerIds?: string[];
  reportTypeIds?: number[];
  sourceSystemIds?: number[];
  sourceSystemEnvironments?: string[];
}

interface REMEventsConfig {
  show: boolean;
  feedIDs: string[];
}

export interface SourceSystemError {
  cob: string;
  snapshot: string;
  isPortfolioNode: boolean;
  portfolioNode: string;
  reportName?: string;
}

interface SourceSystemErrorConfig {
  show: boolean;
  params: SourceSystemError;
}

interface ShowLogsConfig {
  show: boolean;
  feedIDs: string[];
}

interface FeedStatusContainerProps extends RiskDataProps {
  selectedContainers: RiskContainerStatus[];
}

const feedActionMessages = {
  retry: 'Are you sure you want to retry the selected feeds?',
  override: 'Are you sure you want to override the status of the selected feeds?',
};

const QUERY = gql`
  mutation batch($actions: [BatchActions!]!) {
    batchChange(actions: $actions) {
      success
      actions
    }
  }
`;

const showRetryConfirmationModal = (title: string, message: string, callback: () => void) => {
  Modal.confirm({
    title,
    content: message,
    onOk: callback,
  });
};

const FeedStatusContainer: React.FC<FeedStatusContainerProps> = ({
  selectedContainers,
  nodeName,
  onSetDefaultNode,
  nodeId,
  date,
  snapshot,
  containerIds,
  reportTypeIds,
  sourceSystemIds,
  sourceSystemEnvironments,
}) => {
  const client = useApolloClient();
  const [externalState, setExternalState] = useGQLComponentState<FeedStatusContainerExternalState>(
    {
      selectedPortfolios: [],
      selectedNode: {} as HierarchyFeedStatus,
      showPendingFeedsOnly: false,
    },
    'FeedStatusContainer',
  );
  const selectedPortfolios = externalState?.selectedPortfolios ?? {};
  const { showPendingFeedsOnly } = externalState;
  const feedStatusCurrentView = externalState.feedStatusCurrentView ?? FeedStatusView.TreeView;
  const selectedUserRequestType = externalState.selectedUserRequestType ?? UserRequestType.None;
  const [selectedNodeForSignOff, setSelectedNodeForSignOff] = useState<HierarchyFeedStatus>(
    {} as HierarchyFeedStatus,
  );
  const [selectedPortfolioFeeds, setSelectedPortfolioFeeds] = useState<PortfolioFeedStatus[]>([]);
  const [progressIndicator, setProgressIndicator] = useState<{
    action: ActionType;
    message: string;
    title?: string;
  }>({
    action: ActionType.none,
    message: '',
  });
  const [sendPortfolioFeedActionRequest] = useMutation(QUERY);
  const [REMEvents, setREMEvents] = useState<REMEventsConfig>({
    show: false,
    feedIDs: [],
  });
  const [sourceSystemError, setsourceSystemError] = useState<SourceSystemErrorConfig>({
    show: false,
    params: {} as SourceSystemError,
  });
  const [searchTextForNodes, setSearchTextForNodes] = useState('');
  const treeSearchProps = useTreeSearch({
    searchField: 'name',
    subItemsField: 'children',
    idField: 'nodeId',
  });
  const [searchTextForPortfolios, setSearchTextForPortfolios] = useState('');
  const [showLogs, setShowLogs] = useState<ShowLogsConfig>({ show: false, feedIDs: [] });

  useEffect(() => {
    treeSearchProps.setSearchText(searchTextForNodes);
  }, [searchTextForNodes]);

  const createMutationActionForRetryRequest = (
    retryFeedRequest: string,
    feedIDs: string[],
    retryType: RetryRequest,
  ): SendRetryRequestEntities => ({
    [retryFeedRequest]: {
      feedIDs,
      retryType,
    },
  });

  const createMutationActionForOverrideRequest = (
    retryFeedRequest: string,
    feedIDs: string[],
    newStatus: OverrideStatus,
  ): SendOverrideStatusRequestEntities => ({
    [retryFeedRequest]: {
      feedIDs,
      newStatus,
    },
  });

  const fireRefreshEvent = () => {
    window.dispatchEvent(
      new CustomEvent('feedStatusActions', {
        detail: FeedStatusAction.Refresh,
      }),
    );
  };

  const onSetSelectedNode = (node: HierarchyFeedStatus) => {
    clearCacheOfType(client, 'RiskDataPortfolioFeedStatuses');
    setExternalState({
      selectedNodeId: node.nodeId,
      selectedNode: node,
      feedStatusCurrentView: FeedStatusView.GridView,
    });
  };

  const onRemoveSelectedNode = () => {
    clearCacheOfType(client, 'RiskDataPortfolioFeedStatuses');
    setExternalState({
      selectedNodeId: undefined,
      selectedNode: {} as HierarchyFeedStatus,
      feedStatusCurrentView: FeedStatusView.GridView,
    });
  };

  const processPortfolioFeedActionsRequests: <T>(
    actions: T,
    title: string,
  ) => Promise<void> = async (actions, title) => {
    try {
      await sendPortfolioFeedActionRequest({
        variables: {
          actions,
        },
      });
      setProgressIndicator({ action: ActionType.completed, message: 'Sent' });
      fireRefreshEvent();
    } catch (e) {
      setProgressIndicator({
        action: ActionType.error,
        message: 'Failed to process the request',
        title,
      });
    }
  };

  const processOverrideRequest = async (feedIDs: string[], action: OverrideStatus) => {
    const mutationActions = [
      createMutationActionForOverrideRequest('sendOverrideFeedStatusRequest', feedIDs, action),
    ];

    await processPortfolioFeedActionsRequests<SendOverrideStatusRequestEntities[]>(
      mutationActions,
      'Override  Status Request',
    );
  };

  const processRetryRequest = async (
    fmFeedIDs: string[],
    remFeedIDs: string[],
    action: RetryRequest,
  ) => {
    setProgressIndicator({ action: ActionType.inProgress, message: 'Sending...' });
    const mutationActions = [];

    if (fmFeedIDs.length) {
      mutationActions.push(
        createMutationActionForRetryRequest('sendFMRetryFeedRequest', fmFeedIDs, action),
      );
    }

    if (remFeedIDs.length) {
      mutationActions.push(
        createMutationActionForRetryRequest('sendREMRetryFeedRequest', remFeedIDs, action),
      );
    }

    await processPortfolioFeedActionsRequests<SendRetryRequestEntities[]>(
      mutationActions,
      'Retry Feeds Request',
    );
  };

  const onSelectPortfolioFeedAction = (action: PortfolioFeedAction) => {
    const isRetryAction = Object.values(RetryRequest).some((o) => o === action);
    const isOverrideAction = Object.values(OverrideStatus).some((o) => o === action);

    if (isRetryAction) {
      const fmFeedIDs = selectedPortfolioFeeds.filter((i) => i.isFmFeed).map((i) => i.feedId);
      const remFeedIDs = selectedPortfolioFeeds.filter((i) => !i.isFmFeed).map((i) => i.feedId);

      showRetryConfirmationModal('Confirm Retry', feedActionMessages.retry, () => {
        processRetryRequest(fmFeedIDs, remFeedIDs, action as RetryRequest);
      });
    } else if (isOverrideAction) {
      const feedIDs = selectedPortfolioFeeds.map((i) => i.feedId);

      showRetryConfirmationModal('Confirm Override', feedActionMessages.override, () => {
        processOverrideRequest(feedIDs, action as OverrideStatus);
      });
    } else if (action === PortfolioFeedAction.ShowREMEvents) {
      const feedIDs = selectedPortfolioFeeds.map((i) => i.feedId);
      setREMEvents({
        show: true,
        feedIDs,
      });
    } else {
      const feedIDs = selectedPortfolioFeeds.map((i) => i.feedId);

      setShowLogs({
        feedIDs,
        show: true,
      });
    }
  };

  const onClickSignOff = useCallback(
    (node: HierarchyFeedStatus) => {
      setSelectedNodeForSignOff(node);
      setExternalState({
        selectedUserRequestType: UserRequestType.SignOffRequest,
      } as FeedStatusContainerExternalState);
    },
    [setSelectedNodeForSignOff, setExternalState],
  );

  const onSelectSourceSystemError = (params: SourceSystemError) => {
    setsourceSystemError({
      params,
      show: true,
    });
  };

  const onCloseSourceSystemErrorWindow = () => {
    setsourceSystemError({
      params: {} as SourceSystemError,
      show: false,
    });
  };

  const onCloseUserRequestWindow = () => {
    setExternalState({
      selectedUserRequestType: UserRequestType.None,
    } as FeedStatusContainerExternalState);
  };

  return (
    <div className={styles.feedStatusContainer}>
      <ProgressIndicator
        title={progressIndicator.title ?? ''}
        action={progressIndicator.action}
        actionMessage={progressIndicator.message}
      />
      <FeedStatusSubHeader
        selectedPortfolios={selectedPortfolios}
        selectedNode={externalState.selectedNode}
        selectedPortfolioFeeds={selectedPortfolioFeeds}
        selectedFeedStatusView={feedStatusCurrentView}
        searchTextForNodes={searchTextForNodes}
        treeSearchProps={treeSearchProps}
        searchTextForPortfolios={searchTextForPortfolios}
        showPendingFeedsOnly={showPendingFeedsOnly}
        onSetShowPendingFeedsOnly={(value) => {
          setExternalState({
            showPendingFeedsOnly: value,
          });
        }}
        onSetSearchTextForNodes={setSearchTextForNodes}
        onSetSearchTextForPortfolios={setSearchTextForPortfolios}
        onRemoveSelectedNode={onRemoveSelectedNode}
        onSelectPortfolioFeedAction={onSelectPortfolioFeedAction}
        onSelectFeedStatusView={(event) => {
          setExternalState({
            feedStatusCurrentView: event,
          });
        }}
        onSelectUserRequestType={(event) => {
          setExternalState({
            selectedUserRequestType: event,
          });
        }}
        onClear={() => {
          setExternalState({ selectedPortfolios: [] });
          setSelectedPortfolioFeeds([]);
        }}
        onClickShowDetailedStatus={() => {
          setExternalState({ showDetailedStatus: !externalState.showDetailedStatus });
        }}
        showDetailedStatus={externalState.showDetailedStatus}
      />
      <div className={styles.feedStatusGrid}>
        {feedStatusCurrentView === FeedStatusView.TreeView && (
          <HierarchyFeedStatusTreeView
            isRootPortfolioNode
            nodeId={nodeId}
            date={date}
            snapshot={snapshot}
            containerIds={containerIds}
            treeSearchProps={treeSearchProps}
            searchText={searchTextForNodes}
            reportTypeIds={reportTypeIds}
            sourceSystemIds={sourceSystemIds}
            onSetSelectedNode={onSetSelectedNode}
            sourceSystemEnvironments={sourceSystemEnvironments}
            onSelectSourceSystemError={onSelectSourceSystemError}
            onClickSignOff={onClickSignOff}
            onSelectHierarchyNodes={(nodes) => {
              setExternalState({ selectedPortfolios: nodes });
            }}
            onSetDefaultNode={onSetDefaultNode}
            onSetShowPendingFeedsOnly={(value) => {
              setExternalState({
                showPendingFeedsOnly: value,
              });
            }}
            showDetailedStatus={externalState.showDetailedStatus}
          />
        )}
        {feedStatusCurrentView === FeedStatusView.GridView && (
          <PortfolioFeedStatusGridView
            isRootPortfolioNode={
              externalState.selectedNode?.type === NodeType.PORTFOLIO_NODE ||
              !externalState.selectedNodeId
            }
            nodeId={externalState.selectedNodeId ?? nodeId.toString()}
            date={date}
            snapshot={snapshot}
            containerIds={containerIds}
            reportTypeIds={reportTypeIds}
            sourceSystemIds={sourceSystemIds}
            sourceSystemEnvironments={sourceSystemEnvironments}
            searchText={searchTextForPortfolios}
            showPendingFeedsOnly={showPendingFeedsOnly}
            onChange={setSelectedPortfolioFeeds}
            showDetailedStatus={externalState.showDetailedStatus}
            onSelectSourceSystemError={onSelectSourceSystemError}
          />
        )}

        <UserRequestRenderer
          nodeName={nodeName}
          nodeId={nodeId}
          date={date}
          snapshot={snapshot}
          containerIds={containerIds}
          selectedContainers={selectedContainers}
          selectedPortfolios={selectedPortfolios}
          selectedPortfolioFeeds={selectedPortfolioFeeds}
          selectedNodeForSignOff={selectedNodeForSignOff}
          userRequestType={selectedUserRequestType}
          reportTypeIds={reportTypeIds}
          sourceSystemIds={sourceSystemIds}
          sourceSystemEnvironments={sourceSystemEnvironments}
          onCloseUserRequestWindow={onCloseUserRequestWindow}
        />
      </div>
      {REMEvents.show && (
        <REMEventsGridView
          ids={REMEvents.feedIDs}
          onClose={() => {
            setREMEvents({
              show: false,
              feedIDs: [],
            });
          }}
        />
      )}
      {sourceSystemError.show && (
        <PricingErrorStatusWindow
          {...sourceSystemError.params}
          onClose={onCloseSourceSystemErrorWindow}
        />
      )}
      {showLogs.show && (
        <LogsWindow
          feedIDs={showLogs.feedIDs}
          onCloseWindow={() => {
            setShowLogs({
              show: false,
              feedIDs: [],
            });
          }}
        />
      )}
    </div>
  );
};

export default FeedStatusContainer;

export enum NodeType {
  PORTFOLIO_NODE = 'PORTFOLIO_NODE',
  PORTFOLIO_LEAF = 'PORTFOLIO_LEAF',
}

export enum FeedStatusView {
  TreeView,
  GridView,
}

export enum UserRequestType {
  RerunRequest = 'RerunRequest',
  ProxyRequest = 'ProxyRequest',
  ExcludeRequest = 'ExcludeRequest',
  ReloadRequest = 'ReloadRequest',
  SignOffRequest = 'SignOffRequest',
  None = 'none',
}

export enum OverrideStatus {
  Complete = 'COMPLETE',
  Aborted = 'ABORTED',
  NoData = 'NO_DATA',
}

export enum RetryRequest {
  RetryCubeLoad = 'CubeLoad',
  RetryPublish = 'Publish',
  RetrySubCube = 'SubCubeLoad',
  RestartFeed = 'Restart',
}

export enum CommonFeedRequest {
  ShowLogs = 'ShowLogs',
  ShowREMEvents = 'ShowREMEvents',
}

export enum FeedStatusAction {
  Refresh = 'Refresh',
  BackgroundRefresh = 'BackgroundRefresh',
  Clear = 'Clear',
  CollapseAllNodes = 'CollapseAllNodes',
}

export const PortfolioFeedAction = { ...RetryRequest, ...OverrideStatus, ...CommonFeedRequest };
export type PortfolioFeedAction = RetryRequest | OverrideStatus | CommonFeedRequest;

interface SendRetryRequest {
  feedIDs: string[];
  retryType: RetryRequest;
}

export interface SendRetryRequestEntities {
  [action: string]: SendRetryRequest;
}

interface SendOverrideStatusRequest {
  feedIDs: string[];
  newStatus: OverrideStatus;
}

export interface SendOverrideStatusRequestEntities {
  [action: string]: SendOverrideStatusRequest;
}

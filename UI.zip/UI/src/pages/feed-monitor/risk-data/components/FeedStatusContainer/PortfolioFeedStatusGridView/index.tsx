import React, { useEffect, useMemo, useCallback, useState } from 'react';
import { keyBy } from 'lodash';
import { NetworkStatus } from 'umi-plugin-apollo-anz/apolloClient';
import useQueryDiskCache from '@/hooks/useQueryDiskCache';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import Grid, { GridExternalState, ColumnProps } from '@/components/Grid';
import { getSelectionColumn } from '@/components/Grid/selection/getSelectionColumn';
import PreviousCubeVersionsWindow from './PreviousCubeVersionsWindow';
import { PortfolioFeedStatus } from '../../../types/portfolioFeedStatus';
import { FeedStatusAction } from '../types';
import { generateColumns } from './columns';
import query from './query';

import styles from './index.less';
import { SourceSystemError } from '..';

export interface PortfolioFeedStatusState {
  selectedPortfolioLeafs: string[];
}

interface PortfolioFeedStatusGridViewProps {
  nodeId: string;
  date: string;
  snapshot: string;
  containerIds?: string[];
  reportTypeIds?: number[];
  sourceSystemIds?: number[];
  sourceSystemEnvironments?: string[];
  searchText: string;
  showPendingFeedsOnly: boolean;
  isRootPortfolioNode: boolean;
  onChange: (portfolioLeafs: PortfolioFeedStatus[]) => void;
  showDetailedStatus?: boolean;
  onSelectSourceSystemError: (params: SourceSystemError) => void;
}

const pendingFeedsStatuses = ['NOT_STARTED', 'PROCESSING', 'FAILED'];

const identifyFeed = (dataItem: any) =>
  `${dataItem.feedId}:${dataItem.container?.id}:${dataItem.portfolio?.id}`;

const PortfolioFeedStatusGridView: React.FC<PortfolioFeedStatusGridViewProps> = ({
  nodeId,
  date,
  snapshot,
  containerIds,
  reportTypeIds,
  sourceSystemIds,
  searchText,
  showPendingFeedsOnly,
  sourceSystemEnvironments,
  isRootPortfolioNode,
  onChange,
  showDetailedStatus,
  onSelectSourceSystemError,
}) => {
  const { loading, data, refetch, networkStatus } = useQueryDiskCache<{
    RiskDataPortfolioFeedStatuses: PortfolioFeedStatus[];
  }>(query, {
    variables: {
      isRootPortfolioNode,
      nodeId,
      cob: date,
      snapshot,
      containerIds,
      reportTypeIds,
      sourceSystemIds,
      sourceSystemEnvironments,
      statuses: showPendingFeedsOnly ? pendingFeedsStatuses : null,
    },
    notifyOnNetworkStatusChange: true,
  });

  const [externalState, setExternalState] = useGQLComponentState<PortfolioFeedStatusState>(
    {
      selectedPortfolioLeafs: [],
    },
    'PortfolioFeedStatusExternalState',
  );
  const [gridExternalState, setGridExternalState] = useGQLComponentState<GridExternalState>(
    {},
    'gridExternalState',
  );
  const riskDataPortfolioFeedStatuses = data?.RiskDataPortfolioFeedStatuses || [];
  const portfolioFeedStatusById = useMemo(
    () => keyBy(riskDataPortfolioFeedStatuses, identifyFeed),
    [riskDataPortfolioFeedStatuses],
  );
  const riskDataPortfolioFeedStatusesFiltered = useMemo(() => {
    if (!searchText) {
      return riskDataPortfolioFeedStatuses;
    }

    const isValueFound = (value: string) => value.toUpperCase().includes(searchText.toUpperCase());

    return riskDataPortfolioFeedStatuses.filter(
      (i) =>
        isValueFound(i.portfolio.name) ||
        isValueFound(i.reportName) ||
        isValueFound(i.container.name),
    );
  }, [riskDataPortfolioFeedStatuses, searchText]);
  const [showPreviousCubeVersions, setShowPreviousCubeVersions] = useState(false);
  const [selectedCubeLoadId, setSelectedCubeLoadId] = useState<string | null>(null);

  const onSelectPortfolioFeeds = useCallback(
    (value: string[]) => {
      const portfolioLeafs = value.map((o) => portfolioFeedStatusById[o]);
      onChange(portfolioLeafs);

      setExternalState({
        selectedPortfolioLeafs: value,
      } as PortfolioFeedStatusState);
    },
    [onChange, portfolioFeedStatusById, setExternalState],
  );

  const refreshData = (backgroundRefresh = false) => {
    if (!backgroundRefresh) {
      onSelectPortfolioFeeds([]);
    }

    refetch();
  };

  const selectSourceSystemError = useCallback(
    (params: Omit<SourceSystemError, 'cob' | 'snapshot'>) => {
      onSelectSourceSystemError({
        ...params,
        cob: date,
        snapshot,
      });
    },
    [date, onSelectSourceSystemError, snapshot],
  );

  const onSelectPreviousCubeVersion = (cubeLoadId: string) => {
    setSelectedCubeLoadId(cubeLoadId);
    setShowPreviousCubeVersions(true);
  };

  const onClosePreviousCubeVersionWindow = () => {
    setShowPreviousCubeVersions(false);
  };

  const baseColumns = useMemo(
    () =>
      generateColumns({
        onSelectSourceSystemError: selectSourceSystemError,
        onSelectPreviousCubeVersion,
      }),
    [selectSourceSystemError],
  );

  const switchedColumns = useMemo(
    () =>
      baseColumns.map((column) =>
        !column.extras?.isDetailedStatusColumn
          ? column
          : {
              ...column,
              hidden: !showDetailedStatus,
            },
      ),
    [baseColumns, showDetailedStatus],
  );

  const columnsWithSelector = useMemo<ColumnProps[]>(
    () => [
      getSelectionColumn({
        identifier: ['feedSelection', identifyFeed],
        selected: externalState.selectedPortfolioLeafs,
        onChange: onSelectPortfolioFeeds,
      }),
      ...switchedColumns,
    ],
    [externalState.selectedPortfolioLeafs, onSelectPortfolioFeeds, switchedColumns],
  );

  const feedStatusActionEventListener = ({ detail }: CustomEvent<FeedStatusAction>) => {
    switch (detail) {
      case FeedStatusAction.Refresh:
        refreshData();
        break;

      case FeedStatusAction.BackgroundRefresh:
        refreshData(true);
        break;

      case FeedStatusAction.Clear:
        onSelectPortfolioFeeds([]);
        break;

      default:
        break;
    }
  };

  useEffect(() => {
    window.addEventListener('feedStatusActions', feedStatusActionEventListener as EventListener);

    return () => {
      window.removeEventListener(
        'feedStatusActions',
        feedStatusActionEventListener as EventListener,
      );
    };
  }, []);

  return (
    <div className={styles.portfolioFeedStatusGridView}>
      <Grid
        loading={loading || networkStatus !== NetworkStatus.ready}
        data={riskDataPortfolioFeedStatusesFiltered}
        columns={columnsWithSelector}
        externalState={gridExternalState}
        setExternalState={setGridExternalState}
        style={{ height: '100%' }}
        showColumnVisibility
        rowHeight={26}
        supressCustomCellsDuringScrolling
      />
      {showPreviousCubeVersions && (
        <PreviousCubeVersionsWindow
          cubeLoadId={selectedCubeLoadId}
          onCloseWindow={onClosePreviousCubeVersionWindow}
        />
      )}
    </div>
  );
};

export default PortfolioFeedStatusGridView;

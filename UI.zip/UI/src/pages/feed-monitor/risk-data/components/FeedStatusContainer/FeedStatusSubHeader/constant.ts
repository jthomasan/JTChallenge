export const ErrorMessages = {
  minPortfolioSelection: 'Please select at least one portfolio.',
  minPortfolioFeed: 'Please select at least one feed.',
  maxPortfolioSelection:
    'The number of selected portfolio is exceeding the maximum allowed limit (100). Please select less portfolios or a lower level node.',
  maxPortfolioFeed: 'The number of selected feed is exceeding the maximum allowed limit (100).',
  noRerunPortfolioSelection:
    'Invalid portfolio selection. The selected portfolio(s) are not enabled for reruns.',
  feedsWithMultipleSourceSystems: 'Please select feeds with the same source.',
};

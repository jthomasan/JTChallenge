import React from 'react';
import {
  UndoOutlined,
  BranchesOutlined,
  CloseCircleOutlined,
  ExportOutlined,
  StopOutlined,
} from '@ant-design/icons';
import classNames from 'classnames';

import SimpleTD from '@/components/SimpleTD';
import { TreeListCellProps } from '@/components/TreeList';
import Tooltip from '../../../common/Tooltips/RiskDataTooltip';

import styles from './ActivityIndicatorCell.less';

const ActivityIndicatorCell: React.FC<TreeListCellProps> = ({ dataItem, className, ...props }) => (
  <SimpleTD {...props} className={classNames(styles.activityIndicatorCell, className)}>
    {dataItem?.feed?.isRerun ? (
      <Tooltip key="rerun" title="Rerun" mouseEnterDelay={0}>
        <UndoOutlined />
      </Tooltip>
    ) : null}
    {dataItem?.feed?.isProxy ? (
      <Tooltip key="proxy" title="Proxy" mouseEnterDelay={0}>
        <BranchesOutlined />
      </Tooltip>
    ) : null}
    {dataItem?.feed?.isExclusion ? (
      <Tooltip key="exclude" title="Exclude" mouseEnterDelay={0}>
        <CloseCircleOutlined />
      </Tooltip>
    ) : null}
    {dataItem?.feed?.isReload ? (
      <Tooltip key="reload" title="Reloaded" mouseEnterDelay={0}>
        <ExportOutlined />
      </Tooltip>
    ) : null}
    {dataItem?.feed?.hasQuarantine ? (
      <Tooltip key="quarantine" title="Quarantined" mouseEnterDelay={0}>
        <StopOutlined />
      </Tooltip>
    ) : null}
  </SimpleTD>
);

export default ActivityIndicatorCell;

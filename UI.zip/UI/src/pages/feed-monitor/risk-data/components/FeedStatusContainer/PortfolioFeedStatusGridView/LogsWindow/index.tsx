import React, { useState } from 'react';
import { useQuery, gql } from 'umi-plugin-apollo-anz/apolloClient';
import { Button } from 'antd';
import Window from '@/components/Window';
import Grid from '@/components/Grid';
import { constructURL } from '@/utils/request';
import { columns } from './columns';

import styles from './index.less';

interface LogsWindowProps {
  feedIDs: string[];
  onCloseWindow: () => void;
}

interface Logs {
  feedID: string;
  reportName: string;
  portfolio: string;
  message: string;
}

const QUERY = gql`
  query FeedLogMessages($feedIDs: [ID]!) {
    FeedLogMessages(feedIDs: $feedIDs) {
      feedID
      reportName
      portfolio
      message
    }
  }
`;

const LogsWindow: React.FC<LogsWindowProps> = ({ feedIDs, onCloseWindow }) => {
  const [exporting, setExporting] = useState(false);
  const { loading, data } = useQuery<
    Record<'FeedLogMessages', Logs[]>,
    Pick<LogsWindowProps, 'feedIDs'>
  >(QUERY, {
    variables: {
      feedIDs,
    },
    fetchPolicy: 'no-cache',
  });

  const onExport = () => {
    setExporting(true);

    window.location.href = constructURL<Pick<LogsWindowProps, 'feedIDs'>>(
      '/export/feed-monitor/risk-data/feed-log-messages/csv',
      { feedIDs },
    );
    setTimeout(() => {
      setExporting(false);
    }, 2000);
  };

  return (
    <Window
      title="Logs"
      initialHeight={400}
      initialWidth={700}
      minHeight={400}
      minWidth={700}
      onClose={onCloseWindow}
    >
      <div className={styles.gridContainer}>
        <div className={styles.gridHeader}>
          <Button size="small" onClick={onExport}>
            {exporting ? 'Exporting' : 'Export'}
          </Button>
        </div>
        <Grid
          loading={loading}
          data={data?.FeedLogMessages || []}
          columns={columns}
          style={{ height: '100%' }}
          showColumnVisibility
          rowHeight={26}
        />
      </div>
    </Window>
  );
};

export default LogsWindow;

import React, { useMemo } from 'react';
import { uniq } from 'lodash';
import UserRequestWindow, { UserRequestType } from '../UserRequest/UserRequestWindow';
import { RiskDataProps } from '.';
import { RiskContainerStatus } from '../RiskContainerStatusTable/query';
import { HierarchyFeedStatus } from '../../types/hierarchyFeedStatus';
import SelectReportGrid from '../UserRequest/SelectReportGrid';
import RerunRequestForm from '../UserRequest/RerunRequestForm';
import ProxyRequestForm from '../UserRequest/ProxyRequestForm';
import ExcludeRequestForm from '../UserRequest/ExcludeRequestForm';
import ReloadRequestForm from '../UserRequest/ReloadRequestForm';
import RiskContainerStatusHandler from '../UserRequest/RiskContainerStatusHandler';
import SignOffRequestForm from '../UserRequest/SignOffRequestForm';
import { PortfolioFeedStatus } from '../../types/portfolioFeedStatus';

interface UserRequestRendererProps extends RiskDataProps {
  userRequestType: UserRequestType;
  selectedContainers: RiskContainerStatus[];
  selectedPortfolios: HierarchyFeedStatus[];
  selectedPortfolioFeeds: PortfolioFeedStatus[];
  selectedNodeForSignOff: HierarchyFeedStatus;
  onCloseUserRequestWindow: () => void;
}

export const UserRequestRenderer: React.FC<UserRequestRendererProps> = ({
  userRequestType,
  date,
  nodeId,
  snapshot,
  reportTypeIds,
  sourceSystemEnvironments,
  sourceSystemIds,
  selectedContainers,
  selectedPortfolios,
  selectedPortfolioFeeds,
  selectedNodeForSignOff,
  onCloseUserRequestWindow,
}) => {
  const filteredSelectedPortfolios = useMemo(
    () =>
      userRequestType === UserRequestType.RerunRequest
        ? selectedPortfolios.filter((portfolio) => portfolio.isRerunEnabled)
        : selectedPortfolios,
    [selectedPortfolios, userRequestType],
  );

  const reportsFromSelectedPortfolioFeeds = useMemo(
    () => uniq(selectedPortfolioFeeds.map((i) => i?.reportName)),
    [selectedPortfolioFeeds],
  );

  return (
    <>
      {userRequestType === UserRequestType.RerunRequest && (
        <UserRequestWindow
          title="New Rerun Request"
          date={date}
          riskDataProps={{
            nodeName: selectedNodeForSignOff.name,
            nodeId: Number(nodeId),
            date,
            snapshot,
            reportTypeIds,
            sourceSystemIds,
            sourceSystemEnvironments,
          }}
          selectedContainers={selectedContainers}
          selectedPortfolios={filteredSelectedPortfolios}
          userRequestType={userRequestType}
          gridComponent={SelectReportGrid}
          formComponent={RerunRequestForm}
          onClose={onCloseUserRequestWindow}
        ></UserRequestWindow>
      )}

      {userRequestType === UserRequestType.ProxyRequest && (
        <UserRequestWindow
          title="New Proxy Request"
          date={date}
          riskDataProps={{
            nodeName: selectedNodeForSignOff.name,
            nodeId: Number(selectedNodeForSignOff.nodeId),
            date,
            snapshot,
            reportTypeIds,
            sourceSystemIds,
            sourceSystemEnvironments,
          }}
          selectedContainers={selectedContainers}
          selectedPortfolios={filteredSelectedPortfolios}
          userRequestType={userRequestType}
          gridComponent={SelectReportGrid}
          formComponent={ProxyRequestForm}
          onClose={onCloseUserRequestWindow}
        ></UserRequestWindow>
      )}

      {userRequestType === UserRequestType.ExcludeRequest && (
        <UserRequestWindow
          title="New Exclude Request"
          date={date}
          riskDataProps={{
            nodeName: selectedNodeForSignOff.name,
            nodeId: Number(selectedNodeForSignOff.nodeId),
            date,
            snapshot,
            reportTypeIds,
            sourceSystemIds,
            sourceSystemEnvironments,
          }}
          selectedContainers={selectedContainers}
          selectedPortfolios={filteredSelectedPortfolios}
          userRequestType={userRequestType}
          gridComponent={SelectReportGrid}
          formComponent={ExcludeRequestForm}
          onClose={onCloseUserRequestWindow}
        ></UserRequestWindow>
      )}

      {userRequestType === UserRequestType.ReloadRequest && (
        <UserRequestWindow
          title="New Rollback Request"
          date={date}
          riskDataProps={{
            nodeName: selectedNodeForSignOff.name,
            nodeId: Number(selectedNodeForSignOff.nodeId),
            date,
            snapshot,
            reportTypeIds,
            sourceSystemIds,
            sourceSystemEnvironments,
          }}
          selectedContainers={selectedContainers}
          selectedPortfolios={filteredSelectedPortfolios}
          selectedPortfolioFeeds={selectedPortfolioFeeds}
          reportsFromSelectedPortfolioFeeds={reportsFromSelectedPortfolioFeeds}
          sendPortfolioFeeds
          userRequestType={userRequestType}
          formComponent={ReloadRequestForm}
          onClose={onCloseUserRequestWindow}
        ></UserRequestWindow>
      )}

      {userRequestType === UserRequestType.SignOffRequest && (
        <UserRequestWindow
          title="Signoff Data"
          date={date}
          riskDataProps={{
            nodeName: selectedNodeForSignOff.name,
            nodeId: Number(selectedNodeForSignOff.nodeId),
            date,
            snapshot,
            reportTypeIds,
            sourceSystemIds,
            sourceSystemEnvironments,
          }}
          selectedContainers={selectedContainers}
          selectedPortfolios={[selectedNodeForSignOff]}
          userRequestType={userRequestType}
          gridComponent={RiskContainerStatusHandler}
          formComponent={SignOffRequestForm}
          onClose={onCloseUserRequestWindow}
        ></UserRequestWindow>
      )}
    </>
  );
};

import React, { useMemo } from 'react';
import { useQuery, gql } from 'umi-plugin-apollo-anz/apolloClient';
import Window from '@/components/Window';
import Grid from '@/components/Grid';
import ExportButton from '@/components/ExportButton';
import { columns } from './columns';
import { SourceSystemError } from '..';

import styles from './index.less';

interface PricingErrorStatusWindowProps extends SourceSystemError {
  onClose: () => void;
}

const QUERY = gql`
  query RiskDataPricingErrors(
    $cob: String
    $isPortfolioNode: Boolean
    $portfolioNode: String
    $reports: [String]
    $snapshot: String
    $sourceSystemEnvironments: [String]
  ) {
    RiskDataPricingErrors(
      cob: $cob
      isPortfolioNode: $isPortfolioNode
      portfolioNode: $portfolioNode
      reports: $reports
      snapshot: $snapshot
      sourceSystemEnvironments: $sourceSystemEnvironments
    ) {
      businessDate
      report
      reportDescription
      portfolio
      skyTradeID
      murexTradeID
      mxFamily
      mxType
      mxGroup
      mxInstrument
      counterParty
      contractName
      jobName
      errorMessage
    }
  }
`;

interface RiskDataPricingError {
  businessDate: string;
  report: string;
  reportDescription: string;
  portfolio: string;
  skyTradeID: number;
  murexTradeID: number;
  mxFamily: string;
  mxType: string;
  mxGroup: string;
  mxInstrument: string;
  counterParty: string;
  contractName: string;
  jobName: string;
  errorMessage: string;
}

interface RiskDataPricingErrorRequest extends Omit<PricingErrorStatusWindowProps, 'onClose'> {
  reports?: string[];
}

const PricingErrorStatusWindow: React.FC<PricingErrorStatusWindowProps> = ({
  cob,
  isPortfolioNode,
  portfolioNode,
  snapshot,
  reportName,
  onClose,
}) => {
  const queryParams = useMemo(() => {
    const params: RiskDataPricingErrorRequest = {
      cob,
      isPortfolioNode,
      portfolioNode,
      snapshot,
    };

    if (reportName) {
      params.reports = [reportName];
    }

    return params;
  }, [cob, isPortfolioNode, portfolioNode, reportName, snapshot]);

  const { loading, data } = useQuery<
    Record<'RiskDataPricingErrors', RiskDataPricingError[]>,
    RiskDataPricingErrorRequest
  >(QUERY, {
    variables: queryParams,
    fetchPolicy: 'no-cache',
  });

  return (
    <Window
      title="Pricing Error Status"
      initialHeight={500}
      initialWidth={900}
      minHeight={400}
      minWidth={700}
      onClose={onClose}
    >
      <div className={styles.gridContainer}>
        <div className={styles.gridHeader}>
          <ExportButton<RiskDataPricingErrorRequest>
            icon={undefined}
            url="/export/feed-monitor/risk-data/pricing-error-download/csv"
            params={queryParams}
            size="small"
          >
            Export
          </ExportButton>
        </div>
        <Grid
          loading={loading}
          data={data?.RiskDataPricingErrors || []}
          columns={columns}
          style={{ height: '100%' }}
          showColumnVisibility
          rowHeight={26}
        />
      </div>
    </Window>
  );
};

export default PricingErrorStatusWindow;

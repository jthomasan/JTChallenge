import { gql } from 'umi-plugin-apollo-anz/apolloClient';

const query = gql`
  query RiskDataPortfolioFeedStatuses(
    $nodeId: ID
    $cob: String
    $snapshot: String
    $isRootPortfolioNode: Boolean
    $containerIds: [ID]
    $sourceSystemIds: [ID]
    $sourceSystemEnvironments: [String]
    $reportTypeIds: [ID]
    $statuses: [String]
  ) {
    RiskDataPortfolioFeedStatuses(
      nodeId: $nodeId
      cob: $cob
      snapshot: $snapshot
      isRootPortfolioNode: $isRootPortfolioNode
      containerIds: $containerIds
      sourceSystemIds: $sourceSystemIds
      sourceSystemEnvironments: $sourceSystemEnvironments
      reportTypeIds: $reportTypeIds
      statuses: $statuses
    ) {
      id
      feedId
      additionalInfo
      businessDate
      container {
        id
        name
      }
      cubeVersion
      cubeLoadID
      cubeLoadTime
      isEmpty
      isExclusion
      isFmFeed
      isReload
      isRerun
      isStale
      isProxy
      hasSourceSystemError
      portfolio {
        id
        name
      }
      reportName
      sourceSystemEnvironment
      status {
        cubeLoad
        cubeQueue
        cubeTradeEtl
        download
        errorDownload
        fvaCubeLoad
        fvaCubeTradeEtl
        fvaSubcubeLoad
        fvaSubcubePositionEtl
        overall
        rdw
        riskEngine
        signOff
        subCubeLoad
        subCubeQueue
        subCubePositionEtl
        subCubeOverall
      }
      subCubeVersion
    }
  }
`;

export default query;

import { TreeListColumnProps } from '@/components/TreeList';
import SelectableHighlightingCell from '@/components/TreeList/cellRenderers/SelectableHighlightingCell';
import { asCell } from '@/components/SimpleTD';
import { ProgressIndicator } from '../../common/ProgressIndicatorCell';
import { StatusIndicatorCellInner } from '../../common/StatusIndicatorCell';
import ActivityIndicatorCell from './ActivityIndicatorCell';
import {
  SourceSystemStatusCellProps,
  withSourceSystemErrorDownload,
} from '../../common/SourceSystemStatusCell';
import { withSignOff } from './SignOffCell';
import { HierarchyFeedStatus } from '../../../types/hierarchyFeedStatus';
import { generateWarningAndAdditionalInfoCell } from '../../common/WarningAndAdditionalInfoCell';
import { withOverallStatusSummaryTooltip } from '../../common/Tooltips/OverallStatusSummaryTooltip';
import { withStatusSummaryTooltip } from '../../common/Tooltips/StatusSummaryTooltip';
import { SourceSystemError } from '..';
import { withSelectionArrow } from '../../common/SelectionArrow/SelectionArrow';

export interface ColumnProps<T> extends SourceSystemStatusCellProps {
  onClickSignOff: (id: string) => void;
  onSelectNode: (dataItem: T) => void;
  onSelectSourceSystemError: (params: Omit<SourceSystemError, 'cob' | 'snapshot'>) => void;
}

export default <T = HierarchyFeedStatus>({
  onClickSignOff,
  onSelectNode,
  onSelectSourceSystemError,
}: ColumnProps<T>): TreeListColumnProps[] => [
  {
    field: 'name',
    title: 'Portfolio Hierarchy',
    width: '350px',
    expandable: true,
    defaultSortColumn: true,
    treeDisplayField: true,

    customCellRenderer: {
      renderer: withSelectionArrow(
        withOverallStatusSummaryTooltip(SelectableHighlightingCell, {
          statusName: 'Overall Status',
          countField: 'counts',
          nameField: 'name',
          versionField: 'feed.cubeVersion',
        }),
        { onSelect: onSelectNode },
      ),
      extraProps: {
        selectable: true,
        highlightColor: 'rgb(0, 65, 101)',
      },
    },
  },
  {
    field: 'counts.overall.completedPercentage',
    title: 'Overall',
    width: '80px',
    cell: asCell(
      withOverallStatusSummaryTooltip(ProgressIndicator, {
        statusName: 'Overall Status',
        countField: 'counts',
        nameField: 'name',
        versionField: 'feed.cubeVersion',
      }),
    ),
  },
  {
    field: 'feed.status.riskEngine',
    title: 'Risk Engine',
    width: '130px',
    cell: asCell(
      withSourceSystemErrorDownload(
        withStatusSummaryTooltip(StatusIndicatorCellInner, {
          statusName: 'Risk Engine Status',
          countField: 'counts.riskEngine',
          nameField: 'name',
        }),
        { onSelectSourceSystemError },
      ),
    ),
  },
  {
    field: 'feed.isStale',
    title: 'Stale',
    width: '100px',
    cell: generateWarningAndAdditionalInfoCell({
      additionalInfoField: 'feed.additionalInfo',
      nameField: 'name',
      tooltipSubtitle: 'Stale Reason',
    }),
  },
  {
    field: 'feed.isProxy',
    title: 'Proxy',
    width: '100px',
    cell: generateWarningAndAdditionalInfoCell({
      additionalInfoField: 'feed.additionalInfo',
      additionalInfoShortRegex: /\{proxyReason : ([^\s]+)/,
      nameField: 'name',
      tooltipSubtitle: 'Proxy Reason',
    }),
  },
  {
    field: 'feed.status.download',
    title: 'Download',
    width: '100px',
    cell: asCell(
      withStatusSummaryTooltip(StatusIndicatorCellInner, {
        statusName: 'Download Status',
        countField: 'counts.download',
        nameField: 'name',
      }),
    ),
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'feed.status.cubeTradeEtl',
    title: 'Trade ETL',
    width: '100px',
    cell: asCell(
      withStatusSummaryTooltip(StatusIndicatorCellInner, {
        statusName: 'ETL Status',
        countField: 'counts.cubeTradeEtl',
        nameField: 'name',
      }),
    ),
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'feed.status.subCubePositionEtl',
    title: 'Position ETL',
    width: '100px',
    cell: asCell(
      withStatusSummaryTooltip(StatusIndicatorCellInner, {
        statusName: 'Position ETL Status',
        countField: 'counts.subCubePositionEtl',
        nameField: 'name',
      }),
    ),
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'feed.status.cubeLoad',
    title: 'Cube',
    width: '100px',
    cell: asCell(
      withStatusSummaryTooltip(StatusIndicatorCellInner, {
        statusName: 'Cube Status',
        countField: 'counts.cubeLoad',
        nameField: 'name',
        versionField: 'feed.cubeVersion',
      }),
    ),
  },
  {
    field: 'feed.status.subCubeLoad',
    title: 'Subcube',
    width: '100px',
    cell: asCell(
      withStatusSummaryTooltip(StatusIndicatorCellInner, {
        statusName: 'Subcube Status',
        countField: 'counts.subCubeLoad',
        nameField: 'name',
      }),
    ),
  },
  {
    field: 'feed.status.fvaCubeTradeEtl',
    title: 'Trade ETL (FVA)',
    width: '110px',
    cell: asCell(
      withStatusSummaryTooltip(StatusIndicatorCellInner, {
        statusName: 'ETL Status (FVA)',
        countField: 'counts.fvaCubeTradeEtl',
        nameField: 'name',
      }),
    ),
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'feed.status.fvaSubcubePositionEtl',
    title: 'Position ETL (FVA)',
    width: '120px',
    cell: asCell(
      withStatusSummaryTooltip(StatusIndicatorCellInner, {
        statusName: 'Position ETL Status (FVA)',
        countField: 'counts.fvaSubcubePositionEtl',
        nameField: 'name',
      }),
    ),
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'feed.status.fvaCubeLoad',
    title: 'Cube (FVA)',
    width: '100px',
    cell: asCell(
      withStatusSummaryTooltip(StatusIndicatorCellInner, {
        statusName: 'Cube Status (FVA)',
        countField: 'counts.fvaCubeLoad',
        nameField: 'name',
        versionField: 'feed.cubeVersion',
      }),
    ),
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'feed.status.fvaSubcubeLoad',
    title: 'Subcube (FVA)',
    width: '110px',
    cell: asCell(
      withStatusSummaryTooltip(StatusIndicatorCellInner, {
        statusName: 'Subcube Status (FVA)',
        countField: 'counts.fvaCubeLoad',
        nameField: 'name',
      }),
    ),
    extras: {
      isDetailedStatusColumn: true,
    },
  },
  {
    field: 'feed.status.rdw',
    title: 'RDW',
    width: '100px',
    cell: asCell(
      withStatusSummaryTooltip(StatusIndicatorCellInner, {
        statusName: 'Risk Data Warehouse Status',
        countField: 'counts.rdw',
        nameField: 'name',
      }),
    ),
  },
  {
    field: 'counts.signOff.completedPercentage',
    title: 'Signoff',
    width: '100px',
    cell: asCell(
      withSignOff(
        withStatusSummaryTooltip(ProgressIndicator, {
          statusName: 'Signoff Status',
          countField: 'counts.signOff',
          nameField: 'name',
        }),
        { onClick: onClickSignOff },
      ),
    ),
  },
  {
    field: '_activity',
    title: ' ',
    width: '85px',
    sortable: false,
    cell: ActivityIndicatorCell,
  },
];

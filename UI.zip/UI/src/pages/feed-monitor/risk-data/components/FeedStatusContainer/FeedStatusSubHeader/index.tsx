import React, { useState, useRef } from 'react';
import { uniq, uniqBy } from 'lodash';
import { debounce } from 'debounce';
import classnames from 'classnames';
import { Row, Col, Button, Divider, Modal, Menu, Icon, Switch } from 'antd';
import { Chip } from '@progress/kendo-react-buttons';
import SearchField from '@/components/SearchField';
import SimpleDropdown from '@/components/SimpleDropdown';
import { TreeSearch } from '@/components/TreeList/useTreeSearch';
import Authorized from '@/components/Authorized/Authorized';
import { ifAuthorized } from '@/components/Authorized';

import { FeedStatusView, UserRequestType, PortfolioFeedAction, FeedStatusAction } from '../types';
import useGetSourceSystems from '../../UserRequest/hooks/useGetSourceSystems';
import { HierarchyFeedStatus } from '../../../types/hierarchyFeedStatus';
import { PortfolioFeedStatus } from '../../../types/portfolioFeedStatus';
import { ErrorMessages } from './constant';

import styles from './index.less';

const { SubMenu } = Menu;

const portfolioFeedActionTitle = {
  [PortfolioFeedAction.RetryPublish]: 'Retry Publish',
  [PortfolioFeedAction.RetryCubeLoad]: 'Retry Cube Load',
  [PortfolioFeedAction.RetrySubCube]: 'Retry Subcube Load',
  [PortfolioFeedAction.RestartFeed]: 'Restart Feed',
  [PortfolioFeedAction.Complete]: 'Complete',
  [PortfolioFeedAction.Aborted]: 'Aborted',
  [PortfolioFeedAction.NoData]: 'No Data',
  [PortfolioFeedAction.ShowLogs]: 'Show Logs',
  [PortfolioFeedAction.ShowREMEvents]: 'Show REM Events',
};

interface FeedStatusSubHeaderProps {
  selectedPortfolios: HierarchyFeedStatus[];
  selectedNode: HierarchyFeedStatus;
  selectedPortfolioFeeds: PortfolioFeedStatus[];
  selectedFeedStatusView: FeedStatusView;
  treeSearchProps: TreeSearch;
  searchTextForNodes: string;
  searchTextForPortfolios: string;
  showPendingFeedsOnly: boolean;
  onSetShowPendingFeedsOnly: (pendingFeedsOnly: boolean) => void;
  onSetSearchTextForNodes: (value: string) => void;
  onSetSearchTextForPortfolios: (value: string) => void;
  onSelectPortfolioFeedAction: (action: PortfolioFeedAction) => void;
  onSelectFeedStatusView: (feedStatusView: FeedStatusView) => void;
  onRemoveSelectedNode: () => void;
  onSelectUserRequestType: (userRequestType: UserRequestType) => void;
  onClear: () => void;
  onClickShowDetailedStatus: () => void;
  showDetailedStatus?: boolean;
}

const ButtonGroup = Button.Group;

const showErrorModal = (message: string | undefined) =>
  Modal.error({
    title: 'Error',
    content: message,
  });

const FeedStatusSubHeader: React.FC<FeedStatusSubHeaderProps> = ({
  selectedPortfolios,
  selectedNode,
  selectedPortfolioFeeds = [],
  selectedFeedStatusView,
  treeSearchProps,
  searchTextForNodes,
  searchTextForPortfolios,
  showPendingFeedsOnly,
  onSetShowPendingFeedsOnly,
  onSetSearchTextForNodes,
  onSetSearchTextForPortfolios,
  onSelectPortfolioFeedAction,
  onSelectFeedStatusView,
  onSelectUserRequestType,
  onRemoveSelectedNode,
  onClickShowDetailedStatus,
  showDetailedStatus,
}) => {
  const { findNext, findPrev, hasMatches } = treeSearchProps;
  const [portfolioFeedActionMenuOpen, setPortfolioFeedActionMenuOpen] = useState(false);
  const { getSourceSystemBySourceEnvironment } = useGetSourceSystems();

  const areFeedsContainMultipleSourceSystems = () => {
    const sourceSystemIds = uniqBy(selectedPortfolioFeeds, 'sourceSystemEnvironment').map(
      (feed) => getSourceSystemBySourceEnvironment(feed.sourceSystemEnvironment)?.id,
    );

    return uniq(sourceSystemIds).length > 1;
  };

  const onSelectUserRequest = (userRequest: UserRequestType) => {
    if (selectedFeedStatusView === FeedStatusView.TreeView && !selectedPortfolios.length) {
      showErrorModal(ErrorMessages.minPortfolioSelection);
    } else if (selectedPortfolios.length > 100) {
      showErrorModal(ErrorMessages.maxPortfolioSelection);
    } else if (
      userRequest === UserRequestType.RerunRequest &&
      selectedPortfolios.every((portfolio) => !portfolio.isRerunEnabled)
    ) {
      showErrorModal(ErrorMessages.noRerunPortfolioSelection);
    } else {
      onSelectUserRequestType(userRequest);
    }
  };

  const onSelectReloadRequest = () => {
    if (!selectedPortfolioFeeds.length) {
      showErrorModal(ErrorMessages.minPortfolioFeed);
    } else if (selectedPortfolioFeeds.length > 100) {
      showErrorModal(ErrorMessages.maxPortfolioFeed);
    } else if (areFeedsContainMultipleSourceSystems()) {
      showErrorModal(ErrorMessages.feedsWithMultipleSourceSystems);
    } else {
      onSelectUserRequestType(UserRequestType.ReloadRequest);
    }
  };

  const selectPortfolioFeedAction = (key: PortfolioFeedAction) => {
    if (selectedPortfolioFeeds.length) {
      onSelectPortfolioFeedAction(key);
    } else {
      showErrorModal(ErrorMessages.minPortfolioFeed);
    }

    setPortfolioFeedActionMenuOpen(false);
  };

  const popupRef = useRef<HTMLDivElement>(null);

  const fireClearSelectionEvent = () => {
    window.dispatchEvent(
      new CustomEvent('feedStatusActions', {
        detail: FeedStatusAction.Clear,
      }),
    );
  };

  const isPortfolioFilterApplies =
    selectedFeedStatusView === FeedStatusView.GridView && selectedNode.name;

  const fireCollapseAllEvent = () => {
    window.dispatchEvent(
      new CustomEvent('feedStatusActions', {
        detail: FeedStatusAction.CollapseAllNodes,
      }),
    );
  };

  const portfolioFeedActionMenu = (
    <div
      style={{
        overflow: 'auto',
        transform: 'translateZ(0)',
      }}
    >
      <Menu
        className={styles.slimMenu}
        selectable
        multiple
        mode="vertical"
        onSelect={({ key }) => {
          selectPortfolioFeedAction(key as PortfolioFeedAction);
        }}
        getPopupContainer={(triggerNode) => popupRef.current ?? triggerNode}
      >
        {[
          ...(ifAuthorized(
            [
              <Menu.Item key={PortfolioFeedAction.RetryPublish}>
                {portfolioFeedActionTitle[PortfolioFeedAction.RetryPublish]}
              </Menu.Item>,
              <Menu.Item key={PortfolioFeedAction.RetryCubeLoad}>
                {portfolioFeedActionTitle[PortfolioFeedAction.RetryCubeLoad]}
              </Menu.Item>,
              <Menu.Item key={PortfolioFeedAction.RetrySubCube}>
                {portfolioFeedActionTitle[PortfolioFeedAction.RetrySubCube]}
              </Menu.Item>,
              <Menu.Item key={PortfolioFeedAction.RestartFeed}>
                {portfolioFeedActionTitle[PortfolioFeedAction.RestartFeed]}
              </Menu.Item>,
              <SubMenu key="sub1" title={<span>Override Status</span>}>
                <Menu.Item key={PortfolioFeedAction.Aborted} className={styles.slimSubMenuItem}>
                  {portfolioFeedActionTitle[PortfolioFeedAction.Aborted]}
                </Menu.Item>
                <Menu.Item key={PortfolioFeedAction.Complete} className={styles.slimSubMenuItem}>
                  {portfolioFeedActionTitle[PortfolioFeedAction.Complete]}
                </Menu.Item>
                <Menu.Item key={PortfolioFeedAction.NoData} className={styles.slimSubMenuItem}>
                  {portfolioFeedActionTitle[PortfolioFeedAction.NoData]}
                </Menu.Item>
              </SubMenu>,
            ],
            ['FEED_MONITOR.RISK_DATA.WRITE'],
          ) ?? []),
          <Menu.Item key={PortfolioFeedAction.ShowLogs}>
            {portfolioFeedActionTitle[PortfolioFeedAction.ShowLogs]}
          </Menu.Item>,
          <Menu.Item key={PortfolioFeedAction.ShowREMEvents}>
            {portfolioFeedActionTitle[PortfolioFeedAction.ShowREMEvents]}
          </Menu.Item>,
        ]}
      </Menu>
    </div>
  );

  return (
    <div className={styles.feedStatusSubHeader}>
      <Row>
        <Col span={7}>
          {selectedFeedStatusView === FeedStatusView.TreeView ? (
            <SearchField
              className={{
                searchField: styles.searchField,
                searchControls: styles.searchControls,
                searchInput: styles.searchInput,
              }}
              key="search nodes"
              value={searchTextForNodes}
              onChange={debounce(onSetSearchTextForNodes, 300)}
              placeholder="Node Search"
              nextDisabled={!hasMatches}
              prevDisabled={!hasMatches}
              onNext={findNext}
              nextOnEnter
              onPrev={findPrev}
              onCancel={() => {
                onSetSearchTextForNodes('');
              }}
              cancelDisabled={!searchTextForNodes?.length}
            />
          ) : (
            <SearchField
              className={{
                searchField: styles.searchField,
                searchControls: styles.searchControls,
                searchInput: styles.searchInput,
              }}
              key="search portfolios"
              value={searchTextForPortfolios}
              onChange={debounce(onSetSearchTextForPortfolios, 500)}
              placeholder="Portfolio Search"
              onCancel={() => {
                onSetSearchTextForPortfolios('');
              }}
              cancelDisabled={!searchTextForPortfolios?.length}
            />
          )}
        </Col>
        <Col span={9}>
          <Divider type="vertical" />
          <ButtonGroup>
            <Button
              type="default"
              size="small"
              icon="double-right"
              title="Collapse All"
              disabled={selectedFeedStatusView !== FeedStatusView.TreeView}
              onClick={fireCollapseAllEvent}
            />
            <Button
              type={showDetailedStatus ? 'primary' : 'default'}
              size="small"
              icon="info-circle"
              title="Show Detailed Statuses"
              onClick={onClickShowDetailedStatus}
            />
            <Button
              type="default"
              size="small"
              icon="close-circle"
              title="Clear Selection"
              onClick={fireClearSelectionEvent}
            />
          </ButtonGroup>
          <Divider type="vertical" />
          <ButtonGroup>
            <Button
              disabled={selectedFeedStatusView === FeedStatusView.TreeView}
              size="small"
              icon="apartment"
              title="Tree View"
              onClick={() => {
                onSelectFeedStatusView(FeedStatusView.TreeView);
              }}
            />
            <Button
              disabled={selectedFeedStatusView === FeedStatusView.GridView}
              size="small"
              icon="table"
              title="Grid View"
              onClick={() => {
                onSelectFeedStatusView(FeedStatusView.GridView);
              }}
            />
          </ButtonGroup>
          <Authorized authority={['FEED_MONITOR.RISK_DATA.WRITE']}>
            <Divider type="vertical" />
            <ButtonGroup>
              <Button
                key="rerunRequest"
                type="default"
                size="small"
                icon="rollback"
                title="New Rerun Request"
                disabled={selectedFeedStatusView !== FeedStatusView.TreeView}
                onClick={() => {
                  onSelectUserRequest(UserRequestType.RerunRequest);
                }}
              />
              <Button
                key="proxyRequest"
                type="default"
                size="small"
                icon="cluster"
                title="New Proxy Request"
                disabled={selectedFeedStatusView !== FeedStatusView.TreeView}
                onClick={() => {
                  onSelectUserRequest(UserRequestType.ProxyRequest);
                }}
              />
              <Button
                key="excludeRequest"
                type="default"
                size="small"
                icon="scissor"
                title="New Exclude Request"
                disabled={selectedFeedStatusView !== FeedStatusView.TreeView}
                onClick={() => {
                  onSelectUserRequest(UserRequestType.ExcludeRequest);
                }}
              />
              <Button
                key="rollbackRequest"
                type="default"
                size="small"
                icon="reload"
                title="New Rollback Request"
                disabled={selectedFeedStatusView !== FeedStatusView.GridView}
                onClick={onSelectReloadRequest}
              />
            </ButtonGroup>
          </Authorized>
          <Divider type="vertical" />
          <SimpleDropdown
            className={styles.dropdown}
            menu={portfolioFeedActionMenu}
            popupRef={popupRef}
            multiple
            open={portfolioFeedActionMenuOpen}
            onOpenChange={setPortfolioFeedActionMenuOpen}
          >
            <Button size="small" disabled={selectedFeedStatusView === FeedStatusView.TreeView}>
              <Icon type="filter" />
              <Icon
                type="down"
                className={classnames(styles.dropdownIcon, {
                  [styles.dropdownIconOpen]: portfolioFeedActionMenuOpen,
                })}
              />
            </Button>
          </SimpleDropdown>
        </Col>
        <Col span={8}>
          <div className={styles.sidePanel}>
            {selectedFeedStatusView === FeedStatusView.GridView && (
              <div
                className={classnames(styles.pendingFeedsOptionContainer, {
                  [styles.portfolioFilterApplies]: isPortfolioFilterApplies,
                })}
              >
                <span>Pending Feeds Only</span>
                <Switch
                  size="small"
                  checked={showPendingFeedsOnly}
                  onChange={onSetShowPendingFeedsOnly}
                />
              </div>
            )}

            {isPortfolioFilterApplies && (
              <div className={styles.portfolioFilter}>
                Node:
                <Chip text={selectedNode.name} removable onRemove={onRemoveSelectedNode} />
              </div>
            )}
          </div>
        </Col>
      </Row>
    </div>
  );
};

export default FeedStatusSubHeader;

import { ColumnProps } from '@/components/Grid';
import { DATE_FORMATS } from '@/utils/date';
import GridCheckboxCell from '@/components/Grid/cells/GridCheckboxCell';

export const columns: ColumnProps[] = [
  {
    field: 'cubeVersion',
    title: 'Version',
    width: '90px',
    filter: 'numeric',
  },
  {
    field: 'cubeLoadTime',
    title: 'Cube Load Time',
    width: '150px',
    filter: 'date',
    defaultSortColumn: true,
    format: DATE_FORMATS.DATE_TIME,
  },
  {
    field: 'isRerun',
    title: 'Rerun',
    width: '90px',
    filter: 'boolean',
    cell: GridCheckboxCell,
    extras: {
      disabled: true,
    },
  },
  {
    field: 'isProxy',
    title: 'Proxy',
    width: '90px',
    filter: 'boolean',
    cell: GridCheckboxCell,
    extras: {
      disabled: true,
    },
  },
  {
    field: 'isExclusion',
    title: 'Exclude',
    width: '90px',
    filter: 'boolean',
    cell: GridCheckboxCell,
    extras: {
      disabled: true,
    },
  },
  {
    field: 'isReload',
    title: 'Reload',
    width: '90px',
    filter: 'boolean',
    cell: GridCheckboxCell,
    extras: {
      disabled: true,
    },
  },
];

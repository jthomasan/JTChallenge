import React from 'react';
import { get } from 'lodash';
import classnames from 'classnames';
import { CellProps } from '@/components/Grid';
import SimpleTD from '@/components/SimpleTD';
import { HistoryOutlined } from '@ant-design/icons';
import { Button } from 'antd';

import styles from './index.less';

interface CubeVersionCellProps extends CellProps {}

export interface CubeVersionCellInitialProps {
  onSelectPreviousCubeVersion: (cubeLoadId: string) => void;
}

const generateCubeVersionCell = ({
  onSelectPreviousCubeVersion,
}: CubeVersionCellInitialProps): React.FC<CubeVersionCellProps> => ({
  dataItem,
  field = '',
  className,
  ...props
}) => {
  const value = get(dataItem, field);
  const hasPreviousVersions = get(dataItem, 'cubeVersion') > 1;
  const cubeLoadId = get(dataItem, 'cubeLoadID')?.toString();

  return (
    <SimpleTD
      {...props}
      className={classnames(className, styles.cubeVersionCell, styles.wrapTextWithButton)}
    >
      {value}
      {hasPreviousVersions && (
        <Button
          title="Show Previous Versions"
          size="small"
          onClick={() => {
            onSelectPreviousCubeVersion(cubeLoadId);
          }}
        >
          <HistoryOutlined />
        </Button>
      )}
    </SimpleTD>
  );
};

export default generateCubeVersionCell;

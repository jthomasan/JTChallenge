import React, { useMemo, useEffect, useCallback, useRef } from 'react';

import { keyBy, isEqual } from 'lodash';

import { NetworkStatus } from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';

import { NodeMenuItemModel, CTXMenuSelectEvent } from '@/components/ContextMenu';
import TreeListCommon, {
  RowSelectionParams,
  NodeExpandParams,
  TreeListExternalState,
} from '@/components/TreeList';
import withContextMenu from '@/components/TreeList/featureRenderers/WithContextMenu';
import { TreeSearch } from '@/components/TreeList/useTreeSearch';
import useQueryDiskCache from '@/hooks/useQueryDiskCache';

import { SourceSystemError } from '..';
import { FormState } from '../../../types';
import { HierarchyFeedStatus } from '../../../types/hierarchyFeedStatus';
import { FeedStatusAction, NodeType } from '../types';

import getColumns from './column';
import { getSelectedPortfolios } from './getSelectedPortfolios';
import styles from './index.less';
import query from './query';

const TreeList = withContextMenu(TreeListCommon);

interface HierarchyExternalState {
  expandedKeys: string[];
  selectedRows: string[];
}

interface HierarchyFeedStatusTreeViewProps {
  nodeId: number;
  date: string;
  snapshot: string;
  containerIds?: string[];
  reportTypeIds?: number[];
  sourceSystemIds?: number[];
  sourceSystemEnvironments?: string[];
  isRootPortfolioNode: boolean;
  onSetSelectedNode: (selectedNode: HierarchyFeedStatus) => void;
  onSelectSourceSystemError: (params: SourceSystemError) => void;
  treeSearchProps: TreeSearch;
  searchText: string;
  selectedHierarchyNode?: string | null;
  onClickSignOff: (node: HierarchyFeedStatus) => void;
  onSelectHierarchyNodes?: (params: HierarchyFeedStatus[]) => void;
  showDetailedStatus?: boolean;
  onSetShowPendingFeedsOnly: (pendingFeedsOnly: boolean) => void;
  onSetDefaultNode: (value: Pick<FormState, 'node'>) => void;
}

enum ContextMenuOptions {
  SetDefaultNode = 'SetDefaultNode',
  DisplayAllFeeds = 'DisplayAllFeeds',
  DisplayAllPendingFeeds = 'DisplayAllPendingFeeds',
}

const contextMenuItems: (dataItem: any) => NodeMenuItemModel[] = (dataItem) => {
  const items: NodeMenuItemModel[] = [
    {
      value: ContextMenuOptions.DisplayAllFeeds,
      text: 'Display all feeds for this node (Grid View)',
    },
    {
      value: ContextMenuOptions.DisplayAllPendingFeeds,
      text: 'Display pending feeds for this node (Grid View)',
    },
  ];

  if (dataItem.type !== NodeType.PORTFOLIO_LEAF) {
    items.unshift({
      value: ContextMenuOptions.SetDefaultNode,
      text: 'Set as Default Node',
    });
  }

  return items;
};

const HierarchyFeedStatusTreeView: React.FC<HierarchyFeedStatusTreeViewProps> = ({
  nodeId,
  date,
  snapshot,
  containerIds,
  reportTypeIds,
  sourceSystemIds,
  sourceSystemEnvironments,
  selectedHierarchyNode,
  onSelectSourceSystemError,
  searchText,
  treeSearchProps,
  isRootPortfolioNode,
  onClickSignOff,
  onSelectHierarchyNodes,
  showDetailedStatus,
  onSetSelectedNode,
  onSetShowPendingFeedsOnly,
  onSetDefaultNode,
}) => {
  let hierarchyColumns = [];
  const { expandedList, setSearchData, nextMatchedId, resetSearchResults } = treeSearchProps;
  const cachedNodeId = useRef(nodeId);

  const { loading, data, refetch, networkStatus } = useQueryDiskCache<{
    RiskDataHierarchyFeedStatuses: HierarchyFeedStatus[];
  }>(query, {
    variables: {
      isRootPortfolioNode,
      nodeId,
      cob: date,
      snapshot,
      containerIds,
      reportTypeIds,
      sourceSystemIds,
      sourceSystemEnvironments,
    },
    notifyOnNetworkStatusChange: true,
  });

  const [externalState, setExternalState] = useGQLComponentState<HierarchyExternalState>(
    {
      expandedKeys: [nodeId.toString()],
      selectedRows: [],
    },
    'HierarchyFeedStatusExternalState',
  );
  const [treeListExternalState, setTreeListExternalState] = useGQLComponentState<
    TreeListExternalState
  >({}, 'treeListExternalState');
  const hierarchies = data?.RiskDataHierarchyFeedStatuses ?? [];
  const hierarchiesById = useMemo<{ [nodeId: string]: HierarchyFeedStatus }>(
    () => keyBy(hierarchies, 'nodeId'),
    [hierarchies],
  );
  const prevExpandedListFromSearch = useRef<string[]>([]);

  const expandedDataIds = externalState?.expandedKeys;

  const onNodeExpandChange = ({ ids, isExpanded }: NodeExpandParams) => {
    const newlyExpandedIDs = isExpanded
      ? expandedDataIds.filter((id: string) => !ids.includes(id))
      : [...expandedDataIds, ...ids];

    setExternalState({
      expandedKeys: newlyExpandedIDs,
    });
  };

  useEffect(() => {
    if (cachedNodeId.current !== nodeId) {
      cachedNodeId.current = nodeId;
      setExternalState({
        expandedKeys: [nodeId.toString()],
      });
    }
  }, [nodeId, setExternalState]);

  const onRowSelect = useCallback(
    ({ ids }: RowSelectionParams) => {
      setExternalState({
        selectedRows: ids,
      });

      if (onSelectHierarchyNodes) {
        const selectedPortfolios = getSelectedPortfolios(hierarchies, hierarchiesById, ids);
        onSelectHierarchyNodes(selectedPortfolios);
      }
    },
    [hierarchies, hierarchiesById, onSelectHierarchyNodes, setExternalState],
  );

  const handleRowSelection = useCallback(
    (dataItem: HierarchyFeedStatus) => {
      onSetSelectedNode(dataItem);
    },
    [onSetSelectedNode],
  );

  const selectNodeForSignOff = useCallback(
    (id: string) => {
      onClickSignOff(hierarchiesById[id]);
    },
    [onClickSignOff, hierarchiesById],
  );

  const selectSourceSystemError = useCallback(
    (params: Omit<SourceSystemError, 'cob' | 'snapshot'>) => {
      onSelectSourceSystemError({
        ...params,
        cob: date,
        snapshot,
      });
    },
    [date, onSelectSourceSystemError, snapshot],
  );

  const columns = useMemo(
    () =>
      getColumns({
        onClickSignOff: selectNodeForSignOff,
        onSelectNode: handleRowSelection,
        onSelectSourceSystemError: selectSourceSystemError,
      }).filter((column) => (!column.extras?.isDetailedStatusColumn ? true : showDetailedStatus)),
    [selectNodeForSignOff, handleRowSelection, selectSourceSystemError, showDetailedStatus],
  );
  if (selectedHierarchyNode != null) {
    hierarchyColumns = [columns[0]];
  } else {
    hierarchyColumns = columns;
  }

  useEffect(() => {
    if (!isEqual(expandedList, prevExpandedListFromSearch.current)) {
      const expandedListSet = new Set([...expandedDataIds, ...expandedList]);
      setExternalState({ expandedKeys: Array.from(expandedListSet) });
      prevExpandedListFromSearch.current = expandedList;
    }
  }, [expandedDataIds, expandedList, setExternalState]);

  useEffect(() => {
    const refreshData = (backgroundRefresh = false) => {
      if (!backgroundRefresh) {
        refetch();
        onRowSelect({
          ids: [],
          lastSelectedId: '',
        });
        setExternalState({
          expandedKeys: [nodeId.toString()],
        });
      }

      refetch();
    };

    const feedStatusActionEventListener = ({ detail }: CustomEvent<FeedStatusAction>) => {
      switch (detail) {
        case FeedStatusAction.Refresh:
          refreshData();
          break;

        case FeedStatusAction.BackgroundRefresh:
          refreshData(true);
          break;

        case FeedStatusAction.Clear:
          onRowSelect({
            ids: [],
            lastSelectedId: '',
          });
          break;

        case FeedStatusAction.CollapseAllNodes:
          setExternalState({ expandedKeys: [] });
          resetSearchResults();
          break;

        default:
          break;
      }
    };

    window.addEventListener('feedStatusActions', feedStatusActionEventListener as EventListener);

    return () => {
      window.removeEventListener(
        'feedStatusActions',
        feedStatusActionEventListener as EventListener,
      );
    };
  }, [nodeId, onRowSelect, refetch, resetSearchResults, setExternalState]);

  const selectContextMenu = (event: CTXMenuSelectEvent, dataItem: any) => {
    switch (event.itemId) {
      case ContextMenuOptions.SetDefaultNode:
        onSetDefaultNode({
          node: {
            id: dataItem.nodeId,
            name: dataItem.name,
          },
        });
        break;

      case ContextMenuOptions.DisplayAllFeeds:
        onSetShowPendingFeedsOnly(false);
        onSetSelectedNode(dataItem);
        break;

      case ContextMenuOptions.DisplayAllPendingFeeds:
        onSetShowPendingFeedsOnly(true);
        onSetSelectedNode(dataItem);
        break;

      default:
        break;
    }
  };

  return (
    <TreeList
      selectable
      loading={loading || networkStatus !== NetworkStatus.ready}
      className={styles.feedStatusTreeList}
      columns={hierarchyColumns}
      searchText={searchText}
      data={hierarchies}
      idField="nodeId"
      externalState={treeListExternalState}
      setExternalState={setTreeListExternalState}
      selectedRows={externalState?.selectedRows ?? []}
      tableProps={
        selectedHierarchyNode != null ? { style: { tableLayout: 'inherit', width: '100%' } } : {}
      }
      expandedDataIds={expandedDataIds}
      setDisplayData={setSearchData}
      rowHighlightId={nextMatchedId}
      onNodeExpandChange={onNodeExpandChange}
      onRowSelect={onRowSelect}
      contextMenuItems={contextMenuItems}
      onSelectContextMenuItem={selectContextMenu}
    />
  );
};

export default HierarchyFeedStatusTreeView;

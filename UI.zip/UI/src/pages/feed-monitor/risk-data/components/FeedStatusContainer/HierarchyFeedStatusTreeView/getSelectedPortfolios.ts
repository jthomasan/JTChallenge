import { groupBy, unionBy } from 'lodash';
import { HierarchyFeedStatus } from '../../../types/hierarchyFeedStatus';
import { NodeType } from '../types';

export const getSelectedPortfolios = (
  hierarchies: HierarchyFeedStatus[],
  hierarchiesById: { [id: string]: HierarchyFeedStatus },
  selectedIDs: string[],
) => {
  const hierarchiesByParentId = groupBy<HierarchyFeedStatus>(hierarchies, 'parent.nodeId');

  const selectedNodes = selectedIDs
    .map((i) => hierarchiesById[i])
    .filter((o) => o.type === NodeType.PORTFOLIO_NODE);
  const selectedLeafs = selectedIDs
    .map((i) => hierarchiesById[i])
    .filter((o) => o.type === NodeType.PORTFOLIO_LEAF);

  const leafsFromSelectedNodes = getDependancies(selectedNodes, hierarchiesByParentId);

  return unionBy(selectedLeafs, leafsFromSelectedNodes, 'nodeId');
};

function getDependancies(
  nodes: HierarchyFeedStatus[],
  hierarchiesByParentId: { [id: string]: HierarchyFeedStatus[] },
): HierarchyFeedStatus[] {
  let portfolios: HierarchyFeedStatus[] = [];

  nodes.forEach((item) => {
    const hierarchies = hierarchiesByParentId[item.nodeId];

    if (hierarchies) {
      const leafs = hierarchies.filter((o) => o.type === NodeType.PORTFOLIO_LEAF);
      const childNodes = hierarchies.filter((o) => o.type === NodeType.PORTFOLIO_NODE);
      const leafsFromChildNodes = getDependancies(childNodes, hierarchiesByParentId);

      portfolios = [...portfolios, ...leafs, ...leafsFromChildNodes];
    }
  });

  return portfolios;
}

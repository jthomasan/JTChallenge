import React from 'react';
import { gql, useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLActivePage } from 'umi-plugin-apollo-anz/apolloPageState';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import Tabs, { TabPane } from '@/components/Tabs';
import Card from '@/components/Card';

import { RefreshButton } from '@/hooks/useRefresh/RefreshButton';

import SearchField from '@/components/SearchField';
import ExportButton from '@/components/ExportButton';
import PageLoading from '@/components/PageLoading';
import LatestCOBCardTopBar from '@/components/LatestCOBCardTopBar';
import { AutoRefreshSwitch } from '@/hooks/useRefresh/AutoRefreshSwitch';
import PageErrorFallback from '@/error/ErrorFallback';
import { QueryError } from '@/error/types';

import generateTab from './workflowRequest';
import { COBDatePicker } from '../components/COBDatePicker';

import styles from './index.less';
import { containerColumns, reportColumns } from './workflowRequest/columns';

export enum UserRequestTab {
  SIGN_OFF = 'SIGN_OFF',
  RERUN = 'RERUN',
  PROXY = 'PROXY',
  EXCLUSION = 'EXCLUSION',
  RELOAD = 'RELOAD',
  // DATA_LOAD_STATUS = 'DATA_LOAD_STATUS',
  // DATA_LOAD = 'DATA_LOAD',
}

const TabsMap: Record<
  UserRequestTab,
  {
    component: React.ComponentType<{ date: string; filter: string }>;
    name: string;
    exportUrl: string;
    getExportParams?: (source: { date: string }) => Record<string, string>;
  }
> = {
  [UserRequestTab.SIGN_OFF]: {
    name: 'Signoff',
    component: generateTab(UserRequestTab.SIGN_OFF, containerColumns),
    exportUrl: '/export/feed-monitor/user-requests/container-workflow-requests/csv',
    getExportParams: ({ date }) => ({ date, type: UserRequestTab.SIGN_OFF }),
  },
  [UserRequestTab.RERUN]: {
    name: 'Rerun',
    component: generateTab(UserRequestTab.RERUN, reportColumns),
    exportUrl: '/export/feed-monitor/user-requests/report-workflow-requests/csv',
    getExportParams: ({ date }) => ({ date, type: UserRequestTab.RERUN }),
  },
  [UserRequestTab.PROXY]: {
    name: 'Proxy',
    component: generateTab(UserRequestTab.PROXY, reportColumns),
    exportUrl: '/export/feed-monitor/user-requests/report-workflow-requests/csv',
    getExportParams: ({ date }) => ({ date, type: UserRequestTab.PROXY }),
  },
  [UserRequestTab.EXCLUSION]: {
    name: 'Exclude',
    component: generateTab(UserRequestTab.EXCLUSION, reportColumns),
    exportUrl: '/export/feed-monitor/user-requests/report-workflow-requests/csv',
    getExportParams: ({ date }) => ({ date, type: UserRequestTab.EXCLUSION }),
  },
  [UserRequestTab.RELOAD]: {
    name: 'Rollback',
    component: generateTab(UserRequestTab.RELOAD, reportColumns),
    exportUrl: '/export/feed-monitor/user-requests/report-workflow-requests/csv',
    getExportParams: ({ date }) => ({ date, type: UserRequestTab.RELOAD }),
  },
};

const UserRequestTabs = [
  UserRequestTab.SIGN_OFF,
  UserRequestTab.RERUN,
  UserRequestTab.PROXY,
  UserRequestTab.EXCLUSION,
  UserRequestTab.RELOAD,
  // UserRequestTab.DATA_LOAD_STATUS,
  // UserRequestTab.DATA_LOAD,
];

const StartingTab: UserRequestTab = UserRequestTab.SIGN_OFF;

const UserRequestsPage: React.FC<{
  latestCOBDate: string;
}> = ({ latestCOBDate }) => {
  useGQLActivePage('userRequests');
  const [pageState, setPageState] = useGQLComponentState<{
    activeTab: UserRequestTab;
    date: string;
    filter: string;
  }>({
    activeTab: StartingTab,
    date: latestCOBDate,
    filter: '',
  });

  const activeTabConfig = TabsMap[pageState.activeTab];

  return (
    <Card title="User Requests" padded={false} fullPageCard actions={<LatestCOBCardTopBar />}>
      <Tabs
        activeKey={pageState.activeTab}
        onChangeActiveKey={(activeTab) =>
          setPageState({ activeTab: activeTab as keyof typeof TabsMap })
        }
        tabBarExtraContent={
          <div className={styles.tabBarExtraContent}>
            <SearchField
              placeholder="Search"
              onCancel={() => {
                setPageState({ filter: '' });
              }}
              value={pageState.filter}
              onChange={(value) => {
                setPageState({ filter: value });
              }}
            />
            <COBDatePicker
              value={pageState.date}
              onChange={(value) => setPageState({ date: value })}
            />
            <ExportButton
              size="small"
              url={activeTabConfig.exportUrl}
              params={activeTabConfig.getExportParams?.({ date: pageState.date })}
            />
            <AutoRefreshSwitch />
            <RefreshButton size="small" />
          </div>
        }
      >
        {UserRequestTabs.map((key) => {
          const { name: tabName, component: TabComponent } = TabsMap[key];

          return (
            <TabPane title={tabName} key={key}>
              <TabComponent date={pageState.date} filter={pageState.filter} />
            </TabPane>
          );
        })}
      </Tabs>
    </Card>
  );
};

interface CurrentBusinessDateQueryResponse {
  CurrentBusinessDate: string;
}

const CurrentBusinessDateQuery = gql`
  query CurrentBusinessDateQuery {
    CurrentBusinessDate
  }
`;

const UserRequestsPageWrapper: React.FC = () => {
  const { data, loading, error } = useQuery<CurrentBusinessDateQueryResponse>(
    CurrentBusinessDateQuery,
  );

  if (loading) {
    return <PageLoading />;
  }

  if (!data?.CurrentBusinessDate || error) {
    return (
      <PageErrorFallback
        error={new QueryError(error)}
        title="There was an issue fetching the latest COB date"
        retryText="Retry"
      />
    );
  }

  return <UserRequestsPage latestCOBDate={data.CurrentBusinessDate} />;
};

export default UserRequestsPageWrapper;

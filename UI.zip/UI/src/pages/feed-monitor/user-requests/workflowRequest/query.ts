import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export interface WorkflowRequest {
  sourceBusinessDate: string;
  businessDate: string;
  runDate: string;
  portfolio: string;
  container: string;
  status: string;
  snapshot: string;
  comment: string;
  isProcessed: boolean;

  sourceSystem: {
    id: string;
    name: string;
  };

  added: {
    by: string;
    time: string;
  };
  lastUpdated: {
    time: string;
  };

  message: string;
}

export interface WorkflowRequestsQueryResponse {
  WorkflowRequests: WorkflowRequest[];
}

export const WorkflowRequestsQuery = gql`
  query WorkflowRequests($date: Date!, $type: WorkflowType!) {
    WorkflowRequests(date: $date, type: $type) {
      sourceBusinessDate
      businessDate
      runDate
      portfolio
      container
      status
      snapshot
      report
      useVersion
      sourceSystem {
        id
        name
      }
      comment
      isProcessed
      added {
        by
        time
      }
      lastUpdated {
        time
      }

      message
    }
  }
`;

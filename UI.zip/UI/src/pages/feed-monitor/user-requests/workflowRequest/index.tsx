import React from 'react';
import Grid, { ColumnProps, GridExternalState } from '@/components/Grid';
import { useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import useDataFilter from '@/components/Grid/useDataFilter';
import { useRefresh } from '@/hooks/useRefresh';

import { WorkflowRequestsQuery, WorkflowRequestsQueryResponse } from './query';

export default function generateTab(workflowType: string, columns: ColumnProps[]) {
  const WorkflowRequestsTab: React.FC<{ date: string; filter: string }> = ({ date, filter }) => {
    const { data, loading, refetch } = useQuery<WorkflowRequestsQueryResponse>(
      WorkflowRequestsQuery,
      {
        variables: {
          date,
          type: workflowType,
        },
      },
    );

    const { refreshing, background } = useRefresh(() => refetch(), [refetch]);

    const [externalState, setExternalState] = useGQLComponentState<GridExternalState>(
      {},
      WorkflowRequestsTab.displayName,
    );

    const filteredData = useDataFilter({
      data: data?.WorkflowRequests ?? [],
      columns,
      filter,
    });

    return (
      <Grid
        loading={loading || (refreshing && !background)}
        data={filteredData}
        columns={columns}
        style={{ height: '100%', border: 0, position: 'absolute' }}
        externalState={externalState}
        setExternalState={setExternalState}
        groupable
      />
    );
  };

  WorkflowRequestsTab.displayName = `WorkflowRequestTab(${workflowType})`;

  return WorkflowRequestsTab;
}

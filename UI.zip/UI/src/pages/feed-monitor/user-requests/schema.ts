import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export default gql`
  type UserRequestsPage implements Refreshable {
    dummy: String
  }

  extend type Page {
    userRequests: UserRequestsPage
  }
`;

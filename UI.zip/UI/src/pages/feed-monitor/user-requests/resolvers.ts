export const defaults = {
  userRequests: {
    __typename: 'UserRequestsPage',

    errors: [],
  },
};

export const resolvers = {};

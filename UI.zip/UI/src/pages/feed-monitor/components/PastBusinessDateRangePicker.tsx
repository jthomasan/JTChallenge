import React from 'react';

import { DatePicker } from 'antd';
import { RangePickerProps } from 'antd/lib/date-picker/interface';
import moment from 'moment';

import { gql } from 'umi-plugin-apollo-anz/apolloClient';

import useQueryExtended from '@/hooks/useQueryExtended';
import { useRefresh } from '@/hooks/useRefresh';

import styles from './PastBusinessDateRangePicker.less';

const { RangePicker } = DatePicker;

const CurrentBusinessDateOnlyQuery = gql`
  query CurrentBusinessDateOnlyQuery {
    CurrentBusinessDate
  }
`;

const PastBusinessDatesQuery = gql`
  query PastBusinessDatesQuery($count: Int!) {
    CurrentBusinessDate
    PastBusinessDates(count: $count)
  }
`;

interface PastBusinessDatesQueryResponse {
  CurrentBusinessDate: string;
  PastBusinessDates?: string[];
}

export const PastBusinessDateRangePicker: React.FC<{
  count: number | 'all';
  fromDate?: string;
  toDate?: string;
  onChange: (dates: [string, string]) => void;
  disabledDate?: (current: moment.Moment) => boolean;
  ranges?: RangePickerProps['ranges'];
}> = ({ count, fromDate, toDate, onChange, disabledDate, ranges }) => {
  const {
    data: { PastBusinessDates = [], CurrentBusinessDate } = {},
    loading,
    refetch,
  } = useQueryExtended<PastBusinessDatesQueryResponse, { count: number }>(
    count === 'all' ? CurrentBusinessDateOnlyQuery : PastBusinessDatesQuery,
    {
      variables: { count: count !== 'all' ? count : 0 },
    },
  );

  const { refreshing } = useRefresh(() => refetch(), [refetch]);

  return (
    <div style={{ width: '185px' }}>
      <RangePicker
        className={styles.rangePicker}
        size="small"
        format="YYYY-MM-DD"
        allowClear={false}
        value={[moment(fromDate), moment(toDate)]}
        ranges={ranges}
        onChange={(_, dateStrings) => {
          onChange(dateStrings);
        }}
        disabled={loading || refreshing}
        disabledDate={(current) =>
          !current ||
          (!!disabledDate && disabledDate(current)) ||
          (count === 'all' && current.isAfter(CurrentBusinessDate)) ||
          (count !== 'all' &&
            !PastBusinessDates.includes(current.format('YYYY-MM-DD')) &&
            current.format('YYYY-MM-DD') !== CurrentBusinessDate)
        }
      />
    </div>
  );
};

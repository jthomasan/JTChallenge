import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export interface CurrentBusinessDateQueryResponse {
  CurrentBusinessDate: string;
}

export const CurrentBusinessDateQuery = gql`
  query CurrentBusinessDateQuery {
    CurrentBusinessDate
  }
`;

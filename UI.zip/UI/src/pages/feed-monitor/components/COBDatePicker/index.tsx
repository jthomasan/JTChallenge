import React, { useState } from 'react';
import { useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import { Button, DatePicker } from 'antd';
import moment from 'moment';
import { CurrentBusinessDateQuery, CurrentBusinessDateQueryResponse } from './query';

import styles from './index.less';

export const COBDatePicker: React.FC<{
  value?: string;
  onChange?: (value: string) => void;
  disabled?: boolean;
  className?: string;
  disabledDate?: (current: moment.Moment, latestCob: moment.Moment) => boolean;
}> = ({ value, onChange, disabled, className, disabledDate }) => {
  const [datePickerOpen, setDatePickerOpen] = useState(false);

  const { data: { CurrentBusinessDate } = {}, loading } = useQuery<
    CurrentBusinessDateQueryResponse
  >(CurrentBusinessDateQuery);

  const todayDate = moment();
  const latestCob = CurrentBusinessDate ? moment(CurrentBusinessDate).startOf('day') : null;

  return (
    <DatePicker
      className={className}
      disabled={disabled || loading}
      style={{ width: 110 }}
      allowClear={false}
      dropdownClassName={styles.datePickerContainer}
      showToday
      size="small"
      disabledDate={(current) =>
        !!current &&
        (disabledDate
          ? disabledDate(current, latestCob?.clone() as moment.Moment)
          : current > todayDate.endOf('day'))
      }
      value={value ? moment(value, 'YYYY-MM-DD') : null}
      format="YYYY-MM-DD"
      open={datePickerOpen}
      onOpenChange={(newOpen) => {
        setDatePickerOpen(newOpen);
      }}
      renderExtraFooter={() => (
        <Button
          type="link"
          disabled={disabledDate?.(
            latestCob?.clone() as moment.Moment,
            latestCob?.clone() as moment.Moment,
          )}
          onClick={() => {
            setDatePickerOpen(false);
            if (onChange) {
              onChange(CurrentBusinessDate as string);
            }
          }}
        >
          Latest COB
        </Button>
      )}
      onChange={(newValue) => {
        if (newValue && onChange) {
          onChange(newValue.format('YYYY-MM-DD'));
        }
      }}
    />
  );
};

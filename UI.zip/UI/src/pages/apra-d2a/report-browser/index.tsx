import React from 'react';
import Iframe from 'react-iframe';

import Card from '@/components/Card';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'appian-record-view': any;
    }
  }
}

const LimitsPage: React.FC = () => (
  <Card title="Report Browser">
    <Iframe url="/appian/D2AReportBrowser.html" width="100%" height="100%" frameBorder={0} />
  </Card>
);

export default LimitsPage;

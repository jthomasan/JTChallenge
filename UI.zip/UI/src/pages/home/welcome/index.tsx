import React from 'react';

import { Row, Col, Icon } from 'antd';
import classnames from 'classnames';
import moment from 'moment';
import { generatePath } from 'react-router';
import { Link } from 'umi';
import { formatMessage } from 'umi-plugin-react/locale';

import { MeRVRoute } from '@/types/route';
import { isAuthorized } from '@/utils/authority';

import { HomeSubPageProps } from '..';

import styles from './style.less';

interface LinkConfig {
  name: string;
  enabled: boolean;
  msg?: string | string[];
}

const links: LinkConfig[] = [
  {
    name: 'market-risk-limits',
    enabled: true,
  },
  {
    name: 'reference-data',
    enabled: true,
  },
  {
    name: 'feed-monitor',
    enabled: true,
  },
  {
    name: 'market-risk-reporting',
    enabled: false,
    msg: 'To be released',
  },
  {
    name: 'rates-repository',
    enabled: false,
    msg: 'To be released',
  },
  {
    name: 'back-testing',
    enabled: false,
    msg: ['IM Backtesting to be released v0.5.0', 'MR Backtesting to be released'],
  },
  {
    name: 'apra-d2a',
    enabled: false,
    msg: 'To be released in v0.4.0',
  },
];

const getLinkFromRoute = (route: MeRVRoute): string => {
  const { routes: children, path } = route;

  const firstChild = children && children.find((child: any) => isAuthorized(child.authority));
  return generatePath((firstChild && (firstChild.path as string)) || (path as string));
};

const WelcomeLink: React.FC<{
  to?: string;
  className?: string;
}> = (props) => {
  const { to, className, ...rest } = props;
  if (to) {
    return <Link to={to} className={className} {...rest} />;
  }

  return <span className={classnames(className, styles.disabled)} {...rest} />;
};

const getMessages = (messages: string | string[] | undefined) => {
  if (messages === undefined) return [];

  return Array.isArray(messages) ? messages : [messages];
};

export default ({ routes }: HomeSubPageProps) => {
  const dateString = moment(new Date()).format('dddd D MMMM YYYY');

  const buttons = links.map((link) => {
    const { name: linkName, enabled, msg: configuredMessage } = link;

    const childRoute = routes?.find((r) => r.name === linkName);
    if (!childRoute) return null;

    const { name, path, icon } = childRoute;
    const displayLongName = formatMessage({ id: `menu.${name}`, defaultMessage: name });

    const messages = getMessages(configuredMessage);

    return (
      <div key={path as string} className={styles.buttonContainer}>
        <WelcomeLink
          className={styles.button}
          to={enabled ? getLinkFromRoute(childRoute) : undefined}
        >
          <Icon className={styles.icon} type={icon} />
          <span className={styles.longLabel}>{displayLongName}</span>
          {messages.map((msg) => (
            <span className={styles.buttonMessage} key={msg}>
              {msg || ''}
            </span>
          ))}
        </WelcomeLink>
      </div>
    );
  });

  return (
    <div className={styles.container}>
      <Row>
        <Col className={styles.message}>
          Welcome to <span className={styles.bold}>MeRV</span>
        </Col>
      </Row>
      <Row>
        <Col className={styles.date}>{dateString}</Col>
      </Row>
      <div className={styles.menuContainer}>{buttons}</div>
    </div>
  );
};

import React, { useState } from 'react';
import IframeWrapper from '@/components/IframeWrapper';
import GridLayoutElement from '../GridLayoutElement';

export default () => {
  const [selected, setSelected] = useState(0);
  const [iframeKey, setIframeKey] = useState(0);

  const createTableauURL = (project: string, view: string) => {
    const domain = window.location.origin;
    return `${domain}/tableau/views/${project}/${view}?:embed=yes&:toolbar=yes&:tabs=no&:showAppBanner=false&:display_count=n&:showVizHome=n&:device=tablet&:origin=viz_share_link`;
  };

  const urls = [
    createTableauURL('NPV', 'NPVdashboard'),
    createTableauURL('DV01', 'Dashboard'),
    createTableauURL('Top5', 'Top5'),
  ];

  const onSelectionChange = (value: string) => {
    setSelected(parseInt(value, 10));
  };

  const onReload = () => {
    setIframeKey(iframeKey + 1);
  };

  return (
    <GridLayoutElement
      title={['NPV', 'DV01', 'Combined']}
      onSelectionChange={onSelectionChange}
      onReload={onReload}
    >
      <IframeWrapper
        key={iframeKey}
        url={urls[selected]}
        scrolling={false}
        // reloadOnResize
      />
    </GridLayoutElement>
  );
};

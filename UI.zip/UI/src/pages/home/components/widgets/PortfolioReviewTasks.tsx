import React, { useState } from 'react';
import IframeWrapper from '@/components/IframeWrapper';
import GridLayoutElement from '../GridLayoutElement';

export default () => {
  const [selected, setSelected] = useState(0);
  const [iframeKey, setIframeKey] = useState(0);

  const urls = [`/appian/Appian_PortfolioReviewTasks.html`];

  const onSelectionChange = (value: string) => {
    setSelected(parseInt(value, 10));
  };

  const onReload = () => {
    setIframeKey(iframeKey + 1);
  };

  return (
    <GridLayoutElement
      title={['MeRV Tasks']}
      onSelectionChange={onSelectionChange}
      onReload={onReload}
    >
      <IframeWrapper
        key={iframeKey}
        url={urls[selected]}
        scrolling={false}
        // reloadOnResize
      />
    </GridLayoutElement>
  );
};

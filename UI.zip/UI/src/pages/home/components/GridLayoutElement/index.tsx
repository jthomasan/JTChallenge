import React from 'react';
import { Icon, Select } from 'antd';
import _ from 'lodash';
import styles from './index.less';

interface GridLayoutElementProps {
  title?: string | string[];
  onSelectionChange?: (value: string) => void;
  onReload?: () => void;
}

const GridLayoutElement: React.FC<GridLayoutElementProps> = (props) => {
  const { title, onSelectionChange, onReload } = props;

  return (
    <div className={styles.gridElement}>
      <div className={styles.dragBar}>
        {onReload && <Icon onClick={onReload} className={styles.reloadIcon} type="reload" />}
        <Icon className={styles.dragIcon} type="drag" />

        <div className={styles.title}>
          {_.isArray(title) ? (
            <Select
              defaultValue={title[0]}
              className={styles.titleDropdown}
              onChange={onSelectionChange}
            >
              {title.map((val: string, index: number) => (
                <Select.Option key={val} value={index}>
                  {val}
                </Select.Option>
              ))}
            </Select>
          ) : (
            title
          )}
        </div>
      </div>
      <div className={styles.content}>{props.children}</div>
    </div>
  );
};

export default GridLayoutElement;

import React, { Component, CSSProperties } from 'react';

import { Dispatch } from 'redux';
import { connect } from 'dva';
import { Responsive } from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import { withSize } from 'react-sizeme';

import PortfolioReviewTasks from './components/widgets/PortfolioReviewTasks';

const defaultLayouts: any = {
  lg: [
    { i: '1', x: 0, y: 0, w: 12, h: 19, minH: 3, minW: 2 },
    { i: '2', x: 0, y: 0, w: 12, h: 5, minH: 1, minW: 2 },
  ],
};

const withSizeHOC = withSize({ refreshMode: 'debounce' });
const myHOC = (C: any) => (props: any) => <C width={props.size.width} {...props} />;
const ResponsiveGridLayout = withSizeHOC(myHOC(Responsive));

interface AnalysisProps {
  style?: CSSProperties;
  className?: string;
  dispatch: Dispatch<any>;
  loading: boolean;
}

interface AnalysisState {
  gridWidth: string;
  gridHeight: string;
  layouts: any;
}

const gridRef: React.RefObject<HTMLDivElement> = React.createRef();

class Analysis extends Component<AnalysisProps, AnalysisState> {
  state: AnalysisState = {
    gridWidth: '0',
    gridHeight: '0',
    layouts: defaultLayouts,
  };

  reqRef: number = 0;

  timeoutId: number = 0;

  onWidthChange = () => {
    this.onGridSizeChange();
  };

  onResizeStop = () => {
    this.onGridSizeChange();
  };

  onGridSizeChange = () => {
    const grid = gridRef.current;

    const gridWidth: string = `${grid?.offsetWidth || 0}`;
    const gridHeight: string = `${grid?.offsetHeight || 0}`;

    this.setState({ gridWidth, gridHeight });
  };

  onLayoutChange = (_layout: any, layouts: any) => {
    // saveToLS("layouts", layouts);
    this.setState({ layouts });
  };

  render() {
    const { gridWidth, gridHeight } = this.state;
    const { style, className } = this.props;

    return (
      <div
        style={{
          display: 'flex',
          flexDirection: 'row',
          ...(style || {}),
        }}
        className={className}
      >
        <div style={{ flexGrow: 1 }}>
          <ResponsiveGridLayout
            ref={gridRef}
            key={`${gridWidth}|${gridHeight}`}
            className="dnd-layout"
            style={{ marginLeft: -10, marginTop: -10 }}
            layouts={this.state.layouts}
            verticalCompact
            onWidthChange={this.onGridSizeChange}
            onResizeStop={this.onGridSizeChange}
            onLayoutChange={this.onLayoutChange}
            rowHeight={20}
            breakpoints={{ lg: 1 }}
            cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
          >
            <div key="1">
              <PortfolioReviewTasks />
            </div>
          </ResponsiveGridLayout>
        </div>
      </div>
    );
  }
}

export default connect(
  ({
    state,
    dashboardAndanalysis,
    loading,
    settings,
  }: {
    state: any;
    settings: any;
    dashboardAndanalysis: any;
    loading: {
      effects: { [key: string]: boolean };
    };
  }) => ({
    dashboardAndanalysis,
    loading: loading.effects['dashboardAndanalysis/fetch'],
    state,
    settings,
  }),
)(Analysis);

import React, { useMemo } from 'react';

import classnames from 'classnames';

import { MeRVRoute } from '@/types/route';
import { isAuthorized } from '@/utils/authority';

export interface HomeProps {
  className?: string;
  homeRoute: MeRVRoute;
  allRoutes: MeRVRoute[];
  location: Location;
}

export interface HomeSubPageProps {
  routes: MeRVRoute[];
}

const Home: React.FC<HomeProps> = ({ className, homeRoute, allRoutes, location }) => {
  const { authority, routes: childRoutes } = homeRoute;

  const children = useMemo(
    () =>
      childRoutes?.reduce((acc: JSX.Element[], route) => {
        const { name, authority: routeAuthority, component } = route;

        const Component: React.FC<HomeSubPageProps> | undefined = component;

        if (Component && name && isAuthorized(routeAuthority)) {
          const isHidden = location.pathname.toLowerCase() !== (route.path as string).toLowerCase();

          acc.push(
            <div
              key={route.path as string}
              style={{ height: '100%' }}
              className={classnames({ hidden: isHidden })}
            >
              <Component routes={allRoutes} />
            </div>,
          );
        }

        return acc;
      }, []),
    [allRoutes, childRoutes, location.pathname],
  );

  if (!isAuthorized(authority)) {
    return null;
  }

  return (
    <div style={{ height: '100%' }} className={className}>
      {children}
    </div>
  );
};

export default Home;

import React, { useContext, useState, useEffect, useMemo } from 'react';
import { debounce } from 'debounce';
import isEqual from 'lodash/isEqual';
import { Button, Modal, Result, Select as AntSelect } from 'antd';
import { useGQLActivePage, useGQLPageState } from 'umi-plugin-apollo-anz/apolloPageState';
import { TreeListItemChangeEvent } from '@progress/kendo-react-treelist';
import { gql, useApolloClient, clearCacheOfType } from 'umi-plugin-apollo-anz/apolloClient';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
import Card, { AccentGroup, CardTopBar, CardBody } from '@/components/Card';
import Select from '@/components/Select';
import SearchField from '@/components/SearchField';
import RefreshContext from '@/contexts/RefreshContext';
import useQuery from '@/hooks/useQueryExtended';
import withErrorBoundary from '@/HOCs/withErrorBoundary';
import ErrorFallback from '@/error/ErrorFallback';
import { getAuthority, isAuthorized } from '@/utils/authority';
import Treelist, { TreeListExternalState } from '@/components/TreeList';
import useTreeSearch from '@/components/TreeList/useTreeSearch';
import useRefreshNotification from '@/hooks/useRefreshNotification';
import usePrevious from '@/hooks/usePrevious';
import useUncommittedChanges from '@/hooks/useUncommittedChanges';
import InheritedReports from './components/ReportPickerCell/InheritedReports';

import useUpdatePortfolioRunList from './hooks/useUpdatePortfolioRunList';
import useUpdateVolckerDesk from './hooks/useUpdateVolckerDesk';
import useUpdateHoldingPeriod from './hooks/useUpdateHoldingPeriod';
import useUpdateCTDMapping from './hooks/useUpdateCTDMapping';
import RefDataConfigMapping, { ConfigurationCategory } from './mappings';
import styles from './index.less';

const { Option } = AntSelect;

const headers = [
  {
    field: 'title',
    title: 'Name',
    width: 'auto',
  },
];

const Configuration: React.FC<any> = (props) => {
  useGQLActivePage('refDataConfiguration');
  const client = useApolloClient();
  const [{ selectedCategory, expandedIds, searchText }, updatePageState] = useGQLPageState();

  // component state
  const [treeState, updateTreeState] = useGQLComponentState<TreeListExternalState>({});

  const triggerRefresh = useContext(RefreshContext);
  const [shouldRefresh, setShouldRefresh] = useRefreshNotification();

  const [isExporting, setIsExporting] = useState(false);
  const [changes, , , clearAll, ,] = useUncommittedChanges();

  const { updateCurrentReports } = useUpdatePortfolioRunList();
  const { updateVolckerDesk } = useUpdateVolckerDesk();
  const { updateHoldingPeriod } = useUpdateHoldingPeriod();
  const { updateCTDMapping } = useUpdateCTDMapping();

  const {
    findNext,
    findPrev,
    hasMatches,
    nextMatchedId,
    expandedList: searchExpandedList,
    setSearchData,
    setSearchText: startSearchWithText,
  } = useTreeSearch({
    searchField: 'title',
    subItemsField: 'children',
  });

  const refConfig = RefDataConfigMapping[selectedCategory];
  const {
    searchControlPlaceholder,
    showSidePanel,
    legendText,
    exportUrl,
    dataSetName,
    query,
    columns,
    sidePanelSourceField,
  } = refConfig ?? {};

  const prevSearchExpandedList = usePrevious(searchExpandedList);
  const { writeAuthority } = props.route;

  const isWriteAuthorized = useMemo(() => isAuthorized(writeAuthority, getAuthority()), [
    writeAuthority,
  ]);

  const onExportConfigurationData = () => {
    setIsExporting(true);
    window.location.href = exportUrl;
    setTimeout(() => {
      setIsExporting(false);
    }, 1000);
  };

  const showConfirm = (callback: Function) => {
    Modal.destroyAll();
    Modal.confirm({
      title: 'Confirmation',
      content:
        'This action will remove all uncommitted changes. Are you sure you want to continue?',
      onOk: () => {
        callback();
      },
    });
  };

  const onCategorySelectorChange = (value: string) => {
    const refreshStaticData = (shouldClearUncommittedChanges: boolean = false) => {
      if (shouldClearUncommittedChanges) {
        clearAll();
      }
      clearCacheOfType(client, dataSetName);
      updatePageState({ selectedCategory: value, expandedIds: [], searchText: '' });
    };

    if (changes?.length > 0) {
      showConfirm(() => {
        refreshStaticData(true);
      });
    } else {
      refreshStaticData(false);
    }
  };

  const GQL_GENERIC = gql`
    ${query || ' query { placeholder }'}
  `;

  let dataList: any[] = [];

  const { loading, data, refetch: dataRefetch } = useQuery(GQL_GENERIC, {
    notifyOnNetworkStatusChange: true,
    skip: !refConfig,
  });
  if (!loading && data) {
    dataList = data[dataSetName];
  }

  useEffect(() => {
    if (shouldRefresh) {
      dataRefetch();
      setShouldRefresh(false);
    }
  }, [shouldRefresh, dataRefetch, setShouldRefresh]);

  useEffect(() => {
    startSearchWithText(searchText);
  }, [searchText, startSearchWithText]);

  // merge the expand ids from the search hook into the list in state
  useEffect(() => {
    if (!isEqual(searchExpandedList, prevSearchExpandedList)) {
      let newExpandedIds = expandedIds || [];
      searchExpandedList.forEach((id) => {
        if (!newExpandedIds.includes(id)) {
          newExpandedIds = newExpandedIds.concat(id);
        }
      });

      if (newExpandedIds !== expandedIds) {
        updatePageState({
          expandedIds: newExpandedIds,
        });
      }
    }
  }, [searchExpandedList, expandedIds, prevSearchExpandedList, updatePageState]);

  const onSearchTextChange = (inputText: string) => {
    updatePageState({ searchText: inputText });
  };

  // expansion callback for treelist
  const onNodeExpandChange = ({
    ids: newIds,
    isExpanded,
  }: {
    ids: string[];
    isExpanded: boolean;
  }) => {
    const newExpandedIds = isExpanded
      ? (expandedIds || []).filter((id: string) => !newIds.includes(id))
      : [...(expandedIds || []), ...newIds];

    updatePageState({
      expandedIds: newExpandedIds,
    });
  };

  const categorySelector = (
    <Select
      showSearch
      style={{ width: 180 }}
      value={selectedCategory || undefined}
      placeholder="Select Category"
      onChange={onCategorySelectorChange}
      size="small"
      dropdownMatchSelectWidth={false}
    >
      {Object.keys(ConfigurationCategory).map((key) => (
        <Option key={key} value={ConfigurationCategory[key]}>
          {ConfigurationCategory[key]}
        </Option>
      ))}
    </Select>
  );

  const toolbar = selectedCategory ? (
    <>
      <SearchField
        className={{
          searchField: styles.configurationSearchField,
          searchControls: styles.searchControls,
          searchInput: styles.searchInput,
          actionIcon: styles.actionIcon,
        }}
        key="search"
        value={searchText || ''}
        onChange={debounce(onSearchTextChange, 1000)}
        placeholder={searchControlPlaceholder ?? ''}
        nextDisabled={!hasMatches}
        prevDisabled={!hasMatches}
        onNext={findNext}
        onPrev={findPrev}
        onCancel={() => {
          onSearchTextChange('');
        }}
        cancelDisabled={!searchText?.length}
      />

      <Button type="default" size="small" disabled={loading} onClick={triggerRefresh}>
        Refresh
      </Button>
      <Button
        type="default"
        size="small"
        disabled={loading || isExporting}
        onClick={onExportConfigurationData}
      >
        {isExporting ? 'Exporting...' : 'Export'}
      </Button>
    </>
  ) : null;

  const updateDataChange = (e: TreeListItemChangeEvent) => {
    const { dataItem, field, value } = e;

    if (selectedCategory === 'Portfolio Run list') {
      updateCurrentReports({ dataItem, field: field?.split('.')[0] || '', value });
    } else if (selectedCategory === 'Volcker Desk Mapping') {
      updateVolckerDesk({ dataItem, field: field?.split('.')[0] || '', value });
    } else if (selectedCategory === 'Holding Period Nodes') {
      updateHoldingPeriod({ dataItem, field: field?.split('.')[0] || '', value });
    } else if (selectedCategory === 'CTD Mapping') {
      updateCTDMapping({ dataItem, field: field?.split('.')[0] || '', value });
    }
  };

  return (
    <Card className={styles.configurationWrapper} title="Configuration" padded={false}>
      <CardTopBar style={{ flexWrap: 'nowrap' }}>
        <AccentGroup style={{ flexGrow: 1 }}>{categorySelector}</AccentGroup>
        <AccentGroup style={{ flexShrink: 1 }} align="right">
          {toolbar}
        </AccentGroup>
      </CardTopBar>

      <CardBody style={{ display: 'flex', overflow: 'hidden' }}>
        <div style={{ flexGrow: 1 }}>
          {selectedCategory ? (
            <div style={{ position: 'relative', width: '100%', height: '100%' }}>
              <Treelist
                className={styles.treeList}
                data={dataList}
                columns={columns}
                parentField="parent"
                externalState={treeState}
                expandedDataIds={expandedIds}
                onNodeExpandChange={onNodeExpandChange}
                setExternalState={updateTreeState}
                searchText={searchText}
                loading={loading}
                setDisplayData={setSearchData}
                rowHighlightId={nextMatchedId}
                onItemChange={updateDataChange}
                editable={isWriteAuthorized}
              />
            </div>
          ) : (
            <Result
              icon={<span className={`k-icon k-i-gear ${styles.searchIndicatorIcon}`}></span>}
              title="Configuration"
              subTitle="(For configuration maintenance)"
              extra={<span>Select a category</span>}
            />
          )}
        </div>
        {selectedCategory && !loading && showSidePanel && (
          <div className={styles.sideCustomConatiner}>
            <InheritedReports
              headers={headers}
              options={dataList.filter((c: any) => c[sidePanelSourceField])}
              ignoreIdField
              legendText={legendText}
              autoWidth
              ignoreLengthCheck
            />
          </div>
        )}
      </CardBody>
    </Card>
  );
};

export default withErrorBoundary(
  <ErrorFallback title="Error Loading Configuration Data" retryText="Reload Page" />,
)(Configuration);

export const defaults = {
  refDataConfiguration: {
    __typename: 'RefDataConfigurationPage',
    selectedCategory: null,
    expandedIds: [],
    searchText: '',
    changes: [],
    errors: [],
  },
};

export const resolvers = {};

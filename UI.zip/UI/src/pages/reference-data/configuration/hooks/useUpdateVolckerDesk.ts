import { useCallback } from 'react';
import { ApolloClient, gql, useApolloClient } from 'umi-plugin-apollo-anz/apolloClient';
import { ChangeAction, ChangeError, ChangeErrorType } from '@/types/change';
import useUncommittedChanges from '@/hooks/useUncommittedChanges';
import { get, cloneDeep } from 'lodash';
import mappings from '../mappings/volckerDeskMapping';
import prepareVolckerDeskSelectionText, {
  SelectionOption,
} from '../utils/prepareVolckerDeskSelectionText';

const updateCache = (
  client: ApolloClient<object>,
  { id, field, newValues }: { id: string; field: string; newValues: SelectionOption[] },
) => {
  const { query: queryString, dataSetName } = mappings;
  const query = gql(queryString);
  const data = client.readQuery({ query });

  const newData = cloneDeep(data);

  const item = newData[dataSetName].find((i: any) => i.id === id);
  item.modified = true;

  if (Array.isArray(newValues)) {
    item[field] = newValues.map((report) => ({
      ...report,
      __typename: 'RefDataConfigReport',
    }));
    if (newValues?.length > 0) {
      item.isForVolcker = true;
    } else {
      item.isForVolcker = false;
    }
  } else if (typeof newValues === 'boolean') {
    item[field] = newValues;
    if (newValues === false) {
      item.volckerDesk = null;
    }
  }

  client.writeQuery({
    query,
    data: newData,
  });

  // return undo function
  return function undo() {
    client.writeQuery({
      query,
      data,
    });
  };
};

const prepareMutationAction = (newValues: any, field: string, id: string) => {
  const { mutationAction } = mappings;
  if (field === 'isForVolcker') {
    if (newValues === true) {
      return [];
    }

    return {
      [mutationAction]: {
        id,
        [field]: newValues,
        volckerDesk: null,
      },
    };
  }

  if (field === 'volckerDesk') {
    if (newValues && newValues.length > 0) {
      return {
        [mutationAction]: {
          id,
          [field]: newValues[0],
          isForVolcker: true,
        },
      };
    }

    return {
      [mutationAction]: {
        id,
        isForVolcker: false,
      },
    };
  }
  return [];
};

const ERROR_SOURCE_TYPE = 'ConfigData';

const createNewError = (
  sourceId: string,
  sourceField: string,
  errorType?: ChangeErrorType,
  errorMsg?: string,
): ChangeError => ({
  sourceId,
  sourceField,
  sourceType: ERROR_SOURCE_TYPE,
  errorType,
  errorMsg,
});

const validateData = (newValues: any, field: string, dataItem: any) => {
  const errors: ChangeError[] = [];

  if (field === 'isForVolcker') {
    if (newValues === true) {
      const volckerDeskName = dataItem.volckerDesk;
      if (!volckerDeskName) {
        errors.push(createNewError(dataItem.id, field, ChangeErrorType.EMPTY));
      }
    }
  }
  return errors;
};

export default () => {
  const [, addChange, , , , , , replaceAllErrorsForSourceId] = useUncommittedChanges();
  const client = useApolloClient();
  const updateVolckerDesk = useCallback(
    ({ dataItem, field, value: newValues }: { dataItem: any; field: string; value: any }) => {
      const { id, title } = dataItem;

      const action = {
        action: ChangeAction.UPDATE,
        sourceId: id,
        sourceType: title,
        sourceField: field === 'isForVolcker' ? 'Is for Volcker' : 'Volcker Desk Name',
        from: prepareVolckerDeskSelectionText(get(dataItem, field), field),
        to: prepareVolckerDeskSelectionText(newValues, field),
        updateCache: () => updateCache(client, { id, field, newValues }),
        getMutationAction: prepareMutationAction.bind(null, newValues, field, id),
      };
      addChange(action);

      const errors = validateData(newValues, field, dataItem);
      replaceAllErrorsForSourceId(ERROR_SOURCE_TYPE, dataItem.id, errors);
    },
    [],
  );
  return { updateVolckerDesk };
};

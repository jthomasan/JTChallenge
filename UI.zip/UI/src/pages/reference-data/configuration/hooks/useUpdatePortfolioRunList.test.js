import * as apolloClient from 'umi-plugin-apollo-anz/apolloClient';
import { waitForCacheWrites } from 'umi-plugin-apollo-anz/mutationQueue';
import { addChangeMock } from '@/hooks/useUncommittedChanges';
import { ChangeAction } from '@/types/change';
import useUpdatePortfolioRunList from './useUpdatePortfolioRunList';

const { useApolloClient } = apolloClient;
apolloClient.gql = jest.fn();

jest.mock('@/hooks/useUncommittedChanges');
apolloClient.gql = jest.fn();

describe('useUpdatePortfolioRunList hook when updating current reports', () => {
  const writeQueryMock = jest.fn();
  const readQueryMock = jest.fn();

  const dataItem = {
    id: '1',
    title: 'TEST',
    currentReports: [
      {
        id: '03',
        text: 'report 3',
      },
      {
        id: '02',
        text: 'report 2',
      },
      {
        id: '00',
        text: 'report 1',
      },
    ],
  };

  const dataItem2 = {
    id: '0',
    title: 'TEST 0',
    currentReports: [],
  };

  beforeAll(() => {
    useApolloClient.mockReturnValue({
      readQuery: readQueryMock,
      writeQuery: writeQueryMock,
    });
  });

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should add correct fields to addChange', () => {
    // Given
    const originalCacheData = { PortfolioRunList: [dataItem, dataItem2] };
    readQueryMock.mockReturnValue(originalCacheData);
    const { updateCurrentReports } = useUpdatePortfolioRunList();
    const newValues = [
      {
        id: '13',
        text: 'report 13',
      },
      {
        id: '02',
        text: 'report 2',
      },
    ];

    // When
    updateCurrentReports({ dataItem, field: 'currentReports', value: newValues });

    // Then
    expect(addChangeMock).toHaveBeenCalled();

    expect(addChangeMock).toHaveBeenCalledWith(
      expect.objectContaining({
        action: ChangeAction.UPDATE,
        sourceId: '1',
        sourceType: 'TEST',
        sourceField: 'Current Report(s)',
        from: 'report 1;report 2;report 3',
        to: 'report 2;report 13',
      }),
    );
  });

  it('should update cache and undo correctly', async () => {
    // Given
    const originalCacheData = { PortfolioRunList: [dataItem, dataItem2] };
    readQueryMock.mockReturnValue(originalCacheData);
    const { updateCurrentReports } = useUpdatePortfolioRunList();
    const newValues = [
      {
        id: '13',
        text: 'report 13',
      },
      {
        id: '02',
        text: 'report 2',
      },
    ];

    // When
    updateCurrentReports({ dataItem, field: 'currentReports', value: newValues });
    const undo = addChangeMock.mock.calls[0][0].updateCache();
    undo();

    jest.runAllTimers();
    await waitForCacheWrites();

    // Then
    expect(writeQueryMock).toBeCalledTimes(2);

    // update cache
    expect(writeQueryMock).toHaveBeenCalledWith(
      expect.objectContaining({
        data: {
          PortfolioRunList: expect.arrayContaining([
            dataItem2,
            {
              ...dataItem,
              modified: true,
              currentReports: newValues.map((v) => expect.objectContaining(v)),
            },
          ]),
        },
      }),
    );

    // undo
    expect(writeQueryMock).toHaveBeenLastCalledWith(
      expect.objectContaining({
        data: originalCacheData,
      }),
    );
  });

  // TODO:
  it.skip('mutationAction function should return the correct action', () => {
    // Given
    const { updateCurrentReports } = useUpdatePortfolioRunList();
    const newValues = [
      {
        id: '13',
        text: 'report 13',
      },
      {
        id: '02',
        text: 'report 2',
      },
    ];

    // When
    updateCurrentReports({ dataItem, field: 'currentReports', value: newValues });

    // Then
    const mutationAction = addChangeMock.mock.calls[0][0].getMutationAction();
    expect(mutationAction).toEqual({
      // TODO
    });
  });
});

import { useCallback } from 'react';
import { ApolloClient, gql, useApolloClient } from 'umi-plugin-apollo-anz/apolloClient';
import { ChangeAction } from '@/types/change';
import useUncommittedChanges from '@/hooks/useUncommittedChanges';
import { get, cloneDeep } from 'lodash';
import mappings from '../mappings/portfolioRunList';
import concatReportNames, { ReportOption } from '../utils/concatReportNames';

interface PreparedData {
  AllMutations: any[];
  NewData: any;
  OldData: any;
}

const recursivelyFindChilds = <T extends { id: string; parent?: string }>(
  newData: T[],
  id: string,
) => {
  let items = newData.filter((i) => i.parent === id);
  if (items && items.length > 0) {
    items.forEach((element: any) => {
      const childItems = recursivelyFindChilds(newData, element.id);
      items = items.concat(childItems);
    });
  }
  return items;
};

const prepareAllMutationAction = (
  client: ApolloClient<object>,
  { id, field, newValues }: { id: string; field: string; newValues: ReportOption[] },
) => {
  const { query: queryString, dataSetName } = mappings;
  const query = gql(queryString);
  const data = client.readQuery({ query });
  const { mutationAction } = mappings;
  const preparedData: PreparedData = { AllMutations: [], NewData: [], OldData: data };
  let allMutationActions: any[] = [];

  const newData = cloneDeep(data);
  const newValueIds = newValues.map((v) => v.id);

  const item = newData[dataSetName].find((i: any) => i.id === id);
  const oldItem = data[dataSetName].find((i: any) => i.id === id);

  item.modified = true;
  item[field] = newValues.map((report) => ({
    ...report,
    __typename: 'RefDataConfigReport',
  }));

  allMutationActions = allMutationActions.concat({
    [mutationAction]: {
      id,
      [field]: newValues,
    },
  });

  if (field === 'currentReports') {
    const childItems = recursivelyFindChilds(newData[dataSetName], id);

    childItems.forEach((child: any) => {
      if (child && child.currentReports && child.currentReports.length > 0) {
        const elementCurrentReport = child.currentReports.filter(
          (c: ReportOption) => !newValueIds?.includes(c.id),
        );
        if (elementCurrentReport && child.currentReports.length !== elementCurrentReport.length) {
          child.currentReports = elementCurrentReport;
          child.modified = true;

          allMutationActions = allMutationActions.concat({
            [mutationAction]: {
              id: child.id,
              currentReports: elementCurrentReport.map((c: ReportOption) => ({
                id: c.id,
                text: c.text,
              })),
            },
          });
        }
      }

      const oldValue = oldItem.currentReports;
      if (oldValue && oldValue.length > 0) {
        const removedItem = oldValue.filter((c: any) => !newValueIds?.includes(c.id));
        if (removedItem && removedItem.length > 0) {
          const removedItemIds = removedItem.map((v: any) => v.id);
          child.inheritedReports = child.inheritedReports?.filter(
            (c: any) => !removedItemIds?.includes(c.id),
          );
        }
      }
      child.inheritedReports = child.inheritedReports
        .filter((c: any) => !newValueIds.includes(c.id))
        .concat(newValues);
    });
  }
  preparedData.AllMutations = allMutationActions;
  preparedData.NewData = newData;
  return preparedData;
};

const updateCache = (client: ApolloClient<object>, newData: any, oldData: any) => {
  const { query: queryString } = mappings;
  const query = gql(queryString);

  client.writeQuery({
    query,
    data: newData,
  });

  // return undo function
  return function undo() {
    client.writeQuery({
      query,
      data: oldData,
    });
  };
};

export default () => {
  const [, addChange] = useUncommittedChanges();
  const client = useApolloClient();
  const updateCurrentReports = useCallback(
    ({ dataItem, field, value: newValues }: { dataItem: any; field: string; value: any }) => {
      const { id, title } = dataItem;

      const [referrer] = field.split('.');
      const sourceFieldName =
        referrer === 'currentReports' ? 'Current Report(s)' : 'Exclude from Inherited';

      const preparedData: PreparedData = prepareAllMutationAction(client, { id, field, newValues });
      const action = {
        action: ChangeAction.UPDATE,
        sourceId: id,
        sourceType: title,
        sourceField: sourceFieldName,
        from: concatReportNames(get(dataItem, field)),
        to: concatReportNames(newValues),
        updateCache: () => updateCache(client, preparedData.NewData, preparedData.OldData),
        getMutationAction: () => preparedData.AllMutations,
      };

      if (action.from !== action.to) {
        addChange(action);
      }
    },
    [addChange, client],
  );
  return { updateCurrentReports };
};

import { useCallback } from 'react';
import { ApolloClient, gql, useApolloClient } from 'umi-plugin-apollo-anz/apolloClient';
import { ChangeAction } from '@/types/change';
import useUncommittedChanges from '@/hooks/useUncommittedChanges';
import { get, cloneDeep } from 'lodash';
import mappings from '../mappings/ctdMapping';

interface PreparedData {
  AllMutations: any[];
  NewData: any;
  OldData: any;
}

const recursivelyFindChilds = <T extends { id: string; parent?: string }>(
  newData: T[],
  id: string,
) => {
  let items = newData.filter((i) => i.parent === id);
  if (items && items.length > 0) {
    items.forEach((element: any) => {
      const childItems = recursivelyFindChilds(newData, element.id);
      items = items.concat(childItems);
    });
  }
  return items;
};

const prepareAllMutationAction = (
  client: ApolloClient<object>,
  { id, field, newValue }: { id: string; field: string; newValue: boolean },
) => {
  const { query: queryString, dataSetName } = mappings;
  const query = gql(queryString);
  const data = client.readQuery({ query });
  const { mutationAction } = mappings;
  const preparedData: PreparedData = { AllMutations: [], NewData: [], OldData: data };
  let allMutationActions: any = {};

  const newData = cloneDeep(data);

  const item = newData[dataSetName].find((i: any) => i.id === id);

  if (!newValue && item.parent) {
    const parentItem = newData[dataSetName].find((i: any) => i.id === item.parent);
    if (parentItem && parentItem[field]) return preparedData;
  }

  item.modified = true;
  item[field] = newValue;

  allMutationActions = {
    [mutationAction]: {
      id,
      [field]: newValue,
    },
  };

  const childItems = recursivelyFindChilds(newData[dataSetName], id);

  childItems.forEach((child: any) => {
    if (child) {
      child[field] = newValue; // eslint-disable-line no-param-reassign
      child.modified = true; // eslint-disable-line no-param-reassign
    }
  });

  preparedData.AllMutations = allMutationActions;
  preparedData.NewData = newData;
  return preparedData;
};

const updateCache = (client: ApolloClient<object>, newData: any, oldData: any) => {
  const { query: queryString } = mappings;
  const query = gql(queryString);

  client.writeQuery({
    query,
    data: newData,
  });

  // return undo function
  return function undo() {
    client.writeQuery({
      query,
      data: oldData,
    });
  };
};

export default () => {
  const [, addChange] = useUncommittedChanges();
  const client = useApolloClient();
  const updateCTDMapping = useCallback(
    ({ dataItem, field, value: newValue }: { dataItem: any; field: string; value: any }) => {
      const { id, title } = dataItem;

      const sourceFieldName = 'Is CTD';

      const preparedData: PreparedData = prepareAllMutationAction(client, { id, field, newValue });
      if (
        preparedData.NewData &&
        preparedData.NewData.CTDMappings &&
        preparedData.NewData.CTDMappings.length > 0
      ) {
        const action = {
          action: ChangeAction.UPDATE,
          sourceId: id,
          sourceType: title,
          sourceField: sourceFieldName,
          from: get(dataItem, field)?.toString(),
          to: newValue?.toString(),
          updateCache: () => updateCache(client, preparedData.NewData, preparedData.OldData),
          getMutationAction: () => preparedData.AllMutations,
        };

        if (action.from !== action.to) {
          addChange(action);
        }
      }
    },
    [addChange, client],
  );
  return { updateCTDMapping };
};

import { useCallback } from 'react';
import { ApolloClient, gql, useApolloClient } from 'umi-plugin-apollo-anz/apolloClient';
import { ChangeAction } from '@/types/change';
import useUncommittedChanges from '@/hooks/useUncommittedChanges';
import { get, cloneDeep } from 'lodash';
import mappings from '../mappings/holdingPeriodNode';
import { ReportOption } from '../utils/concatReportNames';

interface PreparedData {
  AllMutations: any[];
  NewData: any;
  OldData: any;
}

const prepareAllMutationAction = (
  client: ApolloClient<object>,
  { id, field, newValue }: { id: string; field: string; newValue: ReportOption[] },
) => {
  const { query: queryString, dataSetName } = mappings;
  const query = gql(queryString);
  const data = client.readQuery({ query });
  const { mutationAction } = mappings;
  const preparedData: PreparedData = { AllMutations: [], NewData: [], OldData: data };
  let allMutationActions: any = {};

  const newData = cloneDeep(data);

  const item = newData[dataSetName].find((i: any) => i.id === id);
  item.modified = true;
  item[field] = newValue;

  if (field === 'isForHoldingPeriod' && newValue && item.excludeInternalTrades) {
    allMutationActions = {
      [mutationAction]: {
        id,
        [field]: newValue,
        excludeInternalTrades: true,
      },
    };
  } else {
    allMutationActions = {
      [mutationAction]: {
        id,
        [field]: newValue,
      },
    };
  }

  preparedData.AllMutations = allMutationActions;
  preparedData.NewData = newData;
  return preparedData;
};

const updateCache = (client: ApolloClient<object>, newData: any, oldData: any) => {
  const { query: queryString } = mappings;
  const query = gql(queryString);

  client.writeQuery({
    query,
    data: newData,
  });

  // return undo function
  return function undo() {
    client.writeQuery({
      query,
      data: oldData,
    });
  };
};

export default () => {
  const [, addChange] = useUncommittedChanges();
  const client = useApolloClient();
  const updateHoldingPeriod = useCallback(
    ({ dataItem, field, value: newValue }: { dataItem: any; field: string; value: any }) => {
      const { id, title } = dataItem;

      const sourceFieldName =
        field === 'isForHoldingPeriod' ? 'Is for Holding Period' : 'Exclude Internal Trades';

      const preparedData: PreparedData = prepareAllMutationAction(client, { id, field, newValue });
      if (preparedData?.NewData?.HoldingPeriodNodes?.length) {
        const action = {
          action: ChangeAction.UPDATE,
          sourceId: id,
          sourceType: title,
          sourceField: sourceFieldName,
          from: get(dataItem, field)?.toString(),
          to: newValue?.toString(),
          updateCache: () => updateCache(client, preparedData.NewData, preparedData.OldData),
          getMutationAction: () => preparedData.AllMutations,
        };

        if (action.from !== action.to) {
          addChange(action);
        }
      }
    },
    [addChange, client],
  );
  return { updateHoldingPeriod };
};

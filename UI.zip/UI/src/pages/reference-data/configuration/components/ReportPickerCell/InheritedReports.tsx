import React from 'react';
import { Row, Col } from 'antd';
import { List } from 'react-virtualized';

import styles from './index.less';
import { useResizeDetector } from 'react-resize-detector';

export interface Header {
  title?: string;
  field?: string;
  width?: string;
  height?: string;
  cell?: React.ElementType;
  extras?: any;
}

interface Option {
  id: string;
  text: string;
  title?: string;
}

interface InheritedReportsProps {
  headers?: Header[];
  hideHeaderTitle?: boolean;
  width?: number;
  height?: number;
  options: Option[];
  ignoreIdField?: boolean;
  legendText?: string;
  autoHeight?: boolean;
  autoWidth?: boolean;
  listStyle?: object;
  ignoreLengthCheck?: boolean;
}

const InheritedReports: React.FC<InheritedReportsProps> = ({
  headers = [],
  hideHeaderTitle,
  width = 460,
  height = null,
  options,
  ignoreIdField = false,
  legendText = 'Inherited Items:',
  autoHeight = false,
  autoWidth = false,
  listStyle = {},
  ignoreLengthCheck = false,
}) => {
  const spanSize = (headers.length && (headers.length <= 3 ? 24 / headers.length : 6)) || 24;

  const rowRenderer = ({ key, index, style }: any) => {
    const option = options[index];

    return (
      <div key={key} className={styles.gridRowText} style={style}>
        <Row>
          {!ignoreIdField && (
            <Col span={spanSize} style={{ width: headers[0]?.width || 'auto' }}>
              {option.id}
            </Col>
          )}
          <Col span={spanSize} style={{ width: headers[1]?.width || 'auto' }}>
            {option.text || option.title}
          </Col>
        </Row>
      </div>
    );
  };

  const { height: listWrapperHeight, ref: listWrapperRef } = useResizeDetector<HTMLDivElement>({
    handleWidth: false,
    handleHeight: height === null,
  });

  return (
    <>
      {(ignoreLengthCheck || (options && options.length > 0)) && (
        <fieldset 
          style={{ 
            border: '1px solid rgb(232, 232, 232)', 
            marginTop: 10,
            display: 'flex',
            flexDirection: 'column', 
          }}
        >
          <legend
            style={{
              width: 'auto',
              paddingLeft: '3px',
              paddingRight: '5px',
              marginLeft: '5px',
              marginBottom: '0px',
              fontSize: 'small',
            }}
          >
            {legendText}
          </legend>
          {headers.length > 0 && !hideHeaderTitle && (
            <Row className={styles.header}>
              {headers.map((header) => (
                <Col key={`header-${header.field}`} span={spanSize} style={{ width: header.width }}>
                  {header.title}
                </Col>
              ))}
            </Row>
          )}
          <div className={`${styles.gridRowText} ${styles.listWrapper}`} ref={listWrapperRef}>
            <List
              width={width}
              height={height ?? listWrapperHeight ?? 0}
              rowCount={options.length}
              rowHeight={20}
              rowRenderer={rowRenderer}
              autoHeight={autoHeight}
              autoWidth={autoWidth}
              style={listStyle}
            ></List>
          </div>
        </fieldset>
      )}
    </>
  );
};

export default InheritedReports;

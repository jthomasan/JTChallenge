import React, { useMemo, useRef, useState, useContext } from 'react';
import { Tooltip } from '@progress/kendo-react-tooltip';
import classnames from 'classnames';
import _ from 'lodash';
import { gql } from 'umi-plugin-apollo-anz/apolloClient';
import useQuery from '@/hooks/useQueryExtended';
import EditContext from '@/contexts/EditContext';

import { Popup } from '@progress/kendo-react-popup';
import MultiSelectPopup, {
  MultiSelectPopupProps,
  OptionProp,
} from '@/components/MultiSelect/MultiSelectPopup';
import SimpleTD from '@/components/SimpleTD';
import InheritedReports from './InheritedReports';
import styles from './index.less';
import concatReportNames, { ReportOption } from '../../utils/concatReportNames';

export interface CellProps {
  dataItem: { id: string; inheritedReports: any[]; currentReports: any[] };
  field: string;
  onChange: (e: { dataItem: any; field: string; value: any }) => void;
}

const headers = [
  {
    field: 'id',
    title: 'Name',
    width: '200px',
  },
  {
    field: 'text',
    title: 'Description',
    width: '200px',
  },
];

function MultiSelectPopupWrapped<T extends OptionProp>(
  wrapperProps: {
    defaultValue: T[];
    onBlur: (values: T[]) => void;
  } & Omit<MultiSelectPopupProps<T>, 'onBlur' | 'value' | 'onChange'>,
) {
  const [selectedItems, setSelectedItems] = useState<T[]>(wrapperProps.defaultValue);

  return (
    <MultiSelectPopup
      {...wrapperProps}
      value={selectedItems}
      onChange={(v) => setSelectedItems(v || [])}
      onBlur={() => {
        wrapperProps.onBlur(selectedItems);
      }}
    />
  );
}

const generateReportPickerCell: (extras?: {
  showInheritedReports?: boolean;
  showToolTip?: boolean;
  isMultipleValue?: boolean;
}) => React.FC<CellProps> = (extras = {}) =>
  function ReportPickerCell(props: CellProps) {
    const { showInheritedReports, showToolTip, isMultipleValue } = extras;
    const { dataItem, onChange, field } = props;
    const { id } = dataItem;
    const [rootField, childField] = field.split('.');

    const { editing: gridEditDetails, setEditing, editableFields } = useContext(EditContext);
    const isEditing =
      gridEditDetails && id === gridEditDetails.id && field === gridEditDetails?.field;

    const cellValue = useMemo(() => {
      if (isMultipleValue) {
        return concatReportNames(dataItem ? dataItem[rootField] : []);
      }
      return dataItem ? dataItem[rootField]?.[childField] : '';
    }, [dataItem, rootField, isMultipleValue, childField]);

    const toolTipContent = useMemo(() => {
      if (showToolTip) {
        return (
          <div className={styles.toolTipCustom}>
            {dataItem
              ? dataItem[rootField]?.map((c: any, index: number) => (
                  <p key={`${dataItem?.id}-${rootField}-${index}`} className={styles.toolTipCustom}>
                    {c[childField]}
                  </p>
                ))
              : ''}
          </div>
        );
      }
      return null;
    }, [dataItem, childField, rootField, showToolTip]);

    const { loading, data } = useQuery(
      gql`
        query CurrentReportsQuery {
          PortfolioCurrentReports {
            id
            text
          }
        }
      `,
      {
        skip: !isEditing,
      },
    );

    const selectableData = useMemo(() => {
      let dataList = [];
      if (rootField === 'currentReports') {
        dataList = _(data?.PortfolioCurrentReports || [])
          .differenceWith(
            dataItem?.inheritedReports || [],
            (a: ReportOption, b: ReportOption) => a.id === b.id,
          )
          .sortBy(['id'])
          .value();
      } else if (rootField === 'excludedReports') {
        dataList = dataItem?.inheritedReports ?? [];
      }

      return dataList.map((r) => ({ id: r.id, text: r.text }));
    }, [data, dataItem, rootField]);

    const tdEl = useRef<HTMLTableDataCellElement | null>(null);

    const onMultiSelectBlur = (value: any) => {
      setEditing(null);

      if (onChange) {
        onChange({
          dataItem,
          field,
          value,
        });
      }
    };

    const isEditableCell = editableFields.includes(field);

    const setCellEditing = (e: React.MouseEvent<HTMLTableDataCellElement, MouseEvent>) => {
      if (isEditableCell) {
        setEditing({ id, field });
        e.stopPropagation();
      }
    };

    const inheritedReports = showInheritedReports ? (
      <InheritedReports headers={headers} options={dataItem.inheritedReports} height={155} />
    ) : null;

    return (
      <SimpleTD
        {...props}
        ref={tdEl}
        className={classnames({
          [styles.gridEditingRow]: isEditing,
          'edit-cell-item': isEditableCell,
        })}
        onClick={setCellEditing}
      >
        {loading ? (
          'Loading...'
        ) : (
          <>
            <Tooltip content={() => toolTipContent} anchorElement="target">
              <div title="title" className={styles.toolTipParent}>
                {cellValue}
              </div>
            </Tooltip>
            {isEditing && (
              <Popup
                popupClass={styles.TreeMultiSelectPopup}
                anchor={tdEl.current || undefined}
                animate={false}
                show
                onClose={onMultiSelectBlur}
              >
                <div
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                  }}
                >
                  <MultiSelectPopupWrapped
                    style={{ width: 480 }}
                    headers={headers}
                    defaultValue={dataItem[rootField]}
                    options={selectableData}
                    enableMultiSelect
                    onBlur={onMultiSelectBlur}
                    showSearch
                    optionsContainerWidth={465}
                    optionsContainerHeight={155}
                  >
                    {inheritedReports}
                  </MultiSelectPopupWrapped>
                </div>
              </Popup>
            )}
          </>
        )}
      </SimpleTD>
    );
  };

export default generateReportPickerCell;

import React, { _mockUseEffect } from 'react';
import { shallow } from 'enzyme';
import SimpleTD from '@/components/SimpleTD';
import generateReportPickerCell from './index';

_mockUseEffect(jest.fn((fn) => fn()));

const dataItem = {
  added: {
    by: 'chigrins',
    time: '2020-11-17T08:12:25',
  },
  currentReports: [
    {
      id: 'ARM_BASIS',
      text: 'ARM Basis Delta',
    },
    {
      id: 'ARM_DACI',
      text: 'ARM Accrued Interest, AUD',
    },
    {
      id: 'ARM_DV01',
      text: 'ARM PAR_DV01, AUD',
    },
    {
      id: 'ARM_HYPOPNL',
      text: 'ARM Hypo PnL',
    },
    {
      id: 'ARM_IRNPL',
      text: 'ARM NT Ordinary Stress',
    },
    {
      id: 'ARM_IRPL',
      text: 'ARM IR Parallel, AUD',
    },
    {
      id: 'ARM_MKTV',
      text: 'ARM Market Value, AUD',
    },
    {
      id: 'ARM_NOTV',
      text: 'ARM Notional Value, AUD',
    },
    {
      id: 'ARM_VARF',
      text: 'ARM 1540 day VaR',
    },
    {
      id: 'ARM_VARV',
      text: 'ARM 1 day VaR, AUD',
    },
    {
      id: 'RISK_OTH_PASTCASH',
      text: 'SKY Risk Past Cash',
    },
  ],
  inheritedReports: [],
  id: 6670,
  title: 'ANZ Group',
  parentNodeName: 'ROOT',
  excludedReports: [],
};

describe('Configuration TreeListColonSeperatedCell Data Tests', () => {
  let wrapper = null;
  const ReportPickerCellComponent = generateReportPickerCell({ isMultipleValue: true });

  beforeEach(() => {
    wrapper = shallow(
      <ReportPickerCellComponent field="currentReports.text" dataItem={dataItem} />,
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should mount the component with td', () => {
    expect(wrapper.find(SimpleTD)).toHaveLength(1);
  });

  it('should have the expected value', () => {
    expect(wrapper.find('div').text()).toEqual(
      'ARM Basis Delta;ARM Accrued Interest, AUD;ARM PAR_DV01, AUD;ARM Hypo PnL;ARM NT Ordinary Stress;ARM IR Parallel, AUD;ARM Market Value, AUD;ARM Notional Value, AUD;ARM 1540 day VaR;ARM 1 day VaR, AUD;SKY Risk Past Cash',
    );
  });
});

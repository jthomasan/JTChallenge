import React, { _mockUseEffect } from 'react';
import { shallow } from 'enzyme';
import SimpleTD from '@/components/SimpleTD';
import generateVolckerNamePickerCell from './index';

_mockUseEffect(jest.fn((fn) => fn()));

const dataItem = {
  id: '8597',
  modified: false,
  isForVolcker: true,
  parent: '8570',
  title: 'Treasury - New Zealand',
  volckerDesk: { id: '48', text: 'Commodities - Base Metals', __typename: 'RefDataConfigReport' },
  inheritedVolckerDesk: null,
  added: { by: 'thomaj29', time: '2021-04-12T07:37:12', __typename: 'Added' },
  __typename: 'VolckerDeskMapping',
};

const dataItemForToolTipTest = {
  id: '8597',
  modified: false,
  isForVolcker: true,
  parent: '8570',
  title: 'Treasury - New Zealand',
  volckerDesk: null,
  inheritedVolckerDesk: null,
  added: { by: 'thomaj29', time: '2021-04-12T07:37:12', __typename: 'Added' },
  __typename: 'VolckerDeskMapping',
};

describe('Configuration VolckerNamePickerCell Data Tests', () => {
  let wrapper = null;
  let toolTipWrapper = null;
  const VolckerNamePickerCellComponent = generateVolckerNamePickerCell();

  beforeEach(() => {
    wrapper = shallow(
      <VolckerNamePickerCellComponent field="volckerDesk.text" dataItem={dataItem} />,
    );
    toolTipWrapper = shallow(
      <VolckerNamePickerCellComponent field="volckerDesk.text" dataItem={dataItemForToolTipTest} />,
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should mount the component with td', () => {
    expect(wrapper.find(SimpleTD)).toHaveLength(1);
  });

  it('should have the expected value', () => {
    expect(wrapper.find('span').text()).toEqual('Commodities - Base Metals');
  });

  it('should have the tooltip element', () => {
    expect(toolTipWrapper.find('Tooltip')).toHaveLength(1);
  });

  it('should have expected tooltip title', () => {
    expect(toolTipWrapper.find('div').prop('title')).toEqual('Volcker Desk is required');
  });
});

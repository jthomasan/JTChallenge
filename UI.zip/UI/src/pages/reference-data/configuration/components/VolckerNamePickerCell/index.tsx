import React, { useMemo, useRef, useState, useContext } from 'react';
import classnames from 'classnames';
import { gql } from 'umi-plugin-apollo-anz/apolloClient';
import useQuery from '@/hooks/useQueryExtended';
import EditContext from '@/contexts/EditContext';
import { CloseCircleFilled } from '@ant-design/icons';

import { Popup } from '@progress/kendo-react-popup';
import { Tooltip } from '@progress/kendo-react-tooltip';
import MultiSelectPopup, {
  MultiSelectPopupProps,
  OptionProp,
} from '@/components/MultiSelect/MultiSelectPopup';
import SimpleTD from '@/components/SimpleTD';
import styles from './index.less';
import concatReportNames from '../../utils/concatReportNames';

export interface CellProps {
  dataItem: { id: string; inheritedReports: any[] };
  field: string;
  onChange: (e: { dataItem: any; field: string; value: any }) => void;
}

const headers = [
  {
    field: 'text',
    title: 'Description',
    width: 'auto',
  },
];

function MultiSelectPopupWrapped<T extends OptionProp>(
  wrapperProps: {
    defaultValue: T[];
    onBlur: (values: T[]) => void;
  } & Omit<MultiSelectPopupProps<T>, 'onBlur' | 'value' | 'onChange'>,
) {
  const [selectedItems, setSelectedItems] = useState<T[]>(wrapperProps.defaultValue);

  return (
    <MultiSelectPopup
      {...wrapperProps}
      value={selectedItems}
      onChange={(v) => setSelectedItems(v || [])}
      onBlur={() => {
        wrapperProps.onBlur(selectedItems);
      }}
    />
  );
}

const generateVolckerNamePickerCell: (extras?: {
  showInheritedReports?: boolean;
  isMultipleValue?: boolean;
  isVolckerDesk?: boolean;
}) => React.FC<CellProps> = (extras = {}) =>
  function VolckerNamePickerCell(props: CellProps) {
    const { isMultipleValue } = extras;
    const { dataItem, onChange, field } = props;
    const { id } = dataItem;
    const [rootField, childField] = field.split('.');
    const volckerBoolField = 'isForVolcker';

    const { editing: gridEditDetails, setEditing, editableFields } = useContext(EditContext);
    const isEditing =
      gridEditDetails && id === gridEditDetails.id && field === gridEditDetails?.field;

    const cellValue = useMemo(() => {
      if (isMultipleValue) {
        return concatReportNames(dataItem ? dataItem[rootField] : []);
      }
      if (dataItem && dataItem[rootField] && Array.isArray(dataItem[rootField])) {
        return dataItem[rootField].length > 0 ? dataItem[rootField][0][childField] : '';
      }

      return dataItem ? dataItem[rootField]?.[childField] : '';
    }, [dataItem, rootField, isMultipleValue, childField]);

    const { loading, data } = useQuery(
      gql`
        query VolckerDeskNameQuery {
          VolckerDeskNames {
            id
            text
          }
        }
      `,
      {
        skip: !isEditing,
      },
    );

    const selectableData = useMemo(() => data?.VolckerDeskNames || [], [data]);

    const tdEl = useRef<HTMLTableDataCellElement | null>(null);

    const onMultiSelectBlur = (value: any) => {
      setEditing(null);

      if (onChange) {
        onChange({
          dataItem,
          field,
          value,
        });
      }
    };

    const isEditableCell = editableFields.includes(field);

    const setCellEditing = (e: React.MouseEvent<HTMLTableDataCellElement, MouseEvent>) => {
      if (isEditableCell) {
        setEditing({ id, field });
        e.stopPropagation();
      }
    };

    const defaultValue = () => {
      if (
        dataItem[rootField] &&
        Array.isArray(dataItem[rootField]) &&
        dataItem[rootField].length > 0
      ) {
        return dataItem[rootField][0].id ? dataItem[rootField] : [];
      }

      return dataItem[rootField] && dataItem[rootField].id ? dataItem[rootField] : {};
    };

    const toolTipContent = useMemo(
      () => (
        <div className="ant-alert ant-alert-error">
          <CloseCircleFilled />
          <span className="ant-alert-message" style={{ padding: '7px' }}>
            Volcker Desk is required
          </span>
          <span className="ant-alert-description"></span>
        </div>
      ),
      [],
    );

    return (
      <SimpleTD
        {...props}
        ref={tdEl}
        className={classnames({
          [styles.gridEditingRow]: isEditing,
          [styles.volckerNamePickerCell]: true,
          'edit-cell-item': isEditableCell,
          'has-error': true,
          [styles.hasError]: dataItem && dataItem[volckerBoolField] && !cellValue,
        })}
        onClick={setCellEditing}
      >
        {loading ? (
          'Loading...'
        ) : (
          <>
            {cellValue ? (
              <span>{cellValue}</span>
            ) : (
              <>
                {dataItem && dataItem[volckerBoolField] && (
                  <Tooltip
                    content={() => toolTipContent}
                    anchorElement="target"
                    className={styles.volckerToolTipOverlay}
                  >
                    <div
                      className={classnames({ [styles.hasError]: !isEditing })}
                      style={{ width: '185px', height: '18px' }}
                      title="Volcker Desk is required"
                    ></div>
                  </Tooltip>
                )}
              </>
            )}

            {isEditing && (
              <Popup
                popupClass={styles.TreeMultiSelectPopup}
                anchor={tdEl.current || undefined}
                animate={false}
                show
                onClose={onMultiSelectBlur}
              >
                <div
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                  }}
                >
                  <MultiSelectPopupWrapped
                    style={{ width: 320 }}
                    headers={headers}
                    defaultValue={defaultValue}
                    options={selectableData}
                    onBlur={onMultiSelectBlur}
                    showSearch
                    optionsContainerWidth={305}
                    optionsContainerHeight={155}
                  />
                </div>
              </Popup>
            )}
          </>
        )}
      </SimpleTD>
    );
  };

export default generateVolckerNamePickerCell;

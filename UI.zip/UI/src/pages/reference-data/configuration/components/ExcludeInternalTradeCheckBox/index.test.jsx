import React, { _mockUseEffect, _mockUseContext } from 'react';
import { mount } from 'enzyme';
import SimpleTD from '@/components/SimpleTD';
import EditContext from '@/contexts/EditContext';
import ExcludeInternalTradeCheckBox from './index';

_mockUseEffect(jest.fn((fn) => fn()));

const dataItem = {
  id: '6976',
  modified: false,
  parent: '6670',
  title: 'Monitored Portfolios',
  isForHoldingPeriod: true,
  excludeInternalTrades: false,
  added: { by: 'thomaj29', time: '2021-04-21T00:51:41', __typename: 'Added' },
  __typename: 'HoldingPeriodNode',
};

const dataItemForFalse = {
  id: '6976',
  modified: false,
  parent: '6670',
  title: 'Monitored Portfolios',
  isForHoldingPeriod: false,
  excludeInternalTrades: false,
  added: { by: 'thomaj29', time: '2021-04-21T00:51:41', __typename: 'Added' },
  __typename: 'HoldingPeriodNode',
};

describe('Configuration TreeListCheckBoxCell Data Tests', () => {
  let wrapper = null;
  let wrapperFalse = null;

  beforeEach(() => {
    wrapper = mount(
      <EditContext.Provider>
        <ExcludeInternalTradeCheckBox field="excludeInternalTrades" dataItem={dataItem} />
      </EditContext.Provider>,
    );

    wrapperFalse = mount(
      <EditContext.Provider>
        <ExcludeInternalTradeCheckBox field="excludeInternalTrades" dataItem={dataItemForFalse} />
      </EditContext.Provider>,
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  const setEditingMock = jest.fn().mockImplementation();
  const contextMock = jest.fn().mockReturnValue({
    setEditing: setEditingMock,
    editableFields: ['excludeInternalTrades', 'isForHoldingPeriod'],
  });

  _mockUseContext(contextMock);

  it('should mount the component with td', () => {
    expect(wrapper.find(SimpleTD)).toHaveLength(1);
  });

  it('should have called the setEditingMock one time when isForHoldingPeriod is true', () => {
    const element = wrapper.find(SimpleTD);
    element.simulate('click');

    expect(setEditingMock).toHaveBeenCalledTimes(1);
  });

  it('should have not called the setEditingMock when isForHoldingPeriod is false', () => {
    const element = wrapperFalse.find(SimpleTD);
    element.simulate('click');

    expect(setEditingMock).toHaveBeenCalledTimes(0);
  });
});

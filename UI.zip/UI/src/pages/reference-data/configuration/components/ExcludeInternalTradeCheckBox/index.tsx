import { TreeListCellProps } from '@/components/TreeList';
import SimpleTD from '@/components/SimpleTD';
import React, { SyntheticEvent, useContext } from 'react';
import EditContext from '@/contexts/EditContext';
import { get } from 'lodash';
import classnames from 'classnames';
import styles from './index.less';

interface TreeListCheckboxCellProps extends TreeListCellProps {
  children?: any[];
}

const ExcludeInternalTradeCheckBox: React.FC<TreeListCheckboxCellProps> | any = (
  props: TreeListCheckboxCellProps,
) => {
  const { dataItem, field = '', onChange } = props;
  const { id } = dataItem;

  const isChecked: boolean = get(dataItem, field);

  const { editing: gridEditDetails, setEditing, editableFields } = useContext(EditContext);

  const isEditableCell = editableFields.includes(field) && dataItem.isForHoldingPeriod;
  const isEditing =
    gridEditDetails && id === gridEditDetails.id && field === gridEditDetails?.field;

  const setCellEditing = (e: React.MouseEvent<HTMLTableDataCellElement, MouseEvent>) => {
    if (isEditableCell) {
      setEditing({ id, field });
      e.stopPropagation();
    }
  };

  const setValue = (checked: boolean, event: SyntheticEvent | null = null) => {
    if (onChange) {
      let updatedData: any = '';
      const fieldArr = field.split('.');
      if (fieldArr.length > 1) {
        updatedData = { [fieldArr[fieldArr.length - 1]]: checked };
      } else {
        updatedData = checked;
      }
      const data: any = {
        dataItem,
        field,
        syntheticEvent: event,
        value: updatedData,
      };

      onChange(data);
    }
  };

  const onChangeInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setValue(e.target.checked);
  };

  const cell = (
    <SimpleTD
      {...props}
      tabIndex={-1}
      className={classnames({
        [styles.treeListCheckboxCell]: true,
        [styles.true]: isChecked,
        [styles.false]: !isChecked,
        [styles.editing]: isEditing,
        [styles.notEditing]: !isEditing,
      })}
      onClick={setCellEditing}
    >
      {isEditing ? (
        <>
          <input type="checkbox" checked={!!isChecked} onChange={onChangeInput} />
          {Array.isArray(props.children) && props.children[1]}
        </>
      ) : (
        ''
      )}
    </SimpleTD>
  );

  return cell;
};

ExcludeInternalTradeCheckBox.cellName = 'ExcludeInternalTradeCheckBox';

export default ExcludeInternalTradeCheckBox;

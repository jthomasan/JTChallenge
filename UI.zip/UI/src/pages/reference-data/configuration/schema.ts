import { gql } from 'umi-plugin-apollo-anz/apolloClient';

export default gql`
  type RefDataConfigurationPage implements ChangeRegistry & Refreshable {
    selectedCategory: String
    expandedIds: [String]
    searchText: String
  }

  extend type Page {
    refDataConfiguration: RefDataConfigurationPage
  }
`;

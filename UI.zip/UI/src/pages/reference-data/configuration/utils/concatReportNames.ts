import { sortBy } from 'lodash';

export interface ReportOption {
  id: string;
  text: string;
}

const concatReportNames = (reports: ReportOption[]): string => {
  return sortBy(reports, ['id'])
    .filter(
      (item) =>
        item !== null &&
        item !== undefined &&
        item.id !== undefined &&
        item.text !== undefined &&
        item.text !== '',
    )
    .map((r) => r?.text)
    .join(';');
};
export default concatReportNames;

export interface SelectionOption {
  id: string;
  text: string;
}

const prepareVolckerDeskSelectionText = (selection: any | SelectionOption, field: string): string =>{
  if(field==='isForVolcker'){
      if(typeof selection === "boolean"){
          return selection.toString();
      }
      return '';
  }
  if(field === 'volckerDesk'){
      if(selection && Array.isArray(selection) && selection.length>0){
          return selection[0].text;
      }
  }
  return '';
}
export default prepareVolckerDeskSelectionText;

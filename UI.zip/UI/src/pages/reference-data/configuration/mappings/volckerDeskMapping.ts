import { DATE_FORMATS } from '@/utils/date';
import SelectableHighlightingCell from '@/components/TreeList/cellRenderers/SelectableHighlightingCell';
import TreeListStateCell from '@/components/TreeList/cells/TreeListStateCell';
import TreeListCheckboxCell from '@/components/TreeListCheckboxCell';
import TreeListDateCell from '@/components/TreeList/cells/TreeListDateCell';
import generateVolckerNamePickerCell from '../components/VolckerNamePickerCell';

const volkerDeskMappingQuery = `query configurationQuery {
    VolckerDeskMappings {
      id
      modified
      isForVolcker
      parent
      title
      volckerDesk {
        id
        text
      }
      inheritedVolckerDesk {
        id
        text
      }
      added {
        by
        time
      }
    }
  }`;

export default {
  query: volkerDeskMappingQuery,
  columns: [
    {
      field: 'modified',
      title: 'State',
      width: '60px',
      reorderable: false,
      cell: TreeListStateCell,
    },
    {
      field: 'title',
      title: 'Portfolio Hierarchy',
      width: '300px',
      treeDisplayField: true,
      expandable: true,
      defaultSortColumn: true,
      customCellRenderer: {
        renderer: SelectableHighlightingCell,
        extraProps: { highlightColor: 'rgb(0, 65, 101)' },
      },
    },
    {
      field: 'isForVolcker',
      title: 'Is for Volcker?',
      width: '100px',
      treeDisplayField: true,
      cell: TreeListCheckboxCell,
      editable: true,
    },
    {
      field: 'volckerDesk.text',
      width: '200px',
      title: 'Volcker Desk Name',
      cell: generateVolckerNamePickerCell(),
      reorderable: false,
      editable: true,
    },
    {
      field: 'inheritedVolckerDesk.text',
      width: '200px',
      title: 'Inherited Volker Desk',
      reorderable: false,
    },
    {
      field: 'added.by',
      width: '140px',
      title: 'Last Edited By',
      reorderable: false,
    },
    {
      field: 'added.time',
      width: '140px',
      title: 'Last Edited Time',
      format: DATE_FORMATS.DATE_TIME,
      cell: TreeListDateCell,
    },
  ],
  searchControlPlaceholder: 'Node Search',
  exportUrl: '/export/reference-data/configuration/volcker-desk-mapping/csv',
  dataSetName: 'VolckerDeskMappings',
  mutationAction: 'replaceVolckerDeskMapping',
  showSidePanel: true,
  legendText: 'Is for Volcker',
  sidePanelSourceField: 'isForVolcker',
};

import SelectableHighlightingCell from '@/components/TreeList/cellRenderers/SelectableHighlightingCell';
import TreeListStateCell from '@/components/TreeList/cells/TreeListStateCell';
import generateReportPickerCell from '../components/ReportPickerCell';

const portfolioRunListQuery = `query configurationQuery {
  PortfolioRunList {
    id
    modified
    parent
    title
    currentReports {
      id
      text
    }
    inheritedReports {
      id
      text
    }
    excludedReports {
      id
      text
    }
    added {
      by
      time
    }
  }
}`;

export default {
  query: portfolioRunListQuery,
  columns: [
    {
      field: 'modified',
      title: 'State',
      width: '60px',
      reorderable: false,
      cell: TreeListStateCell,
    },
    {
      field: 'title',
      title: 'Portfolio Hierarchy',
      width: '300px',
      treeDisplayField: true,
      expandable: true,
      defaultSortColumn: true,
      customCellRenderer: {
        renderer: SelectableHighlightingCell,
        extraProps: { highlightColor: 'rgb(0, 65, 101)' },
      },
    },
    {
      field: 'currentReports.text',
      width: '340px',
      title: 'Current Report(s)',
      cell: generateReportPickerCell({
        showInheritedReports: true,
        showToolTip: true,
        isMultipleValue: true,
      }),
      reorderable: false,
      editable: true,
    },
    {
      field: 'inheritedReports.text',
      width: '340px',
      title: 'Inherited Report(s)',
      cell: generateReportPickerCell({ showToolTip: true, isMultipleValue: true }),
      reorderable: false,
    },
    {
      field: 'excludedReports.text',
      width: '340px',
      title: 'Exclude from Inherited',
      cell: generateReportPickerCell({ showToolTip: true, isMultipleValue: true }),
      reorderable: false,
      editable: true,
    },
  ],
  searchControlPlaceholder: 'Node Search',
  exportUrl: '/export/reference-data/configuration/portfolio-runlist/csv',
  dataSetName: 'PortfolioRunList',
  mutationAction: 'replacePortfolioRunList',
  showSidePanel: false,
};

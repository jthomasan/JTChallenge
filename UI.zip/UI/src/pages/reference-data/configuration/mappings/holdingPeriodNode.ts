import { DATE_FORMATS } from '@/utils/date';
import SelectableHighlightingCell from '@/components/TreeList/cellRenderers/SelectableHighlightingCell';
import TreeListStateCell from '@/components/TreeList/cells/TreeListStateCell';
import TreeListCheckboxCell from '@/components/TreeListCheckboxCell';
import TreeListDateCell from '@/components/TreeList/cells/TreeListDateCell';
import ExcludeInternalTradeCheckBox from '../components/ExcludeInternalTradeCheckBox';

const holdingPeriodNodeQuery = `query configurationQuery {
    HoldingPeriodNodes {
    id
    modified
    parent
    title
    isForHoldingPeriod
    excludeInternalTrades
    added {
      by
      time
    }
  }
}`;

export default {
  query: holdingPeriodNodeQuery,
  columns: [
    {
      field: 'modified',
      title: 'State',
      width: '60px',
      reorderable: false,
      cell: TreeListStateCell,
    },
    {
      field: 'title',
      title: 'Portfolio Hierarchy',
      width: '300px',
      treeDisplayField: true,
      expandable: true,
      defaultSortColumn: true,
      customCellRenderer: {
        renderer: SelectableHighlightingCell,
        extraProps: { highlightColor: 'rgb(0, 65, 101)' },
      },
    },
    {
      field: 'isForHoldingPeriod',
      width: '150px',
      title: 'Is for Holding Period?',
      cell: TreeListCheckboxCell,
      reorderable: false,
      editable: true,
    },
    {
      field: 'excludeInternalTrades',
      width: '150px',
      title: 'Exclude Internal Trades',
      cell: ExcludeInternalTradeCheckBox,
      reorderable: false,
      editable: true,
    },
    {
      field: 'added.by',
      width: '150px',
      title: 'Last Edited By',
      reorderable: false,
    },
    {
      field: 'added.time',
      width: '150px',
      title: 'Last Edited Time',
      format: DATE_FORMATS.DATE_TIME,
      cell: TreeListDateCell,
    },
  ],
  searchControlPlaceholder: 'Node Search',
  exportUrl: '/export/reference-data/configuration/holding-period-node/csv',
  dataSetName: 'HoldingPeriodNodes',
  mutationAction: 'replaceHoldingPeriodNode',
  showSidePanel: true,
  legendText: 'Is for Holding Period',
  sidePanelSourceField: 'isForHoldingPeriod',
};

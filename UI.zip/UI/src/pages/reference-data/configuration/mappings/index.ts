import portfolioRunList from './portfolioRunList';
import volckerDeskMapping from './volckerDeskMapping';
import holdingPeriodNode from './holdingPeriodNode';
import ctdMapping from './ctdMapping';

export enum ConfigurationCategory {
  PORTFOLIO_RUN_LIST = 'Portfolio Run list',
  VOLCKER_DESK_MAPPING = 'Volcker Desk Mapping',
  HOLDING_PERIOD_NODE = 'Holding Period Nodes',
  CTD_MAPPING = 'CTD Mapping',
}

export default {
  [ConfigurationCategory.PORTFOLIO_RUN_LIST]: portfolioRunList,
  [ConfigurationCategory.VOLCKER_DESK_MAPPING]: volckerDeskMapping,
  [ConfigurationCategory.HOLDING_PERIOD_NODE]: holdingPeriodNode,
  [ConfigurationCategory.CTD_MAPPING]: ctdMapping,
};

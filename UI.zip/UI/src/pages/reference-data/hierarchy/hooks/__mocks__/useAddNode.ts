const mock = jest.fn().mockReturnValue({ addNode: { add: jest.fn(), undoAdd: jest.fn() } });

export default mock;

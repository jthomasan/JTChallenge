const mock = jest.fn().mockReturnValue({ deleteNode: jest.fn() });

export default mock;

const mock = jest.fn().mockReturnValue({ renameNode: jest.fn() });

export default mock;

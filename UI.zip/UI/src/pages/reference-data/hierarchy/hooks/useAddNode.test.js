import { useApolloClient } from 'umi-plugin-apollo-anz/apolloClient';
import { waitForCacheWrites } from 'umi-plugin-apollo-anz/mutationQueue';
import uuid from 'uuid-random';
import { addChangeMock } from '@/hooks/useUncommittedChanges';
import { ChangeAction } from '@/types/change';
import useAddNode from './useAddNode';

jest.mock('@/hooks/useUncommittedChanges');

describe('useAddNode hook', () => {
  const writeQueryMock = jest.fn();
  const readQueryMock = jest.fn();
  const parentFullPath = 'ANZ Group|ANZ ETFS';
  const newNodeId = uuid();
  const newNodeTitle = 'Test Add Node';
  const newNode = {
    id: newNodeId,
    parent: '2',
    title: newNodeTitle,
    children: [],
    typeId: '1',
    fullPath: `${parentFullPath}|${newNodeTitle}`,
  };

  beforeAll(() => {
    useApolloClient.mockReturnValue({
      readQuery: readQueryMock,
      writeQuery: writeQueryMock,
    });
  });

  beforeEach(() => {
    writeQueryMock.mockReset();
    readQueryMock.mockReset();
    addChangeMock.mockReset();
  });

  it('should add correct fields to addChange on add', () => {
    // Given
    const { addNode } = useAddNode();

    // When
    addNode(parentFullPath, newNode);

    // Then
    expect(addChangeMock).toHaveBeenCalled();

    const arg = addChangeMock.mock.calls[0][0];
    expect(arg.action).toEqual(ChangeAction.ADD);
    expect(arg.sourceType).toEqual(`[Node] ${newNodeTitle}`);
    expect(arg.from).toEqual('');
    expect(arg.to).toEqual(parentFullPath);
  });

  it('should have mutation action function return correct action', () => {
    // Given
    const { addNode } = useAddNode();

    // When
    addNode(parentFullPath, newNode);

    // Then
    const mutationAction = addChangeMock.mock.calls[0][0].getMutationAction();
    expect(mutationAction).toEqual({
      addNode: {
        nodeId: newNode.id,
        parent: { nodeId: newNode.parent },
        title: newNode.title,
        typeId: newNode.typeId,
      },
    });
  });

  it('should update cache add new node and add new node id to be the children of its parent', async () => {
    // Given
    const nodeToBeAdd = {
      __typename: 'Node',
      id: newNode.id,
      title: newNode.title,
      children: [],
      parent: newNode.parent,
      fullPath: newNode.fullPath,
    };
    const originalNodes = [
      { id: '1', children: ['2'] },
      { id: '2', children: ['3'], parent: '1' },
      { id: '3', parent: '2' },
      { id: '4' },
    ];
    const expectedNodesAfterAdd = [
      { id: '1', children: ['2'] },
      { id: '2', children: [newNodeId, '3'], parent: '1' },
      { id: '3', parent: '2' },
      { id: '4' },
      nodeToBeAdd,
    ];
    readQueryMock.mockReturnValue({ Nodes: originalNodes });
    const { addNode } = useAddNode();

    // When
    addNode(parentFullPath, newNode);
    const updateCache = addChangeMock.mock.calls[0][0].updateCache();
    updateCache();

    jest.runAllTimers();
    await waitForCacheWrites();

    // Then
    expect(writeQueryMock).toBeCalledTimes(2);

    // update cache
    const updateCallArgs = writeQueryMock.mock.calls[0][0];
    expect(updateCallArgs.data.Nodes).toEqual(expectedNodesAfterAdd);

    // undo
    const undoCallArgs = writeQueryMock.mock.calls[1][0];
    expect(undoCallArgs.data.Nodes).toEqual(originalNodes);
  });
});

import React, { useEffect, useState, ChangeEvent, RefObject } from 'react';
import { Input, Alert } from 'antd';
import { Popup } from '@progress/kendo-react-popup';
import classNames from 'classnames';

import { visibleY } from '@/utils/utils';
import styles from './index.less';
import { Node, NodeError } from '../Node';

interface NodeTitleProps {
  item: Node;
  searchText: string;
  searchHighlightColor: string;
  domId: string;
  isInput: boolean;
  popupClosable?: boolean;
  error?: NodeError | null;
  clearError: () => void;
  onInputSave: (sourceNodeId: string, nodeTitle: string) => void;
  onCancel: () => void;
  scrollY: number;
}

const NodeTitle: React.FC<NodeTitleProps> = (props) => {
  const {
    item,
    searchText,
    searchHighlightColor,
    domId,
    isInput,
    onInputSave,
    onCancel,
    popupClosable,
    error,
    clearError,
    scrollY,
  } = props;
  const title = item.title.toLowerCase();
  const index = title.indexOf(searchText.toLowerCase());
  const beforeStr = item.title.substring(0, index);
  const highlightStr = item.title.substring(index, index + searchText.length);
  const afterStr = item.title.substring(index + searchText.length);
  const inputRef: RefObject<Input> = React.createRef();
  const titleRef: RefObject<HTMLElement> = React.createRef();

  const [titleInput, setTitleInput] = useState(item.title);
  const [renderedInput, setRenderedInput] = useState<HTMLInputElement | null>(null);
  const [renderedTitle, setRenderedTitle] = useState<HTMLSpanElement | null>(null);
  const [isElmentOnScreen, setIsElementOnScreen] = useState<boolean>(true);

  const popupRef: RefObject<Popup> = React.createRef();

  const onInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    setTitleInput(e.target.value);
    if (error) {
      clearError();
    }
  };

  const focusCurrentInput = () => {
    if (inputRef && inputRef.current) {
      inputRef.current.focus();
      setRenderedInput(inputRef.current.input);
    } else {
      setRenderedInput(null);
    }
  };

  const setRenderedTitleElement = () => {
    if (titleRef && titleRef.current) {
      setRenderedTitle(titleRef.current);
    } else {
      setRenderedTitle(null);
    }
  };

  // Set to focus when user enter edit mode
  useEffect(() => {
    if (isInput) {
      focusCurrentInput();
      setTitleInput(item.title);
    }
    setRenderedTitleElement();
  }, [isInput]);

  useEffect(() => {
    focusCurrentInput();
    setRenderedTitleElement();
  }, [error]);

  useEffect(() => {
    if (popupRef.current) {
      const { anchor } = popupRef.current.props;
      if (anchor) {
        setIsElementOnScreen(visibleY(anchor));
      }
    }
  }, [scrollY]);

  const renderTitle = () => {
    let titleElement = null;
    if (isInput) {
      titleElement = (
        <Input
          ref={inputRef}
          value={titleInput}
          size="small"
          onChange={onInputChange}
          onClick={(e) => {
            e.stopPropagation();
          }}
          onDoubleClick={(e) => {
            e.stopPropagation();
          }}
          onPressEnter={() => onInputSave(item.id, titleInput.trim())}
          onBlur={() => onInputSave(item.id, titleInput.trim())}
          onKeyDown={(e) => e.key === 'Escape' && onCancel()}
          className={classNames({
            [styles.inputError]: error !== null,
          })}
        />
      );
    } else if (index > -1) {
      titleElement = (
        <span id={domId} ref={titleRef}>
          {beforeStr}
          <span style={{ color: searchHighlightColor, fontWeight: 'bold' }}>{highlightStr}</span>
          {afterStr}
        </span>
      );
    } else {
      titleElement = (
        <span id={domId} ref={titleRef} style={{ display: 'inline-block' }}>
          {item.title}
        </span>
      );
    }

    const showError = error !== null;

    return (
      <>
        {titleElement}
        <Popup
          ref={showError ? popupRef : undefined}
          anchor={renderedTitle || renderedInput || undefined}
          anchorAlign={{ horizontal: 'left', vertical: 'top' }}
          popupAlign={{ horizontal: 'left', vertical: 'bottom' }}
          animate={false}
          show={showError && isElmentOnScreen}
        >
          <Alert
            message={error && error.message}
            type="error"
            showIcon
            closable={popupClosable}
            onClose={onCancel}
          />
        </Popup>
      </>
    );
  };

  return renderTitle();
};

export default React.memo(NodeTitle);

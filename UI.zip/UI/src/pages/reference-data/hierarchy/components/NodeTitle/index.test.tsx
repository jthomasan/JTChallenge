import React from 'react';
import { shallow } from 'enzyme';

import NodeTitle from './index';

describe('Test Hierarchy Panel Component', () => {
  it('should NodeTitle render title of node on no search matched', () => {
    const expectedTitle = 'Test Node';
    const wrapper = shallow(
      <NodeTitle
        item={{
          id: '4',
          title: expectedTitle,
          parent: '1',
          children: [],
        }}
        searchText="ABC"
        searchHighlightColor="#FFF"
        domId="refHier-4"
        isInput={false}
        onInputSave={jest.fn()}
        clearError={jest.fn()}
        onCancel={jest.fn()}
      />,
    );
    expect(wrapper.find('span').text()).toEqual(expectedTitle);
  });

  it('should NodeTitle render highlighted text on search text matched', () => {
    const expectedHighlightText = 'MP';
    const wrapper = shallow(
      <NodeTitle
        item={{
          id: '4',
          title: 'MP - Test Node',
          parent: '1',
          children: [],
        }}
        searchText={expectedHighlightText}
        searchHighlightColor="#FFF"
        domId="refHier-4"
        isInput={false}
        onInputSave={jest.fn()}
        clearError={jest.fn()}
        onCancel={jest.fn()}
      />,
    );
    expect(
      wrapper
        .find('span')
        .first()
        .children()
        .find('span')
        .text(),
    ).toEqual(expectedHighlightText);
  });

  describe('Test Node Title when it is input', () => {
    let wrapper: any = null;
    const mockInputSaveFn = jest.fn();
    const mockCancel = jest.fn();
    const nodeTitle = 'MP - Test Node';
    beforeEach(() => {
      wrapper = shallow(
        <NodeTitle
          item={{
            id: '4',
            title: nodeTitle,
            parent: '1',
            children: [],
          }}
          searchText="ABC"
          searchHighlightColor="#FFF"
          domId="refHier-4"
          isInput
          onInputSave={mockInputSaveFn}
          clearError={jest.fn()}
          onCancel={mockCancel}
        />,
      );
    });

    it('should render input on rename', () => {
      expect(wrapper.find('Input')).toHaveLength(1);
    });

    it('should input be saved on press enter', () => {
      wrapper.find('Input').prop('onPressEnter')();
      expect(mockInputSaveFn).toHaveBeenCalledWith('4', nodeTitle);
    });

    it('should input be saved on input lose focue', () => {
      wrapper.find('Input').simulate('blur');
      expect(mockInputSaveFn).toHaveBeenCalledWith('4', nodeTitle);
    });

    it('should input be cancelled on escape key pressed', () => {
      wrapper.find('Input').simulate('keydown', { key: 'Escape' });
      expect(mockCancel).toHaveBeenCalled();
    });
  });
});

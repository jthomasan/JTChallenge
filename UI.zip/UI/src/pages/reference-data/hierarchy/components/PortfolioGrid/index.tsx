import React, { useEffect, useState, MouseEvent } from 'react';
import { GridRowProps } from '@progress/kendo-react-grid';
import { Offset } from '@progress/kendo-react-popup';
import { isEqual } from 'lodash';

import { ExternalisedStateProps } from '@/types/externalised-state';
import Card from '@/components/Card';
import SearchField from '@/components/SearchField';
import ExportButton from '@/components/ExportButton';
import { CTXMenuSelectEvent } from '@/components/ContextMenu';
import Grid from '@/components/Grid';
import { DATE_FORMATS } from '@/utils/date';
import ClassificationModal, { Classification, ClassificationOptions } from '../ClassificationModal';
import { HierarchyRefEnum } from '../HierarchyPanel';
import styles from './index.less';

enum ContextMenuAction {
  APPLY_CLASSIFICATION = '0',
}

export const ContextMenuActionText = {
  [ContextMenuAction.APPLY_CLASSIFICATION]: 'Apply Classification',
};

interface PortfolioGridExternalState {
  portfolioSearchText: string;
  selectedPortfolioId: number;
  classification: Classification;
  isModalShown: boolean;
  isPortfolioContextMenuShown: boolean;
  contextMenuOffset: Offset;
}

interface PortfolioGridProps<K> extends ExternalisedStateProps<K> {
  nodeTypeId: string;
  cob: string;
  populatedNodeId: string;
  populatedNodeTitle?: string;
  portfolios: any[];
  classificationOptions: ClassificationOptions;
  loading: boolean;
  isClassificationEnabled: boolean;
  hierarchyType?: HierarchyRefEnum;
  onPortfolioSearch: (value: string) => void;
  onUpdateClassification: (oldParam: Classification, newParam: Classification) => void;
}

const formatIsActiveCell = {
  cellName: 'formatIsActiveCell',
};

const defaultState = {
  portfolioSearchText: '',
};

const PortfolioGrid: React.FC<PortfolioGridProps<PortfolioGridExternalState>> = (props) => {
  const {
    portfolios,
    classificationOptions,
    loading,
    setExternalState,
    externalState,
    onPortfolioSearch,
    onUpdateClassification,
    populatedNodeId,
    populatedNodeTitle,
    cob,
    nodeTypeId,
    hierarchyType,
  } = props;
  const state = { ...defaultState, ...externalState };
  const { portfolioSearchText, selectedPortfolioId, classification, isModalShown } = state;
  const [ignorePopulatedNodeId, setIgnorePopulatedNodeId] = useState(true);

  const randomClassName = `pg-${Math.random()
    .toString(36)
    .substring(2, 15)}`;

  const onSearchTextChange = (value: string) => {
    setExternalState({ portfolioSearchText: value });
  };

  const onContextMenuOpen = (event: MouseEvent, rowId: number) => {
    setExternalState({
      selectedPortfolioId: rowId,
      isPortfolioContextMenuShown: true,
      contextMenuOffset: {
        top: event.clientY,
        left: event.clientX,
      },
    });
  };

  const onHandleModal = (isOpen: boolean) => {
    setExternalState({
      isModalShown: isOpen,
    });
  };

  const fetchClassificationFromPortfolio = () => {
    const selectedPortfolio = portfolios.find((item) => item.id === selectedPortfolioId);

    setExternalState({
      classification: {
        id: populatedNodeId,
        portfolioId: selectedPortfolioId,
        portfolioTitle: selectedPortfolio.title,
        ...selectedPortfolio.classification,
      },
    });
  };

  const onContextMenuSelect = ({ itemId }: CTXMenuSelectEvent) => {
    switch (itemId) {
      case ContextMenuAction.APPLY_CLASSIFICATION:
        fetchClassificationFromPortfolio();
        onHandleModal(true);
        break;

      default:
        break;
    }
  };

  const onApplyClassification = (newClassification: Classification) => {
    onUpdateClassification(classification, newClassification);
    onHandleModal(false);
  };

  const onCancelClassification = () => {
    onHandleModal(false);
  };

  useEffect(() => {
    if (populatedNodeId !== '' && populatedNodeId !== '-1' && !ignorePopulatedNodeId) {
      setExternalState({ portfolioSearchText: '' });
    }
    if (ignorePopulatedNodeId) {
      setIgnorePopulatedNodeId(false);
    }
  }, [populatedNodeId]);

  const rowRender = (
    trElement: React.ReactElement<HTMLTableRowElement>,
    gridRowProps: GridRowProps,
  ) => {
    const trProps = {
      ...trElement.props,
      onContextMenu: (event: MouseEvent) => {
        const { dataItem } = gridRowProps;
        event.preventDefault();
        onContextMenuOpen(event, dataItem.id);
      },
    };
    return React.cloneElement(trElement, { ...trProps }, trElement.props.children);
  };

  let entityType;

  switch (hierarchyType) {
    case HierarchyRefEnum.REVENUE:
      entityType = 'Revenue Code';
      break;
    case HierarchyRefEnum.LEGAL_ENTITY:
      entityType = 'Legal Entity Code';
      break;
    default:
      entityType = 'Portfolio';
  }

  return (
    <Card
      title={`${entityType} ${populatedNodeTitle || ''}`}
      actions={
        <>
          <SearchField
            key="portfolioSearch"
            placeholder={`${entityType} Search`}
            value={portfolioSearchText}
            onChange={onSearchTextChange}
            onSearch={onPortfolioSearch}
            disabled={nodeTypeId === undefined || nodeTypeId === '-1'}
          />
          <ExportButton
            key="portfolioExport"
            className={styles.exportButton}
            url={`/export/reference-data/hierarchy/portfolios/csv?nodeId=${populatedNodeId}&typeId=${nodeTypeId}&titleSearch=${portfolioSearchText}&cob=${cob}`}
            disabled={!portfolios?.length}
          />
        </>
      }
    >
      <div className={styles.gridContainer}>
        <Grid
          loading={loading}
          currentStateWatcher={populatedNodeId}
          style={{
            height: '100%',
            lineHeight: '18px',
          }}
          className={`${randomClassName} ${styles.portfolioGrid}`}
          customRowRender={rowRender}
          onContextMenuSelect={onContextMenuSelect}
          data={portfolios}
          columns={[
            {
              field: 'title',
              width: '180px',
              locked: true,
              title: 'Name',
              filter: 'text',
              defaultSortColumn: true,
            },
            {
              field: 'isActive',
              width: '70px',
              title: 'Active',
              filter: 'boolean',
              cell: formatIsActiveCell,
              sortDisabled: true,
            },
            { field: 'parent.fullPath', width: '300px', title: 'Full Path', filter: 'text' },
            {
              field: 'createdOn',
              width: '140px',
              title: 'Added Time',
              filter: 'date',
              format: DATE_FORMATS.DATE_TIME,
            },
            {
              field: 'source',
              width: '100px',
              title: 'Source',
              filter: 'text',
              format: '{0:D}',
            },
          ]}
          externalState={state as any}
          setExternalState={setExternalState}
          useStandardCellsUnlessEditing
        />
      </div>

      {isModalShown && (
        <ClassificationModal
          isModalShown={isModalShown}
          nodeId={populatedNodeId}
          portfolioId={selectedPortfolioId}
          classificationOptions={classificationOptions}
          classification={classification}
          onApplyClassification={onApplyClassification}
          onCancelClassification={onCancelClassification}
        />
      )}
    </Card>
  );
};

const compare = (prevProps: any, nextProps: any) => isEqual(prevProps, nextProps);

export default React.memo(PortfolioGrid, compare);

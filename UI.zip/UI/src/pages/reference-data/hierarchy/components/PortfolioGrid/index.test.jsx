import React, { _mockUseEffect, _mockUseState } from 'react';
import { shallow } from 'enzyme';

import PortfolioGrid from './index';

describe('Test Portfolio Grid Component', () => {
  let wrapper = null;
  const mockUpdateGridState = jest.fn();
  const mockOnPortfolioSearch = jest.fn();
  const mockExternalState = {
    portfolioSearchText: '',
    scrollLeft: 0,
    scrollTop: 0,
  };

  beforeEach(() => {
    wrapper = shallow(
      <PortfolioGrid
        portfolios={[]}
        loading
        populatedNodeId="-1"
        isClassificationEnabled
        setExternalState={mockUpdateGridState}
        externalState={mockExternalState}
        onPortfolioSearch={mockOnPortfolioSearch}
      />,
      { lifecycleExperimental: true },
    );
  });

  it('should portfolio grid update component state after search text change', () => {
    wrapper
      .find('Card')
      .props()
      .actions.props.children[0].props.onChange('AU');
    expect(mockUpdateGridState).toHaveBeenCalledWith({ portfolioSearchText: 'AU' });
  });

  it('should portfolio grid reset search text after node selection', () => {
    _mockUseState(jest.fn().mockReturnValue([false, jest.fn()]));
    _mockUseEffect(jest.fn((fn) => fn()));

    wrapper.setProps({
      populatedNodeId: '5',
    });

    expect(mockUpdateGridState).toHaveBeenCalledWith({ portfolioSearchText: '' });
  });

  it.skip('should return empty context menu when classification not enabled', () => {
    wrapper.setProps({
      isClassificationEnabled: false,
    });

    const items = wrapper.find('ContextMenu').prop('items');

    expect(items).toEqual([]);
  });

  it('should display the correct title and search placeholder', () => {
    let title;
    let placeholder;
    let Card = wrapper.find('Card');
    ({ title } = Card.props());
    ({ placeholder } = Card.props().actions.props.children[0].props);

    expect(title).toEqual('Portfolio ');
    expect(placeholder).toEqual('Portfolio Search');

    // Revenue Hierarchy
    wrapper.setProps({
      hierarchyType: 'REVENUE',
    });

    Card = wrapper.find('Card');
    ({ title } = Card.props());
    ({ placeholder } = Card.props().actions.props.children[0].props);

    expect(title).toEqual('Revenue Code ');
    expect(placeholder).toEqual('Revenue Code Search');

    // Legal Entity Hierarchy
    wrapper.setProps({
      hierarchyType: 'LEGAL_ENTITY',
    });

    Card = wrapper.find('Card');
    ({ title } = Card.props());
    ({ placeholder } = Card.props().actions.props.children[0].props);

    expect(title).toEqual('Legal Entity Code ');
    expect(placeholder).toEqual('Legal Entity Code Search');
  });
});

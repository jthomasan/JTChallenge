import React from 'react';
import { shallow } from 'enzyme';
import { getNodes } from './testdata/nodes';
import NodeHierarchyTree from './index';

describe('NodeHierarchyTree Component', () => {
  let wrapper = null;
  const event = { preventDefault: jest.fn() };
  const mockNodeDict = getNodes();
  const mockOnExpand = jest.fn();
  const mockOnSelect = jest.fn();
  const mockOnDoubleClick = jest.fn();
  const mockOnRightClick = jest.fn();
  const mockOnNodeMoveStart = jest.fn();
  const mockOnNodeDragClearError = jest.fn();
  const mockOnNodeMoveDone = jest.fn();
  const mockOnScroll = jest.fn();

  beforeAll(() => {
    wrapper = shallow(
      <NodeHierarchyTree
        nodes={mockNodeDict}
        nodesTitleRenderer={{}}
        expandedKeys={['1']}
        isNodeReachedMaxDepth={false}
        onExpand={mockOnExpand}
        onSelect={mockOnSelect}
        onDoubleClick={mockOnDoubleClick}
        onRightClick={mockOnRightClick}
        onNodeMoveStart={mockOnNodeMoveStart}
        onNodeDragClearError={mockOnNodeDragClearError}
        onNodeMoveDone={mockOnNodeMoveDone}
        selectedKey="1"
        onScroll={mockOnScroll}
        scrollPosition={{
          scrollLeft: 0,
          scrollTop: 0,
        }}
      />,
      { lifecycleExperimental: true },
    );

    jest.runAllTimers();
    jest.spyOn(event, 'preventDefault');
  });

  beforeEach(() => {
    mockOnExpand.mockReset();
    mockOnSelect.mockReset();
    mockOnDoubleClick.mockReset();
    mockOnRightClick.mockReset();
    mockOnNodeMoveStart.mockReset();
    mockOnNodeMoveDone.mockReset();
    mockOnScroll.mockReset();
  });

  it('should node be moved to right position under right node', () => {
    // Given
    const nodeBeMoved = '5';
    const nodeDropTo = '3';
    const nodeHierarchyTree = wrapper.find('DirectoryTree');

    // When
    nodeHierarchyTree.prop('onDrop')({
      node: { props: { eventKey: nodeDropTo } },
      dropToGap: true,
      dragNode: { props: { eventKey: nodeBeMoved } },
      dropPosition: 2,
    });

    // Then
    expect(mockOnNodeMoveDone).toBeCalledWith(mockNodeDict[nodeBeMoved], mockNodeDict['1'], 2);
  });

  it('should node be moved under the drop node', () => {
    // Given
    const nodeBeMoved = '5';
    const nodeDropTo = '3';
    const nodeHierarchyTree = wrapper.find('DirectoryTree');

    // When
    nodeHierarchyTree.prop('onDrop')({
      node: { props: { eventKey: nodeDropTo } },
      dropToGap: false,
      dragNode: { props: { eventKey: nodeBeMoved } },
      dropPosition: 1,
    });

    // Then
    expect(mockOnNodeMoveDone).toBeCalledWith(mockNodeDict[nodeBeMoved], mockNodeDict['3'], 0);
  });

  it('should deny node being moved when reached max level', () => {
    wrapper.setProps(
      {
        isNodeReachedMaxDepth: true,
      },
      () => {
        const nodeHierarchyTree = wrapper.find('DirectoryTree');

        nodeHierarchyTree.prop('onDrop')({
          event,
        });

        expect(event.preventDefault).toBeCalled();
        expect(mockOnNodeDragClearError).toHaveBeenCalledTimes(1);
      },
    );
  });

  it('should call clear error message when drag ends', () => {
    const nodeHierarchyTree = wrapper.find('DirectoryTree');

    nodeHierarchyTree.prop('onDragEnd')({
      event,
    });

    jest.runAllTimers();
    expect(event.preventDefault).toBeCalled();
    expect(mockOnNodeDragClearError).toBeCalled();
  });
});

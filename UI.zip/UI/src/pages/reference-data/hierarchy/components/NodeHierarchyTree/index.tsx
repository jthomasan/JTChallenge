import React, { Component, RefObject } from 'react';
import Tree from '@/components/Tree';
import {
  AntTreeNode,
  AntTreeNodeExpandedEvent,
  AntTreeNodeSelectedEvent,
  AntTreeNodeMouseEvent,
} from 'antd/es/tree';
import { AntTreeNodeDropEvent, AntTreeNodeDragEnterEvent } from 'antd/lib/tree/Tree';
import { Node } from '../Node';
import styles from './index.less';

const { TreeNode, DirectoryTree } = Tree;

export type NodeDict = { [id: string]: Node };

export interface ScrollPosition {
  scrollLeft: number;
  scrollTop: number;
}

interface HierachyNodeState {
  containerRef: RefObject<HTMLDivElement>;
  readyToDehydrateScrolling: boolean;
}
interface HierachyNodeProps {
  nodes: NodeDict;
  isNodeReachedMaxDepth: boolean;
  nodesTitleRenderer: { [nodeId: string]: React.ReactNode };
  expandedKeys: Array<string>;
  onExpand: (expandedKeys: string[], info: AntTreeNodeExpandedEvent) => void | PromiseLike<void>;
  onSelect: (selectedKeys: string[], e: AntTreeNodeSelectedEvent) => void;
  onDoubleClick: (e: React.MouseEvent<HTMLElement>, node: AntTreeNode) => void;
  onRightClick: (options: AntTreeNodeMouseEvent) => void;
  onNodeMoveStart: (options: AntTreeNodeMouseEvent) => void;
  onNodeDragEnter?: (options: AntTreeNodeDragEnterEvent) => void;
  onNodeDragLeave?: (options: AntTreeNodeMouseEvent) => void;
  onNodeDragClearError: () => void;
  onNodeMoveDone: (
    nodeBeMoved: Node | undefined,
    parentMoveTo: Node | undefined,
    indexMoveTo: number,
  ) => void;
  selectedKey: string;
  className: string;
  onScroll?: (scrollPosition: ScrollPosition) => void;
  scrollPosition: ScrollPosition;
  draggable: boolean;
}

class HierachyNode extends Component<HierachyNodeProps, HierachyNodeState> {
  constructor(props: HierachyNodeProps) {
    super(props);
    this.state = {
      containerRef: React.createRef(),
      readyToDehydrateScrolling: false,
    };
  }

  componentDidMount() {
    this.setState({ readyToDehydrateScrolling: true });
  }

  componentDidUpdate() {
    this.dehydrateScrolling();
  }

  dehydrateScrolling = () => {
    const {
      scrollPosition: { scrollLeft, scrollTop },
    } = this.props;
    const { containerRef, readyToDehydrateScrolling } = this.state;

    if (
      containerRef.current &&
      readyToDehydrateScrolling &&
      (typeof scrollLeft !== 'undefined' || typeof scrollTop !== 'undefined')
    ) {
      containerRef.current.scrollTo(scrollLeft || 0, scrollTop || 0);
      this.setState({ readyToDehydrateScrolling: false });
    }
  };

  onScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { onScroll } = this.props;
    const { scrollTop, scrollLeft } = e.target as HTMLElement;

    if (onScroll) onScroll({ scrollTop, scrollLeft });
  };

  onDrop = (options: AntTreeNodeDropEvent) => {
    const { nodes, onNodeMoveDone, isNodeReachedMaxDepth, onNodeDragClearError } = this.props;

    if (isNodeReachedMaxDepth) {
      options.event.preventDefault();
      onNodeDragClearError();
    } else {
      // Drag Position
      const nodeBeMoved = options.dragNode.props.eventKey
        ? nodes[options.dragNode.props.eventKey]
        : undefined;

      // Drop Position
      let indexMoveTo = 0;
      const dropTargetId = options.node.props.eventKey;
      let parentMoveTo;
      if (dropTargetId) {
        parentMoveTo = options.dropToGap ? nodes[nodes[dropTargetId].parent] : nodes[dropTargetId];
        const dropTargetIndex =
          options.dropToGap && parentMoveTo.children
            ? parentMoveTo.children.findIndex((nodeId) => nodeId === dropTargetId)
            : 0;
        const dropTargetRelativeIndex = options.dropToGap
          ? options.dropPosition - dropTargetIndex
          : 0;
        if (options.dropToGap) {
          indexMoveTo = dropTargetRelativeIndex === 1 ? dropTargetIndex + 1 : dropTargetIndex;
        }
      }
      onNodeMoveDone(nodeBeMoved, parentMoveTo, indexMoveTo);
    }
  };

  render() {
    const {
      nodes,
      className,
      selectedKey,
      onSelect,
      onDoubleClick,
      onExpand,
      onRightClick,
      onNodeMoveStart,
      onNodeDragEnter,
      onNodeDragClearError,
      onNodeDragLeave,
      expandedKeys,
      nodesTitleRenderer,
      draggable,
    } = this.props;
    const { containerRef } = this.state;

    const renderChildren = (children?: string[]) => {
      if (!children || !children.length) return null;

      return children.reduce((acc: React.ReactElement[], childId: string) => {
        const child: Node = nodes[childId];
        if (child) {
          // eslint-disable-next-line no-use-before-define, @typescript-eslint/no-use-before-define
          acc.push(renderNode(child));
        }
        return acc;
      }, []);
    };

    const renderNode = (node: Node) => {
      const { id, children } = node;
      const childNodes = renderChildren(children);
      return (
        <TreeNode
          key={id}
          title={nodesTitleRenderer[id]}
          isLeaf={!(node.children && node.children.length > 0)}
        >
          {childNodes}
        </TreeNode>
      );
    };

    const rootIndex = Object.keys(nodes).find((key) => nodes[key].parent === '');
    const rootNode = rootIndex ? nodes[rootIndex] : null;
    const tree = rootNode && renderNode(rootNode);

    return (
      <div
        ref={containerRef}
        className={`${styles.treeContainer} ${className}`}
        onScroll={this.onScroll}
      >
        {tree ? (
          <DirectoryTree
            draggable={draggable}
            selectable
            selectedKeys={selectedKey === '' ? [] : [selectedKey]}
            expandAction={false}
            onSelect={onSelect}
            onDoubleClick={onDoubleClick}
            onRightClick={onRightClick}
            onExpand={onExpand}
            onDragStart={onNodeMoveStart}
            onDragEnter={onNodeDragEnter}
            onDragLeave={onNodeDragLeave}
            onDragEnd={(options) => {
              // Temp forced to trigger this function after onNodeDragEnter
              setTimeout(() => {
                options.event.preventDefault();
                onNodeDragClearError();
              }, 500);
            }}
            onDrop={this.onDrop}
            expandedKeys={expandedKeys}
          >
            {tree}
          </DirectoryTree>
        ) : (
          <div className={styles.emptyTreeContainer}>No records available</div>
        )}
      </div>
    );
  }
}

export default HierachyNode;

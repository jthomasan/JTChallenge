import React, { useState } from 'react';
import { Select as AntSelect } from 'antd';
import Select from '@/components/Select';

const { Option } = AntSelect;

interface DataItem {
  id: string;
  text: string;
}

interface ClassificationDropdownProps {
  dataItem: DataItem[];
  allowClear?: boolean;
  value: string;
  onChange: (value: string) => void;
}

const ClassificationDropdown: React.FC<ClassificationDropdownProps> = (props) => {
  const { dataItem, allowClear, value, onChange } = props;
  const [ddlOptions, setDdlOptions] = useState(dataItem);

  const onSearch = (val: string) => {
    setDdlOptions(
      dataItem.filter((item: DataItem) => item.text.toLowerCase().includes(val.toLowerCase())),
    );
  };

  const resetOptions = () => {
    setDdlOptions(dataItem);
  };

  return (
    <Select
      showSearch
      filterOption={false}
      allowClear={allowClear}
      value={value}
      onChange={onChange}
      onSearch={onSearch}
      onFocus={resetOptions}
      onBlur={resetOptions}
      onSelect={resetOptions}
    >
      {ddlOptions.map((item) => (
        <Option key={item.id}>{item.text}</Option>
      ))}
    </Select>
  );
};

export default ClassificationDropdown;

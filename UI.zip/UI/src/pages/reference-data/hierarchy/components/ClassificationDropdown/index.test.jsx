import React, { _mockUseState } from 'react';
import { shallow } from 'enzyme';

import Select from '@/components/Select';
import ClassificationDropdown from './index';

describe('Test Classification Dropdown Component', () => {
  let wrapper;
  const dataItem = [
    {
      id: '1',
      text: 'Credit',
    },
    {
      id: '2',
      text: 'Debit',
    },
  ];
  let selectedValue = 'Credit';
  const mockOnChange = jest.fn((value) => {
    selectedValue = value;
  });

  const mockSetDdlOptions = jest.fn();
  _mockUseState(jest.fn().mockReturnValue([dataItem, mockSetDdlOptions]));

  beforeEach(() => {
    wrapper = shallow(
      <ClassificationDropdown
        dataItem={dataItem}
        allowClear={false}
        value={selectedValue}
        onChange={mockOnChange}
      ></ClassificationDropdown>,
      { lifecycleExperimental: true },
    );
  });

  it('should classification dropdown default values when mounted successfully', () => {
    const select = wrapper.find(Select);
    expect(select).toHaveLength(1);
    expect(select.find('Option')).toHaveLength(2);
    expect(select.prop('value')).toBe(selectedValue);
  });

  it('should classification dropdown change existing value when trigger onchange', () => {
    const select = wrapper.find(Select);
    select.simulate('change', 'Debit');
    expect(mockOnChange).toHaveBeenCalledWith('Debit');
  });

  it('should classification dropdown reflect new value after change', () => {
    const select = wrapper.find(Select);
    expect(select.prop('value')).toBe(selectedValue);
  });

  it('should search text fileter the options', () => {
    // Given
    const select = wrapper.find(Select);
    const searchText = 'cr';

    // When
    select.prop('onSearch')(searchText);

    // Then
    expect(mockSetDdlOptions).toHaveBeenCalledWith([dataItem[0]]);
  });

  it('should focus, blur and select reset ddlOptions to be initial options', () => {
    // Given
    const select = wrapper.find(Select);
    // When
    select.simulate('focus');
    select.simulate('blur');
    select.prop('onSelect')();
    // Then
    expect(mockSetDdlOptions).toHaveBeenCalledWith(dataItem);
    expect(mockSetDdlOptions).toHaveBeenCalledWith(dataItem);
    expect(mockSetDdlOptions).toHaveBeenCalledWith(dataItem);
  });
});

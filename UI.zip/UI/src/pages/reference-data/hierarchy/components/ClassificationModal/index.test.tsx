// @ts-ignore
import React, { _mockUseState } from 'react';
import { shallow, ShallowWrapper } from 'enzyme';

import ClassificationModal, { Classification } from './index';
import { classificationOptions } from './testdata/classificationOptions';

describe('Test Classification Modal Component', () => {
  let wrapper: ShallowWrapper;
  let modal: any = null;
  let classificationDropdowns: any = null;
  const portfolioId = 2;
  const classification: Partial<Classification> = {
    assetType: 'CREDIT',
    capitalMultiplier: 'MYANMAR',
    hyperionUnit: 'Excluded',
  };
  const classificationWithOtherProps: Classification = {
    id: '1',
    nodeTitle: 'Test',
    portfolioId,
    portfolioTitle: 'Test',
    assetType: 'CREDIT',
    capitalMultiplier: 'MYANMAR',
    hyperionUnit: 'Excluded',
  };
  const newClassification = {
    ...classificationWithOtherProps,
  };

  const mockOnApplyClassification = jest.fn();
  const mockOnCancelClassification = jest.fn();

  const setNewClassification = jest.fn();

  beforeEach(() => {
    _mockUseState(jest.fn().mockReturnValue([newClassification, setNewClassification]));

    wrapper = shallow(
      <ClassificationModal
        classificationOptions={classificationOptions}
        nodeId="1"
        portfolioId={portfolioId}
        classification={classificationWithOtherProps}
        isModalShown
        onApplyClassification={mockOnApplyClassification}
        onCancelClassification={mockOnCancelClassification}
      ></ClassificationModal>,
      { lifecycleExperimental: true },
    );

    modal = wrapper.find('Modal').first();
    classificationDropdowns = modal.children().find('ClassificationDropdown');
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should classification modal be shown after mounted successfully', () => {
    expect(modal).toHaveLength(1);
  });

  it('should classification modal apply button be disabled when field are not modified', () => {
    const Footer = () => modal.prop('footer');
    const footer = shallow(<Footer />);
    expect(
      footer
        .find('Button')
        .last()
        .prop('disabled'),
    ).toBe(true);
  });

  it('should classification modal set existing values to dropdown after mounted successfully', () => {
    expect(classificationDropdowns).toHaveLength(4);
    Object.values(classification).forEach((value, index) => {
      expect(classificationDropdowns.at(index).prop('value')).toBe(value);
    });
  });

  it('should classification modal change the existing values and enable apply button', () => {
    classificationDropdowns.forEach((item: any) => {
      item.props().onChange('COMMODITY');
    });

    expect(setNewClassification).toHaveBeenCalledTimes(4);
  });

  it('should classification modal pass the new classification when click apply button', () => {
    const Footer = () => modal.prop('footer');
    const footer = shallow(<Footer />);
    // @ts-ignore
    footer
      .find('Button')
      .last()
      .prop('onClick')();

    expect(mockOnApplyClassification).toHaveBeenCalledWith(newClassification);
  });

  it('should classification modal call cancel classification when click cancel button', () => {
    const Footer = () => modal.prop('footer');
    const footer = shallow(<Footer />);

    // @ts-ignore
    footer
      .find('Button')
      .first()
      .prop('onClick')();

    expect(mockOnCancelClassification).toHaveBeenCalledTimes(1);
  });
});

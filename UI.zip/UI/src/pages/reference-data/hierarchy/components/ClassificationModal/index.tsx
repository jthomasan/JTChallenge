import React, { useState } from 'react';
import { Button, Form, Input } from 'antd';
import { isEqual } from 'lodash';
import classnames from 'classnames';
import Modal from '@/components/Modal';
import ClassificationDropdown from '../ClassificationDropdown';

import styles from './index.less';

export interface Classification {
  typeId?: string;
  id: string;
  nodeTitle: string;
  portfolioId: number;
  portfolioTitle: string;
  assetType: string;
  capitalMultiplier: string;
  hyperionUnit: string;
  syntheticPortfolio?: string;
  comment?: string;
}

export interface ClassificationOption {
  id: string;
  text: string;
}

export interface ClassificationOptions {
  assetType: ClassificationOption[];
  capitalMultiplier: ClassificationOption[];
  hyperionUnit: ClassificationOption[];
  syntheticPortfolio: ClassificationOption[];
}

export enum ClassificationType {
  AssetType = 'assetType',
  CapitalMultiplier = 'capitalMultiplier',
  HyperionUnit = 'hyperionUnit',
  syntheticPortfolio = 'syntheticPortfolio',
  Comment = 'comment',
}

interface ClassificationModalExternalState {}

interface ClassificationModalProps<K> {
  isModalShown: boolean;
  isCalledFromNodes?: boolean;
  nodeId: string;
  portfolioId?: number;
  classification?: Classification;
  classificationOptions: ClassificationOptions;
  onApplyClassification: (classification: Classification) => void;
  onCancelClassification: () => void;
}

const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
};

const ClassificationModal: React.FC<ClassificationModalProps<ClassificationModalExternalState>> = (
  props,
) => {
  const {
    isModalShown,
    isCalledFromNodes,
    nodeId,
    classification: existingClassification = {} as Classification,
    classificationOptions,
    onApplyClassification,
    onCancelClassification,
  } = props;

  const [newClassification, setNewClassification] = useState(existingClassification);

  const arePropsValid =
    !isEqual(existingClassification, newClassification) &&
    !!newClassification.assetType &&
    !!newClassification.capitalMultiplier;

  const onUpdateClassification = (value: string, type: ClassificationType) => {
    setNewClassification({
      ...newClassification,
      [type]: value,
    });
  };

  const onSave = () => {
    const classification = {
      ...newClassification,
    };
    if (isCalledFromNodes) {
      classification.id = nodeId;
    }
    onApplyClassification(classification);
  };

  return (
    <Modal
      title="Apply Classification"
      visible={isModalShown}
      onOk={onSave}
      onCancel={onCancelClassification}
      footer={[
        <Button id="cancelBtn" key="cancel" onClick={onCancelClassification}>
          Cancel
        </Button>,
        <Button id="applyBtn" key="Apply" type="primary" disabled={!arePropsValid} onClick={onSave}>
          Apply
        </Button>,
      ]}
    >
      <Form {...layout} name="basic">
        <Form.Item label="Asset Type" className={classnames(styles.formItemAlign, styles.required)}>
          <ClassificationDropdown
            dataItem={classificationOptions.assetType}
            value={newClassification[ClassificationType.AssetType]}
            onChange={(value) => onUpdateClassification(value, ClassificationType.AssetType)}
          />
        </Form.Item>
        <Form.Item
          label="Capital Multiplier"
          className={classnames(styles.formItemAlign, styles.required)}
        >
          <ClassificationDropdown
            dataItem={classificationOptions.capitalMultiplier}
            value={newClassification[ClassificationType.CapitalMultiplier]}
            onChange={(value) =>
              onUpdateClassification(value, ClassificationType.CapitalMultiplier)
            }
          />
        </Form.Item>
        {!isCalledFromNodes && (
          <Form.Item
            label="Hyperion Unit"
            className={classnames(styles.formItemAlign, styles.required)}
          >
            <ClassificationDropdown
              dataItem={classificationOptions.hyperionUnit}
              value={newClassification[ClassificationType.HyperionUnit]}
              onChange={(value) => onUpdateClassification(value, ClassificationType.HyperionUnit)}
            />
          </Form.Item>
        )}
        <Form.Item label="Synthetic Portfolio" className={styles.formItemAlign}>
          <ClassificationDropdown
            dataItem={classificationOptions.syntheticPortfolio}
            allowClear
            value={newClassification[ClassificationType.syntheticPortfolio] || ''}
            onChange={(value) =>
              onUpdateClassification(value, ClassificationType.syntheticPortfolio)
            }
          />
        </Form.Item>
        <Form.Item label="Comment" className={styles.formItemAlign}>
          <Input
            type="text"
            value={newClassification[ClassificationType.Comment] || ''}
            onChange={({ target }) =>
              onUpdateClassification(target.value, ClassificationType.Comment)
            }
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default ClassificationModal;

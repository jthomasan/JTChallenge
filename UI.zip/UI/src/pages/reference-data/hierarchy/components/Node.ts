export interface NodeError {
  nodeId: string;
  message: string;
  ignorable?: boolean;
  popupClosable?: boolean;
}

export interface Node {
  id: string;
  title: string;
  parent: string;
  children?: Array<string>;
  fullPath: string;
}

import React, { useState } from 'react';
import { Popconfirm, DatePicker } from 'antd';
import moment, { Moment } from 'moment';
import { DatePickerProps } from 'antd/lib/date-picker/interface';

import styles from './index.less';

export interface CoBDatePickerProps extends DatePickerProps {
  cob: string;
  popupConfirmMessage: string;
  shouldConfirmOnDateChange: boolean;
  handleDateChange: (date: string) => void;
}

const CoBDatePicker: React.FC<CoBDatePickerProps> = ({
  cob,
  popupConfirmMessage,
  shouldConfirmOnDateChange,
  handleDateChange,
  ...datePickerProps
}) => {
  const [popconfirmVisible, setPopconfirmVisible] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [isPickerOpen, setIsPickerOpen] = useState(false);

  const dateFormat = 'YYYYMMDD';
  const dateValue = cob ? moment(cob, dateFormat) : null;

  const isDateDisabled = (current: Moment | null) => {
    if (current) {
      return current >= moment().startOf('day');
    }
    return true;
  };

  const onDateChange = (date: Moment | null) => {
    const dateString = date ? date.format(dateFormat) : '';
    if (shouldConfirmOnDateChange) {
      setPopconfirmVisible(true);
      setSelectedDate(dateString);
    } else {
      handleDateChange(dateString);
    }
  };

  const resetState = () => {
    setPopconfirmVisible(false);
    setSelectedDate('');
  };

  const onPopupConfirm = () => {
    handleDateChange(selectedDate);
    resetState();
  };

  const onLastestDateSelected = () => {
    handleDateChange('');
    setIsPickerOpen(false);
  };

  const calendarFooter = () =>
    cob !== '' && (
      <span className={styles.datePickerFooter} onClick={onLastestDateSelected}>
        Select Latest COB
      </span>
    );

  return (
    <Popconfirm
      title={popupConfirmMessage}
      visible={popconfirmVisible}
      onConfirm={onPopupConfirm}
      onCancel={resetState}
      okText="Yes"
      cancelText="No"
    >
      <div className={styles.cobDatePicker}>
        <DatePicker
          style={{
            width: '115px',
          }}
          open={isPickerOpen}
          onOpenChange={(open) => setIsPickerOpen(open)}
          allowClear={false}
          showToday={false}
          onChange={onDateChange}
          disabledDate={isDateDisabled}
          renderExtraFooter={calendarFooter}
          value={dateValue}
          {...datePickerProps}
        />
      </div>
    </Popconfirm>
  );
};

export default CoBDatePicker;

import React, { _mockUseState } from 'react';
import { shallow } from 'enzyme';
import moment from 'moment';
import { Popconfirm, DatePicker } from 'antd';
import DatePickerWithConfirmation from './index';

describe('DatePickerWithConfirmation', () => {
  let wrapper = '';
  const mockOnCobChange = jest.fn();
  const setState = jest.fn();
  _mockUseState(jest.fn().mockReturnValue(['', setState]));

  beforeAll(() => {
    wrapper = shallow(
      <DatePickerWithConfirmation
        placeholder="Latest cob"
        popupConfirmMessage="Refresh and discard all uncommitted changes ?"
        format="DD/MM/YYYY"
        value={moment('20191212', 'YYYYMMDD')}
        disabled={false}
        shouldConfirmOnDateChange
        handleDateChange={mockOnCobChange}
      />,
      { lifecycleExperimental: true },
    );
  });

  it('should component render properly', () => {
    expect(wrapper.find(Popconfirm)).toHaveLength(1);
    expect(wrapper.find(DatePicker)).toHaveLength(1);
  });

  it('should onDateChange show popupConfirm if shouldConfirmOnDateChange is true', () => {
    const datePicker = wrapper.find(DatePicker);
    const date = moment('20200201', 'YYYYMMDD');
    datePicker.prop('onChange')(date);
    expect(setState).toBeCalledWith(true);
    expect(setState).toBeCalledWith('20200201');
  });

  it('should onDateChange handle cob change if shouldConfirmOnDateChange is false', () => {
    wrapper.setProps({ shouldConfirmOnDateChange: false });
    const datePicker = wrapper.find(DatePicker);
    const date = moment('20200201', 'YYYYMMDD');
    datePicker.prop('onChange')(date);
    expect(mockOnCobChange).toBeCalledWith('20200201');
  });

  it('should date picker control the right state of picker panel', () => {
    const datePicker = wrapper.find(DatePicker);
    datePicker.prop('onOpenChange')(true);
    expect(setState).toBeCalledWith(true);
  });

  it('should popup confirm action handle cob change and reset state', () => {
    const popupConfirm = wrapper.find(Popconfirm);
    popupConfirm.prop('onConfirm')();
    expect(mockOnCobChange).toBeCalled();
    expect(setState).toBeCalledWith(false);
    expect(setState).toBeCalledWith('');
  });

  it('should popup confirm action handle cob change and reset state', () => {
    const popupConfirm = wrapper.find(Popconfirm);
    popupConfirm.prop('onCancel')();
    expect(setState).toBeCalledWith(false);
    expect(setState).toBeCalledWith('');
  });
});

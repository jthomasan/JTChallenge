export const hierarchies = [
  {
    id: '1',
    name: 'Risk Portfolio Hierarchy',
    maxLevel: 4,
    type: 'hierarchy',
    applyClassification: true,
  },
  {
    id: '7',
    name: 'Geography Hierarchy',
    maxLevel: 7,
    type: 'hierarchy',
    applyClassification: true,
  },
  {
    id: '9',
    name: 'Legal Entity Hierarchy',
    maxLevel: 4,
    type: 'hierarchy',
    applyClassification: false,
  },
  {
    id: '13',
    name: 'Finance Business Hierarchy',
    maxLevel: 9,
    type: 'hierarchy',
    applyClassification: false,
  },
  {
    id: '14',
    name: 'Revenue Hierarchy',
    maxLevel: 9,
    type: 'hierarchy',
    applyClassification: false,
  },
];

import React from 'react';
import { shallow } from 'enzyme';
import Select from '@/components/Select';
import HierachyPanel, { NodeActions } from './index';
import { getNodes } from './testdata/nodes';
import { hierarchies } from './testdata/hierarchies';
import { NodeDeleteError } from '../../hooks/useDeleteNode';
import { classificationOptions } from '../ClassificationModal/testdata/classificationOptions';

describe('Hierarchy Panel Component', () => {
  let wrapper = null;
  const mockOnTypeChange = jest.fn();
  const mockOnTreeNodePopulate = jest.fn();
  const mockTreeState = {
    nodeActionType: null,
    isContextMenuShown: false,
    contextMenuOffset: {},
    searchText: '',
    selectedNode: '-1',
    hierarchyTreeScrollPosition: {
      scrollTop: 0,
      scrollLeft: 0,
    },
    expandedKeys: null,
    nodeError: null,
  };
  const mockUpdateTreeState = jest.fn();
  const nodeTypeId = '1';
  const mockNodes = getNodes();
  const matchedSearchNodes = ['5', '6', '7', '8', '9', '14', '15', '16', '17', '18'];
  const onNodeRenameMock = jest.fn();
  const onNodeDeleteMock = jest.fn().mockResolvedValue({
    success: true,
  });
  const onNodeAddMock = jest.fn();
  const onUndoNodeAddMock = jest.fn();
  const onNodeMoveMock = jest.fn();
  const onUpdateClassificationMock = jest.fn();

  beforeAll(() => {
    wrapper = shallow(
      <HierachyPanel
        nodes={[]}
        nodeTypeId={nodeTypeId}
        hierarchiesLoading={false}
        hierarchies={hierarchies}
        onTypeChange={mockOnTypeChange}
        onTreeDoubleCick={mockOnTreeNodePopulate}
        loading
        externalState={mockTreeState}
        setExternalState={mockUpdateTreeState}
        onNodeRename={onNodeRenameMock}
        onNodeDelete={onNodeDeleteMock}
        onNodeAdd={onNodeAddMock}
        onUndoNodeAdd={onUndoNodeAddMock}
        onNodeMove={onNodeMoveMock}
        onUpdateClassification={onUpdateClassificationMock}
        cob=""
      />,
      { lifecycleExperimental: true },
    )
      .first()
      .shallow();

    jest.runAllTimers();
  });

  beforeEach(() => {
    mockOnTypeChange.mockReset();
    mockOnTreeNodePopulate.mockReset();
    mockUpdateTreeState.mockReset();
    onNodeRenameMock.mockReset();
    onNodeDeleteMock.mockReset();
    onUpdateClassificationMock.mockReset();
  });

  it('should be loading after mounted successfully', () => {
    expect(wrapper.find('Form')).toHaveLength(1);
    expect(wrapper.find('PageLoading')).toHaveLength(1);
  });

  it('should dropdown loads default hierarchy list', () => {
    const select = wrapper.find(Select);
    expect(select).toHaveLength(1);
    expect(select.find('Option')).toHaveLength(5);
    expect(select.prop('value')).toBe('Risk Portfolio Hierarchy');
  });

  it('should change the value when when trigger onchange', () => {
    const select = wrapper.find(Select);
    select.simulate('change', '9');
    expect(mockOnTypeChange).toHaveBeenCalledWith('9');
  });

  it('should generate local state after nodes are loaded', () => {
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
    });
    const sortedNodeIds = wrapper.state('sortedNodeIds');
    const nodeDict = wrapper.state('nodeDict');
    expect(sortedNodeIds).toHaveLength(mockNodes.length);
    expect(Object.keys(nodeDict)).toHaveLength(mockNodes.length);
    // first id always be root
    expect(nodeDict[sortedNodeIds[0]].parent).toBe('');
  });

  it('should have the correct hierarchy node id highlighted when search text is entered', () => {
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
    });

    wrapper
      .find('Card')
      .props()
      .actions.props.children[0].props.onChange('MP');
    expect(wrapper.state('matchedSearchNodes')).toEqual(matchedSearchNodes);
    jest.runAllTimers();
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      searchText: 'MP',
    });
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      expandedKeys: ['4', '1'],
    });
  });

  it('should select the right node id when search next/prev button is clicked', () => {
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState: {
        ...mockTreeState,
        searchText: 'MP',
        selectedNode: '-1',
      },
    });
    wrapper.setState({
      matchedSearchNodes,
    });
    wrapper
      .find('Card')
      .props()
      .actions.props.children[0].props.onNext();
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      selectedNode: '5',
      nodeActionType: null,
      expandedKeys: ['4', '1'],
    });
    wrapper
      .find('Card')
      .props()
      .actions.props.children[0].props.onPrev();
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      selectedNode: '18',
      nodeActionType: null,
      expandedKeys: ['4', '1'],
    });
  });

  it('should right click the node trigger context menu show', () => {
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
    });
    wrapper.setProps({ editable: true });
    const selectedNode = '4';
    const nodeHierarchyTree = wrapper.find('HierachyNode');
    nodeHierarchyTree.prop('onRightClick')({
      event: {
        clientX: 212,
        clientY: 102,
      },
      node: {
        props: {
          eventKey: selectedNode,
        },
      },
    });
    // check context menu popup on right click
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeError: null,
      selectedNode,
      nodeActionType: null,
      isContextMenuShown: true,
      contextMenuOffset: {
        left: 212,
        top: 102,
      },
    });
  });

  it('should rename option dismiss the context menu', () => {
    wrapper.setProps({
      externalState: mockTreeState,
    });

    const contextMenu = wrapper.find('ContextMenu');
    contextMenu.prop('onSelect')({
      itemId: NodeActions.RENAME,
    });
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeActionType: NodeActions.RENAME,
      isContextMenuShown: false,
      contextMenuOffset: {},
      selectedNode: '-1',
    });
  });

  it('should call apply classification on the context menu', () => {
    wrapper.setProps({
      externalState: mockTreeState,
    });

    const contextMenu = wrapper.find('ContextMenu');
    contextMenu.prop('onSelect')({
      itemId: NodeActions.APPLY_CLASSIFICATION,
    });
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeActionType: NodeActions.APPLY_CLASSIFICATION,
      isContextMenuShown: false,
      contextMenuOffset: {},
      selectedNode: '-1',
    });
  });

  it('should add option dismiss the context menu and add dummy node', () => {
    // Given
    const externalState = Object.assign({}, mockTreeState, {
      selectedNode: '2',
    });

    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState,
    });
    const contextMenu = wrapper.find('ContextMenu');
    // When
    contextMenu.prop('onSelect')({
      itemId: NodeActions.ADD,
    });
    // Then
    const args = onNodeAddMock.mock.calls[0];
    expect(args[0]).toBe('ANZ Group|ANZ ETFS');
    expect(args[1].title).toBe('New Node');
    expect(args[1].parent).toBe('2');
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeActionType: NodeActions.ADD,
      isContextMenuShown: false,
      contextMenuOffset: {},
      selectedNode: args[1].id,
      expandedKeys: ['2'],
    });
  });

  it('should save option save the node rename/add changes', () => {
    // Given
    let externalState = Object.assign({}, mockTreeState, {
      nodeActionType: NodeActions.RENAME,
      isContextMenuShown: false,
      contextMenuOffset: {},
      searchText: '',
      selectedNode: '-1',
    });

    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState,
    });

    jest.runAllTimers();

    const nodeHierarchyTree = wrapper.find('HierachyNode');
    const sourceNodeId = '18';
    const typeId = '1';
    const newTitle = 'Test New Title';
    const targetNodeTitleProps = nodeHierarchyTree.prop('nodesTitleRenderer')[sourceNodeId].props;
    const oldTitle = targetNodeTitleProps.item.title;
    // When
    targetNodeTitleProps.onInputSave(sourceNodeId, newTitle);
    // Then
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeActionType: null,
    });
    expect(onNodeRenameMock).toHaveBeenCalledWith(sourceNodeId, typeId, oldTitle, newTitle);

    // Given
    externalState = Object.assign({}, mockTreeState, {
      nodeActionType: NodeActions.ADD,
    });

    wrapper.setProps({
      externalState,
    });

    // When
    targetNodeTitleProps.onInputSave(sourceNodeId, newTitle);
    // Then
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeActionType: null,
    });
    expect(onNodeRenameMock).toHaveBeenCalledWith(sourceNodeId, typeId, oldTitle, newTitle);
  });

  it('should change to error state when the title is duplicate', () => {
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
    });
    const nodeHierarchyTree = wrapper.find('HierachyNode');
    const sourceNodeId = '18';
    const newTitle = 'MP - Comm';
    const targetNodeTitleProps = nodeHierarchyTree.prop('nodesTitleRenderer')[sourceNodeId].props;
    targetNodeTitleProps.onInputSave(sourceNodeId, newTitle);
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeError: {
        nodeId: sourceNodeId,
        message: 'Duplicate Node Name',
        ignorable: false,
        popupClosable: true,
      },
    });
  });

  it('should cancel option cancel the rename state', () => {
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
    });
    const nodeHierarchyTree = wrapper.find('HierachyNode');
    nodeHierarchyTree.prop('nodesTitleRenderer')['18'].props.onCancel();
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeActionType: null,
      nodeError: null,
    });
  });

  it('should cancel option cancel the add state and trigger add undo', () => {
    // Given
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState: {
        ...mockTreeState,
        nodeActionType: NodeActions.ADD,
      },
    });
    const nodeHierarchyTree = wrapper.find('HierachyNode');

    // When
    nodeHierarchyTree.prop('nodesTitleRenderer')['18'].props.onCancel();

    // Then
    expect(onUndoNodeAddMock).toBeCalled();
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeActionType: null,
      nodeError: null,
    });
  });

  it('should call prop delete function when Delete is chosen in the context menu', () => {
    // GIVEN
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState: {
        ...mockTreeState,
        selectedNode: '2',
      },
    });

    // WHEN
    const contextMenu = wrapper.find('ContextMenu');
    contextMenu.prop('onSelect')({
      itemId: NodeActions.DELETE,
    });

    // THEN
    expect(onNodeDeleteMock).toHaveBeenCalledTimes(1);
  });

  it('should change to error state when deleting node with children', () => {
    // GIVEN
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState: {
        ...mockTreeState,
        selectedNode: '1',
      },
    });

    // WHEN
    const contextMenu = wrapper.find('ContextMenu');
    contextMenu.prop('onSelect')({
      itemId: NodeActions.DELETE,
    });

    // THEN
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeError: {
        nodeId: '1',
        message: 'Please delete all child nodes first',
        ignorable: true,
        popupClosable: true,
      },
    });
  });

  it('should change to error state when deleting node with portfolios', async () => {
    // GIVEN
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState: {
        ...mockTreeState,
        selectedNode: '2',
      },
    });

    const promise = Promise.resolve({
      success: false,
      error: NodeDeleteError.PORTFOLIO_EXISTS,
    });

    onNodeDeleteMock.mockReturnValue(promise);

    // WHEN
    const contextMenu = wrapper.find('ContextMenu');
    contextMenu.prop('onSelect')({
      itemId: NodeActions.DELETE,
    });

    await promise;

    // THEN
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeError: {
        nodeId: '2',
        message: 'Please remap all portfolios first',
        ignorable: true,
        popupClosable: true,
      },
    });
  });

  it('should node be selected on start dragging node', () => {
    // Given
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState: {
        ...mockTreeState,
        expandedKeys: ['1'],
      },
    });
    const nodeHierarchyTree = wrapper.find('HierachyNode');
    const selectedNode = '5';

    // When
    nodeHierarchyTree.prop('onNodeMoveStart')({ node: { props: { eventKey: selectedNode } } });

    // Then
    expect(mockUpdateTreeState).toBeCalledWith({ selectedNode });
  });

  it('should node be moved to right position and state are changed accordingly', () => {
    // Given
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState: {
        ...mockTreeState,
        expandedKeys: ['1'],
      },
    });
    const nodeBeMoved = mockNodes.find((node) => node.id === '5');
    const parentMoveTo = mockNodes.find((node) => node.id === '3');
    const nodeHierarchyTree = wrapper.find('HierachyNode');

    const expectedNodeBeMoved = Object.assign({}, nodeBeMoved, {
      typeId: '1',
      cob: '',
    });
    // When
    nodeHierarchyTree.prop('onNodeMoveDone')(nodeBeMoved, parentMoveTo, 0);

    // Then
    expect(onNodeMoveMock).toBeCalledWith(expectedNodeBeMoved, parentMoveTo, 0);
    expect(mockUpdateTreeState).toBeCalledWith({ expandedKeys: ['1', '3'] });
  });

  it('should return selected node child max depth when start move', () => {
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState: {
        ...mockTreeState,
        expandedKeys: ['1'],
      },
    });
    const nodeHierarchyTree = wrapper.find('HierachyNode');
    const selectedNode = '4';

    // When
    nodeHierarchyTree.prop('onNodeMoveStart')({ node: { props: { eventKey: selectedNode } } });

    // Then
    const nodeChildMaxDepth = wrapper.state('nodeChildMaxDepth');
    expect(nodeChildMaxDepth).toEqual(3);
  });

  it('should allow or deny when selected node max depth less equal or more than max level when dragging', () => {
    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState: {
        ...mockTreeState,
        expandedKeys: ['1'],
      },
    });
    const nodeHierarchyTree = wrapper.find('HierachyNode');
    const selectedNode = '9';

    nodeHierarchyTree.prop('onNodeMoveStart')({ node: { props: { eventKey: selectedNode } } });

    // Calculate node child max depth
    const nodeChildMaxDepth = wrapper.state('nodeChildMaxDepth');
    expect(nodeChildMaxDepth).toEqual(2);

    nodeHierarchyTree.prop('onNodeDragEnter')({ node: { props: { eventKey: '2' } } });

    let isNodeReachedMaxDepth = wrapper.state('isNodeReachedMaxDepth');

    // With in max level
    expect(isNodeReachedMaxDepth).toEqual(false);

    nodeHierarchyTree.prop('onNodeDragEnter')({ node: { props: { eventKey: '18' } } });

    isNodeReachedMaxDepth = wrapper.state('isNodeReachedMaxDepth');
    // Out of max level
    expect(isNodeReachedMaxDepth).toEqual(true);
  });

  it('should deny if reached max level when add new nodes', () => {
    const externalState = Object.assign({}, mockTreeState, {
      selectedNode: '11',
    });

    wrapper.setProps({
      nodes: mockNodes,
      loading: false,
      externalState,
    });
    const contextMenu = wrapper.find('ContextMenu');

    contextMenu.prop('onSelect')({
      itemId: NodeActions.ADD,
    });

    const nodeError = {
      nodeId: '11',
      ignorable: false,
      message: 'Exceeded max allowable level of 4',
      popupClosable: false,
    };

    wrapper.setProps({
      externalState: {
        ...mockTreeState,
        nodeError,
      },
    });

    // Execute all pending micro tasks
    jest.runAllTicks();
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeError,
    });

    // Execute all pending macro tasks
    jest.runAllTimers();
    expect(mockUpdateTreeState).toHaveBeenCalledWith({
      nodeError: null,
    });
  });

  it('should call apply classification function', () => {
    wrapper.setProps({
      isModalShown: true,
      nodeId: '1',
      classificationOptions,
    });
    const classificationModal = wrapper.find('ClassificationModal');

    classificationModal.prop('onApplyClassification')({
      id: '1',
      assetType: 'CREDIT',
      capitalMultiplier: 'MYANMAR',
      hyperionUnit: 'Excluded',
    });

    expect(onUpdateClassificationMock).toBeCalledWith({
      id: '1',
      nodeTitle: 'GQL ANZ Group',
      assetType: 'CREDIT',
      capitalMultiplier: 'MYANMAR',
      hyperionUnit: 'Excluded',
      typeId: '1',
    });

    classificationModal.prop('onCancelClassification')();
    const isModalShown = wrapper.state('isModalShown');
    expect(isModalShown).toEqual(false);
  });
});

import React, { Component } from 'react';
import _, { isEqual } from 'lodash';
import { Form, message } from 'antd';
import uuid from 'uuid-random';

import { Offset } from '@progress/kendo-react-popup';
import { AntTreeNodeMouseEvent } from 'antd/es/tree/Tree';
import { AntTreeNodeDragEnterEvent } from 'antd/lib/tree/Tree';
import classnames from 'classnames';
import { debounce } from 'debounce';
import PageLoading from '@/components/PageLoading/';
import { ExternalisedStateProps } from '@/types/externalised-state';
import anzTheme from '@/../config/anzTheme';
import withExternalState from '@/HOCs/withExternalState';
import ContextMenu from '@/components/ContextMenu';
import Card from '@/components/Card';
import SearchField from '@/components/SearchField';
import Select, { Option } from '@/components/Select';
import ExportButton from '@/components/ExportButton';

import CoBDatePicker from '../CoBDatePicker';
import NodeTitle from '../NodeTitle';
import NodeHierarchyTree, { NodeDict, ScrollPosition } from '../NodeHierarchyTree';
import ClassificationModal, { ClassificationOptions, Classification } from '../ClassificationModal';
import { Node, NodeError } from '../Node';
import { NodeDeleteError, NodeDeleteResponse } from '../../hooks/useDeleteNode';
import { NewNode } from '../../hooks/useAddNode';
import { MoveTargetNode } from '../../hooks/useMoveNode';

import styles from './index.less';

export enum NodeActions {
  ADD = '0',
  RENAME = '1',
  DELETE = '2',
  APPLY_CLASSIFICATION = '3',
}

export const NodeActionText = new Map<string, string>([
  [NodeActions.ADD, 'Add'],
  [NodeActions.RENAME, 'Rename'],
  [NodeActions.DELETE, 'Delete'],
  [NodeActions.APPLY_CLASSIFICATION, 'Apply Classification'],
]);

const AddNodeDummyTitle = 'New Node';

export enum HierarchyRefEnum {
  RISK_PORTFOLIO = 'RISK_PORTFOLIO',
  GEOGRAPHY = 'GEOGRAPHY',
  LEGAL_ENTITY = 'LEGAL_ENTITY',
  FINANCE_BUSINESS = 'FINANCE_BUSINESS',
  REVENUE = 'REVENUE',
}

export interface Hierarchy {
  id: string;
  name: string;
  maxLevel: number;
  ref: HierarchyRefEnum;
  applyClassification: boolean;
}

export interface SelectedTreeNode {
  nodeId: string | undefined;
  isLeaf: boolean | undefined;
}

interface HierachyPanelExternalState {
  nodeActionType: NodeActions | null;
  isContextMenuShown: boolean;
  contextMenuOffset: Offset;
  searchText: string;
  selectedNode: string;
  nodeError: NodeError | null;
  hierarchyTreeScrollPosition: ScrollPosition;
  expandedKeys: string[] | null;
}

interface HierachyPanelProps extends ExternalisedStateProps<HierachyPanelExternalState> {
  nodes: any;
  loading: boolean;
  hierarchiesLoading: boolean;
  nodeTypeId: string;
  cob: string;
  hierarchies: Hierarchy[];
  classificationOptions: ClassificationOptions;
  onTypeChange: (val: string) => void;
  onCobChange: (date: string) => void;
  onTreeDoubleCick: (selectedTreeNode: SelectedTreeNode) => void;
  onNodeRename: (sourceNodeId: string, typeId: string, oldTitle: string, newTitle: string) => void;
  onNodeDelete: (node: Node, nodeTypeId: string, cob: string) => Promise<NodeDeleteResponse>;
  onNodeAdd: (parentNodeFullPath: string, newNode: NewNode) => void;
  onUndoNodeAdd: () => void;
  onNodeMove: (nodeBeMoved: MoveTargetNode, parentMoveTo: Node, indexMoveTo: number) => void;
  onUpdateClassification: (classification: Classification) => void;
  hasUncommittedChanges: boolean;
  editable: boolean;
}

interface HierachyPanelState {
  sortedNodeIds: string[];
  scrollToNodeId: string | null;
  isModalShown: boolean;
  nodeDict: NodeDict;
  matchedSearchNodes: Array<string>;
  nodeChildMaxDepth: number;
  isNodeReachedMaxDepth: boolean;
  componentUpdating: boolean;
}

class HierachyPanel extends Component<HierachyPanelProps, HierachyPanelState> {
  static externalState: HierachyPanelExternalState = {
    nodeError: null,
    nodeActionType: null,
    isContextMenuShown: false,
    contextMenuOffset: {} as Offset,
    searchText: '',
    selectedNode: '-1',
    hierarchyTreeScrollPosition: { scrollLeft: 0, scrollTop: 0 },
    expandedKeys: null,
  };

  timeout: any;

  searchExpandTimer: number | null;

  constructor(props: HierachyPanelProps) {
    super(props);
    this.timeout = null;
    this.searchExpandTimer = null;
    this.state = {
      sortedNodeIds: [],
      scrollToNodeId: null,
      isModalShown: false,
      nodeDict: {},
      matchedSearchNodes: [],
      nodeChildMaxDepth: 0,
      isNodeReachedMaxDepth: false,
      componentUpdating: false,
    };
  }

  shouldComponentUpdate(nextProps: any, nextState: any) {
    const isPropsEqual = isEqual(nextProps, this.props);
    const isStateEqual = isEqual(nextState, this.state);

    return !isPropsEqual || !isStateEqual;
  }

  componentDidUpdate(preProps: HierachyPanelProps) {
    const { nodeDict: currentNodeDict, scrollToNodeId } = this.state;
    const { nodes, loading, externalState, setExternalState } = this.props;
    const { searchText, expandedKeys } = externalState;

    if (scrollToNodeId) {
      const scrollParentId = (currentNodeDict[scrollToNodeId] || {}).parent;

      if ((expandedKeys || []).includes(scrollParentId)) {
        this.scrollToNode();
      }
    }
    // reset nodeDict when there is no nodes
    if (nodes !== preProps.nodes && !loading && nodes && nodes.length === 0) {
      // eslint-disable-next-line react/no-did-update-set-state
      this.setState({
        nodeDict: {},
      });
    }

    // if getting new or updated list of nodes to display then initialise working maps and arrays
    if (nodes !== preProps.nodes && nodes && nodes.length > 0) {
      const rootNode = nodes.find((node: Node) => node.parent === '');
      const nodeDict = this.transformToNodeMap(nodes);
      const sortedNodeIds = this.dfTraversal(rootNode, nodeDict);

      const matchedNodes = this.getSearchMatches(sortedNodeIds, nodeDict, searchText);

      this.onClearError();

      // eslint-disable-next-line react/no-did-update-set-state
      this.setState({
        matchedSearchNodes: matchedNodes.matched,
        sortedNodeIds,
        nodeDict,
        componentUpdating: true,
      });
      const useMatchedToExpand: boolean =
        _.some(expandedKeys, (key) => !nodeDict[key]) || !expandedKeys;

      // timeout hack below since antd tree sometimes does not expand properly with autoExpandParent set to false
      setTimeout(() => {
        this.setState({
          componentUpdating: false,
        });

        if (useMatchedToExpand) {
          setExternalState({
            // if there are >=1 key that does not exist in new nodedict
            expandedKeys: matchedNodes.toExpand,
          });
        }
      }, 0);
    }
  }

  getElementIdByKey = (key: string) => `refHierNode-${key}`;

  scrollToNode = () => {
    const { scrollToNodeId: key } = this.state;
    if (!key) return;

    const element = document.getElementById(this.getElementIdByKey(key));

    if (element) {
      if (this.timeout) {
        clearTimeout(this.timeout);
      }

      this.timeout = setTimeout(() => {
        element.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
      }, 200);
    }

    this.setState({
      scrollToNodeId: null,
    });
  };

  /**
   * Depth First Traversal will traverse the tree in depth frist squence and build a sorted lis of node ids
   */
  dfTraversal = (node: Node, nodeDict: NodeDict): string[] => {
    const returnedIds: string[] = [node.id];
    if (node.children && node.children.length > 0) {
      return node.children.reduce(
        (acc, id) => acc.concat(this.dfTraversal(nodeDict[id], nodeDict)),
        returnedIds,
      );
    }
    return returnedIds;
  };

  isNodeTitleDuplicate = (nodeId: string, title: string) => {
    const { nodes } = this.props;
    return nodes.filter((node: Node) => node.title === title && node.id !== nodeId).length > 0;
  };

  isNodeTitleValidate = (sourceNodeId: string, oldTitle: string, newTitle: string) => {
    const {
      setExternalState,
      externalState: { nodeActionType },
    } = this.props;
    // check add node title to be different from dummy
    if (newTitle.trim() === AddNodeDummyTitle && nodeActionType === NodeActions.ADD) {
      this.addNodeEditError(sourceNodeId, 'Please Change Node Name');
      return false;
    }
    // check empty input
    if (newTitle.trim() === '') {
      this.addNodeEditError(sourceNodeId, 'Node Name Required');
      return false;
    }
    // check if changes made
    if (oldTitle === newTitle) {
      setExternalState({ nodeActionType: null });
      return false;
    }
    // check duplicate title
    if (this.isNodeTitleDuplicate(sourceNodeId, newTitle)) {
      this.addNodeEditError(sourceNodeId, 'Duplicate Node Name');
      return false;
    }
    return true;
  };

  addNodeEditError = (
    sourceNodeId: string,
    msg: string,
    ignorable: boolean = false,
    popupClosable = true,
  ) => {
    const { setExternalState } = this.props;

    setExternalState({
      nodeError: {
        nodeId: sourceNodeId,
        message: msg,
        ignorable,
        popupClosable,
      },
    });
  };

  getParentNodes = (nodeId: string, nodeDict: NodeDict) => {
    const node = nodeDict[nodeId];
    let parents: string[] = [];

    if (node && node.parent) {
      parents.push(node.parent);
      parents = parents.concat(this.getParentNodes(node.parent, nodeDict));
    }

    return parents;
  };

  getSearchMatches = (sortedNodeIds: string[], nodeDict: NodeDict, searchText: string) => {
    if (!searchText) return { matched: [], toExpand: [] };

    const matched = sortedNodeIds.filter((id: string) =>
      nodeDict[id].title.toLowerCase().includes(searchText.toLowerCase()),
    );
    const toExpand = _.uniq(
      matched.reduce(
        (acc: string[], id: string) => acc.concat(this.getParentNodes(id, nodeDict)),
        [],
      ),
    );

    return { matched, toExpand };
  };

  onSearchTextChange = (searchText: string) => {
    const { sortedNodeIds, nodeDict } = this.state;
    const {
      setExternalState,
      externalState: { expandedKeys },
    } = this.props;

    const matches = this.getSearchMatches(sortedNodeIds, nodeDict, searchText);
    this.setState({
      matchedSearchNodes: matches.matched,
    });
    setExternalState({
      searchText,
    });

    // rudimentary debounce
    if (this.searchExpandTimer) window.clearTimeout(this.searchExpandTimer);
    this.searchExpandTimer = window.setTimeout(() => {
      setExternalState({
        expandedKeys: _.uniq((expandedKeys || []).concat(matches.toExpand)),
      });
    }, 800);
  };

  onTreeSelect = (selectedKeys: string[]) => {
    const { nodeDict } = this.state;
    const { setExternalState, externalState } = this.props;
    const { nodeError, expandedKeys } = externalState;
    if (selectedKeys.length && !nodeError) {
      const nodeId = selectedKeys[0];

      setExternalState({
        selectedNode: nodeId,
        expandedKeys: _.uniq((expandedKeys || []).concat(this.getParentNodes(nodeId, nodeDict))),
        nodeActionType: null,
      });
    }
  };

  onTreeNodeRightClick = (options: AntTreeNodeMouseEvent) => {
    const { setExternalState, externalState, cob } = this.props;
    const { event, node } = options;
    const { nodeError } = externalState;
    const nodeId = node.props.eventKey;

    if ((!nodeError || nodeError.ignorable) && cob === '') {
      setExternalState({
        nodeError: null,
        selectedNode: nodeId || '-1',
        nodeActionType: null,
        isContextMenuShown: true,
        contextMenuOffset: {
          left: event.clientX,
          top: event.clientY,
        },
      });
    }
  };

  onTreeScroll = (scrollPosition: { scrollTop: number; scrollLeft: number }) => {
    const { setExternalState } = this.props;
    const { scrollTop, scrollLeft } = scrollPosition;

    setExternalState({
      hierarchyTreeScrollPosition: { scrollLeft, scrollTop },
    });
  };

  nodeHasChildren = (nodeId: string) =>
    !!(
      this.state.nodeDict[nodeId] &&
      this.state.nodeDict[nodeId].children &&
      this.state.nodeDict[nodeId].children?.length
    );

  deleteNode = async (nodeId: string) => {
    const { setExternalState, onNodeDelete, nodeTypeId, cob } = this.props;
    const node = this.state.nodeDict[nodeId];

    if (!node) return;

    if (this.nodeHasChildren(nodeId)) {
      this.addNodeEditError(nodeId, 'Please delete all child nodes first', true);
      return;
    }

    const res = await onNodeDelete(node, nodeTypeId, cob);

    if (!res.success) {
      if (res.error === NodeDeleteError.PORTFOLIO_EXISTS) {
        this.addNodeEditError(nodeId, 'Please remap all portfolios first', true);
      }
      return;
    }

    message.success('Deleted');
    setExternalState({ selectedNode: '-1' });
  };

  onContextMenuSelect = ({ itemId }: any, maxLevel: number) => {
    const { setExternalState, externalState, nodeTypeId, onNodeAdd, cob } = this.props;
    const { selectedNode, expandedKeys } = externalState;
    const { nodeDict } = this.state;

    let newExternalState: any = {
      nodeActionType: itemId,
      isContextMenuShown: false,
      contextMenuOffset: {} as Offset,
      selectedNode,
    };

    if (itemId === NodeActions.DELETE) {
      this.deleteNode(selectedNode);
      newExternalState = { ...newExternalState, nodeActionType: null };
    }

    if (itemId === NodeActions.ADD) {
      const nodeLevel = this.getParentDepth(nodeDict[selectedNode]) + 1;

      if (nodeLevel <= maxLevel) {
        const parentNode = nodeDict[selectedNode];
        const newNodeId = uuid();
        const newNode = {
          id: newNodeId,
          parent: selectedNode,
          title: AddNodeDummyTitle,
          children: [],
          typeId: nodeTypeId,
          fullPath: `${parentNode.fullPath}|${AddNodeDummyTitle}`,
          cob,
        };

        onNodeAdd(parentNode.fullPath, newNode);
        newExternalState = {
          ...newExternalState,
          selectedNode: newNode.id,
          expandedKeys: _.uniq([...(expandedKeys || []), selectedNode]),
        };
      } else {
        newExternalState = { ...newExternalState, nodeActionType: null };

        // Execute after the completion of current task
        queueMicrotask(() => {
          this.onNodeDragShowError(selectedNode, maxLevel);
          setTimeout(() => {
            this.onNodeDragClearError();
          }, 2000);
        });
      }
    }

    if (itemId === NodeActions.APPLY_CLASSIFICATION) {
      this.setState({ isModalShown: true });
    }

    setExternalState(newExternalState);
  };

  onContextMenuDismiss = () => {
    const { setExternalState } = this.props;
    setExternalState({
      nodeError: null,
      nodeActionType: null,
      isContextMenuShown: false,
      contextMenuOffset: {} as Offset,
    });
  };

  onApplyClassification = (classification: Classification) => {
    const { title } = this.state.nodeDict[classification.id];
    const { nodeTypeId } = this.props;

    this.props.onUpdateClassification({ ...classification, nodeTitle: title, typeId: nodeTypeId });
    this.setState({ isModalShown: false });
  };

  onCancelClassification = () => {
    this.setState({ isModalShown: false });
  };

  onNodeChangesSave = (sourceNodeId: string, newTitle: string) => {
    const { nodeTypeId, setExternalState, onNodeRename, externalState } = this.props;
    const { nodeDict } = this.state;
    const { nodeActionType } = externalState;
    const oldTitle = nodeDict[sourceNodeId].title;

    if (!this.isNodeTitleValidate(sourceNodeId, oldTitle, newTitle)) {
      return;
    }

    setExternalState({ nodeActionType: null });
    if (nodeActionType === NodeActions.RENAME || nodeActionType === NodeActions.ADD) {
      onNodeRename(sourceNodeId, nodeTypeId, oldTitle, newTitle);
    }
  };

  onNodeChangesCancel = () => {
    const {
      setExternalState,
      onUndoNodeAdd,
      externalState: { nodeActionType },
    } = this.props;
    if (nodeActionType === NodeActions.ADD) {
      onUndoNodeAdd();
    }
    setExternalState({
      nodeError: null,
      nodeActionType: null,
    });
  };

  searchNodeByOne = (option: { forward: boolean } = { forward: true }) => {
    const {
      externalState: { selectedNode },
    } = this.props;
    const { matchedSearchNodes } = this.state;

    let nextNodeId = option.forward
      ? matchedSearchNodes[0]
      : matchedSearchNodes[matchedSearchNodes.length - 1];
    const selectedNodeIndex: number = matchedSearchNodes.findIndex(
      (nodeid: string) => nodeid === selectedNode,
    );
    let nextMatchedIndex = option.forward ? selectedNodeIndex + 1 : selectedNodeIndex - 1;

    if (nextMatchedIndex > matchedSearchNodes.length - 1) {
      nextMatchedIndex = 0;
    } else if (nextMatchedIndex < 0) {
      nextMatchedIndex = matchedSearchNodes.length - 1;
    }
    nextNodeId = matchedSearchNodes[nextMatchedIndex] || nextNodeId;

    this.setState({
      scrollToNodeId: nextNodeId,
    });

    this.onTreeSelect([nextNodeId]);
  };

  onExpand = (expandedKeys: Array<string>) => {
    const { setExternalState } = this.props;

    setExternalState({
      expandedKeys,
    });
  };

  getContextMenuOptions = (isClassificationEnabled: boolean, options: any[]) => {
    if (!isClassificationEnabled) {
      return options.filter((item) => item.value !== NodeActions.APPLY_CLASSIFICATION);
    }

    return options;
  };

  onNodeMoveDone = (
    nodeBeMoved: Node | undefined,
    parentMoveTo: Node | undefined,
    indexMoveTo: number,
  ) => {
    const {
      cob,
      nodeTypeId,
      setExternalState,
      onNodeMove,
      externalState: { expandedKeys },
    } = this.props;
    if (nodeBeMoved && parentMoveTo && nodeBeMoved.parent !== parentMoveTo.id) {
      onNodeMove(
        Object.assign({}, nodeBeMoved, {
          typeId: nodeTypeId,
          cob,
        }),
        parentMoveTo,
        indexMoveTo,
      );
      setExternalState({
        expandedKeys: expandedKeys
          ? [...new Set(expandedKeys.concat(parentMoveTo.id))]
          : [parentMoveTo.id],
      });
    }
  };

  // Calculate depth of node tree
  getChildMaxDepth = (node: Node): number => {
    const { nodeDict } = this.state;

    if (!node.children) {
      return 0;
    }

    const depth = node.children.reduce(
      (acc, curr) => Math.max(acc, this.getChildMaxDepth(nodeDict[curr])),
      0,
    );

    return depth + 1;
  };

  getParentDepth = (node: Node): number => {
    const { nodeDict } = this.state;
    if (!node) {
      return 0;
    }

    return this.getParentDepth(nodeDict[node.parent]) + 1;
  };

  onMoveStart = (options: AntTreeNodeMouseEvent) => {
    const { nodeDict } = this.state;
    const { setExternalState } = this.props;
    const { eventKey: nodeId = '' } = options.node.props;
    const maxDepth = this.getChildMaxDepth(nodeDict[nodeId]);

    this.setState({
      nodeChildMaxDepth: maxDepth,
    });
    setExternalState({ selectedNode: nodeId });
  };

  onNodeDragEnter = (options: AntTreeNodeDragEnterEvent, maxLevel: number) => {
    const { nodeDict, nodeChildMaxDepth } = this.state;
    const {
      externalState: { selectedNode },
    } = this.props;
    const { eventKey: nodeId = '' } = options.node.props;
    const { parent: parentId } = nodeDict[nodeId];
    const nodeMaxDepth = this.getParentDepth(nodeDict[parentId]) + nodeChildMaxDepth + 1;
    const isNodeReachedMaxDepth = nodeMaxDepth > maxLevel;

    if (isNodeReachedMaxDepth && selectedNode !== nodeId) {
      this.onNodeDragShowError(nodeId, maxLevel);
    }

    this.setState({
      isNodeReachedMaxDepth,
    });
  };

  onNodeDragShowError = (nodeId: string, maxLevel: number) => {
    this.addNodeEditError(nodeId, `Exceeded max allowable level of ${maxLevel}`, false, false);
  };

  onNodeDragClearError = () => {
    const { externalState, setExternalState } = this.props;

    if (externalState.nodeError) {
      setExternalState({
        nodeError: null,
      });
    }
  };

  onNodeDragLeave = (options: AntTreeNodeMouseEvent) => {
    options.event.preventDefault();
    this.onNodeDragClearError();
  };

  onClearError = () => this.props.setExternalState({ nodeError: null });

  transformToNodeMap = (nodes: Node[]) => {
    let nodeDict: NodeDict = {};

    // create node map from array
    if (nodes) {
      nodeDict = nodes.reduce((acc, node) => {
        acc[node.id] = node;
        return acc;
      }, {});
    }
    return nodeDict;
  };

  generateNodesTitle = () => {
    const { externalState } = this.props;
    const { nodeDict } = this.state;
    const {
      searchText,
      selectedNode,
      nodeActionType,
      nodeError,
      hierarchyTreeScrollPosition,
    } = externalState;
    const returnedNodes = {};

    Object.keys(nodeDict).forEach((key) => {
      const item = nodeDict[key];
      const searchHighlightColor =
        selectedNode === key ? anzTheme['menu-color'] : anzTheme['primary-color'];

      returnedNodes[key] = (
        <NodeTitle
          domId={this.getElementIdByKey(key)}
          item={item}
          searchText={searchText}
          searchHighlightColor={searchHighlightColor}
          isInput={
            selectedNode === key &&
            (nodeActionType === NodeActions.RENAME || nodeActionType === NodeActions.ADD)
          }
          onInputSave={this.onNodeChangesSave}
          onCancel={this.onNodeChangesCancel}
          error={nodeError && nodeError.nodeId === key ? nodeError : null}
          popupClosable={nodeError?.popupClosable ?? true}
          clearError={this.onClearError}
          scrollY={hierarchyTreeScrollPosition.scrollTop}
        />
      );
    });

    return returnedNodes;
  };

  render() {
    const {
      matchedSearchNodes,
      componentUpdating,
      nodeDict,
      isModalShown,
      isNodeReachedMaxDepth,
    } = this.state;
    const {
      hierarchies,
      classificationOptions,
      loading,
      hierarchiesLoading,
      nodeTypeId,
      cob,
      onTypeChange,
      onCobChange,
      externalState,
      onTreeDoubleCick,
      hasUncommittedChanges,
      editable,
    } = this.props;
    const {
      searchText,
      selectedNode,
      isContextMenuShown,
      expandedKeys,
      contextMenuOffset,
      nodeError,
      hierarchyTreeScrollPosition,
    } = externalState;
    const isSearchNextPreDisabled =
      searchText === '' || !matchedSearchNodes || matchedSearchNodes.length === 0;

    let selectedHierarchyName = '';
    let hierarchyMaxLevel = 0;
    let isClassificationEnabled = false;

    if (nodeTypeId) {
      const hierarchyInfo = hierarchies.find((item) => item.id === nodeTypeId);
      selectedHierarchyName = hierarchyInfo?.name ?? '';
      hierarchyMaxLevel = hierarchyInfo?.maxLevel ?? 0;
      isClassificationEnabled = hierarchyInfo?.applyClassification ?? false;
    }

    return (
      <Card
        title="Hierarchy"
        className={styles.referenceDataCard}
        actions={
          <>
            <SearchField
              key="search"
              placeholder="Node Search"
              value={searchText}
              onChange={this.onSearchTextChange}
              onNext={() => this.searchNodeByOne({ forward: true })}
              nextDisabled={isSearchNextPreDisabled}
              onPrev={() => this.searchNodeByOne({ forward: false })}
              prevDisabled={isSearchNextPreDisabled}
              disabled={nodeTypeId === undefined || nodeTypeId === '-1'}
            />
            <ExportButton
              key="export"
              className={styles.exportButton}
              url={`/export/reference-data/hierarchy/nodes/csv?typeId=${nodeTypeId}&cob=${cob}`}
              disabled={Object.keys(nodeDict).length === 0}
            />
          </>
        }
      >
        <Form layout="inline">
          <Form.Item>
            <Select
              value={selectedHierarchyName || undefined}
              className={styles.selectItem}
              dropdownMatchSelectWidth={false}
              disabled={hierarchiesLoading}
              placeholder={!hierarchiesLoading ? 'Select Hierarchy' : 'Loading...'}
              onChange={onTypeChange}
            >
              {hierarchies.map((data) => (
                <Option key={data.id} value={data.id}>
                  {data.name}
                </Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item>
            <CoBDatePicker
              placeholder="Latest COB"
              popupConfirmMessage="Refresh and discard all uncommitted changes ?"
              format="DD/MM/YYYY"
              cob={cob}
              disabled={nodeTypeId === '-1'}
              shouldConfirmOnDateChange={hasUncommittedChanges}
              handleDateChange={onCobChange}
            />
          </Form.Item>
        </Form>
        {componentUpdating || loading ? (
          <PageLoading />
        ) : (
          <NodeHierarchyTree
            className={classnames({
              [styles.hasError]: !!nodeError,
            })}
            nodes={nodeDict}
            isNodeReachedMaxDepth={isNodeReachedMaxDepth}
            nodesTitleRenderer={this.generateNodesTitle()}
            expandedKeys={expandedKeys || []}
            onExpand={this.onExpand}
            onSelect={this.onTreeSelect}
            onDoubleClick={(e, node) =>
              onTreeDoubleCick({ nodeId: node.props.eventKey, isLeaf: node.props.isLeaf })
            }
            onRightClick={editable ? this.onTreeNodeRightClick : () => {}}
            onNodeMoveStart={this.onMoveStart}
            onNodeDragEnter={(options) => this.onNodeDragEnter(options, hierarchyMaxLevel)}
            onNodeDragLeave={this.onNodeDragLeave}
            onNodeDragClearError={this.onNodeDragClearError}
            onNodeMoveDone={this.onNodeMoveDone}
            selectedKey={selectedNode}
            onScroll={debounce(this.onTreeScroll, 1000)}
            scrollPosition={hierarchyTreeScrollPosition}
            draggable={cob === '' && editable}
          />
        )}
        <ContextMenu
          items={this.getContextMenuOptions(isClassificationEnabled, [
            { value: NodeActions.ADD, text: NodeActionText.get(NodeActions.ADD) },
            { value: NodeActions.RENAME, text: NodeActionText.get(NodeActions.RENAME) },
            { value: NodeActions.DELETE, text: NodeActionText.get(NodeActions.DELETE) },
            {
              value: NodeActions.APPLY_CLASSIFICATION,
              text: NodeActionText.get(NodeActions.APPLY_CLASSIFICATION),
            },
          ])}
          isContextMenuShown={isContextMenuShown}
          contextMenuOffset={contextMenuOffset}
          onSelect={(options) => this.onContextMenuSelect(options, hierarchyMaxLevel)}
          onContextMenuDismiss={this.onContextMenuDismiss}
        />
        {isModalShown && (
          <ClassificationModal
            isCalledFromNodes
            isModalShown={isModalShown}
            nodeId={selectedNode}
            classificationOptions={classificationOptions}
            onApplyClassification={this.onApplyClassification}
            onCancelClassification={this.onCancelClassification}
          />
        )}
      </Card>
    );
  }
}

export default withExternalState(HierachyPanel);

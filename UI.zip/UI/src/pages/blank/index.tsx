import React from 'react';

interface BlankPagerProps {}

const BlankPage: React.FC<BlankPagerProps> = () => <div></div>;
export default BlankPage;

import React from 'react';
import Card from '@/components/Card';
import Iframe from 'react-iframe';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'appian-record-view': any;
    }
  }
}

const LimitsPage: React.FC = () => (
  <Card title="Pending Limits">
    <Iframe url="/appian/PendingLimits.html" width="100%" height="100%" frameBorder={0} />
  </Card>
);

export default LimitsPage;

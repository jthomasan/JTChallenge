import React from 'react';
import { Result, Button } from 'antd';
import { BaseErrorFallbackProps } from '@/error/ErrorBoundary';
import { ErrorTypes } from '@/error/types';

import styles from './index.less';

interface PageErrorFallbackProps extends BaseErrorFallbackProps {
  error?: BaseErrorFallbackProps['error'];
  title?: string;
  retryText?: string;
}

const PageErrorFallback: React.FC<PageErrorFallbackProps> = (props) => {
  const { error = {}, onRetry, title, retryText } = props;
  const Subtitle = () => (
    <details className={styles.errorDetails}>
      <summary>Error Details</summary>
      {error.message}
    </details>
  );
  return (
    <Result
      status={error.name === ErrorTypes.UNEXPECTED_ERROR ? 'error' : 'warning'}
      title={title || 'Error Loading Application'}
      subTitle={error.message ? <Subtitle /> : null}
      extra={
        retryText
          ? [
              <Button key="retryBtn" type="primary" onClick={onRetry}>
                {retryText}
              </Button>,
            ]
          : undefined
      }
    />
  );
};

export default PageErrorFallback;

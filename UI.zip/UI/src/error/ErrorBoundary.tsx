import React, { ReactElement } from 'react';
import ErrorFallback from './ErrorFallback';

export interface BaseErrorFallbackProps {
  error?: any;
  onRetry?: (event?: React.MouseEvent<HTMLElement, MouseEvent>) => void;
}

export interface ErrorBoundaryProps {
  /**
   * The title to be displayed in the default ErrorFallback
   */
  errorTitle?: string;
  /**
   * The text to be displayed in the retry button of the default ErrorFallback. If not defined the retry button will not display
   */
  errorRetryText?: string;
  /**
   * custom fallback component can be defined here to overwrite the default ErrorFallback
   */
  fallback?: ReactElement;
  /**
   * retryWatcher allow ErrorBoudary to watch on a flag and trigger retry on flag value change
   */
  retryWatcher?: any;
}

export interface ErrorBoundaryState {
  error: any;
  retryWatcher: any;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: any) {
    super(props);
    this.state = { error: null, retryWatcher: props.retryWatcher };
  }

  static getDerivedStateFromError(error: any) {
    // Update state so the next render will show the fallback UI.
    return { error };
  }

  static getDerivedStateFromProps(nextProps: ErrorBoundaryProps, prevState: ErrorBoundaryState) {
    const watcherChanged = nextProps.retryWatcher !== prevState.retryWatcher;
    if (prevState.error && watcherChanged) {
      return { error: null, retryWatcher: nextProps.retryWatcher };
    }

    return { retryWatcher: nextProps.retryWatcher };
  }

  onRetry = () => {
    this.setState({ error: null });
  };

  render() {
    const { error } = this.state;
    const { errorTitle, errorRetryText, fallback, children } = this.props;
    const fallbackComponent = fallback ? (
      React.cloneElement(fallback, { error, onRetry: this.onRetry } as BaseErrorFallbackProps)
    ) : (
      <ErrorFallback
        title={errorTitle}
        retryText={errorRetryText}
        error={error}
        onRetry={this.onRetry}
      />
    );
    return error ? fallbackComponent : children;
  }
}

export default ErrorBoundary;

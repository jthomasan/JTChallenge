export enum ErrorTypes {
  UNEXPECTED_ERROR = 'Error',
  QUERY_ERROR = 'QueryError',
  UNCOMMITTED_CHANGES_ERROR = 'UncommittedChangesError',
}

export class QueryError extends Error {
  constructor(args: any) {
    super(args);
    this.name = ErrorTypes.QUERY_ERROR;
  }
}

export class UncommittedChangesError extends Error {
  originalError: any;

  faliedActionMessage?: string;

  committedActionsMessage?: string;

  committedActionsDetails?: any;

  constructor(
    originalError: any,
    committedActionsMessage?: string,
    committedActionsDetails?: any,
    ...args: any
  ) {
    super(args);
    this.name = ErrorTypes.UNCOMMITTED_CHANGES_ERROR;
    this.originalError = originalError;
    this.committedActionsMessage = committedActionsMessage;
    this.committedActionsDetails = committedActionsDetails;
  }
}

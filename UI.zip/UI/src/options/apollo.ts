import { InMemoryCacheConfig } from 'umi-plugin-apollo-anz/apolloClient';

export const cacheOptions: InMemoryCacheConfig = {
  typePolicies: {
    UnderlyingNameListOption: {
      keyFields: ['id', 'typeId'],
    },
  },
};

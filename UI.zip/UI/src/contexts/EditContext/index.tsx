import React from 'react';

export type EditingDetails = {
  id: string;
  field: string;
} | null;

export default React.createContext<{
  editing: EditingDetails;
  editableFields: string[];
  setEditing: (details: EditingDetails) => void;
}>({
  editing: null,
  editableFields: [],
  setEditing: () => {},
});

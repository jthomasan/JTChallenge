import React, { MutableRefObject } from 'react';

export const LayoutRefContext = React.createContext<
  MutableRefObject<HTMLElement> | MutableRefObject<null> | null
>(null);

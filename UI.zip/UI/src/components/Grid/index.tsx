import React, {
  useEffect,
  useRef,
  useState,
  SyntheticEvent,
  useMemo,
  useCallback,
  ComponentType,
  MouseEvent,
  KeyboardEvent,
} from 'react';

import { PageLoading } from '@ant-design/pro-layout';
import { SortDescriptor, CompositeFilterDescriptor } from '@progress/kendo-data-query';
import {
  Grid as KendoGrid,
  GridProps as KendoGridProps,
  GridColumnProps as KendoGridColumnProps,
  GridHeaderCellProps as KendoHeaderCellProps,
  GridRowProps,
  GridEvent,
  GridColumn,
  GridColumnMenuFilter,
  GridCellProps,
  GridItemChangeEvent,
} from '@progress/kendo-react-grid';
import { Offset } from '@progress/kendo-react-popup';
import { parseDate, formatDate } from '@telerik/kendo-intl';
import { Alert } from 'antd';
import classnames from 'classnames';
import { debounce } from 'debounce';
import { keyBy, isEqual, cloneDeep, get } from 'lodash';
import { useResizeDetector } from 'react-resize-detector';
import uuid from 'uuid-random';

import ContextMenu, { NodeMenuItemModel, CTXMenuSelectEvent } from '@/components/ContextMenu';
import { dataChangeErrorMessages } from '@/constants/messages';
import { useFallbackToInternalState } from '@/hooks/useFallbackToInternalState';
import { ChangeError } from '@/types/change';
import { ExternalisedStateProps } from '@/types/externalised-state';
import {
  process,
  swapObjectWithIdAndAssignExpandedFlag,
  swapIdWithObject,
} from '@/utils/dataUtils';

import { extractTDProps } from '../SimpleTD';

import styles from './index.less';

interface ColumnVisibility {
  id: string;
  name: string;
  hide: boolean;
}

export interface GridExternalState {
  sortColumns?: SortDescriptor[];
  groupColumns?: any;
  filterColumns?: CompositeFilterDescriptor;
  visibleColumns?: ColumnVisibility[];
  scrollLeft?: number;
  scrollTop?: number;
  gridStateTracker?: any;
}

export interface ColumnExtraProps {
  selector?: any;
  isPrimaryField?: boolean;
}

interface ColumnInfo extends ColumnExtraProps {
  editableCellProps?: ColumnExtraProps;
}

type Value = string | number | boolean | object;

export interface ColumnProps extends Omit<KendoGridColumnProps, 'headerCell'> {
  hidden?: boolean;
  cellWhileOnEditMode?: ComponentType<GridCellProps>;
  internalUseOnly?: boolean;
  sortDisabled?: boolean;
  filterDisabled?: boolean;
  defaultSortColumn?: boolean | 'asc' | 'desc';
  defaultGroupColumn?: boolean;
  onlyEditableOnNew?: boolean;
  enableEditableMode?: (dataItem: any, field: string, value: Value) => boolean;
  extras?: ColumnInfo | any;

  headerCell?: React.ComponentType<
    KendoHeaderCellProps & {
      data: any[];
    }
  >;
}

export interface CellInfo {
  id: string;
  field: string;
  event: SyntheticEvent;
}

export interface FieldHelperProps {
  displayField?: string;
  showValidator?: boolean;
  hideByDefault?: boolean;
  disabled?: boolean;
  [name: string]: any;
}

export interface CellProps extends GridCellProps {
  extras?: FieldHelperProps;
  children?: React.ReactNode;
}

export interface CurrentExpandedGroup {
  field: string;
  value: string;
  expanded: boolean;
}

interface ContextMenuProperty {
  isContextMenuShown: boolean;
  contextMenuOffset: Offset;
}

export interface GridProps<K = GridExternalState> extends Partial<ExternalisedStateProps<K>> {
  loading: boolean;
  currentStateWatcher?: any;
  dataRefreshWatcher?: any;
  contextMenuItems?: (context: any) => NodeMenuItemModel[];
  showColumnVisibility?: boolean;
  className?: string;
  style?: React.CSSProperties;
  editable?: boolean;
  /**
   * If groupable is set to true, it will disable the virtual scrolling of grid
   */
  groupable?: boolean;
  disableVirtualScroll?: boolean;
  /**
   * Group options specify how group function should work
   */
  groupOptions?: {
    /**
     * If fixedGroupColumns are defined, we are grouping the data by group of columns defined here
     * in a specific sequence
     */
    fixedGroupColumns: string[];
  };
  editField?: string;
  totalRecord?: number;
  customRowRender?: (
    row: React.ReactElement<HTMLTableRowElement>,
    props: GridRowProps,
  ) => React.ReactNode;
  customCellRender?: (
    row: React.ReactElement<HTMLTableCellElement | JSX.IntrinsicElements['td']>,
    props: GridCellProps,
  ) => React.ReactNode;
  data: any[] | Map<string, any>;
  columns: ColumnProps[];
  columnVirtualization?: boolean;
  supressCustomCellsDuringScrolling?: boolean;
  onItemChange?: (event: GridItemChangeEvent) => void;
  onContextMenuSelect?: (event: CTXMenuSelectEvent, data?: any) => void;
  onScroll?: (event: GridEvent) => void;
  preSortColumns?: SortDescriptor[];
  pageSize?: number;
  useStandardCellsUnlessEditing?: boolean;
  rowHeight?: KendoGridProps['rowHeight'];
  idField?: string;
}

const defaultExternalState = {
  sortColumns: [],
  scrollLeft: 0,
  scrollTop: 0,
};

function parseDataToDataMap(
  targetMap: Map<string, any>,
  sourceData: Map<string, any> | any[],
  idField: string,
  editFieldName: string,
) {
  // copy data into full map. Data can be either an array or a map
  if (sourceData) {
    if (sourceData instanceof Map) {
      sourceData.forEach((d, key) => {
        targetMap.set(key, d);
      });
    } else {
      sourceData.forEach((d: any) => {
        let id = d[idField];
        if (id == null) {
          id = uuid();
        }

        targetMap.set(id.toString(), { [idField]: id, [editFieldName]: null, ...d });
      });
    }
  }

  return targetMap;
}

const Grid: React.FC<GridProps<GridExternalState>> = (props) => {
  const {
    loading,
    currentStateWatcher = true,
    className,
    supressCustomCellsDuringScrolling,
    style,
    editable,
    groupable,
    editField,
    customRowRender,
    customCellRender,
    totalRecord,
    showColumnVisibility,
    contextMenuItems = () => [],
    data,
    columns,
    columnVirtualization = !groupable,
    onContextMenuSelect,
    externalState: trueExternalState,
    setExternalState: trueSetExternalState,
    onItemChange,
    preSortColumns,
    pageSize: pageSizeProp,
    dataRefreshWatcher,
    useStandardCellsUnlessEditing,
    rowHeight = 26,
    idField = 'id',
    disableVirtualScroll = false,
  } = props;

  const virtualScrollEnabled = !groupable && !disableVirtualScroll;

  const [externalState, setExternalState] = useFallbackToInternalState(
    trueExternalState,
    trueSetExternalState,
    {},
  );

  const state = { ...defaultExternalState, ...externalState };
  const {
    groupColumns,
    sortColumns,
    filterColumns,
    visibleColumns = [],
    gridStateTracker,
    scrollLeft,
    scrollTop,
  } = state;
  const gridContainerRef = useRef<HTMLDivElement | null>(null);
  const { height: gridHeight } = useResizeDetector({
    targetRef: gridContainerRef,
    handleWidth: false,
    handleHeight: typeof pageSizeProp === 'undefined',
  });

  const pageSize =
    typeof pageSizeProp === 'undefined'
      ? Math.ceil(((gridHeight ?? 0) / rowHeight) * 2)
      : pageSizeProp;

  const editMode = useRef(false);
  const editFieldName: string = editField || 'inEdit';

  const [, setScrollX] = useState(0);
  const [isScrolling, setIsScrolling] = useState(false);
  const [skip, setSkip] = useState(0);
  const scrollPosition = useRef({ scrollLeft: 0, scrollTop: 0 });
  const scrollTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [contextMenuProperties, setContextMenuProperties] = useState({} as ContextMenuProperty);
  const [selectedRowData, setSelectedRowData] = useState({});
  const [selectedCellInfo, setSelectedCellInfo] = useState({} as CellInfo);
  const [dataUpdateCount, setDataUpdateCount] = useState(0);
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});
  const fullDataMapRef = useRef<Map<string, any> | null>(null);
  const lastEditedId = useRef<string>();
  const displayListIdsRef = useRef(new Map());

  if (fullDataMapRef.current === null) {
    fullDataMapRef.current = parseDataToDataMap(
      new Map<string, any>(),
      data,
      idField,
      editFieldName,
    );
  }

  const fullDataMap = fullDataMapRef.current;
  const displayListIds = displayListIdsRef.current;

  const updateScrollPositionDebounced = useCallback(
    debounce(({ left, top }: { left: number; top: number }) => {
      if (!(externalState.scrollLeft === left && externalState.scrollTop === top)) {
        scrollPosition.current = { scrollLeft: left, scrollTop: top };
      }
    }, 1000),
    [],
  );

  useEffect(
    () => () => {
      setExternalState(scrollPosition.current);
    },
    [setExternalState, scrollPosition],
  );

  const incrementDataUpdateCount = () => {
    setDataUpdateCount(dataUpdateCount + 1);
  };

  const resetEditFields = () => {
    setSelectedCellInfo({} as CellInfo);
  };

  const resetData = () => {
    fullDataMap.clear();
    parseDataToDataMap(fullDataMap, data, idField, editFieldName);
    incrementDataUpdateCount();
  };

  const resetGridEditing = () => {
    editMode.current = false;
    resetData();
  };

  const setAllColumnsVisible = (visible: boolean = true) => {
    setExternalState({
      visibleColumns: visibleColumns.map((item) => ({
        ...item,
        hide: !visible,
      })),
    });
  };

  const getGridDomElement = () => document.querySelector(`.${className} .k-grid-content`);

  // Scroll to memoized position on grid load
  useEffect(() => {
    if (!loading) {
      const container = getGridDomElement();
      if (container && (typeof scrollLeft !== 'undefined' || typeof scrollTop !== 'undefined')) {
        container.scrollTo(scrollLeft || 0, scrollTop || 0);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading]);

  useEffect(() => {
    if (gridStateTracker !== currentStateWatcher) {
      const container = getGridDomElement();
      if (container) {
        container.scrollTo(scrollLeft || 0, scrollTop || 0);
      }
      setSkip(0);
      resetEditFields();
      setAllColumnsVisible();
      updateScrollPositionDebounced({ left: 0, top: 0 });

      const defaultSortColumn =
        columns.find((c) => c.defaultSortColumn) || (columns[0]?.sortDisabled ? null : columns[0]);
      const defaultGroupColumn = columns.find((c) => c.defaultGroupColumn);

      setExternalState({
        sortColumns:
          defaultSortColumn && defaultSortColumn.field
            ? [
                {
                  dir:
                    typeof defaultSortColumn.defaultSortColumn === 'string'
                      ? defaultSortColumn.defaultSortColumn
                      : 'asc',
                  field: defaultSortColumn.field,
                },
              ]
            : [],
        groupColumns: defaultGroupColumn ? [{ field: defaultGroupColumn.field }] : [],
        filterColumns: undefined,
        gridStateTracker: currentStateWatcher,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStateWatcher]);

  const columnObj = useMemo(() => keyBy(columns, 'field'), [columns]);

  const updateEditField = (rawId: string, event: SyntheticEvent, field: string) => {
    if (rawId && event.type === 'click') {
      editMode.current = true;
      const id = rawId.toString();

      if (lastEditedId.current != null && fullDataMap.has(lastEditedId.current)) {
        const clonedRow = cloneDeep(fullDataMap.get(lastEditedId.current));
        fullDataMap.set(lastEditedId.current, { ...clonedRow, [editFieldName]: null });
      }

      if (fullDataMap.has(id)) {
        const clonedRow = cloneDeep(fullDataMap.get(id));
        fullDataMap.set(id, { ...clonedRow, [editFieldName]: field });
      }
      lastEditedId.current = id;
      incrementDataUpdateCount();
    }
  };

  const rowRender = useCallback(
    (trElement: React.ReactElement<HTMLTableRowElement>, gridRowProps: GridRowProps) => {
      const { modified, errors = {} } = gridRowProps.dataItem;
      const isEdited = typeof modified !== 'undefined' && modified !== false;

      const hasErrors = errors && Object.keys(errors).length;

      const trProps = {
        ...trElement.props,
        className: `${trElement.props.className} ${isEdited && styles.gridEditedRow} ${hasErrors &&
          'has-error'}`,
      };

      if (Array.isArray(trElement.props.children)) {
        // Inject an extra, variable width cell to fill out row
        trElement.props.children.push(<td key="_spacer" />);
      }

      const customElement = React.cloneElement(trElement, { ...trProps }, trElement.props.children);
      return customRowRender ? customRowRender(customElement, gridRowProps) : customElement;
    },
    [customRowRender],
  );

  useEffect(() => {
    type CompareColumn = {
      field?: string;
      title?: string;
      hide: boolean | null;
    };

    const columnsForCompare: CompareColumn[] = columns
      .filter((item) => !item.internalUseOnly)
      .map((item) => ({
        field: item.field,
        title: item.title,
        hide: item.hidden ?? null,
      }));

    const visibleColumnsForCompare: CompareColumn[] = visibleColumns.map((item) => ({
      field: item.id,
      title: item.name,
      hide: item.hide,
    }));

    const areColumnsEqual = columnsForCompare.every((propCol, index) => {
      const visCol = visibleColumnsForCompare[index];

      return (
        visCol &&
        propCol.field === visCol.field &&
        propCol.title === visCol.title &&
        (propCol.hide === null || propCol.hide === visCol.hide)
      );
    });

    if (columns.length > 0 && !areColumnsEqual) {
      setExternalState({
        visibleColumns: columns.reduce((acc: ColumnVisibility[], item) => {
          if (!item.internalUseOnly) {
            acc.push({
              id: item.field,
              name: item.title,
              hide: item.hidden ?? (item.extras?.hideByDefault || false),
            } as ColumnVisibility);
          }
          return acc;
        }, []),
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [columns]);

  const onScroll = (event: GridEvent) => {
    const { scrollLeft: left, scrollTop: top } = event.nativeEvent.target;

    updateScrollPositionDebounced({ left, top });
    setScrollX(left);

    if (!isScrolling) {
      setIsScrolling(true);
    }

    if (scrollTimeout.current !== null) {
      clearTimeout(scrollTimeout.current);
    }
    scrollTimeout.current = setTimeout(() => {
      setIsScrolling(false);
    }, 500);
  };

  const onSortChange = (event: any) => {
    const targetColumn = columns.find((column) => column.field === event.sort[0].field);
    if (targetColumn && !targetColumn.sortDisabled) {
      setExternalState({ sortColumns: event.sort });
    }
  };

  const onFilterChange = (event: any) => {
    setExternalState({ filterColumns: event.filter });
  };

  const onItemChangeOnGrid = (event: GridItemChangeEvent) => {
    if (onItemChange && event.value !== undefined) {
      onItemChange(event);
    }

    resetEditFields();
  };

  const onExpandChange = (event: any) => {
    const { field, value } = event.dataItem;
    const expanded = event.value;

    setExpandedGroups({
      ...expandedGroups,
      [`${field}:${value}`]: expanded,
    });
  };

  const onGroupChange = (event: any) => {
    setExternalState({ groupColumns: event.group });
  };

  useEffect(() => {
    resetEditFields();
    resetData();

    if ([...fullDataMap.values()].findIndex((d) => d[editFieldName]) >= 0) {
      editMode.current = true;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, dataRefreshWatcher]);

  useEffect(() => {
    const { field, event } = selectedCellInfo;
    const id = selectedCellInfo[idField];

    if (!id && !field) {
      resetGridEditing();
    } else {
      updateEditField(id, event, field);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCellInfo, idField]);

  const onContextMenuOpen = (event: MouseEvent) => {
    setContextMenuProperties({
      isContextMenuShown: true,
      contextMenuOffset: {
        top: event.clientY,
        left: event.clientX,
      },
    });
  };

  const onSelectContextMenu = (event: CTXMenuSelectEvent) => {
    if (event.itemId !== 'columnVisibility' && onContextMenuSelect) {
      onContextMenuSelect(event, selectedRowData);
    }
    const itemModel: any = event.item;
    if (itemModel && itemModel.shouldCloseMenuAfterSelect) {
      setContextMenuProperties({
        isContextMenuShown: false,
        contextMenuOffset: {} as Offset,
      });
    }
  };

  const onContextMenuDismiss = () => {
    setContextMenuProperties({
      isContextMenuShown: false,
      contextMenuOffset: {} as Offset,
    });
  };

  const gridColumns: ColumnProps[] = useMemo(() => {
    const hasVisible = visibleColumns.reduce((acc, curr) => acc || !curr.hide, false);

    if (visibleColumns.length > 0 && hasVisible) {
      return visibleColumns.reduce((acc, curr) => {
        if (!curr?.hide) {
          return [...acc, columnObj[curr.id]];
        }
        return [...acc];
      }, [] as ColumnProps[]);
    }

    return [
      {
        field: '',
        filterDisabled: true,
        sortDisabled: true,
        title: '',
        width: '100px',
      } as ColumnProps,
    ];
  }, [visibleColumns, columnObj]);

  const handleColumnVisibility = (id: string) => {
    setExternalState({
      visibleColumns: visibleColumns.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            hide: !item.hide,
          };
        }

        return item;
      }),
    });
  };

  const ContextSubMenuItem = (options: any) => {
    const { text, includeSeparator, children, ...otherProps } = options;

    return (
      <>
        <div
          className={classnames({
            [styles.columnVisibilityOption]: true,
            [styles.hasSeparator]: includeSeparator,
          })}
          {...otherProps}
        >
          {children || <span>{text}</span>}
        </div>
      </>
    );
  };

  const contextMenuItemRender = (item: ColumnVisibility) => (
    <ContextSubMenuItem id={item.id} onClick={() => handleColumnVisibility(item.id)}>
      <input type="checkbox" checked={!item.hide} readOnly />
      <span>{item.name}</span>
    </ContextSubMenuItem>
  );

  const columnVisibilityList = useMemo(() => {
    const menuItems = visibleColumns.map(
      (item) =>
        ({
          value: item.id,
          text: item.name,
          render: contextMenuItemRender.bind({}, item),
        } as NodeMenuItemModel),
    );

    const selectOptions = [
      {
        value: 'show.all',
        render: ContextSubMenuItem.bind(null, { text: 'Show All', onClick: setAllColumnsVisible }),
      },
      {
        value: 'hide.all',
        render: ContextSubMenuItem.bind(null, {
          text: 'Hide All',
          includeSeparator: true,
          onClick: setAllColumnsVisible.bind(null, false),
        }),
      },
    ];

    return [...selectOptions, ...menuItems];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visibleColumns]);

  const modifiedSortColumns = useMemo(() => [...(preSortColumns || []), ...sortColumns], [
    preSortColumns,
    sortColumns,
  ]);

  const processedData = useMemo(
    () =>
      process([...fullDataMap.values()], {
        group: groupColumns,
        sort: modifiedSortColumns,
        filter: filterColumns,
      }).data.map((el) => swapObjectWithIdAndAssignExpandedFlag(el, expandedGroups, idField)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [groupColumns, modifiedSortColumns, filterColumns, dataUpdateCount, expandedGroups, idField],
  );

  const onPageChange = useCallback<NonNullable<KendoGridProps['onPageChange']>>((event) => {
    setSkip(event.page.skip);
  }, []);

  const consolidatedContextMenuItems = useMemo(() => {
    if (showColumnVisibility) {
      return [
        {
          value: 'columnVisibility',
          text: 'Column Visibility',
          subMenus: columnVisibilityList,
        },
        ...contextMenuItems({ selectedRowData }),
      ];
    }

    return contextMenuItems({ selectedRowData });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visibleColumns, showColumnVisibility, contextMenuItems, selectedRowData]);

  const cellRender = useCallback(
    (tdElement: React.ReactElement<JSX.IntrinsicElements['td']>, cellProps: GridCellProps) => {
      if (!tdElement) {
        return null;
      }
      const { dataItem, field = '' } = cellProps;

      const { errors } = dataItem;
      const id = dataItem[idField];
      const inEdit = cellProps.dataItem[editFieldName];

      const fieldParams = columnObj[field] || {};
      const cellInfo = fieldParams.cell as any;

      const cellWhileOnEditMode = fieldParams.cellWhileOnEditMode as any;
      const isNew = cellProps.dataItem.modified === null;
      const onlyEditableOnNew = !!fieldParams.onlyEditableOnNew;
      const isOnEditableMode =
        fieldParams.enableEditableMode &&
        fieldParams.enableEditableMode(dataItem, field, dataItem[field]);
      const isEditableCell =
        (fieldParams?.editable || isOnEditableMode) && (isNew || !onlyEditableOnNew);
      const error: ChangeError = errors && errors[field];
      const isEditing = inEdit === field;

      const additionalProps = {
        fullData: fullDataMap,
        className: classnames(tdElement.props.className, {
          [styles.gridEditingRow]: isEditing,
          'edit-cell-item': isEditableCell,
          [styles.hasError]: !!error,
        }),
        onClick: (event: MouseEvent<HTMLTableCellElement>) => {
          event.persist();

          if (editable && isEditableCell) {
            setSelectedCellInfo({
              id,
              field,
              event,
            });
          } else {
            resetEditFields();
          }
        },
        onContextMenu: (event: MouseEvent<HTMLTableCellElement>) => {
          if (!consolidatedContextMenuItems?.length) {
            return; // Don't prevent default if we have no menu to display
          }

          event.preventDefault();
          onContextMenuOpen(event);
          setSelectedRowData(dataItem);
        },
        onKeyDown: (event: KeyboardEvent<HTMLTableCellElement>) => {
          event.persist();
        },
      };

      const children: any[] = [tdElement.props.children];

      if (error) {
        let errorMsg = '';

        if (error.errorMsg) {
          ({ errorMsg } = error);
        } else {
          errorMsg = dataChangeErrorMessages[error?.errorType || ''];
        }

        children.push(
          <Alert
            key="alert"
            className={styles.errorAlert}
            message={errorMsg}
            type="error"
            showIcon
          />,
        );
      }

      let customTDElement = tdElement;
      let customChildren = children;

      if (
        cellInfo &&
        cellInfo?.displayCustomCell !== false &&
        (!useStandardCellsUnlessEditing || isEditing || cellInfo?.displayCustomCell)
      ) {
        if (
          isScrolling &&
          !displayListIds.has(dataItem[idField]) &&
          supressCustomCellsDuringScrolling
        ) {
          return (
            <td>
              <span className="k-placeholder-line" />
            </td>
          );
        }

        const Cell = cellInfo as any;
        const el = (
          <Cell
            extras={fieldParams.extras}
            {...cellProps}
            {...fieldParams}
            additionalProps={additionalProps}
          />
        );
        customTDElement = el;
      }

      if (cellWhileOnEditMode && isEditing) {
        const Cell = cellWhileOnEditMode as any;
        const editableCellProps = fieldParams.extras?.editableCellProps || {};

        const el = (
          <Cell
            extras={editableCellProps}
            {...cellProps}
            {...fieldParams}
            additionalProps={additionalProps}
          />
        );
        customTDElement = el;
      }

      if (fieldParams.format && fieldParams.filter === 'date') {
        const [dateCell, ...rest] = children;
        customChildren = [formatDate(parseDate(dateCell), fieldParams.format)];

        // append error elements if there are errors
        if (rest) {
          customChildren = customChildren.concat(rest);
        }
      }

      if (fieldParams.extras?.displayRenderer && !isEditing) {
        const [, ...rest] = children;
        const { displayRenderer } = fieldParams.extras;
        const value = get(dataItem, fieldParams.field || '');

        customChildren = [displayRenderer(value, field, dataItem)];

        if (rest) {
          customChildren = customChildren.concat(rest);
        }
      }

      if (cellInfo?.cellName && !isEditing) {
        additionalProps.className = `${additionalProps.className} ${cellInfo?.cellName} ${
          cellInfo?.cellName
        }${customChildren[0] ? '-' : ''}${customChildren[0]}`;

        customChildren = [''];
      }

      const customElement = React.cloneElement(
        customTDElement,
        extractTDProps({ ...tdElement.props, ...additionalProps }),
        customChildren,
      );

      return customCellRender ? customCellRender(customElement, cellProps) : customElement;
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [customCellRender, columnObj, editable, idField, isScrolling],
  );

  const finalData = useMemo(
    () => processedData.map((o) => swapIdWithObject(o, (id) => fullDataMap.get(id.toString()))),
    [processedData, fullDataMap],
  );

  const children = useMemo(
    () =>
      gridColumns.map((c) => {
        if (!c) return null;

        const headerCell: KendoGridColumnProps['headerCell'] = !c.headerCell
          ? undefined
          : (headerCellProps) => {
              const HeaderCell = c.headerCell as NonNullable<ColumnProps['headerCell']>;
              return <HeaderCell {...headerCellProps} data={finalData} />;
            };

        return (
          <GridColumn
            key={c.field}
            {...c}
            format=""
            headerClassName={classnames(c.headerClassName, {
              'filter-active': GridColumnMenuFilter.active(c.field || '', filterColumns),
            })}
            headerCell={headerCell}
            cell={null as any}
            columnMenu={
              c.filterable !== false
                ? (filterProps: any) => (
                    <div className={styles.gridColumnMenuFilter}>
                      <GridColumnMenuFilter {...filterProps} expanded />
                    </div>
                  )
                : null
            }
          />
        );
      }),
    [gridColumns, filterColumns, finalData],
  );

  const pagedData = (!virtualScrollEnabled
    ? processedData
    : processedData.slice(
        skip,
        skip + Math.max(1, pageSize), // Slice at least 1 from the dataset to avoid "No Data..." flashing when height is 0 (before useResizeDetector has a chance to trigger)
      )
  ).map((o) => swapIdWithObject(o, (id) => fullDataMap.get(id.toString())));

  useEffect(() => {
    if (!isScrolling) {
      displayListIds.clear();
      pagedData.forEach((i) => {
        displayListIds.set(i[idField], i[idField]);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isScrolling]);

  return (
    <div ref={gridContainerRef} className={styles.gridContainer}>
      {loading || externalState.gridStateTracker !== currentStateWatcher ? (
        <PageLoading />
      ) : (
        <>
          <KendoGrid
            className={`${
              editMode.current ? styles.gridEditMode : styles.gridReadOnlyMode
            } ${className} ${styles.theGrid}`}
            style={style}
            editField={editField}
            rowHeight={rowHeight}
            groupable={groupable}
            sortable={{
              allowUnsort: false,
              mode: 'single',
            }}
            group={groupColumns}
            sort={modifiedSortColumns}
            filter={filterColumns}
            resizable
            reorderable
            scrollable={virtualScrollEnabled ? 'virtual' : 'scrollable'}
            columnVirtualization={columnVirtualization}
            pageSize={pageSize}
            skip={skip}
            total={totalRecord || processedData.length}
            rowRender={rowRender}
            cellRender={cellRender as any}
            data={pagedData}
            onSortChange={onSortChange}
            onItemChange={onItemChangeOnGrid}
            onPageChange={onPageChange}
            onFilterChange={onFilterChange}
            onScroll={onScroll}
            onGroupChange={onGroupChange}
            onExpandChange={onExpandChange}
            expandField="expanded"
          >
            {children}
          </KendoGrid>
          {consolidatedContextMenuItems && consolidatedContextMenuItems.length > 0 && (
            <ContextMenu
              items={consolidatedContextMenuItems}
              isContextMenuShown={contextMenuProperties.isContextMenuShown}
              contextMenuOffset={contextMenuProperties.contextMenuOffset}
              onSelect={onSelectContextMenu}
              onContextMenuDismiss={onContextMenuDismiss}
            />
          )}
        </>
      )}
    </div>
  );
};

export default React.memo(Grid, (prev, next) => isEqual(prev, next));

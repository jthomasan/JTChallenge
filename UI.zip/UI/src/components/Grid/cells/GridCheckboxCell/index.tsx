import React from 'react';
import { get } from 'lodash';
import { CellProps } from '@/components/Grid';
import SimpleTD from '@/components/SimpleTD';

interface GridCheckboxCellProps extends CellProps {}

const GridCheckboxCell: React.FC<GridCheckboxCellProps> = ({
  extras = {},
  dataItem,
  field = '',
  ...props
}) => {
  const { disabled } = extras;
  const isChecked = get(dataItem, field);

  return (
    <SimpleTD {...props}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
        }}
      >
        <input type="checkbox" disabled={disabled} checked={isChecked} />
      </div>
    </SimpleTD>
  );
};

export default GridCheckboxCell;

import { get, without, difference, chain, intersection } from 'lodash';
import React from 'react';
import SimpleTD from '@/components/SimpleTD';
import { mapToDataItemsOnly } from '@/utils/dataUtils';
import { ColumnProps } from '..';
import styles from './getSelectionColumn.less';

type IdentifierFunction = (dataItem: any) => string;
type Identifier = string | [string, IdentifierFunction];

export interface GetSelectionColumnOptions {
  identifier: Identifier;
  selected?: string[];
  disabled?: boolean;
  onChange: (newSelected: string[]) => void;
}

interface BaseGenerateOnSelectOptions {
  onChange: GetSelectionColumnOptions['onChange'];
  selected: GetSelectionColumnOptions['selected'];
}

interface GenerateOnSelectAllOptions extends BaseGenerateOnSelectOptions {
  data: any[];
  identifier: GetSelectionColumnOptions['identifier'];
}

const identify = (dataItem: any, identifier: Identifier): string =>
  typeof identifier === 'object' ? identifier[1](dataItem) : get(dataItem, identifier);

const chainFlattenAndIdentify = (data: any[], identifier: Identifier) =>
  chain(data)
    .flatMap(mapToDataItemsOnly)
    .map((dataItem) => identify(dataItem, identifier));

function generateOnSelect({ onChange, selected }: BaseGenerateOnSelectOptions) {
  if (!onChange) {
    return undefined;
  }

  return (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();

    if (e.target.checked) {
      onChange(selected ? [...selected, e.target.value] : [e.target.value]);
    } else {
      onChange(selected ? without(selected, e.target.value) : []);
    }
  };
}

function generateOnSelectAll({ onChange, selected, identifier, data }: GenerateOnSelectAllOptions) {
  if (!onChange) {
    return undefined;
  }

  return (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();

    if (e.target.checked) {
      onChange(
        chainFlattenAndIdentify(data, identifier)
          .union(selected)
          .value(),
      );
    } else if (selected) {
      onChange(difference(selected, chainFlattenAndIdentify(data, identifier).value()));
    }
  };
}

export const getSelectionColumn = ({
  identifier,
  selected,
  disabled,
  onChange,
}: GetSelectionColumnOptions) => {
  const rowOnChange = generateOnSelect({
    onChange,
    selected,
  });

  const identifierName = typeof identifier === 'object' ? identifier[0] : identifier;

  const column: ColumnProps = {
    field: `_selected-${identifierName}`,
    width: 25,
    filterable: false,
    resizable: false,
    cell: ({ dataItem, ...props }) => {
      const currentIdentifier = identify(dataItem, identifier);

      return (
        <SimpleTD {...props} style={{ lineHeight: 0, textOverflow: 'unset' }}>
          <input
            type="checkbox"
            disabled={disabled}
            checked={selected ? selected.indexOf(currentIdentifier) >= 0 : false}
            onChange={rowOnChange}
            value={currentIdentifier}
          />
        </SimpleTD>
      );
    },
    headerClassName: styles.selectorHeader,
    headerCell: ({ data }) => {
      const flattenedData = chainFlattenAndIdentify(data, identifier).value();

      return (
        <input
          type="checkbox"
          disabled={disabled}
          checked={
            data?.length > 0 &&
            selected &&
            selected.length > 0 &&
            intersection(selected, flattenedData).length === flattenedData.length
          }
          onChange={generateOnSelectAll({
            onChange,
            selected,
            identifier,
            data,
          })}
        />
      );
    },
  };

  return column;
};

import React from 'react';
import { shallow } from 'enzyme';
import { Grid as KendoGrid } from '@progress/kendo-react-grid';
import Grid from './index';

describe('GridTest', () => {
  let wrapper = null;
  const mockSetExternalState = jest.fn();

  beforeEach(() => {
    wrapper = shallow(
      <Grid
        data={[
          { title: 'test', fullPath: 'test', addedTime: 'test' },
          { title: 'test1', fullPath: 'test1', addedTime: 'test1' },
          { title: 'test2', fullPath: 'test2', addedTime: 'test2' },
        ]}
        columns={[
          { field: 'title', width: '100px', title: 'Name' },
          { field: 'fullPath', width: '100px', title: 'Full path', sortDisabled: true },
          { field: 'addedTime', width: '100px', title: 'Added time' },
        ]}
        externalState={{ sortColumns: [], gridStateTracker: true }}
        setExternalState={mockSetExternalState}
      />,
      { lifecycleExperimental: true },
    );
  });

  it('should sort handler change sort to right state if column required sort', () => {
    const grid = wrapper.find(KendoGrid);
    const sortColumns = [
      {
        dir: 'asc',
        field: 'title',
      },
    ];
    const event = {
      sort: sortColumns,
    };
    grid.prop('onSortChange')(event);

    expect(mockSetExternalState).toBeCalledWith({ sortColumns });
  });
});

import { _unmock as unmockReact } from 'react';
import { renderHook, act } from '@testing-library/react-hooks';

import useDataFilter, { FilterableColumnProps } from '.';

describe('useDataFilter', () => {
  beforeEach(() => {
    unmockReact();
  });
  it('filters data for only specified columns', () => {
    const columns: FilterableColumnProps[] = [
      {
        field: 'a',
        enableSimpleFilter: true,
      },
      {
        field: 'b',
      },
      {
        title: 'no field',
      },
    ];
    const data: any[] = [
      {
        a: 'ABA',
      },
      {
        a: 'BaB',
      },
      {
        b: 'AB',
      },
      {
        b: 'BA',
      },
    ];

    const { result, rerender } = renderHook(
      (props) =>
        useDataFilter({
          columns: props.columns,
          data: props.data,
          filter: props.filter,
        }),
      {
        initialProps: {
          filter: '',
          columns,
          data,
        },
      },
    );

    expect(result.current).toBe(data);

    act(() => {
      rerender({
        filter: 'AB',
        columns,
        data,
      });
    });

    expect(result.current).toStrictEqual([data[0], data[1]]);

    act(() => {
      rerender({
        filter: 'AB',
        columns: columns.map((column) => ({ ...column, enableSimpleFilter: true })),
        data,
      });
    });

    expect(result.current).toStrictEqual([data[0], data[1], data[2]]);
  });

  it('filters data as the input data changes', () => {
    const columns: FilterableColumnProps[] = [
      {
        field: 'a',
        enableSimpleFilter: true,
      },
    ];
    const data: any[] = [
      {
        a: 'ABA',
      },
      {
        a: 'BaB',
      },
    ];

    const { result, rerender } = renderHook(
      (props) =>
        useDataFilter({
          columns: props.columns,
          data: props.data,
          filter: props.filter,
        }),
      {
        initialProps: {
          filter: 'AB',
          columns,
          data,
        },
      },
    );

    expect(result.current).toStrictEqual(data);

    act(() => {
      rerender({
        filter: 'AB',
        columns,
        data: [data[0]],
      });
    });

    expect(result.current).toStrictEqual([data[0]]);
  });
});

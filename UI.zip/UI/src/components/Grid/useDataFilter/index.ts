import { get } from 'lodash';
import { useMemo } from 'react';
import { ColumnProps } from '..';

export interface FilterableColumnProps extends ColumnProps {
  enableSimpleFilter?: boolean;
}

export default function useDataFilter({
  data,
  filter,
  columns,
}: {
  data: any[];
  columns: FilterableColumnProps[];
  filter?: string;
}) {
  const columnsForFilter = useMemo(
    () =>
      columns.filter(
        (column) => !!column.field && column.enableSimpleFilter,
      ) as (FilterableColumnProps & Required<Pick<FilterableColumnProps, 'field'>>)[],
    [columns],
  );

  const filterIndex = useMemo(
    () =>
      data?.map<[string, any]>((row) => [
        columnsForFilter
          .map(
            ({ field }) =>
              get(row, field)
                ?.toString?.()
                .toUpperCase() ?? '',
          )
          .join('::'),
        row,
      ]),
    [data, columnsForFilter],
  );

  const filteredData = useMemo(() => {
    if (!filter || !filterIndex) {
      return null;
    }

    const upperCaseFilter = filter.trim().toUpperCase();

    return filterIndex
      .filter(([stringToTest]) => stringToTest.indexOf(upperCaseFilter) >= 0)
      .map(([, row]) => row);
  }, [filter, filterIndex]);

  return filteredData ?? data;
}

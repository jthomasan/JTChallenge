import React, { PropsWithChildren } from 'react';
import { Select } from 'antd';
import { SelectProps, SelectValue } from 'antd/lib/select';
import styles from './index.less';

interface hi<P> extends React.FC<P> {
  <T = SelectValue>(props: PropsWithChildren<SelectProps<T>>): JSX.Element;
}
const SelectWrapper: hi<SelectProps> = (props: PropsWithChildren<SelectProps<SelectValue>>) => (
  <div className={styles.select}>
    <Select {...props} />
  </div>
);

export default SelectWrapper;

export { SelectProps } from 'antd/lib/select';
export const { Option } = Select;

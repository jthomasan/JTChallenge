import React, { _mockUseEffect } from 'react';
import { mount } from 'enzyme';
import SimpleTD from '@/components/SimpleTD';
import TreeListCheckboxCell from './index';

_mockUseEffect(jest.fn((fn) => fn()));

const dataItem = {
  id: '6976',
  modified: false,
  parent: '6670',
  title: 'Monitored Portfolios',
  isForHoldingPeriod: true,
  excludeInternalTrades: false,
  added: { by: 'thomaj29', time: '2021-04-21T00:51:41', __typename: 'Added' },
  __typename: 'HoldingPeriodNode',
};

const dataItemForFalse = {
  id: '6976',
  modified: false,
  parent: '6670',
  title: 'Monitored Portfolios',
  isForHoldingPeriod: false,
  excludeInternalTrades: false,
  added: { by: 'thomaj29', time: '2021-04-21T00:51:41', __typename: 'Added' },
  __typename: 'HoldingPeriodNode',
};

describe('Configuration TreeListCheckBoxCell Data Tests', () => {
  let wrapper = null;
  let wrapperFalse = null;

  beforeEach(() => {
    wrapper = mount(<TreeListCheckboxCell field="isForHoldingPeriod" dataItem={dataItem} />);
    wrapperFalse = mount(
      <TreeListCheckboxCell field="isForHoldingPeriod" dataItem={dataItemForFalse} />,
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should mount the component with td', () => {
    expect(wrapper.find(SimpleTD)).toHaveLength(1);
  });

  it('should have the expected true attribute', () => {
    expect(wrapper.find(SimpleTD).prop('className')).toEqual(
      'treeListCheckboxCell true notEditing',
    );
  });

  it('should have the expected false attribute for second data set', () => {
    expect(wrapperFalse.find(SimpleTD).prop('className')).toEqual(
      'treeListCheckboxCell false notEditing',
    );
  });
});

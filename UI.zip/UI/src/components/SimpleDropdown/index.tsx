import { useOnClickOutside, ClickOutsideEvent } from '@/hooks/useOnClickOutside';
import { Popup } from '@progress/kendo-react-popup';
import React, { useState, useRef } from 'react';

interface SimpleDropdown {
  multiple?: boolean;
  menu: React.ReactElement;
  open?: boolean;
  className?: string;
  onOpenChange?: (open: boolean, e: ClickOutsideEvent | React.MouseEvent<HTMLDivElement>) => void;
  popupRef?: React.RefObject<HTMLDivElement>;
}

const SimpleDropdown: React.FC<SimpleDropdown> = ({
  multiple,
  menu,
  onOpenChange,
  open,
  popupRef,
  ...props
}) => {
  const localPopupRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLDivElement>(null);
  const [openState, setOpenState] = useState(false);

  const openPropPresent = open !== null && open !== undefined;
  const finalOpen = openPropPresent ? open : openState;

  useOnClickOutside(popupRef ?? localPopupRef, (e) => {
    if (!buttonRef.current || buttonRef.current.contains(e.target as Node)) {
      return;
    }

    // eslint-disable-next-line no-unused-expressions
    onOpenChange?.(false, e);

    if (!openPropPresent) {
      setOpenState(false);
    }
  });

  return (
    <>
      <div
        ref={buttonRef}
        onClick={(e) => {
          e.preventDefault();

          // eslint-disable-next-line no-unused-expressions
          onOpenChange?.(!finalOpen, e);

          if (!openPropPresent) {
            setOpenState(!finalOpen);
          }
        }}
        {...props}
      />
      <Popup anchor={buttonRef.current ?? undefined} show={finalOpen} animate={false}>
        <div ref={popupRef ?? localPopupRef}>{menu}</div>
      </Popup>
    </>
  );
};

export default SimpleDropdown;

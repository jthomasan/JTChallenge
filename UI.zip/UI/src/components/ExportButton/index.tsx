/* eslint-disable no-unused-expressions */
import React, { useState } from 'react';
import Button, { ButtonProps } from 'antd/lib/button';
import { Tooltip } from 'antd';
import { stringify } from 'qs';

interface ExportButtonProps<T extends Record<string, any> = Record<string, any>>
  extends Omit<ButtonProps, 'onClick'> {
  url?: string;
  params?: T;
  exporting?: boolean;
  onExport?: () => void;
  onExportingChange?: (exporting: boolean) => void;
}

const ExportButton: <T extends Record<string, any> = Record<string, any>>(
  props: ExportButtonProps<T>,
) => React.ReactElement<any, any> | null = ({
  url,
  exporting: externalExporting,
  onExport,
  onExportingChange,
  params = null,
  ...props
}) => {
  const [tooltipVisible, setTooltipVisible] = useState(false);
  const [internalExporting, setExporting] = useState(false);

  const exporting = externalExporting ?? internalExporting;
  const disabled = props.disabled || exporting;

  return (
    <Tooltip
      placement="bottomRight"
      title={exporting ? 'Exporting...' : 'Export to CSV'}
      visible={tooltipVisible || exporting}
      onVisibleChange={(visible) => setTooltipVisible(visible)}
      destroyTooltipOnHide
    >
      <Button
        icon={exporting ? 'loading' : 'download'}
        {...props}
        disabled={disabled}
        onClick={() => {
          if (disabled) {
            return;
          }

          setExporting(true);
          onExportingChange?.(true);

          const searchParams = params ? `?${stringify(params, { arrayFormat: 'comma' })}` : '';
          window.location.href = `${url}${searchParams}`;
          onExport?.();

          setTimeout(() => {
            setExporting(false);
            onExportingChange?.(false);
          }, 1000);
        }}
      />
    </Tooltip>
  );
};

export default ExportButton;

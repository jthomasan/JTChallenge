import React, { useState, useEffect } from 'react';
import { Splitter } from '@progress/kendo-react-layout';
import { Grid, GridColumn, GridEvent } from '@progress/kendo-react-grid';
import { useGQLComponentState } from 'umi-plugin-apollo-anz/apolloComponentState';
// eslint-disable-next-line import/no-extraneous-dependencies
import {
  SaveFilled,
  SaveOutlined,
  ExclamationCircleFilled,
  CloseCircleOutlined,
  RollbackOutlined,
  CaretDownFilled,
  CaretUpFilled,
} from '@ant-design/icons';
import classnames from 'classnames';
import { setIn } from 'immutable';
import { Change, ChangeError } from '@/types/change';
import ActionCell from '@/components/UncommittedChanges/ActionCell';
import CustomCell from '@/components/UncommittedChanges/CustomCell';
import { message, Popconfirm } from 'antd';
import { noop } from 'lodash';
import styles from './index.less';

export enum CellField {
  Action = 'action',
  SourceType = 'sourceType',
  SourceField = 'sourceField',
  From = 'from',
  To = 'to',
  Details = 'details',
}
export interface SplitViewProps {
  changes: Change[];
  changeErrors: ChangeError[];
  onRefresh: () => void;
  onUndo: () => void;
  onSave: () => void;
  className: string;
  children: any;
}

const defaultPanes = [{}, { size: '150px', scrollable: false, min: '24px', def: '150px' }];

const SplitView: React.FC<SplitViewProps> = (props) => {
  const {
    changes,
    changeErrors,
    children,
    onUndo: propsUndo,
    onRefresh: propsRefresh,
    onSave: propsSave,
    className,
  } = props;

  const [panePersistedState, updatePanePersistedState] = useGQLComponentState(
    defaultPanes,
    'splitter',
  );
  const [paneState, updatePaneState] = useState(panePersistedState);
  const [hasScrolled, updateHasScrolled] = useState(false);

  const isCollapsed = paneState[1] && paneState[1].size === paneState[1].min;

  const randomClassName = `cs-${Math.random()
    .toString(36)
    .substring(2, 15)}`;

  let timeout: number = 0;
  const onPaneLayoutChange = (updatedLayout: any) => {
    updatePaneState(updatedLayout);

    if (timeout) {
      clearTimeout(timeout);
    }
    timeout = window.setTimeout(() => {
      updatePanePersistedState(updatedLayout);
    }, 3000);
  };

  const onScroll = (event: GridEvent) => {
    const { scrollTop } = event.nativeEvent.target;
    const container = document.querySelector(`.${randomClassName} .k-grid-content`);

    if (container) {
      const maxScroll = container.scrollHeight - container.clientHeight;
      updateHasScrolled(scrollTop !== maxScroll);
    }
  };

  const onMinMax = () => {
    const { min, def } = paneState[1];
    const newPane = setIn(paneState[1], ['size'], isCollapsed ? def : min);
    const newPaneState = setIn(paneState, [1], newPane);
    updatePanePersistedState(newPaneState);
    updatePaneState(newPaneState);
  };

  useEffect(() => {
    const container = document.querySelector(`.${randomClassName} .k-grid-content`);

    if (container && !hasScrolled) {
      const maxScroll = container.scrollHeight - container.clientHeight;
      container.scrollTo(0, maxScroll);
    }
  });

  const onUndo = () => {
    propsUndo();
    message.success('Undo');
  };

  const onRefresh = () => {
    propsRefresh();
  };

  const onSave = () => {
    propsSave();
  };

  const hasErrors = changeErrors && changeErrors.length;

  return (
    <Splitter
      className={`${className} changeSplitView`}
      panes={paneState}
      orientation="vertical"
      onLayoutChange={onPaneLayoutChange}
    >
      <div className={styles.contentPane}>{children}</div>

      {changes.length && (
        <div className={styles.changesPane}>
          <div className={styles.actionBar}>
            <div className={styles.minMax} onClick={onMinMax}>
              {isCollapsed ? (
                <CaretUpFilled title="Expand" />
              ) : (
                <CaretDownFilled title="Collapse" />
              )}
            </div>
            <span className={styles.message}>
              <strong>
                There {changes.length > 1 ? 'are' : 'is'} {changes.length} uncommitted change
                {changes.length > 1 ? 's' : ''} {isCollapsed ? '' : 'shown below.'}
              </strong>
              <span>Click Save to commit change{changes.length > 1 ? 's' : ''}.</span>
            </span>

            <div className={styles.actionButtons}>
              <div className={styles.saveButton}>
                <Popconfirm
                  title={hasErrors ? 'Fix all errors before saving' : 'Save all changes?'}
                  onConfirm={hasErrors ? noop : onSave}
                  okText={hasErrors ? 'OK' : 'Save'}
                  cancelText="No"
                  cancelButtonProps={{ style: { display: hasErrors ? 'none' : 'inline-block' } }}
                  icon={
                    hasErrors ? (
                      <span className={styles.popIconWarning}>
                        <ExclamationCircleFilled title="Warning" />
                      </span>
                    ) : (
                      <span className={styles.popIcon}>
                        <SaveOutlined title="Save" />
                      </span>
                    )
                  }
                >
                  <div>
                    <SaveFilled title="Save" />{' '}
                    <strong>
                      <span>Save</span>
                    </strong>
                  </div>
                </Popconfirm>
              </div>
              <div className={styles.cancelButton}>
                <Popconfirm
                  title="Discard changes and refresh?"
                  onConfirm={onRefresh}
                  okText="Refresh"
                  cancelText="No"
                  icon={
                    <span className={styles.popIcon}>
                      <CloseCircleOutlined title="Cancel" />
                    </span>
                  }
                >
                  <div>
                    <CloseCircleOutlined title="Cancel" /> <span>Cancel</span>
                  </div>
                </Popconfirm>
              </div>
              <div className={styles.undoButton} onClick={onUndo}>
                <RollbackOutlined title="Undo" /> <span>Undo</span>
              </div>
            </div>
          </div>
          <div className={styles.gridWrapper}>
            <Grid
              className={classnames({ [randomClassName]: true, [styles.changesGrid]: true })}
              data={changes}
              resizable
              style={{
                height: '100%',
                lineHeight: '18px',
              }}
              onScroll={onScroll}
            >
              <GridColumn field={CellField.Action} width="100px" title="Action" cell={ActionCell} />
              <GridColumn field={CellField.SourceType} width="220px" title="For" />
              <GridColumn
                field={CellField.SourceField}
                width="150px"
                title="Field"
                cell={CustomCell}
              />
              <GridColumn field={CellField.From} width="180px" title="From" cell={CustomCell} />
              <GridColumn field={CellField.To} width="180px" title="To" cell={CustomCell} />
              <GridColumn field={CellField.Details} title="Details" />
            </Grid>
          </div>
        </div>
      )}
    </Splitter>
  );
};

export default SplitView;

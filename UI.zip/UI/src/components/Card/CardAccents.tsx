import React from 'react';
import classnames from 'classnames';
import styles from './CardAccents.less';

interface ClassNameProps {
  className?: string;
  style?: React.CSSProperties;
}

const wrapDiv = <T extends {}>(
  baseClassName: string | ((props: T) => string),
): React.FC<ClassNameProps & T> => (props) => (
  <div
    className={classnames(
      props.className,
      typeof baseClassName === 'string' ? baseClassName : baseClassName(props),
    )}
    style={props.style}
  >
    {props.children}
  </div>
);

export const CardBody: React.FC<JSX.IntrinsicElements['div']> = ({
  className,
  children,
  ...props
}) => (
  <div className={classnames(className, styles.cardBody)} {...props}>
    {children}
  </div>
);

export const CardTopBar = wrapDiv(styles.cardAccent);

export const AccentGroup = wrapDiv<{ align?: 'right' | 'left' }>(({ align }) =>
  classnames(styles.cardAccentGroup, { [styles.cardAccentGroupRight]: align === 'right' }),
);

import React, { ReactNode, ReactNodeArray } from 'react';
import classnames from 'classnames';

import styles from './index.less';

export interface CardProps {
  title?: string;
  subTitle?: string;
  actions?: ReactNode | ReactNodeArray;
  className?: string;
  padded?: boolean;
  fullPageCard?: boolean;
}

const Card: React.FC<CardProps> = (props) => {
  const {
    title,
    subTitle,
    actions,
    className,
    padded = true,
    fullPageCard = false,
    children,
  } = props;

  return (
    <div className={`${className || ''} ${styles.card}`}>
      <div className={styles.cardHead}>
        <div className={styles.cardHeadTitle}>
          {title || null}
          <small className={styles.cardHeadSubTitle}>{subTitle ? `(${subTitle})` : ''}</small>
        </div>
        <div className={styles.cardHeadActions}>{actions}</div>
      </div>
      <div
        className={classnames(styles.cardBody, {
          [styles.cardBodyPadded]: padded,
          [styles.cardBodyFullPage]: fullPageCard,
        })}
      >
        {children}
      </div>
    </div>
  );
};

export default Card;

export * from './CardAccents';

// eslint-disable-next-line import/no-duplicates
import React from 'react';
// eslint-disable-next-line import/no-duplicates
import * as reactFnc from 'react';
import { mount } from 'enzyme';

import ContextMenu from './index';

// eslint-disable-next-line no-underscore-dangle
reactFnc._mockUseEffect(jest.fn((fn) => fn()));

describe('Test Context Menu Component', () => {
  let wrapper = null;
  const mockDismissFn = jest.fn();
  const mockSelectFn = jest.fn();
  beforeAll(() => {
    const div = document.createElement('div');
    div.setAttribute('id', 'container');
    document.body.appendChild(div);

    wrapper = mount(
      <ContextMenu
        items={[
          { value: 'add', text: 'Add' },
          { value: 'rename', text: 'Rename' },
          { value: 'delete', text: 'Delete' },
          { value: 'classf', text: 'Apply Classification' },
        ]}
        isContextMenuShown
        contextMenuOffset={{
          left: 201,
          top: 121,
        }}
        onContextMenuDismiss={mockDismissFn}
        onSelect={mockSelectFn}
      />,
      { lifecycleExperimental: true, attachTo: div },
    );
  });

  afterAll(() => {
    const div = document.getElementById('container');
    if (div) {
      document.body.removeChild(div);
    }
  });

  it('should Context Menu be mounted with Popup Component', () => {
    expect(wrapper.find('Popup')).toHaveLength(1);
    expect(wrapper.find('MenuItemLink')).toHaveLength(4);
  });

  it('should not call dismiss action on click inside the component', () => {
    wrapper
      .find(ContextMenu)
      .find('.popup-content')
      .getDOMNode()
      .click();
    expect(mockDismissFn).not.toHaveBeenCalled();
  });

  it('should call dismiss action on click outside the component', () => {
    wrapper
      .find('.menuOverlay')
      .getDOMNode()
      .click();
    expect(mockDismissFn).toHaveBeenCalled();
  });

  it('should both click and right click the menu item trigger item selection', () => {
    const addOption = wrapper.find('div[children="Add"]');
    addOption.simulate('click');
    expect(mockSelectFn).toHaveBeenCalled();
    addOption.simulate('contextmenu');
    expect(mockSelectFn).toHaveBeenCalled();
  });
});

import React, { useRef, MutableRefObject, useMemo, SyntheticEvent } from 'react';
import { Popup, Offset } from '@progress/kendo-react-popup';
import { Menu, MenuItemModel, MenuItem } from '@progress/kendo-react-layout';
import classnames from 'classnames';

import styles from './index.less';

export interface CTXMenuSelectEvent {
  itemId: string;
  item: MenuItemModel;
  nativeEvent: any;
}

export interface NodeMenuItemModel extends MenuItemModel {
  value: string;
  subMenus?: NodeMenuItemModel[];
  shouldCloseMenuAfterSelect?: boolean;
}

interface ContextMenuProps {
  items: NodeMenuItemModel[];
  isContextMenuShown: boolean;
  contextMenuOffset: Offset;
  onContextMenuDismiss: () => void;
  onSelect: (event: CTXMenuSelectEvent) => void;
}

const ContextMenu: React.FC<ContextMenuProps> = (props) => {
  const wrapperRef: MutableRefObject<HTMLDivElement | null> = useRef(null);
  const { items, isContextMenuShown, contextMenuOffset, onContextMenuDismiss, onSelect } = props;

  const renderCustomItem = ({ itemId, item }: { itemId: string; item: NodeMenuItemModel }) => (
    <div
      className={styles.customItem}
      onClick={(e) => {
        onSelect({ itemId, item, nativeEvent: e });
      }}
    >
      {item.text}
    </div>
  );

  const getContextMenu = (contextMenus: NodeMenuItemModel[]) =>
    contextMenus.map((item) => (
      <MenuItem
        key={item.value}
        text={item.text}
        render={() => {
          if (item.render) {
            return item.render(item);
          }
          return renderCustomItem({ itemId: item.value, item });
        }}
        disabled={item.disabled}
      >
        {Array.isArray(item.subMenus) && getContextMenu(item.subMenus)}
      </MenuItem>
    ));

  // Create ids for avoid closing the menu when mouse leaves
  const customCloseItemIds = useMemo(() => {
    const getIds = (menus: NodeMenuItemModel[], count?: number) =>
      menus.reduce((acc, curr, index): any => {
        if (curr.subMenus && curr.subMenus.length > 0) {
          return [...acc, index.toString(), ...getIds(curr.subMenus, index)];
        }

        return count !== undefined ? [...acc, `${count}_${index}`] : [...acc, index.toString()];
      }, []);

    return getIds(items);
  }, [items]);

  const dismissMenu = (e: SyntheticEvent) => {
    e.stopPropagation();
    e.preventDefault();
    onContextMenuDismiss();
  };

  return (
    <>
      <div
        onClick={dismissMenu}
        onContextMenu={dismissMenu}
        className={classnames({
          menuOverlay: true,
          [styles.menuOverlay]: true,
          [styles.menuShown]: isContextMenuShown,
        })}
      >
        <Popup show={isContextMenuShown} offset={contextMenuOffset} animate={false}>
          <div onClick={(e) => e.stopPropagation()} className="popup-content" ref={wrapperRef}>
            <Menu customCloseItemIds={customCloseItemIds} className={styles.menu} vertical>
              {items?.length > 0 && getContextMenu(items)}
            </Menu>
          </div>
        </Popup>
      </div>
    </>
  );
};

export default ContextMenu;

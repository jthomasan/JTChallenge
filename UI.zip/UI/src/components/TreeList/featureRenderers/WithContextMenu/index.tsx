import React, { useState } from 'react';

import { Offset } from '@progress/kendo-react-popup';

import ContextMenu, { NodeMenuItemModel, CTXMenuSelectEvent } from '@/components/ContextMenu';

import { TreeListProps, TreeListExternalState } from '../../index';

interface ContextMenuProperty {
  isContextMenuShown: boolean;
  contextMenuOffset: Offset;
  dataItem: any;
}

interface WithContextMenuProps extends TreeListProps<TreeListExternalState> {
  contextMenuItems: NodeMenuItemModel[] | ((dataItem: any) => NodeMenuItemModel[]);
  onSelectContextMenuItem: (event: CTXMenuSelectEvent, dataItem: any) => void;
}

const withContextMenu: (
  TreeList: React.FC<TreeListProps<TreeListExternalState>>,
) => React.FC<WithContextMenuProps> = (TreeList) => ({
  contextMenuItems,
  onSelectContextMenuItem,
  ...props
}) => {
  const [dataItem, setDataItem] = useState<any | null>(null);
  const [currentContextMenuItems, setCurrentContextMenuItems] = useState<NodeMenuItemModel[]>([]);
  const [contextMenuOffset, setContextOffset] = useState<Offset>({
    top: 0,
    left: 0,
  });

  const setContextMenuItems = (event: MouseEvent, selectedDataItem: any) => {
    const finalContextMenuItems =
      typeof contextMenuItems === 'function'
        ? contextMenuItems(selectedDataItem)
        : contextMenuItems;

    if (finalContextMenuItems.length) {
      setContextOffset({
        top: event.clientY,
        left: event.clientX,
      });
      setCurrentContextMenuItems(finalContextMenuItems);
      setDataItem(selectedDataItem);
    }
  };

  const onContextMenuDismiss = () => {
    setContextOffset({ top: 0, left: 0 });
    setCurrentContextMenuItems([]);
  };

  const selectItem = (event: CTXMenuSelectEvent) => {
    if (onSelectContextMenuItem) {
      onSelectContextMenuItem(event, dataItem);
    }

    onContextMenuDismiss();
  };

  return (
    <>
      <TreeList {...props} onContextMenu={setContextMenuItems} />
      <ContextMenu
        items={currentContextMenuItems}
        isContextMenuShown={currentContextMenuItems.length > 0}
        contextMenuOffset={contextMenuOffset}
        onSelect={selectItem}
        onContextMenuDismiss={onContextMenuDismiss}
      />
    </>
  );
};

export default withContextMenu;

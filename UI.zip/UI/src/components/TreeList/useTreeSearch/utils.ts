export const treeForEach = (
  data: any,
  subItemsField: string,
  callback: (data: any) => boolean,
): boolean => {
  if (data) {
    if (!callback(data)) {
      return false;
    }
  }

  if (data && data[subItemsField] && data[subItemsField].length) {
    for (let i = 0; i < data[subItemsField].length; i += 1) {
      const child: any = data[subItemsField][i];
      if (!treeForEach(child, subItemsField, callback)) {
        return false;
      }
    }
  }

  return true;
};

export const getHighlightedDetails = (
  node: any,
  childrenField: string,
  expandField: string,
  parentExpanded: boolean = true,
): {
  itemLineCount: number;
  found: boolean;
  idsToExpand: Set<string>;
  node: any;
} => {
  let itemLineCount = 1;
  let found = node.highlight;
  let idsToExpand = new Set<string>();
  let foundNode = found ? node : null;

  const isExpanded = parentExpanded && node[expandField];

  if (!found && node && node[childrenField] && node[childrenField].length) {
    let childTotals = 0;
    for (let i = 0; i < node[childrenField].length; i += 1) {
      const child: any = node[childrenField][i];
      const res = getHighlightedDetails(child, childrenField, expandField, isExpanded);

      found = found || res.found;

      childTotals += res.itemLineCount;

      if (found) {
        if (!node[expandField]) {
          idsToExpand.add(node.id);
        }
        foundNode = res.node;
        idsToExpand = new Set([...idsToExpand, ...res.idsToExpand]);
        break;
      }
    }

    if (found || isExpanded) {
      itemLineCount += childTotals;
    }
  }

  return {
    itemLineCount,
    found,
    idsToExpand,
    node: foundNode,
  };
};

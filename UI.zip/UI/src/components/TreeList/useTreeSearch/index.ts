import { useState, useEffect, useRef } from 'react';
import { isEqual } from 'lodash';

interface TreeSearchProps {
  searchField: string;
  subItemsField: string;
  idField?: string;
}

export interface SearchResults {
  id: string;
  parentIds: string[];
}

const findIdsInTree = (
  searchResults: Map<string, SearchResults>,
  data: any,
  subItemsField: string,
  searchField: string,
  searchText: string,
  idField: string,
  parentIds: string[] = [],
) => {
  if (data[searchField]?.toLowerCase().includes(searchText.toLowerCase().trim())) {
    searchResults.set(data[idField], {
      id: data[idField],
      parentIds,
    });
  }

  if (data && data[subItemsField]?.length) {
    data[subItemsField].forEach((child: any) => {
      findIdsInTree(searchResults, child, subItemsField, searchField, searchText, idField, [
        ...parentIds,
        data[idField],
      ]);
    });
  }
};

export interface TreeSearch {
  hasMatches: boolean;
  expandedList: string[];
  setSearchText: (value: string) => void;
  setSearchData: (data: any) => void;
  findNext: () => void;
  findPrev: () => void;
  nextMatchedId: string | null;
  resetSearchResults: () => void;
}

export default ({ searchField, subItemsField, idField = 'id' }: TreeSearchProps): TreeSearch => {
  const [data, setData] = useState<any[]>([]);
  const [searchText, setSearchTextState] = useState('');
  const [stateSearchResults, setStateSearchResults] = useState<string[]>([]);
  const [findPosition, setFindPosition] = useState<number>(-1);
  const searchData = useRef([]);

  const searchResults = useRef<Map<string, SearchResults>>(new Map());
  const expandedList = useRef<string[]>([]);

  const resetSearchResults = () => {
    setFindPosition(-1);
    searchResults.current.clear();
    expandedList.current = [];
    setStateSearchResults([]);
  };

  useEffect(() => {
    if (searchText && searchText.length && data) {
      searchResults.current.clear();
      findIdsInTree(searchResults.current, data, subItemsField, searchField, searchText, idField);
      setStateSearchResults(Array.from(searchResults.current.keys()));
    } else {
      resetSearchResults();
    }
  }, [searchText, data]);

  const setSearchText = (newSearchText: string) => {
    if (searchText !== newSearchText) {
      setFindPosition(-1);
      setSearchTextState(newSearchText);
    }
  };

  const setSearchData = (newData: any) => {
    if (!isEqual(searchData.current, newData)) {
      searchData.current = newData;
      setData(searchData.current);
    }
  };

  const findNext = () => {
    setFindPosition((prevPos) => {
      if (!searchResults.current.size) return -1;
      const newPos = prevPos + 1;

      return searchResults.current.size > newPos ? newPos : 0;
    });
  };

  function findPrev() {
    setFindPosition((prevPos) => {
      if (!searchResults.current.size) return -1;
      const newPos = prevPos - 1;
      return newPos >= 0 ? newPos : searchResults.current.size - 1;
    });
  }

  useEffect(() => {
    if (findPosition === -1) {
      expandedList.current = [];
    } else {
      const id = stateSearchResults[findPosition];
      expandedList.current = searchResults.current.get(id)?.parentIds ?? [];
    }
  }, [findPosition]);

  return {
    hasMatches: !!stateSearchResults?.length,
    expandedList: expandedList.current,
    setSearchText,
    setSearchData,
    findNext,
    findPrev,
    nextMatchedId:
      stateSearchResults.length > findPosition ? stateSearchResults[findPosition] : null,
    resetSearchResults,
  };
};

import React, { _mockUseEffect } from 'react';
import { shallow } from 'enzyme';

import useTreeSearch from '.';

describe('useTreeSearch hook', () => {
  let hookFunctions = {};
  let effects = [];
  const runEffects = () => {
    effects.forEach((e) => {
      e();
    });
  };

  const testData = {
    id: 0,
    title: 'Root',
    children: [
      {
        id: 1,
        title: 'Child 1',
        children: [
          {
            id: 11,
            title: 'Grand child 1',
            children: [{}, {}],
          },
          {
            id: 12,
            title: 'grand child 2',
            children: [{}, {}],
          },
        ],
      },
      {
        id: 2,
        title: 'Child 2',
      },
    ],
  };

  const Component = () => {
    hookFunctions = useTreeSearch({ searchField: 'title', subItemsField: 'children' });
    return null;
  };

  beforeAll(() => {
    _mockUseEffect(
      jest.fn((e) => {
        effects.push(e);
      }),
    );
  });

  beforeEach(() => {
    effects = [];
  });

  it('should return matches when search text matches', () => {
    // Given
    const searchResultMock = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce(['child', jest.fn()]);
    React.useState.mockReturnValueOnce([[], searchResultMock]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    runEffects();

    // Then
    expect(searchResultMock).toHaveBeenCalledWith([1, 11, 12, 2]);
  });

  it('should return only one match when search text only matches root', () => {
    // Given
    const searchResultMock = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce([' root ', jest.fn()]);
    React.useState.mockReturnValueOnce([[], searchResultMock]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    runEffects();

    // Then
    expect(searchResultMock).toHaveBeenCalledWith([0]);
  });

  it('should return no matches when search text does not match', () => {
    // Given
    const searchResultMock = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce(['NUP', jest.fn()]);
    React.useState.mockReturnValueOnce([[], searchResultMock]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    runEffects();

    // Then
    expect(searchResultMock).toHaveBeenCalledWith([]);
  });

  it('should return correct hasMatches flag when results are found', async () => {
    // Given
    const searchResultMock = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce([' root ', jest.fn()]);
    React.useState.mockReturnValueOnce([[0], searchResultMock]);

    // When
    shallow(<Component />, { lifecycleExperimental: true });

    // Then
    expect(hookFunctions.hasMatches).toBe(true);
  });

  it('should return correct hasMatches flag when results are not found', async () => {
    // Given
    const searchResultMock = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce([' root ', jest.fn()]);
    React.useState.mockReturnValueOnce([[], searchResultMock]);

    // When
    shallow(<Component />, { lifecycleExperimental: true });

    // Then
    expect(hookFunctions.hasMatches).toBe(false);
  });

  it('should not increment search pointer if no search results', async () => {
    // Given
    const mockSetFindPosition = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce(['anything', jest.fn()]);
    React.useState.mockReturnValueOnce([[], jest.fn()]);
    React.useState.mockReturnValueOnce([-1, mockSetFindPosition]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    hookFunctions.findNext();

    // Then
    const [newPosFnc] = mockSetFindPosition.mock.calls[0];
    const newPos = newPosFnc(33);
    expect(newPos).toBe(-1);
  });

  it('should increment search pointer', async () => {
    // Given
    const mockSetFindPosition = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce(['child', jest.fn()]);
    React.useState.mockReturnValueOnce([
      {
        ids: [2, 3],
        idsToExpand: new Set([1, 2, 3, 4]),
      },
      jest.fn(),
    ]);
    React.useState.mockReturnValueOnce([-1, mockSetFindPosition]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    runEffects();
    hookFunctions.findNext();

    // Then
    const [newPosFnc] = mockSetFindPosition.mock.calls[0];
    const newPos = newPosFnc(2);
    expect(newPos).toBe(3);
  });

  it('should increment search pointer back to beginning when at the end of the search results', async () => {
    // Given
    const mockSetFindPosition = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce(['child', jest.fn()]);
    React.useState.mockReturnValueOnce([
      {
        ids: [2, 3],
        idsToExpand: new Set([1, 2, 3, 4]),
      },
      jest.fn(),
    ]);
    React.useState.mockReturnValueOnce([-1, mockSetFindPosition]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    runEffects();
    hookFunctions.findNext();

    // Then
    const [newPosFnc] = mockSetFindPosition.mock.calls[0];
    const newPos = newPosFnc(3);
    expect(newPos).toBe(0);
  });

  it('should not decrement search pointer if no search results', async () => {
    // Given
    const mockSetFindPosition = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce(['anything', jest.fn()]);
    React.useState.mockReturnValueOnce([
      {
        ids: [],
        idsToExpand: new Set([1, 2, 3, 4]),
      },
      jest.fn(),
    ]);
    React.useState.mockReturnValueOnce([-1, mockSetFindPosition]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    hookFunctions.findPrev();

    // Then
    const [newPosFnc] = mockSetFindPosition.mock.calls[0];
    const newPos = newPosFnc(33);
    expect(newPos).toBe(-1);
  });

  it('should decrement search pointer', async () => {
    // Given
    const mockSetFindPosition = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce(['child', jest.fn()]);
    React.useState.mockReturnValueOnce([
      {
        ids: [2, 3],
        idsToExpand: new Set([1, 2, 3, 4]),
      },
      jest.fn(),
    ]);
    React.useState.mockReturnValueOnce([-1, mockSetFindPosition]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    runEffects();
    hookFunctions.findPrev();

    // Then
    const [newPosFnc] = mockSetFindPosition.mock.calls[0];
    const newPos = newPosFnc(1);
    expect(newPos).toBe(0);
  });

  it('should decrement search pointer to the end when at the beginning of the search results', async () => {
    // Given
    const mockSetFindPosition = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce(['child', jest.fn()]);
    React.useState.mockReturnValueOnce([
      {
        ids: [2, 3],
        idsToExpand: new Set([1, 2, 3, 4]),
      },
      jest.fn(),
    ]);
    React.useState.mockReturnValueOnce([-1, mockSetFindPosition]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    runEffects();
    hookFunctions.findPrev();

    // Then
    const [newPosFnc] = mockSetFindPosition.mock.calls[0];
    const newPos = newPosFnc(0);
    expect(newPos).toBe(3);
  });

  it('should reset search result when search is emptied', async () => {
    // Given
    const mockSetFindPosition = jest.fn();
    const mockSetStateSearchResults = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce(['', jest.fn()]);
    React.useState.mockReturnValueOnce([[2, 3], mockSetStateSearchResults]);
    React.useState.mockReturnValueOnce([-1, mockSetFindPosition]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    runEffects();
    hookFunctions.findPrev();

    // Then
    expect(mockSetFindPosition).toBeCalledWith(-1);
    expect(mockSetStateSearchResults).toBeCalledWith([]);
  });

  it('should properly set search text', async () => {
    // Given
    const mockSetSearchText = jest.fn();
    React.useState.mockReturnValueOnce([testData, jest.fn()]);
    React.useState.mockReturnValueOnce(['', mockSetSearchText]);
    React.useState.mockReturnValueOnce([
      {
        ids: [2, 3],
        idsToExpand: new Set([1, 2, 3, 4]),
      },
      jest.fn(),
    ]);
    React.useState.mockReturnValueOnce([-1, jest.fn()]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    hookFunctions.setSearchText('abc');

    // Then
    expect(mockSetSearchText).toBeCalledWith('abc');
  });

  it('should properly set data', async () => {
    // Given
    const mockSetData = jest.fn();
    React.useState.mockReturnValueOnce([testData, mockSetData]);
    React.useState.mockReturnValueOnce(['', jest.fn()]);
    React.useState.mockReturnValueOnce([
      {
        ids: [2, 3],
        idsToExpand: new Set([1, 2, 3, 4]),
      },
      jest.fn(),
    ]);
    React.useState.mockReturnValueOnce([-1, jest.fn()]);

    shallow(<Component />, { lifecycleExperimental: true });

    // When
    hookFunctions.setSearchData('abc');

    // Then
    expect(mockSetData).toBeCalledWith('abc');
  });
});

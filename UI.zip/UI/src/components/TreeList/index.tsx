import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  ReactElement,
  ReactNode,
  useContext,
} from 'react';
import { keyBy } from 'lodash';
import { useResizeDetector } from 'react-resize-detector';
import classnames from 'classnames';
import {
  TreeList as KendoTreeList,
  TreeListProps as KendoTreeListProps,
  filterBy,
  orderBy,
  mapTree,
  createDataTree,
  extendDataItem,
  TreeListExpandChangeEvent,
  TreeListDataStateChangeEvent,
  TreeListColumnProps as KendoTreeListColumnProps,
  TreeListRowClickEvent,
  TreeListColumnReorderEvent,
  TreeListRowProps,
  TreeListItemChangeEvent,
  TreeListCellProps,
} from '@progress/kendo-react-treelist';
import { SortDescriptor } from '@progress/kendo-data-query';
import { ExternalisedStateProps } from '@/types/externalised-state';
import EditContext, { EditingDetails } from '@/contexts/EditContext';
import { LayoutRefContext } from '@/contexts/LayoutRefContext';
import { getHighlightedDetails } from './useTreeSearch/utils';
import PageLoading from '../PageLoading';

import styles from './index.less';

export { TreeListCellProps } from '@progress/kendo-react-treelist';

export interface ColumnExtraProps {
  selector?: any;
  isPrimaryField?: boolean;
}

export interface CustomCellRendererProps extends TreeListCellProps {
  extras?: any;
}

export interface TreeListColumnProps extends KendoTreeListColumnProps {
  field: string;
  treeDisplayField?: boolean;
  defaultSortColumn?: boolean;
  customCellRenderer?: {
    renderer: (cellProps: CustomCellRendererProps) => ReactNode;
    extraProps: any;
  };
  editable?: boolean;
  type?: any;
  extras?: Record<string, any>;
}

interface DataState extends KendoTreeListProps {
  columns: TreeListColumnProps[];
}

export interface NodeExpandParams {
  isExpanded: boolean;
  ids: string[];
}

export interface TreeListExternalState {
  selectedRows?: string[];
  dataState?: DataState;
}

export interface RowSelectionParams {
  ids: string[];
  lastSelectedId: string;
}

export interface TreeListProps<k> extends KendoTreeListProps, ExternalisedStateProps<k> {
  idField?: string;
  parentField?: string;
  loading?: boolean;
  columns: TreeListColumnProps[];
  expandedDataIds?: string[];
  onNodeExpandChange?: (props: NodeExpandParams) => void;
  selectedRows?: string[];
  selectable?: boolean;
  editable?: boolean;
  selectableField?: string;
  onRowSelect?: (params: RowSelectionParams) => void;
  searchText?: string;
  onContextMenu?: (param: MouseEvent, dataItem: any) => void;
  setDisplayData?: (data: any) => void;
  rowHighlightId?: string | null;
  onItemChange?: (e: TreeListItemChangeEvent) => void;
}

const getDefaultSortColumn = (columns: TreeListColumnProps[]): SortDescriptor => {
  const getDefaultColumnInfo = columns.find((o) => o?.defaultSortColumn) as TreeListColumnProps;

  if (!getDefaultColumnInfo) {
    return {} as SortDescriptor;
  }

  return {
    dir: 'asc',
    field: getDefaultColumnInfo.field,
  };
};

const getEditableFields = (columns: TreeListColumnProps[]): string[] =>
  columns.filter((c) => c?.editable).map((c) => c.field);

const getDefaultDataState = (
  defaultColumns: TreeListColumnProps[],
  externalState: TreeListExternalState,
): DataState => {
  const { dataState = {} as DataState } = externalState;
  const { sort = [], filter = [], columns = defaultColumns } = dataState;

  return {
    sort: sort.length ? sort : [getDefaultSortColumn(columns)],
    filter,
    columns,
  };
};

const getDisplayField = (columns: TreeListColumnProps[]): string | undefined =>
  columns.find((col) => col.treeDisplayField)?.field;

const ROW_HEIGHT = 26;

/**
 * This function sync the expandedList with the expand and highlight flag on each tree item
 * @param dataTree
 * @param expandedList
 * @param matchedSearchId
 */
const annotateData = (
  idField: string,
  subItemsField: string,
  expandField: string,
  dataTree: any[],
  expandedList: string[],
  selectedIDList: string[],
  highlightId?: string | null,
) =>
  mapTree(dataTree, subItemsField, (item: any) =>
    extendDataItem(item, subItemsField, {
      [expandField]: expandedList.includes(item[idField]),
      selected: selectedIDList.includes(item[idField]),
      highlight: highlightId === item[idField],
    }),
  );

const TreeList: React.FC<TreeListProps<TreeListExternalState>> = (props) => {
  const {
    className,
    data = [],
    loading,
    onRowSelect,
    expandedDataIds = [],
    onNodeExpandChange,
    style,
    tableProps,
    onContextMenu,
    columns = [],
    idField = 'id',
    parentField = 'parent',
    expandField = 'expanded',
    subItemsField = 'children',
    selectedRows = [],
    selectable,
    editable = false,
    externalState = {},
    setExternalState = () => {},
    searchText = '',
    setDisplayData,
    rowHighlightId,
    onItemChange,
  } = props;

  const [dataState, setDataState] = useState(getDefaultDataState(columns, externalState));
  const [editingDetails, setEditingDetails] = useState<EditingDetails>(null);
  const treeDataById = useMemo(() => keyBy(data, idField), [data, idField]);

  const internalState = useRef<TreeListExternalState>({
    dataState,
  });
  const { height: treeListHeight, ref: treeListRef } = useResizeDetector<HTMLDivElement>();
  const rootLayout = useContext(LayoutRefContext);

  useEffect(() => {
    internalState.current = { dataState };
  }, [dataState]);

  const removeEditingState = () => {
    setEditingDetails(null);
  };

  // sync internal state with external state will component unmount
  useEffect(() => {
    if (rootLayout?.current) {
      rootLayout.current.addEventListener('onClick', removeEditingState, false);
    }
    return () => {
      if (rootLayout?.current) {
        rootLayout.current.removeEventListener('onClick', removeEditingState, false);
      }
      setExternalState(internalState.current);
    };
  }, []);

  const handleDataStateChange = (event: TreeListDataStateChangeEvent) => {
    setDataState({ ...dataState, ...event.dataState } as any);
  };

  const parentIDsOfSelectedNodes = useMemo(() => {
    const selectedParentIDs: string[] = [];

    const setParentIDs = (item: any) => {
      const parentId = item[parentField]?.[idField] ?? item[parentField];

      if (parentId != null && typeof parentId !== 'object') {
        selectedParentIDs.push(parentId);
        setParentIDs(treeDataById[parentId]);
      }
    };

    selectedRows.forEach((i) => {
      if (treeDataById[i] != null) {
        setParentIDs(treeDataById[i]);
      }
    });

    return selectedParentIDs;
  }, [idField, parentField, selectedRows, treeDataById]);

  const handleRowSelection = (id: string) => {
    if (selectable) {
      const isIDExist = selectedRows.some((i) => i === id);
      let newlySelectedRows = [...selectedRows, id];

      if (isIDExist) {
        newlySelectedRows = selectedRows.filter((i) => i !== id);
      }

      if (onRowSelect) {
        onRowSelect({ ids: newlySelectedRows, lastSelectedId: id });
      }
    }
  };

  const handleRowClick = (event: TreeListRowClickEvent) => {
    handleRowSelection(event.dataItem[idField]);
  };

  const onColumnReorder = (event: TreeListColumnReorderEvent) => {
    setDataState({
      ...dataState,
      columns: event.columns as TreeListColumnProps[],
    });
  };

  // process flat data into a tree list
  const dataTree = useMemo(
    () =>
      createDataTree(
        data,
        (i) => i[idField],
        (i) => i[parentField]?.[idField] ?? i[parentField],
        subItemsField,
      ),
    [data],
  );

  const displayField = useMemo(() => getDisplayField(columns), [columns]);

  // filter and sorting on the tree list
  const sortedAndFilteredData = useMemo(() => {
    const filteredData = filterBy(dataTree, dataState.filter ?? [], subItemsField);
    const sortedData = orderBy(filteredData, dataState.sort as any, subItemsField);
    return sortedData;
  }, [dataTree, dataState]);

  const processedData = useMemo(
    () =>
      annotateData(
        idField,
        subItemsField,
        expandField,
        sortedAndFilteredData,
        expandedDataIds,
        selectedRows,
        rowHighlightId,
      ),
    [sortedAndFilteredData, expandedDataIds, rowHighlightId, selectedRows],
  );

  const onItemChangeOnTreeView = (event: TreeListItemChangeEvent) => {
    if (onItemChange) {
      onItemChange(event);
    }
  };

  useEffect(() => {
    if (!rowHighlightId) return;

    const firstNode = processedData.length ? processedData[0] : {};
    const highlightDetail = getHighlightedDetails(firstNode, subItemsField, expandField);

    // execute callback for nodes that need to be expanded
    if (highlightDetail.found && onNodeExpandChange) {
      onNodeExpandChange({ isExpanded: false, ids: [...highlightDetail.idsToExpand] });
    }

    setTimeout(() => {
      const scrollableContainer: HTMLElement | null = document.querySelector(
        `.k-treelist-scrollable`,
      );

      if (highlightDetail.found && scrollableContainer) {
        const containerHeight = scrollableContainer.offsetHeight;
        const scrollOffset = containerHeight / 4;
        let scrollTop = highlightDetail.itemLineCount * ROW_HEIGHT - scrollOffset;
        scrollTop = scrollTop > 0 ? scrollTop : 0;

        scrollableContainer.scrollTo({ top: scrollTop, behavior: 'smooth' });
      }
    }, 100);
  }, [rowHighlightId]);

  useEffect(() => {
    if (setDisplayData) {
      setDisplayData(processedData.length ? processedData[0] : null);
    }
  }, [processedData]);

  const onExpandChange = (event: TreeListExpandChangeEvent) => {
    if (onNodeExpandChange) {
      onNodeExpandChange({
        isExpanded: event.value,
        ids: [event.dataItem[idField]],
      });
    }
  };

  const cellRender = (
    cell: ReactElement<HTMLTableCellElement> | null,
    cellProps: TreeListCellProps,
  ) => {
    if (!cell) return null;

    const { field = '' } = cellProps;
    let customCell: React.ReactNode = cell?.props.children[1];
    const columnConfig: TreeListColumnProps | undefined = columns.find((c) => c.field === field);
    const { customCellRenderer } = columnConfig || {};

    if (customCellRenderer) {
      const { renderer, extraProps } = customCellRenderer;
      customCell = renderer({
        ...cellProps,
        extras: {
          ...extraProps,
          parentIDsOfSelectedNodes,
          searchText,
          onSelect: handleRowSelection,
          idField,
          subItemsField,
        },
      });
    }

    const children = (
      <div
        style={{
          display: 'flex',
        }}
      >
        {cell.props.children[0]}
        {customCell}
      </div>
    );

    return React.cloneElement(cell, cell.props, children);
  };

  const rowRender = (
    rowElement: React.ReactElement<HTMLTableRowElement>,
    rowProps: TreeListRowProps,
  ) => {
    const { highlight, id, modified } = rowProps.dataItem;

    const newElementProps = {
      ...rowElement.props,
      'data-id': id,
      className: classnames({
        [rowElement.props.className]: rowElement.props.className.length,
        [styles.highlight]: highlight,
        [styles.gridEditedRow]: modified,
      }),
      onContextMenu: (event: MouseEvent) => {
        event.preventDefault();

        if (onContextMenu) {
          onContextMenu(event, rowProps.dataItem);
        }
      },
    };

    return React.cloneElement(rowElement, newElementProps, rowElement.props.children);
  };

  return (
    <div ref={treeListRef} className={styles.treeListContainer}>
      {loading ? (
        <PageLoading />
      ) : (
        <EditContext.Provider
          value={{
            editing: editingDetails,
            editableFields: getEditableFields(columns),
            setEditing: (details) => {
              if (editable) {
                setEditingDetails(details);
              }
            },
          }}
        >
          <KendoTreeList
            {...dataState}
            resizable
            reorderable
            style={{
              height: `${Number(treeListHeight)?.toFixed(0) ?? 0}px`,
              overflow: 'auto',
              width: '100%',
              ...style,
            }}
            className={classnames(
              editingDetails ? styles.gridEditMode : styles.gridReadOnlyMode,
              styles.theGrid,
              className,
            )}
            expandField={expandField}
            subItemsField={subItemsField}
            rowHeight={ROW_HEIGHT}
            tableProps={{ style: { tableLayout: 'fixed', width: '0' }, ...tableProps }}
            sortable={{
              allowUnsort: false,
              mode: 'single',
            }}
            scrollable="virtual"
            data={processedData}
            rowRender={rowRender}
            onRowClick={handleRowClick}
            onDataStateChange={handleDataStateChange}
            onExpandChange={onExpandChange}
            columns={columns}
            onItemChange={onItemChangeOnTreeView}
            dataItemKey={displayField || 'title'}
            onColumnReorder={onColumnReorder}
            cellRender={cellRender}
          />
        </EditContext.Provider>
      )}
    </div>
  );
};

export default TreeList;

import React, { ReactElement } from 'react';
import classnames from 'classnames';
import { filterTooltipProps } from '@/components/Tooltip';

import { CustomCellRendererProps } from '../..';
import styles from './index.less';

export interface CellProps {
  dataItem: { id: string };
  field: string;
  searchText: string;
  highlightColor: string;
  selectable: boolean;
  onDoubleClick?: (params: { dataItem: any }) => void;
}

const SelectableHighlightingCell: (
  props: CustomCellRendererProps,
) => ReactElement<CustomCellRendererProps> = (props) => {
  const {
    dataItem,
    field,
    extras: { parentIDsOfSelectedNodes, searchText, highlightColor, selectable, onSelect, idField },
  } = props;

  const id = dataItem[idField];
  const { selected } = dataItem;

  const displayValue = dataItem[field || ''] ?? '';
  let content = displayValue;
  const searchTextTrimmed = searchText?.trim();

  if (searchTextTrimmed && searchTextTrimmed.length && displayValue.length) {
    const index = displayValue.toLowerCase().indexOf(searchTextTrimmed.toLowerCase());
    const beforeStr = displayValue.substring(0, index);
    const highlightStr = displayValue.substring(index, index + searchTextTrimmed.length);
    const afterStr = displayValue.substring(index + searchTextTrimmed.length);

    if (index > -1) {
      content = (
        <>
          {beforeStr}
          <span
            key={`highlightcustom-highlight-${id}`}
            style={{ color: `${highlightColor}`, fontWeight: 'bold' }}
            onMouseDown={(e) => {
              e.preventDefault();
            }}
            onClick={() => {
              onSelect(id);
            }}
          >
            {highlightStr}
          </span>
          {afterStr}
        </>
      );
    }
  }

  const isChildSelected = parentIDsOfSelectedNodes.find((i: string) => i === id);

  return (
    <div
      key={`highlightcustom-${dataItem.id}`}
      style={{
        display: 'grid',
        width: '100%',
        cursor: 'pointer',
      }}
      className={classnames({
        [styles.selectableCell]: selectable,
        [styles.selected]: selected,
        [styles.childRowSelected]: isChildSelected && !selected,
      })}
      onMouseDown={(e) => {
        e.preventDefault();
      }}
      onClick={() => {
        onSelect(id);
      }}
      {...filterTooltipProps(props)}
    >
      <div className={styles.textContainer}>{content}</div>
    </div>
  );
};

export default SelectableHighlightingCell;

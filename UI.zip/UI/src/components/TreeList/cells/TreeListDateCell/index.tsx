import React, { ReactElement } from 'react';
import { get } from 'lodash';
import { parseDate, formatDate } from '@telerik/kendo-intl';
import SimpleTD from '@/components/SimpleTD';
import { CustomCellRendererProps } from '../..';

const TreeListDateCell: (
  props: CustomCellRendererProps,
) => ReactElement<CustomCellRendererProps> = ({ dataItem, field, format, ...props }) => {
  const dateInputValue = get(dataItem, field || '') ?? '';

  let cellValue = '';

  if (format && dateInputValue) {
    cellValue = formatDate(parseDate(dateInputValue), format);
  }

  return <SimpleTD {...props}>{cellValue}</SimpleTD>;
};

export default TreeListDateCell;

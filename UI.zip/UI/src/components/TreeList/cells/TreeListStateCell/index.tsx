import React, { ReactElement } from 'react';
import classnames from 'classnames';
import SimpleTD from '@/components/SimpleTD';

import styles from './index.less';
import { CustomCellRendererProps } from '../..';

const TreeListStateCell: (
  props: CustomCellRendererProps,
) => ReactElement<CustomCellRendererProps> = ({ dataItem, ...props }) => (
  <SimpleTD {...props} className={styles.TreeListStateCellTD}>
    <div
      key={`state-${props.id}`}
      className={classnames(
        styles.TreeListStateCell,
        `${styles.TreeListStateCell}-${dataItem?.modified}`,
      )}
    />
  </SimpleTD>
);

export default TreeListStateCell;

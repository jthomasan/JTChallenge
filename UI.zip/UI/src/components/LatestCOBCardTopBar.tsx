import { gql, useQuery } from 'umi-plugin-apollo-anz/apolloClient';
import React from 'react';

interface LatestCOBCardTopBarQueryResponse {
  CurrentBusinessDate: string;
}

const LatestCOBCardTopBarQuery = gql`
  query CardTopBarQuery {
    CurrentBusinessDate
  }
`;

const LatestCOBCardTopBar: React.FC<JSX.IntrinsicElements['span']> = (props) => {
  const { data } = useQuery<LatestCOBCardTopBarQueryResponse>(LatestCOBCardTopBarQuery);
  if (!data?.CurrentBusinessDate) {
    return null;
  }

  return <span {...props}>Latest available COB date: {data.CurrentBusinessDate}</span>;
};

export default LatestCOBCardTopBar;

import React from 'react';
import { Modal as AntModal } from 'antd';
import { ModalProps as AntModalProps } from 'antd/lib/modal';

interface ModalProps extends AntModalProps {
  children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = (props) => {
  const { children } = props;

  return (
    <AntModal {...props} centered maskClosable={false}>
      {children}
    </AntModal>
  );
};

export default Modal;

import classNames from 'classnames';
import React, { useCallback } from 'react';

import styles from './Tabs.less';

interface TabPaneProps {
  title: string;
  key: string;
}

export const TabPane: React.FC<TabPaneProps> = ({ children }) => <>{children}</>;

const Tabs: React.FC<{
  activeKey: string;
  onChangeActiveKey: (key: string) => void;
  tabBarExtraContent?: React.ReactNode;
  children: React.ReactElement<TabPaneProps, typeof TabPane>[];
}> = ({ activeKey, onChangeActiveKey, tabBarExtraContent, children }) => {
  const onClick = useCallback<NonNullable<JSX.IntrinsicElements['button']['onClick']>>(
    (e) => {
      const { key } = (e.target as HTMLButtonElement).dataset;
      if (!key) {
        return;
      }

      // eslint-disable-next-line no-unused-expressions
      onChangeActiveKey?.(key);
      e.preventDefault();
    },
    [onChangeActiveKey],
  );

  return (
    <>
      <div className={styles.tabBar}>
        <div className={styles.tabBarTabs}>
          {children.map((child) => (
            <button
              type="button"
              className={classNames(styles.tab, { [styles.active]: child.key === activeKey })}
              data-key={child.key}
              key={child.key as NonNullable<typeof child.key>}
              onClick={onClick}
            >
              {child.props.title}
            </button>
          ))}
        </div>
        {tabBarExtraContent ?? null}
      </div>
      {children.find((child) => child.key === activeKey)}
    </>
  );
};

export default Tabs;

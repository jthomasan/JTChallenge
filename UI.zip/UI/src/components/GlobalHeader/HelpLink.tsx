import React from 'react';

// eslint-disable-next-line import/no-extraneous-dependencies
import { QuestionCircleOutlined } from '@ant-design/icons';

import HeaderLink from './HeaderLink';

const HelpLink: React.FC = () => (
  <HeaderLink href={window.env?.HELP_URL} target="_blank" rel="noopener noreferrer">
    <QuestionCircleOutlined title="Help" />
  </HeaderLink>
);

export default HelpLink;

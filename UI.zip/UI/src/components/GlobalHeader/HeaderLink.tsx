import React from 'react';
import classnames from 'classnames';

import styles from './HeaderLink.less';

const HeaderLink: React.FC<React.DetailedHTMLProps<
  React.AnchorHTMLAttributes<HTMLAnchorElement>,
  HTMLAnchorElement
>> = ({ children, ...props }) => (
  <a className={classnames(props.className, styles['header-link'])} {...props}>
    {children}
  </a>
);

export default HeaderLink;

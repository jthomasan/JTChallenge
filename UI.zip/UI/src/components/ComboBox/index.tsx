import React, { useMemo, useState } from 'react';
import {
  ComboBox as KendoComboBox,
  ComboBoxPageChangeEvent,
  ComboBoxFilterChangeEvent,
  ComboBoxProps,
} from '@progress/kendo-react-dropdowns';
import { filterBy, FilterDescriptor } from '@progress/kendo-data-query';
import { isEmpty } from 'lodash';

const ComboBox: React.FC<ComboBoxProps> = (props) => {
  const { data, ...rest } = props;
  const defaultPageSize = 15;
  const enableVirtualScrollThreshold = 50;
  const [skip, setSkip] = useState(0);
  const [filter, setFilter] = useState({} as FilterDescriptor);

  const totalDataLength = data?.length || 0;
  const isAboveVSThreshold = totalDataLength > enableVirtualScrollThreshold;
  const onPageChange = (event: ComboBoxPageChangeEvent) => setSkip(event.page.skip);
  const onFilterChange = (event: ComboBoxFilterChangeEvent) => {
    setSkip(0);
    setFilter(event.filter);
  };

  const processedData = useMemo(() => {
    if (!data) {
      return [];
    }
    return isEmpty(filter) ? data : filterBy(data, filter);
  }, [data, filter]);

  const pagedData = useMemo(
    () =>
      isAboveVSThreshold ? processedData?.slice(skip, skip + defaultPageSize) : processedData || [],
    [processedData, skip],
  );

  const virtualOptions = isAboveVSThreshold
    ? {
        total: processedData.length,
        pageSize: defaultPageSize,
        skip,
      }
    : undefined;

  return (
    <KendoComboBox
      data={pagedData}
      virtual={virtualOptions}
      onPageChange={onPageChange}
      onFilterChange={onFilterChange}
      filterable
      {...rest}
    />
  );
};

export default ComboBox;

import styled from 'styled-components';

const Input = styled.input`
  text-overflow: ellipsis;
  touch-action: manipulation;
  -webkit-appearance: none;
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-variant: tabular-nums;
  list-style: none;
  font-feature-settings: 'tnum';
  position: relative;
  display: inline-block;
  width: 100%;
  height: 24px;
  padding: 0px 5px;
  color: rgba(0, 0, 0, 0.65);
  font-size: 14px;
  line-height: 1.5;
  background-color: #fff;
  background-image: none;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  transition: all 0.3s;
`;

Input.displayName = 'Input';

export default Input;

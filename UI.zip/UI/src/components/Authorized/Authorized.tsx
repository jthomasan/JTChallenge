import React from 'react';
import { isAuthorized, getAuthority, IMervAuthorityType } from '@/utils/authority';

import check, { IAuthorityType } from './CheckPermissions';

import AuthorizedRoute from './AuthorizedRoute';
import Secured from './Secured';

interface AuthorizedProps {
  authority: IAuthorityType | IMervAuthorityType;
  noMatch?: React.ReactNode;
  devOnly?: boolean;
}

interface AuthorizedComponent extends React.FC<AuthorizedProps> {
  Secured: typeof Secured;
  check: typeof check;
  AuthorizedRoute: typeof AuthorizedRoute;
}

const Authorized: React.FC<AuthorizedProps> = ({ children, authority, noMatch = null }) => {
  if (isAuthorized(authority as IMervAuthorityType, getAuthority())) {
    return <>{children}</>;
  }

  return <>{noMatch}</>;
};

export default Authorized as AuthorizedComponent;

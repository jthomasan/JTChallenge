import React from 'react';

import { IMervAuthorityType, isAuthorized } from '@/utils/authority';

import Authorized from './Authorized';
import Secured from './Secured';
import check from './CheckPermissions';
import renderAuthorize from './renderAuthorize';

Authorized.Secured = Secured;
Authorized.check = check;

const RenderAuthorize = renderAuthorize(Authorized);

export function ifAuthorized<T extends React.ReactNode>(
  node: T,
  authority: IMervAuthorityType,
): T | null {
  if (isAuthorized(authority)) {
    return node;
  }

  return null;
}

export default RenderAuthorize;

import React from 'react';
import { Tree } from 'antd';
import { DirectoryTreeProps } from 'antd/lib/tree';
import styles from './index.less';

export const DirectoryTree: React.FC<DirectoryTreeProps> = (props) => (
  <div className={styles.tree}>
    <Tree.DirectoryTree {...props}>{props.children}</Tree.DirectoryTree>
  </div>
);

export const { TreeNode } = Tree;

export default { DirectoryTree, TreeNode };

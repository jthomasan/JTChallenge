import React from 'react';
import { Window, WindowProps } from '@progress/kendo-react-dialogs';

import styles from './index.less';

const WindowWrapper: React.FC<WindowProps> = (props) => {
  const rootElement = document.getElementById('root') as HTMLElement;

  return (
    <div className={styles.window}>
      <Window {...props} appendTo={rootElement} />
    </div>
  );
};

export default WindowWrapper;

import React from 'react';
import styles from './Divider.less';

const Divider: React.FC<{ orientation?: 'horizontal' | 'vertical' }> = ({
  orientation = 'vertical',
}) => <span className={`${styles.divider} ${styles[orientation]}`} />;

export default Divider;

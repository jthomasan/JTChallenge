import React, { useState, useEffect, useMemo } from 'react';
import { Menu, Tooltip, Icon } from 'antd';
import classNames from 'classnames';
import { Link } from 'umi';
import { FormattedMessage, formatMessage } from 'umi-plugin-react/locale';

import { getAuthority, isAuthorized } from '@/utils/authority';
import styles from './SideMenu.less';
import { generatePath } from 'react-router';

export interface SubMenuProps {
  handleMenuCollapse: () => void;
  routes: any;
  currentPathname: string;
  collapsed?: boolean;
}

const addTrailingSlash = (str: string) => (str.charAt(str.length - 1) !== '/' ? `${str}/` : str);

const createMenuItem = (
  route: any,
  isSelected: boolean,
  collapsed: boolean,
  currentAuthority: string[],
  onMouseEnter?: (path: string) => void,
  onMouseLeave?: () => void,
) => {
  const { path, name, shortname, icon, routes: children } = route;
  const firstChild: any =
    children && children.find((child: any) => isAuthorized(child.authority, currentAuthority));
  const linkTo = generatePath((firstChild && firstChild.path) || path);

  const displayLongName = formatMessage({ id: `menu.${name}`, defaultMessage: name });
  const isFirstLevel = path.split('/').length < 3;

  return (
    <Menu.Item
      key={path}
      onMouseEnter={() => {
        if (onMouseEnter) onMouseEnter(path);
      }}
      onMouseLeave={() => {
        if (onMouseLeave) onMouseLeave();
      }}
      className={classNames({
        'ant-menu-item-selected': isSelected,
      })}
    >
      <Tooltip
        title={displayLongName}
        placement="right"
        overlayClassName={classNames({
          [styles.hidden]: !collapsed && isFirstLevel,
        })}
      >
        <Link to={linkTo}>
          <Icon type={icon} />
          <span className={styles.longLabel}>{displayLongName}</span>
          {shortname && (
            <span className={styles.shortLabel}>
              <FormattedMessage id={`menu.${shortname}`} defaultMessage={shortname} />
            </span>
          )}
        </Link>
      </Tooltip>
    </Menu.Item>
  );
};

const SubMenu: React.FC<SubMenuProps> = (props) => {
  const { handleMenuCollapse, routes, currentPathname, collapsed } = props;

  const currentTopPathname = `/${
    currentPathname.split('/').length > 1 ? currentPathname.split('/')[1] : ''
  }`;

  const [selectedMenuPath, setSelectedMenuPath] = useState(currentTopPathname);
  const currentAuthority = useMemo(() => getAuthority(), []);

  useEffect(() => {
    setSelectedMenuPath(currentTopPathname);
  }, [currentPathname]);

  let menuTimeout: any = null;

  const onMouseOverMenuItem = (path: string) => {
    clearTimeout(menuTimeout);
    menuTimeout = setTimeout(() => {
      setSelectedMenuPath(path);
    }, 150);
  };

  const onMouseLeaveMenuItem = () => {
    clearTimeout(menuTimeout);
  };

  const onMouseLeaveMenu = () => {
    setSelectedMenuPath(currentTopPathname);
  };

  const isRouteSelected = (route: any) => {
    const { path } = route;
    let matched = path === selectedMenuPath;

    if (selectedMenuPath === currentTopPathname) {
      matched = addTrailingSlash(currentPathname).indexOf(addTrailingSlash(path)) === 0;
    }

    return matched;
  };

  const routesToMenu = (
    _routes: any,
    arr: any,
    key: string,
    onMouseEnter?: (path: string) => void,
    onMouseLeave?: () => void,
  ) => {
    // eslint-disable-next-line no-param-reassign
    arr[key] = [];

    _routes.forEach((route: any) => {
      const { hideInMenu, name, routes: children, path, authority } = route;

      if (!hideInMenu && name && isAuthorized(authority, currentAuthority)) {
        const isSelected = isRouteSelected(route);
        arr[key].push(
          createMenuItem(
            route,
            isSelected,
            !!collapsed,
            currentAuthority,
            onMouseEnter,
            onMouseLeave,
          ),
        );

        if (children && children.length) {
          routesToMenu(children, arr, path);
        }
      }
    }, []);
  };

  const menuData: { [key: string]: object } = {};
  routesToMenu(routes, menuData, 'main', onMouseOverMenuItem, onMouseLeaveMenuItem);

  const { main: mainMenu } = menuData;

  return (
    <section onMouseLeave={onMouseLeaveMenu} className={styles.sideBar}>
      <Menu
        theme="dark"
        mode="inline"
        defaultSelectedKeys={['1']}
        defaultOpenKeys={['sub1']}
        className={classNames({
          [styles.sideBarMenu]: true,
          [styles.collapsed]: collapsed,
        })}
        inlineCollapsed={collapsed}
      >
        <div
          className={styles.foldWrapper}
          onClick={handleMenuCollapse}
          onMouseEnter={onMouseLeaveMenu}
        >
          <Icon type={collapsed ? 'menu-unfold' : 'menu-fold'} />
        </div>
        {mainMenu}
      </Menu>

      <div
        className={classNames({
          [styles.subMenuWrapper]: true,
          [styles.subMenuFloating]: !menuData[currentTopPathname],
          [styles.hidden]: !menuData[currentTopPathname] && !menuData[selectedMenuPath],
        })}
      >
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={['1']}
          defaultOpenKeys={['sub1']}
          className={classNames({
            [styles.subBarMenu]: true,
            [styles.sideBarMenu]: true,
            [styles.subBarCollapsed]: true,
            [styles.subBarDisabled]: !menuData[selectedMenuPath],
          })}
          inlineCollapsed
        >
          {menuData[selectedMenuPath]}
        </Menu>
      </div>
    </section>
  );
};

export default SubMenu;

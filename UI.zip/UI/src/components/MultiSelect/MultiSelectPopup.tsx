/* eslint-disable react/no-array-index-key */
import React, { useMemo, useState, useEffect } from 'react';

import { Button, Row, Col } from 'antd';
import Search from 'antd/lib/input/Search';
import classnames from 'classnames';
import { sortBy, keyBy, differenceWith } from 'lodash';
import { List } from 'react-virtualized';

// Should seperate this from the static-data page
import { StaticDataHelperProps } from '@/pages/reference-data/static-data/mappings/staticDataSet';

import styles from './MultiSelectPopup.less';

export interface Header {
  title?: string;
  field?: string;
  width?: string;
  height?: string;
  cell?: React.ElementType;
  extras?: StaticDataHelperProps;
}

export interface IdentifiedValue {
  id: string | number;
}

export interface OptionProp extends Record<string, any> {
  id: string | number;
  text: string;
  isOptional?: boolean;
}

interface CellUpdates {
  id: string | number;
  field: string;
  value: any;
}

const Tag: React.FC<any> = (props: any): any => {
  const { item, onSelect } = props;

  return (
    <div className={styles.tagWrapper}>
      {item.text}
      <span
        className="k-icon k-i-close"
        onClick={() => {
          onSelect(item.id);
        }}
      />
    </div>
  );
};

const Option: React.FC<any> = (props: any): any => {
  const {
    option,
    showCellOnMultiSelectCell,
    selectedOptionInfo,
    spanSize,
    headers,
    onSelect,
    onChangeFromCell,
  } = props;

  const onChange = (event: any) => {
    if (event.value != null) {
      const data: CellUpdates = {
        id: event.dataItem.id,
        field: event.field,
        value: event.value,
      };

      onChangeFromCell(data);
    }
  };

  return (
    <Row
      className={classnames(styles.option, {
        [styles.selected]: !!selectedOptionInfo,
        [styles.selectedCell]: showCellOnMultiSelectCell,
      })}
      onClick={(e) => {
        e.preventDefault();
        const sel = window.getSelection();
        if (sel?.type !== 'Range') {
          onSelect(option.id);
        }
      }}
    >
      {(headers.length > 0 &&
        headers.map((header: Header, index: number) => {
          const Cell = header.cell as any;

          if (Cell) {
            if (showCellOnMultiSelectCell) {
              const field = header.extras?.selectorField || '';
              const value = selectedOptionInfo?.[field] ?? header.extras?.defaultValue;

              return (
                <Col
                  key={`${option.id}-${index}`}
                  span={spanSize}
                  className={styles.Cell}
                  style={{ width: header.width, height: header.height }}
                >
                  <Cell
                    {...header.extras}
                    dataItem={{ ...option }}
                    field={field}
                    type={header.extras?.typeOf || 'string'}
                    value={value}
                    onChange={onChange}
                  />
                </Col>
              );
            }

            return <></>;
          }

          return (
            <Col
              key={`${option.id}-${index}`}
              span={spanSize}
              style={{
                width: header.width ?? '100%',
                height: header.height,
              }}
              title={option[header?.field || '']}
            >
              {option[header?.field || '']}
            </Col>
          );
        })) || (
        <Col span={spanSize} title={option.text}>
          {option.text}
        </Col>
      )}
    </Row>
  );
};

const OptionContainer: React.FC<any> = (props: any): any => {
  const {
    width = 335,
    height = 218,
    hideHeaderTitle,
    headers,
    options,
    showCellOnMultiSelectCell,
    selectionList,
    onSelect,
    onChangeFromCell,
  } = props;
  const selectionMap = useMemo(() => keyBy(selectionList, 'id'), [selectionList]);
  const spanSize = (headers.length && (headers.length <= 3 ? 24 / headers.length : 6)) || 24;

  const rowRenderer = ({ key, index, style }: any) => {
    const option = options[index];

    return (
      <div key={key} style={style}>
        <Option
          key={key}
          headers={headers}
          option={option}
          selectedOptionInfo={selectionMap[option.id]}
          spanSize={spanSize || 24}
          showCellOnMultiSelectCell={showCellOnMultiSelectCell}
          onSelect={onSelect}
          onChangeFromCell={onChangeFromCell}
        />
      </div>
    );
  };

  return (
    <>
      {headers.length > 0 && !hideHeaderTitle && (
        <Row className={styles.header}>
          {headers.map((header: Header, index: number) => (
            <Col key={`header-${index}`} span={spanSize} style={{ width: header.width }}>
              {header.title}
            </Col>
          ))}
        </Row>
      )}
      <div className={styles.optionContainer}>
        <List
          width={width}
          height={height}
          rowCount={options.length}
          rowHeight={showCellOnMultiSelectCell ? 35 : 20}
          rowRenderer={rowRenderer}
        />
      </div>
    </>
  );
};

const getExistingData = <T,>(existingData: T[] | T) => {
  if (Array.isArray(existingData)) {
    return existingData?.map((item: any) => {
      const { __typename, ...rest } = item;
      return rest as T;
    });
  }

  const { __typename, ...rest } = existingData as any;
  return [rest] as T[];
};

export interface MultiSelectPopupProps<
  T extends IdentifiedValue,
  O extends T & OptionProp = T & OptionProp
> extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
  onChange: (values: T[]) => void;
  onBlur?: () => void;
  optionsContainerWidth?: number;
  optionsContainerHeight?: number;
  hideHeaderTitle?: boolean;
  headers?: Header[];
  options?: O[];
  value: T[];
  isChipEnabled?: boolean;
  enableMultiSelect?: boolean;
  showCellOnMultiSelectCell?: boolean;
  showSearch?: boolean;
  search?: string;
  isOptional?: boolean;
}

function MultiSelectPopup<T extends IdentifiedValue, O extends T & OptionProp = T & OptionProp>({
  hideHeaderTitle,
  headers = [],
  options = [],
  value,
  onBlur,
  onChange,
  isChipEnabled,
  enableMultiSelect,
  showCellOnMultiSelectCell,
  showSearch = false,
  search: searchProp,
  optionsContainerWidth,
  optionsContainerHeight,
  children,
  isOptional = false,
  ...props
}: React.PropsWithChildren<MultiSelectPopupProps<T, O>>): React.ReactElement {
  const selectionList = value ? getExistingData(value) : [];
  const [pendingOptions, setPendingOptions] = useState<O[]>(options);

  useEffect(() => {
    setPendingOptions((prevPendingOptions) => {
      const mappedPrevPendingOptions = keyBy(prevPendingOptions, 'id');

      return options.map((option) => {
        if (!(option.id in mappedPrevPendingOptions)) {
          return option;
        }

        return {
          ...option,
          ...mappedPrevPendingOptions[option.id],
        };
      });
    });
  }, [options]);

  const [search, setSearch] = useState('');

  const searchValue = showSearch ? search : searchProp;
  const optionList = useMemo(() => {
    if (searchValue) {
      return pendingOptions.filter((item) => {
        if (item.text?.toUpperCase().includes(searchValue.toUpperCase())) {
          return true;
        }
        if (
          item.id
            ?.toString()
            .toUpperCase()
            .includes(searchValue.toUpperCase())
        ) {
          return true;
        }
        return false;
      });
    }
    return pendingOptions;
  }, [pendingOptions, searchValue]);

  const addDefaultValueWhenValueDoesntExist = (item: any): any => {
    let newItem = { ...item };
    const defaultValueColumns = (headers as any[]).filter(
      (header) => header.extras?.defaultValue != null,
    );

    defaultValueColumns.forEach((column) => {
      const { field } = column;

      if (!newItem[field] || newItem[field] == null) {
        newItem = {
          ...newItem,
          [field]: column.extras.defaultValue,
        };
      }
    });

    return newItem;
  };

  const removeRedundantProps = ({ __typename: _, typeId: __, ...rest }: any) => rest;

  const updateSelectionList = (event: string) => {
    const isExist = !!selectionList.find((item) => item.id === event);

    if (!isExist) {
      const selectedItem = pendingOptions.find((o) => o.id === event);
      const resolvedData = addDefaultValueWhenValueDoesntExist(removeRedundantProps(selectedItem));

      if (enableMultiSelect) {
        const items = sortBy([...selectionList, resolvedData], (o) => Number(o.id));
        onChange(items);
      } else {
        onChange([resolvedData]);
      }
    } else if (enableMultiSelect) {
      const items = selectionList.filter((item) => item.id !== event);
      onChange(items);
    } else {
      onChange([]);
    }
  };

  const changesFromCell = (event: CellUpdates) => {
    setPendingOptions(
      pendingOptions.map((o) => {
        if (o.id === event.id) {
          return {
            ...o,
            [event.field]: event.value,
          };
        }

        return o;
      }),
    );

    const isExist = !!selectionList.find((o) => o.id === event.id);

    if (isExist) {
      const items = selectionList.map((o) => {
        if (o.id === event.id) {
          return {
            ...o,
            [event.field]: event.value,
          };
        }

        return o;
      });

      onChange(items);
    }
  };

  const onClear = () => {
    if (searchValue && selectionList && selectionList.length > 0) {
      const newSelection = differenceWith(
        selectionList,
        optionList || [],
        (a: any, b: any) => a.id === b.id,
      );
      onChange(newSelection);
    } else {
      onChange([]);
    }
  };

  const onSelectAll = () => {
    if (searchValue && optionList && optionList.length > 0) {
      const selectionIds = selectionList?.map((c: any) => c.id) || [];
      const optionIds = optionList?.map((c: any) => c.id) || [];
      const appendedItems = pendingOptions.filter(
        (item) => selectionIds.includes(item.id) || optionIds.includes(item.id),
      );
      onChange(appendedItems);
    } else {
      const items = sortBy(optionList || pendingOptions, (o) => o.id);
      const newItems = items.map((item) =>
        addDefaultValueWhenValueDoesntExist(removeRedundantProps(item)),
      );
      onChange(newItems);
    }
  };

  const onClose = (e: React.MouseEvent<HTMLElement, MouseEvent>) => {
    if (onBlur) {
      onBlur();
    }
    e.stopPropagation();
  };

  return (
    <div className={styles.multiSelectWrapper} {...props}>
      {isChipEnabled && (
        <>
          <div className={styles.selectionContainer}>
            {selectionList.map((item) => (
              <Tag key={item.id} item={item} onSelect={updateSelectionList} />
            ))}
            {selectionList.length === 0 && (
              <small style={{ marginLeft: '5px' }}>No selection found</small>
            )}
          </div>

          <hr />
        </>
      )}

      {showSearch ? (
        <Search
          placeholder="Search"
          onChange={(e) => {
            setSearch(e.target.value);
          }}
          className={styles.searchTextbox}
        />
      ) : null}
      <OptionContainer
        width={optionsContainerWidth}
        height={optionsContainerHeight}
        hideHeaderTitle={hideHeaderTitle}
        headers={headers}
        options={optionList}
        selectionList={selectionList}
        showCellOnMultiSelectCell={showCellOnMultiSelectCell}
        onSelect={updateSelectionList}
        onChangeFromCell={changesFromCell}
      />
      {children}
      <div style={{ textAlign: 'right' }}>
        {(enableMultiSelect || isOptional) && (
          <>
            <Button type="default" size="small" onClick={onClear} className={styles.btn}>
              Clear
            </Button>
            {enableMultiSelect && (
              <Button type="default" size="small" onClick={onSelectAll} className={styles.btn}>
                Select All
              </Button>
            )}
          </>
        )}
        <Button type="primary" size="small" onClick={onClose} className={styles.btn}>
          Ok
        </Button>
      </div>
    </div>
  );
}

export default MultiSelectPopup;

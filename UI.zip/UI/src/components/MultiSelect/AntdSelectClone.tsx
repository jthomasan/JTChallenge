import React from 'react';
import AntDSelect, { Option, SelectProps } from '../Select';

export interface CustomSelectProps<T> extends Omit<SelectProps, 'dropdownRender' | 'value'> {
  value: T | T[];
  valueRenderer?: (value: T | T[]) => React.ReactNode;
  dropdownRender: (dropdownProps?: SelectProps) => React.ReactNode;
}

function Select<T>({ value, valueRenderer, dropdownRender, ...props }: CustomSelectProps<T>) {
  return (
    <AntDSelect
      mode="default"
      value={value && (!Array.isArray(value) || value.length) ? '_value' : undefined}
      optionLabelProp="label"
      dropdownRender={(_, dropdownProps) => dropdownRender(dropdownProps)}
      {...props}
    >
      {value && (!Array.isArray(value) || value.length) ? (
        <Option value="_value" label={valueRenderer ? valueRenderer(value) : value} />
      ) : null}
    </AntDSelect>
  );
}

export default Select;

import React, { useCallback, useMemo, useState } from 'react';
import { InputProps } from 'antd/lib/input';
import { keyBy } from 'lodash';
import Select, { CustomSelectProps } from './AntdSelectClone';
import MultiSelectPopup, {
  MultiSelectPopupProps,
  OptionProp,
  IdentifiedValue,
} from './MultiSelectPopup';

interface BaseSelectProps<T extends IdentifiedValue>
  extends Omit<CustomSelectProps<T>, 'valueRenderer' | 'onChange' | 'dropdownRender'> {
  placeholder?: InputProps['placeholder'];
  options: MultiSelectPopupProps<T & OptionProp>['options'];
  style?: React.CSSProperties;
  size?: CustomSelectProps<T>['size'];
  dropdownMatchSelectWidth?: CustomSelectProps<T>['dropdownMatchSelectWidth'];
  disabled?: boolean;
}

interface SelectPropsSingular<T extends IdentifiedValue> extends BaseSelectProps<T> {
  multiple?: false;
  onChange: (value?: T) => void;
  value: T;
  valueRenderer?: (value: T) => React.ReactNode;
}

interface SelectPropsMultiple<T extends IdentifiedValue> extends BaseSelectProps<T> {
  multiple: true;
  onChange: (value: T[]) => void;
  value: T[];
  valueRenderer?: (value: T[]) => React.ReactNode;
}

type SelectPropsOverload<T extends IdentifiedValue> = Omit<
  SelectPropsSingular<T> | SelectPropsMultiple<T>,
  'onChange' | 'valueRenderer'
> & {
  onChange: (value?: T | T[]) => void;
  valueRenderer?: (value: T | T[]) => React.ReactNode;
};

function MultiSelect<T extends IdentifiedValue>(props: SelectPropsSingular<T>): React.ReactElement;
function MultiSelect<T extends IdentifiedValue>(props: SelectPropsMultiple<T>): React.ReactElement;
function MultiSelect<T extends IdentifiedValue>({
  multiple,
  value,
  onChange,
  options,
  ...props
}: SelectPropsOverload<T>) {
  const onChangeWrapped = useCallback<MultiSelectPopupProps<T>['onChange']>((nextValue) => {
    if (multiple) {
      onChange(nextValue ?? []);
    } else {
      onChange(nextValue?.length ? nextValue[0] : undefined);
    }
  }, []);

  const optionsById = useMemo(() => keyBy(options, ({ id }) => id), [options]);

  const [open, setOpenValue] = useState(false);
  const [search, setSearch] = useState('');

  const setOpen = (newOpen: boolean) => {
    setOpenValue(newOpen);
    if (!newOpen) {
      setSearch('');
    }
  };

  return (
    <Select
      open={open}
      showSearch
      dropdownMatchSelectWidth={false}
      onSearch={(searchStr: string) => {
        setSearch(searchStr);
      }}
      onDropdownVisibleChange={(newOpen: boolean) => {
        setOpen(newOpen);
      }}
      value={value}
      valueRenderer={(renderValue) => {
        if (Array.isArray(renderValue)) {
          return renderValue.map((v) => optionsById[v.id]?.text).join(',');
        }

        return optionsById[renderValue.id]?.text;
      }}
      dropdownRender={(dropdownProps) => (
        <MultiSelectPopup
          value={Array.isArray(value) ? value : [value]}
          onChange={onChangeWrapped}
          options={options}
          enableMultiSelect={multiple}
          onBlur={() => {
            setOpen(false);
          }}
          onMouseDown={(e) => {
            e.preventDefault();
          }}
          onScroll={dropdownProps?.onPopupScroll}
          showSearch={false}
          search={search}
        />
      )}
      {...props}
    />
  );
}

export default MultiSelect;

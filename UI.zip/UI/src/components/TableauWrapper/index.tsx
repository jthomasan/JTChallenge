import React, { useEffect } from 'react';
import TableauReport from 'tableau-react';

interface TableauWrapperProps {
  url: string;
  query?: string;
}

const TableauWrapper: React.FC<TableauWrapperProps> = (props) => {
  const [containerWidth, setContainerWidth] = React.useState(0);
  const [containerHeight, setContainerHeight] = React.useState(0);
  const { url, query } = props;

  const ref: React.RefObject<HTMLDivElement> = React.createRef();

  useEffect(() => {
    const div = ref.current;
    const newWidth = div?.offsetWidth || 0;
    const newHeight = div?.offsetHeight || 0;

    if (containerWidth !== newWidth) {
      setContainerWidth(newWidth);
    }

    if (containerHeight !== newHeight) {
      setContainerHeight(newHeight);
    }
  });

  const tableauReport =
    containerWidth > 0 && containerHeight > 0 ? (
      <TableauReport
        key={containerWidth}
        url={url}
        query={query}
        options={{
          hideTabs: false,
          height: containerHeight,
          width: containerWidth,
        }}
      />
    ) : null;

  return (
    <div ref={ref} style={{ overflow: 'hidden', height: '100%' }}>
      {tableauReport}
    </div>
  );
};
export default TableauWrapper;

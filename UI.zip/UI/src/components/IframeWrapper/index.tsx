import React, { useEffect } from 'react';
import Iframe from 'react-iframe';

interface IframeWrapperProps {
  url: string;
  reloadOnResize?: boolean;
  scrolling?: boolean;
}

const IframeWrapper: React.FC<IframeWrapperProps> = ({
  url,
  reloadOnResize = false,
  scrolling = true,
}) => {
  const [containerWidth, setContainerWidth] = React.useState(0);
  const [containerHeight, setContainerHeight] = React.useState(0);

  const ref: React.RefObject<HTMLDivElement> = React.createRef();

  useEffect(() => {
    const div = ref.current;
    const newWidth = div?.offsetWidth || 0;
    const newHeight = div?.offsetHeight || 0;

    if (containerWidth !== newWidth) {
      setContainerWidth(newWidth);
    }

    if (containerHeight !== newHeight) {
      setContainerHeight(newHeight);
    }
  });

  let key = url;
  if (reloadOnResize) {
    key = `${url}-${containerWidth}-${containerHeight}`;
  }

  const iframe =
    containerWidth > 0 && containerHeight > 0 ? (
      <Iframe
        key={key}
        url={url}
        width={`${containerWidth}px`}
        height={`${containerHeight}px`}
        scrolling={scrolling ? 'yes' : 'no'}
        frameBorder={0}
        display="block"
        position="relative"
      />
    ) : null;

  return (
    <div ref={ref} style={{ overflow: 'hidden', height: '100%' }}>
      {iframe}
    </div>
  );
};
export default IframeWrapper;

import React from 'react';

export type TDElementProps = Omit<JSX.IntrinsicElements['td'], 'onChange'>;

export const extractTDProps = (props: Partial<TDElementProps>): JSX.IntrinsicElements['td'] => ({
  'aria-colindex': props['aria-colindex'],
  'aria-selected': props['aria-selected'],
  className: props.className,
  colSpan: props.colSpan,
  onClick: props.onClick,
  onDoubleClick: props.onDoubleClick,
  onContextMenu: props.onContextMenu,
  onKeyDown: props.onKeyDown,
  onMouseEnter: props.onMouseEnter,
  onMouseLeave: props.onMouseLeave,
  onBlur: props.onBlur,
  role: props.role,
  tabIndex: props.tabIndex,
  style: props.style,
  ref: props.ref,
  key: props.key,
  draggable: props.draggable,
});

const SimpleTD = React.forwardRef<HTMLTableDataCellElement, TDElementProps>(
  ({ children, ...props }, ref) => (
    <td {...extractTDProps(props)} ref={ref}>
      {children}
    </td>
  ),
);

export const asCell = <P,>(Component: React.ComponentType<P>) => {
  const CellComponent = React.forwardRef<HTMLTableDataCellElement, P>((props, ref) => (
    <SimpleTD {...props} ref={ref}>
      <Component {...props} />
    </SimpleTD>
  ));

  const currentComponentName =
    Component.displayName ?? Component.name ?? Component.constructor?.name;
  CellComponent.displayName = `${currentComponentName}Cell`;

  return CellComponent;
};

export default SimpleTD;

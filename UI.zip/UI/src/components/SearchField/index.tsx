import React, { useState, useEffect } from 'react';
import classnames from 'classnames';
// eslint-disable-next-line import/no-extraneous-dependencies
import { DownOutlined, UpOutlined, CloseOutlined, SearchOutlined } from '@ant-design/icons';
import Input from '../Input';
import styles from './index.less';

export interface SearchFieldProps {
  placeholder?: string;
  value?: string;
  disabled?: boolean;
  className?: {
    actionIcon?: string;
    searchControls?: string;
    searchField?: string;
    searchInput?: string;
  };
  onChange?: (value: string) => void;
  nextOnEnter?: boolean;
  onNext?: () => void;
  nextDisabled?: boolean;
  onPrev?: () => void;
  prevDisabled?: boolean;
  onCancel?: () => void;
  cancelDisabled?: boolean;
  onSearch?: (value: string) => void;
}

const SearchField: React.FC<SearchFieldProps> = (props) => {
  const {
    placeholder,
    className,
    value,
    onChange,
    onNext,
    nextOnEnter,
    nextDisabled,
    onPrev,
    prevDisabled,
    onSearch,
    onCancel,
    cancelDisabled,
    disabled,
  } = props;

  const [inputValue, setInputValue] = useState(value);

  const onInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value: newVal } = event.target;
    if (onChange) onChange(newVal);
    setInputValue(newVal);
  };

  const onSearchAction = () => {
    if (onSearch) onSearch(inputValue || '');
  };

  const onKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      if (nextOnEnter && !nextDisabled && onNext) {
        onNext();
      } else {
        onSearchAction();
      }
    }
  };

  useEffect(() => {
    setInputValue(value);
  }, [value]);

  const controls =
    onSearch || onPrev || onNext || onCancel ? (
      <div className={classnames(styles.searchControls, className?.searchControls)}>
        {onSearch && (
          <div
            className={classnames({
              [styles.actionIcon]: true,
            })}
            onClick={onSearchAction}
          >
            <SearchOutlined key="search" title="Search" />
          </div>
        )}

        {onPrev && (
          <div
            className={classnames(
              {
                [styles.actionIcon]: true,
                [styles.disabled]: prevDisabled,
              },
              className?.actionIcon,
            )}
            onClick={prevDisabled ? () => {} : onPrev}
          >
            <UpOutlined key="searchprev" title="Search Prev" />
          </div>
        )}

        {onNext && (
          <div
            className={classnames(
              {
                [styles.actionIcon]: true,
                [styles.disabled]: nextDisabled,
              },
              className?.actionIcon,
            )}
            onClick={nextDisabled ? () => {} : onNext}
          >
            <DownOutlined key="searchnext" title="Search Next" />
          </div>
        )}

        {onCancel && (
          <div
            className={classnames(
              {
                [styles.actionIcon]: true,
                [styles.disabled]: cancelDisabled,
              },
              className?.actionIcon,
            )}
            onClick={cancelDisabled ? () => {} : onCancel}
          >
            <CloseOutlined key="searchcancel" title="Cancel Search" />
          </div>
        )}
      </div>
    ) : null;

  return (
    <div className={classnames(styles.searchField, className?.searchField)}>
      <Input
        className={classnames(styles.searchInput, className?.searchInput)}
        placeholder={placeholder}
        value={inputValue}
        onChange={onInputChange}
        onKeyPress={onKeyPress}
        disabled={disabled}
      />
      {controls}
    </div>
  );
};

export default SearchField;

import React from 'react';
import { GridCellProps } from '@progress/kendo-react-grid';
// eslint-disable-next-line import/no-extraneous-dependencies
import { CloseCircleFilled } from '@ant-design/icons';

import { Popover, Alert } from 'antd';
import styles from './index.less';

const ActionCell: React.FC<GridCellProps> = (props) => {
  const { dataItem, field = '' } = props;

  return dataItem.error ? (
    <td className={styles.actionColumn}>
      <Popover
        placement="bottomRight"
        trigger="click"
        content={<Alert type="error" message={dataItem.error} />}
        overlayClassName="uncommittedChangeErrorPopover"
      >
        <CloseCircleFilled className={styles.errorIcon} title="Error" />
        <span className={styles.errorText}>{dataItem[field]}</span>
      </Popover>
    </td>
  ) : (
    <td>{dataItem[field]}</td>
  );
};

export default ActionCell;

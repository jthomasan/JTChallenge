import React from 'react';
import { Grid, GridColumn } from '@progress/kendo-react-grid';
import { UncommittedChangesError } from '@/error/types';
import styles from './index.less';
import { CellField } from '../../ChangeSplitView';
import CustomCell from '../CustomCell';

export interface UncommitedChangesError {
  error: UncommittedChangesError;
}

const UncommitedChangesError: React.FC<UncommitedChangesError> = (props) => {
  const { committedActionsMessage, committedActionsDetails, originalError } = props.error;

  return (
    <div>
      <p>{originalError.message}</p>
      <span>{committedActionsMessage}</span>
      {committedActionsDetails && committedActionsDetails.length > 0 && (
        <details className={styles.errorDetails}>
          <summary>Show details</summary>
          <Grid
            className={styles.committedActionsGrid}
            data={committedActionsDetails}
            style={{ maxHeight: '200px' }}
            resizable
          >
            <GridColumn field={CellField.Action} width={60} title="Action" />
            <GridColumn field={CellField.SourceType} width={80} title="For" />
            <GridColumn field={CellField.SourceField} width={50} title="Field" cell={CustomCell} />
            <GridColumn field={CellField.From} width={165} title="From" cell={CustomCell} />
            <GridColumn field={CellField.To} width={165} title="To" cell={CustomCell} />
          </Grid>
        </details>
      )}
    </div>
  );
};

export default UncommitedChangesError;

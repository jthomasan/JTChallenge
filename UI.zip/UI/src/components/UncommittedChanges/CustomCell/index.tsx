import React from 'react';
import classNames from 'classnames';
import { GridCellProps } from '@progress/kendo-react-grid';
import styles from './index.less';

const UncommittedChangesCustomCell: React.FC<GridCellProps> = (props) => {
  const { dataItem, field = '' } = props;
  const value = dataItem[field];

  if (Array.isArray(value)) {
    return (
      <td>
        {value.map((item, index) => (
          <div
            // eslint-disable-next-line react/no-array-index-key
            key={index}
            className={classNames(value.length - 1 !== index ? styles.cellItemSeparator : '')}
          >
            {String(item)}
          </div>
        ))}
      </td>
    );
  }
  return <td>{value}</td>;
};

export default React.memo(UncommittedChangesCustomCell);

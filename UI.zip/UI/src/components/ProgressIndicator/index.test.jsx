import React, { _mockUseEffect, _mockUseState } from 'react';
import renderer from 'react-test-renderer';
import { message, Modal } from 'antd';
import ProgressIndicator, { ActionType } from './index';

describe('ProgressIndicator Tests', () => {
  it('should render ProgressIndicator component when render successfully', () => {
    _mockUseEffect(jest.fn((fn) => fn()));
    _mockUseState(jest.fn().mockReturnValue([false, jest.fn()]));

    const progressIndicator = renderer
      .create(<ProgressIndicator action={ActionType.none} actionMessage=""></ProgressIndicator>)
      .toJSON();

    expect(progressIndicator).toMatchSnapshot();
  });

  it('should call loading when action set to inProgress', () => {
    _mockUseEffect(jest.fn((fn) => fn()));
    _mockUseState(jest.fn().mockReturnValue([true, jest.fn()]));
    const spy = jest.spyOn(message, 'loading');

    jest.runAllTimers();

    const progressIndicator = renderer
      .create(
        <ProgressIndicator
          action={ActionType.inProgress}
          actionMessage="Saving..."
        ></ProgressIndicator>,
      )
      .toJSON();

    expect(progressIndicator).toMatchSnapshot();
    expect(spy).toHaveBeenCalledTimes(1);
    expect(spy).toHaveBeenCalledWith('Saving...', 0);

    spy.mockRestore();
  });

  it('should call success when action set to completed', () => {
    _mockUseEffect(jest.fn((fn) => fn()));
    _mockUseState(jest.fn().mockReturnValue([true, jest.fn()]));
    const spy = jest.spyOn(message, 'success');

    jest.runAllTimers();

    const progressIndicator = renderer
      .create(
        <ProgressIndicator action={ActionType.completed} actionMessage="Saved"></ProgressIndicator>,
      )
      .toJSON();

    expect(progressIndicator).toMatchSnapshot();
    expect(spy).toHaveBeenCalledTimes(1);
    expect(spy).toHaveBeenCalledWith('Saved', 2);

    spy.mockRestore();
  });

  it('should call error when action set to error', () => {
    _mockUseEffect(jest.fn((fn) => fn()));
    _mockUseState(jest.fn().mockReturnValue([true, jest.fn()]));
    const spy = jest.spyOn(Modal, 'error');

    jest.runAllTimers();

    const progressIndicator = renderer
      .create(
        <ProgressIndicator action={ActionType.error} actionMessage="Failed"></ProgressIndicator>,
      )
      .toJSON();

    expect(progressIndicator).toMatchSnapshot();
    expect(spy).toHaveBeenCalledTimes(1);

    spy.mockRestore();
  });
});

import React, { useEffect, useState, ReactNode } from 'react';
import { message, Modal } from 'antd';
import classnames from 'classnames';
import styles from './index.less';

export enum ActionType {
  inProgress = 'isProgress',
  completed = 'completed',
  error = 'error',
  none = 'none',
}

interface Props {
  title?: string;
  action: ActionType;
  actionMessage: string | ReactNode;
  hideOverlay?: boolean;
}

const ProgressIndicator: React.FC<Props> = (props) => {
  const { title, action, actionMessage, hideOverlay } = props;
  const [showOverlay, setShowOverlay] = useState(false);

  const clear = () => {
    message.destroy();
    setShowOverlay(false);
  };

  useEffect(() => {
    clear();

    switch (action) {
      case ActionType.inProgress:
        setShowOverlay(!hideOverlay);
        message.loading(actionMessage, 0);
        break;

      case ActionType.completed:
        message.success(actionMessage, 2);
        break;

      case ActionType.error:
        Modal.error({
          title: title ?? 'Error Saving Uncommitted Changes',
          content: actionMessage,
          keyboard: false,
          width: 650,
        });
        break;

      default:
        break;
    }
  }, [action]);

  return (
    <div
      id="progressIndicator"
      className={classnames(styles.overlay, showOverlay ? styles.show : '')}
    ></div>
  );
};

export default ProgressIndicator;

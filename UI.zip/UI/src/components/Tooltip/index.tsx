import React from 'react';

import { Tooltip as AntDTooltip } from 'antd';
import { TooltipPropsWithTitle } from 'antd/lib/tooltip';
import classNames from 'classnames';

import styles from './Tooltip.less';

export type TooltipProps = TooltipPropsWithTitle;

export type TooltipEventProps = {
  onMouseEnter?: React.HTMLAttributes<any>['onMouseEnter'];
  onMouseLeave?: React.HTMLAttributes<any>['onMouseLeave'];
};

export const filterTooltipProps = ({
  onMouseEnter,
  onMouseLeave,
}: TooltipEventProps | Record<string, any>) => ({ onMouseEnter, onMouseLeave });

export const TooltipChildWrapper: React.FC<{
  Component?: keyof JSX.IntrinsicElements;
}> = ({ Component = 'div', children, ...props }) => (
  <Component {...filterTooltipProps(props)}>{children}</Component>
);

const Tooltip: React.FC<TooltipProps> = ({
  children,
  title,
  mouseLeaveDelay = 0,
  mouseEnterDelay = 0.25,
  placement = 'bottom',
  overlayClassName,
  ...props
}) => (
  <AntDTooltip
    title={title ?? null}
    overlayClassName={classNames(styles.tooltip, overlayClassName)}
    placement={placement}
    mouseEnterDelay={mouseEnterDelay}
    mouseLeaveDelay={mouseLeaveDelay}
    destroyTooltipOnHide
    {...props}
  >
    {children}
  </AntDTooltip>
);

export default Tooltip;

// @ts-ignore
import React, { _mockUseState, _mockUseEffect } from 'react';
import renderer from 'react-test-renderer';
import { shallow } from 'enzyme';
import SecurityLayout from './SecurityLayout';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
let mockCallback: Function = () => {};
const mockSigninRedirect = jest.fn();
const mockSigninRedirectCallback = jest.fn();
const mockIsUserAuthenticated = jest.fn(() => new Promise((res) => res(false)));
const mockStartUserAuthentication = jest.fn();
const mockCompleteUserAuthentication = jest.fn(() => new Promise((res) => res({})));
const mockHandleSilentAuthentication = jest.fn(() => new Promise((res) => res({})));
const mockClearAuthenticationState = jest.fn();

jest.mock('oidc-client', () => ({
  UserManager: () => ({
    signinRedirect: mockSigninRedirect,
    signinRedirectCallback: mockSigninRedirectCallback,
    events: {
      addAccessTokenExpiring: jest.fn(),
      addAccessTokenExpired: jest.fn(),
      addUserLoaded: jest.fn(),
      addSilentRenewError: jest.fn(),
    },
  }),
}));

jest.mock('../services/authentication', () => ({
  authErrorsNotification: (callback: any) => {
    mockCallback = callback;
  },
  isUserAuthenticated: () => mockIsUserAuthenticated(),
  startUserAuthentication: (args: any) => mockStartUserAuthentication(args),
  completeUserAuthentication: () => mockCompleteUserAuthentication(),
  handleSilentAuthentication: () => mockHandleSilentAuthentication(),
  clearAuthenticationState: () => mockClearAuthenticationState(),
}));

jest.mock('umi/router', () => ({
  push: jest.fn(),
}));

jest.mock('../services/storage', () => ({
  deleteAllDBs: jest.fn(),
}));

describe('Security Layout Component Tests', () => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  let wrapper = null;
  let effect: Function = () => {};

  beforeAll(() => {
    process.env.NODE_ENV = 'test';

    _mockUseEffect(
      jest.fn((e) => {
        effect = e;
      }),
    );
  });

  beforeEach(() => {
    wrapper = shallow(
      <SecurityLayout>
        <div>Hello World</div>
      </SecurityLayout>,
      {
        lifecycleExperimental: true,
      },
    );
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should component show authentication loader when unauthenticated', () => {
    const component = renderer
      .create(
        <SecurityLayout>
          <div>Hello World</div>
        </SecurityLayout>,
      )
      .toJSON();

    expect(component).toMatchSnapshot();
  });

  it('should initiate authentication process when unauthenticated', async () => {
    delete window.location;
    // @ts-ignore
    window.location = {
      pathname: '/home',
      search: '?state=mockState',
    };

    _mockUseState(jest.fn().mockReturnValue([false, jest.fn()]));
    effect();

    await expect(mockIsUserAuthenticated).toHaveBeenCalledTimes(1);
    await expect(mockStartUserAuthentication).toHaveBeenCalledWith({
      params: '?state=mockState',
      pathname: '/home',
    });
  });

  it('should complete the authentication process when unauthenticated and in auth page', async () => {
    const state = {
      pathname: '/home',
      params: '?state=mockState',
    };
    const encodedState = encodeURIComponent(JSON.stringify(state));

    delete window.location;
    // @ts-ignore
    window.location = {
      pathname: '/auth',
      search: `#state=${encodedState}`,
    };

    _mockUseState(jest.fn().mockReturnValue([false, jest.fn()]));

    effect();
    mockCompleteUserAuthentication.mockImplementation(() => Promise.resolve(state));
    mockIsUserAuthenticated.mockImplementation(() => Promise.resolve(true));

    await expect(mockIsUserAuthenticated).toHaveBeenCalledTimes(1);
    await expect(mockCompleteUserAuthentication).toHaveBeenCalledTimes(1);
  });

  it('should initiate silent authentication process when loaded in iframe', () => {
    // @ts-ignore
    delete window.parent;
    _mockUseState(jest.fn().mockReturnValue([true, jest.fn()]));

    effect(() => {
      expect(mockHandleSilentAuthentication).toHaveBeenCalledTimes(1);
    });
  });

  it('should component show child elements when authenticated', () => {
    _mockUseState(jest.fn().mockReturnValue([true, jest.fn()]));
    effect();

    const component = renderer
      .create(
        <SecurityLayout>
          <div>Hello World</div>
        </SecurityLayout>,
      )
      .toJSON();

    expect(component).toMatchSnapshot();
  });
});

import React, { useEffect, useState, ReactNode, useRef } from 'react';
import { Dispatch } from 'redux';
import { connect } from 'dva';
import { Layout, message } from 'antd';
import '@fortawesome/fontawesome-free/css/all.min.css';
import classnames from 'classnames';
import '@progress/kendo-theme-default/dist/all.css';
import { ConnectState } from '@/models/connect';
import MeRVHeader from '@/components/GlobalHeader/MeRVHeader';
import { MenuDataItem, Settings, BasicLayoutProps } from '@ant-design/pro-layout';
import SideMenu from '@/components/SideMenu';
import ChangeSplitView from '@/components/ChangeSplitView';
import ProgressIndicator, { ActionType } from '@/components/ProgressIndicator';
import useRefreshNotification from '@/hooks/useRefreshNotification';
import useUncommittedChanges from '@/hooks/useUncommittedChanges';
import withErrorBoundary from '@/HOCs/withErrorBoundary';
import ErrorFallback from '@/error/ErrorFallback';
import UncommitedChangesError from '@/components/UncommittedChanges/ErrorModal';
import RefreshContext from '@/contexts/RefreshContext';
import { LayoutRefContext } from '@/contexts/LayoutRefContext';
import { useRefresh, withRefresh } from '@/hooks/useRefresh';
import { MeRVRoute } from '@/types/route';
import { HomeProps } from '@/pages/home';

import styles from './SideMenuLayout.less';

export interface SideMenuLayoutProps extends BasicLayoutProps {
  breadcrumbNameMap: {
    [path: string]: MenuDataItem;
  };
  route: BasicLayoutProps['route'] & {
    authority: string[];
  };
  settings: Settings;
  dispatch: Dispatch;
  location: any;
}
export type TopMenuLayoutContext = { [K in 'location']: SideMenuLayoutProps } & {
  breadcrumbNameMap: {
    [path: string]: MenuDataItem;
  };
};

const TopMenu: React.FC<any> = () => (
  // <Select defaultValue="1" className={styles.applicationDropdown}>
  //   <Option value="1">Market Risk Viewer</Option>
  //   <Option value="2">Scenario Manager</Option>
  // </Select>
  <div className={styles.applicationDropdown}>Market Risk Viewer</div>
);

const TopToolbar: React.FC<any> = () => (
  <>
    {/* <Badge dot>
      <Icon type="notification" />
    </Badge>
    <Badge dot>
      <Avatar size={30} icon="user" />
    </Badge> */}
  </>
);

const SideMenuLayout: React.FC<SideMenuLayoutProps> = (props) => {
  const {
    dispatch,
    collapsed,
    route: { routes },
    location,
    children,
  } = props;

  const [
    changes,
    ,
    undoChange,
    clearAllChanges,
    commitChanges,
    changeErrors,
  ] = useUncommittedChanges();
  const [shouldRefresh, updateShouldRefresh] = useRefreshNotification();
  const [isChildRefreshing, setChildRefreshing] = useState(false);
  const [progressIndicator, setProgressIndicator] = useState<{
    action: ActionType;
    message: string | ReactNode;
  }>({
    action: ActionType.none,
    message: '',
  });
  const layoutRef = useRef<HTMLDivElement>(null);

  const { refresh } = useRefresh();

  const handleMenuCollapse = (): void => {
    if (dispatch) {
      dispatch({
        type: 'global/changeLayoutCollapsed',
        payload: !collapsed,
      });
    }
  };

  const refreshAll = (): void => {
    refresh();
    updateShouldRefresh(true);
    setChildRefreshing(true);
  };

  const saveAll = async () => {
    setProgressIndicator({ action: ActionType.inProgress, message: 'Saving...' });
    try {
      const result = await commitChanges();
      if (result) {
        setProgressIndicator({ action: ActionType.completed, message: 'Saved' });
        refreshAll();
      } else {
        setProgressIndicator({ action: ActionType.none, message: '' });
      }
    } catch (e) {
      setProgressIndicator({
        action: ActionType.error,
        message: <UncommitedChangesError error={e} />,
      });
    }
  };

  const dispatchOnClickEvent = (e: React.MouseEvent<HTMLElement, MouseEvent>) => {
    if (e.currentTarget) {
      e.currentTarget.dispatchEvent(new Event('onClick'));
    }
  };

  useEffect(() => {
    if (!shouldRefresh && isChildRefreshing) {
      clearAllChanges();
      message.success('Refreshed Data');
      setChildRefreshing(false);
    }
  }, [shouldRefresh]);

  const currentTopPathname = `/${
    location.pathname.split('/').length > 1 ? location.pathname.split('/')[1] : ''
  }`;
  const isHome = currentTopPathname === '/home';
  const isTableauSignin = location.hash.includes('#/signin?');

  if (isTableauSignin && location.pathname === '/') {
    window.location.href = `/tableau/${location.hash}`;
  }

  const homeRoute: MeRVRoute = routes?.find((r: any) => r.name === 'home') as MeRVRoute;
  const HomeComponent: React.FC<HomeProps> | undefined = homeRoute.component;

  return (
    <LayoutRefContext.Provider value={layoutRef}>
      <RefreshContext.Provider value={refreshAll}>
        <div ref={layoutRef} onClick={dispatchOnClickEvent}>
          <Layout>
            <ProgressIndicator
              action={progressIndicator.action}
              actionMessage={progressIndicator.message}
            />
            <MeRVHeader menu={<TopMenu />} toolbar={<TopToolbar />} />
            <section className={styles.mainContent}>
              <SideMenu
                handleMenuCollapse={handleMenuCollapse}
                routes={routes}
                currentPathname={location.pathname}
                collapsed={collapsed}
              />
              <section className={styles.mainPanel}>
                {HomeComponent && (
                  <HomeComponent
                    className={classnames({
                      hidden: !isHome,
                    })}
                    allRoutes={routes as MeRVRoute[]}
                    homeRoute={homeRoute}
                    location={location}
                  />
                )}

                <ChangeSplitView
                  className={classnames({
                    hidden: isHome,
                  })}
                  changes={changes}
                  onUndo={undoChange}
                  onRefresh={refreshAll}
                  onSave={saveAll}
                  changeErrors={changeErrors}
                >
                  {!isHome && children}
                </ChangeSplitView>
              </section>
            </section>
          </Layout>
        </div>
      </RefreshContext.Provider>
    </LayoutRefContext.Provider>
  );
};

export default connect(({ global, settings }: ConnectState) => ({
  collapsed: global.collapsed,
  settings,
  global,
}))(
  withErrorBoundary(<ErrorFallback title="Unexpected Error" retryText="Reload Application" />)(
    withRefresh(SideMenuLayout),
  ),
);

import React, { useState, useEffect } from 'react';
import router from 'umi/router';
import { Spin, Modal } from 'antd';

import { useApolloClient, ApolloClient } from 'umi-plugin-apollo-anz/apolloClient';
import {
  isUserAuthenticated,
  startUserAuthentication,
  completeUserAuthentication,
  authErrorsNotification,
  NotificationType,
  handleSilentAuthentication,
  clearAuthenticationState,
} from '../services/authentication';
import { authErrorMessages } from '../constants/messages';
import { deleteAllDBs } from '../services/storage';

import styles from './SecurityLayout.less';

declare const IS_MOCK_DISABLED: boolean;

const clearQueryParams = () => {
  router.replace({
    query: '',
  });
};

const completeAuthProcess = async (
  setIsAuthenticated: Function,
  apolloClient: ApolloClient<any>,
) => {
  try {
    const state = await completeUserAuthentication(apolloClient);
    const isUserLoggedIn = await isUserAuthenticated();

    setIsAuthenticated(isUserLoggedIn);

    if (isUserLoggedIn) {
      router.push({
        pathname: state.pathname,
        search: state.params,
      });
    }
  } catch (error) {
    clearQueryParams();

    clearAuthenticationState(false);
  }
};

const initAuthProcess = async (setIsAuthenticated: Function, apolloClient: ApolloClient<any>) => {
  const currentPathname = window.location.pathname;
  const isUserLoggedIn = await isUserAuthenticated();

  if (!isUserLoggedIn) {
    if (currentPathname === '/auth' && window.location.hash !== '') {
      await completeAuthProcess(setIsAuthenticated, apolloClient);
    } else if (currentPathname === '/auth' && window.location.search !== '') {
      clearQueryParams();
      await clearAuthenticationState();
    } else {
      startUserAuthentication({
        pathname: currentPathname !== '/auth' ? currentPathname : 'home',
        params: window.location.search,
      });
    }
  } else {
    setIsAuthenticated(isUserLoggedIn);

    if (currentPathname === '/auth') {
      router.push('/home');
    }
  }
};

// Warn the user if silent renewal fails or couldnt authenticate the user
const authenticationError = () => {
  Modal.destroyAll();
  Modal.error({
    title: 'Authentication Error',
    content: authErrorMessages.authenticationError,
    keyboard: false,
    okButtonProps: {
      hidden: true,
    },
  });
};

const sessionTimeoutError = () => {
  Modal.destroyAll();
  Modal.error({
    title: 'Session timeout',
    content: authErrorMessages.sessionTimeout,
    keyboard: false,
    okButtonProps: {
      hidden: true,
    },
  });
};

const Layout: React.FC = ({ children }) => {
  const isLoadedInsideIFrame = window !== window.parent;
  const apolloClient = useApolloClient();

  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    authErrorsNotification((notification: NotificationType) => {
      switch (notification) {
        case NotificationType.TokenExpired:
          deleteAllDBs(true);
          sessionTimeoutError();
          break;
        case NotificationType.AuthenticationError:
          deleteAllDBs(true);
          authenticationError();
          break;

        default:
          break;
      }
    });

    if (!isAuthenticated && !isLoadedInsideIFrame) {
      initAuthProcess(setIsAuthenticated, apolloClient);
    } else if (isLoadedInsideIFrame) {
      handleSilentAuthentication();
    }

    deleteAllDBs();
  }, []);

  const authenticationIndicator = (
    <div className={styles.authenticationIndicator}>
      <Spin size="large" tip="Authenticating..." />
    </div>
  );

  return <>{isAuthenticated ? children : authenticationIndicator}</>;
};

export default Layout;

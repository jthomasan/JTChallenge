export const AUTO_REFRESH_INTERVAL = 1000 * 60 * 5; // 5 mins

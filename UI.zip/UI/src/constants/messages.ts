import { ChangeErrorType } from '@/types/change';

export const authErrorMessages = {
  authenticationError:
    'An unknown error occurred during the authentication process. Please refresh the page to continue.',
  sessionTimeout: 'Sorry, your session has timed out. Please refresh the page to continue.',
};

export const dataChangeErrorMessages = {
  [ChangeErrorType.EMPTY]: 'Enter a value',
  [ChangeErrorType.NOT_UNIQUE]: 'Value must be unique',
  [ChangeErrorType.NOT_UNIQUE_BETWEEN_FIELDS]: 'Value already selected for {value}',
  [ChangeErrorType.NOT_UNIQUE_AS_A_COMPOSITE_FIELD]: '{value} must be a unique combination',
  [ChangeErrorType.MIN_LIMIT]: 'Value must be greater than or equal to {value}',
  [ChangeErrorType.MAX_LIMIT]: 'Value must be less than or equal to {value}',
  [ChangeErrorType.MIN_LIMIT_BY]: 'Value must be greater than or equal to {value} column value',
  [ChangeErrorType.MAX_LIMIT_BY]: 'Value must be less than or equal to {value} column value',
  [ChangeErrorType.MIN_LENGTH]: 'Value must have a minimum length of {value}',
  [ChangeErrorType.MAX_LENGTH]: 'Value must have a maximum length of {value}',
  [ChangeErrorType.REQUIRED_LENGTH]: 'Value must have a length of {value}',
  [ChangeErrorType.REQUIRED_FIELD]: '{value} cannot be empty when {value} is {value}',
};

export default {
  module: {
    rules: [],
  },
};

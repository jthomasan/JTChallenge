const gql = require("graphql-tag");
exports.schema = gql`
  extend type Query {
    SpecificRiskAudit(from: Date!, to: Date!, measureType: ID!): [SpecificRiskAudit]
    SpecificRiskAuditMeasureTypes: [Option]
  }

  type SpecificRiskAudit {
    date: Date
    tenDayVaR: String
    stressVaR: String
    specRiskIR: String
    specRiskEQ: String
    specRiskSec: String
    economicalCap: String
    tenDayVaRAssetType: String
    stressVaRAssetType: String
  }
`;

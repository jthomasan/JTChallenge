const gql = require('graphql-tag');
exports.schema = gql`
  extend input BatchActions {
    sendRerunRequest: RerunRequestInput
    sendProxyRequest: ProxyRequestInput
    sendExcludeRequest: ExcludeRequestInput
    sendReloadRequest: ReloadRequestInput
    sendSignOffRequest: SignOffRequestInput
    sendFMRetryFeedRequest: RetryFeedInput
    sendREMRetryFeedRequest: RetryFeedInput
    sendOverrideFeedStatusRequest: OverrideFeedStatusInput
  }

  extend type Query {
    RiskContainerStatuses(
      nodeId: ID!
      date: Date!
      snapshot: String!
      sourceSystemEnvironments: [String]
      sourceSystemIds: [ID]
      reportTypeIds: [ID]
    ): [RiskContainerStatus]
    RiskDataHierarchyFeedStatuses(
      nodeId: ID
      cob: String
      snapshot: String
      isRootPortfolioNode: Boolean
      containerIds: [ID]
      sourceSystemEnvironments: [String]
      sourceSystemIds: [ID]
      reportTypeIds: [ID]
      statuses: String
    ): [RiskDataHierarchyFeedStatus]
    RiskDataPortfolioFeedStatuses(
      nodeId: ID
      cob: String
      snapshot: String
      isRootPortfolioNode: Boolean
      containerIds: [ID]
      sourceSystemEnvironments: [String]
      sourceSystemIds: [ID]
      reportTypeIds: [ID]
      statuses: [String]
    ): [PortfolioFeedStatus]
    RiskDataReports(
      selectedContainers: [String]!
      sourceSystemId: ID!
    ): [RiskDataReport]
    RiskDataPricingErrors(
      cob: String
      isPortfolioNode: Boolean
      portfolioNode: String
      reports: [String]
      snapshot: String
      sourceSystemEnvironments: [String]
    ): [RiskDataPricingError]
    ReportTypes: [ReportType]
    RiskDataSourceSystems(isRiskDataSource: Boolean): [SourceSystem]
    Snapshots: [String]
    PortfolioHierarchies(date: Date!): [PortfolioHierarchyNode]
    PortfolioHierarchiesWithDate(date: Date): PortfolioHierarchiesDate
    CurrentBusinessDate: Date
    FeedLogMessages(feedIDs: [ID]!): [FeedLogMessage]
    CubeVersions(
      cob: String
      portfolios: [String]
      snapshot: String
      sourceSystemId: ID
      reports: [String]
    ): [CubeVersion]
    FeedREMEvents(feedIDs: [ID]!): [FeedREMEvent]

    SourceSystemFeedStatuses(
      nodeId: ID!
      cob: Date!
      snapshots: [String]
    ): [SourceSystemFeedStatus]

    PreviousCubeVersions(cubeLoadId: ID): [PreviousCubeVersion]
  }

  type PortfolioHierarchyNodeLink {
    id: ID!
    nodeId: ID!
    name: String
  }

  type RiskDataHierarchyFeedStatus {
    id: ID!
    nodeId: ID!
    name: String
    type: String
    isSignOffAllowed: Boolean!
    isRerunEnabled: Boolean
    level: Int
    overallStatus: String
    feed: Feed
    parent: PortfolioHierarchyNodeLink
    counts: FeedCount
  }

  type PortfolioHierarchyNode {
    id: ID!
    nodeId: ID!
    name: String
    type: String
    level: Int
    overallStatus: String
    parent: PortfolioHierarchyNodeLink
  }

  type PortfolioHierarchiesDate {
    date: Date
    nodes: [PortfolioHierarchyNode]
  }

  type ReportType {
    id: ID!
    name: String
  }

  type SourceSystem {
    id: ID!
    name: String
    description: String
    isRiskDataSource: Boolean
    environments: [SourceSystemEnvironment]
  }

  type SourceSystemEnvironment {
    id: ID
    name: String
    snapshot: String
    sourceSystem: SourceSystem
    mrePositionSource: String
    fxRateSource: [String]
    isActive: Boolean
  }

  type RiskContainerStatus {
    id: ID
    containerId: ID
    name: String
    isSignOffRequired: Boolean
    overall: OverallStatusSummary
    cube: StatusSummary
    subCube: StatusSummary
    fvaCube: StatusSummary
    fvaSubCube: StatusSummary
    rdw: StatusSummary
    signOff: SignOffStatusSummary
  }

  type SourceSystemFeedStatus {
    id: ID
    sourceSystemId: ID
    name: String

    cube: SourceSystemStatusSummary
    subCube: SourceSystemStatusSummary
    rdw: SourceSystemStatusSummary

    cubeStatus: String
    overallStatus: String

    allFeedsScheduled: Boolean
  }

  type SourceSystemStatusSummary {
    completed: Int
    completedPercent: Float
    notStarted: Int
    processing: Int
    failed: Int

    total: Int
  }

  type StatusSummary {
    completed: Int
    completedPercent: Float
    processing: Int
    notStarted: Int
    noData: Int
    failed: Int
    total: Int
  }

  type OverallStatusSummary {
    completed: Int
    completedPercent: Float
    hasFailures: Boolean
    total: Int
  }

  type SignOffStatusSummary {
    completed: Int
    completedPercent: Float
    pending: Int
    noData: Int
    total: Int
  }

  type FeedCount {
    riskEngine: FeedCountDetail
    riskEngineError: FeedCountDetail
    download: FeedCountDetail
    rdw: FeedCountDetail
    signOff: FeedCountDetail
    overall: FeedCountDetail
    cubeQueue: FeedCountDetail
    cubeLoad: FeedCountDetail
    cubeTradeEtl: FeedCountDetail
    subCubeLoad: FeedCountDetail
    subCubePositionEtl: FeedCountDetail
    fvaCubeLoad: FeedCountDetail
    fvaCubeTradeEtl: FeedCountDetail
    fvaSubcubeLoad: FeedCountDetail
    fvaSubcubePositionEtl: FeedCountDetail
  }

  type FeedCountDetail {
    notStarted: Float
    processing: Float
    completed: Float
    failed: Float
    noData: Float
    aborted: Float
    total: Float
    completedPercentage: Float
  }

  type Feed {
    businessDate: String
    reportName: String
    containerId: Int
    containerName: String
    portfolioName: String
    portfolioId: Int
    sourceSystemEnvironment: String
    hasSourceSystemError: Boolean
    isEmpty: Boolean
    isRerun: Boolean
    isExclusion: Boolean
    isProxy: Boolean
    isReload: Boolean
    isFmFeed: Boolean
    isStale: Boolean
    hasQuarantine: Boolean
    cubeVersion: Int
    subCubeVersion: Int
    cubeLoadId: Int
    cubeLoadTime: String
    feedId: Int
    status: FeedLoadStatus
    additionalInfo: String
  }

  type FeedLoadStatus {
    riskEngine: String
    download: String
    rdw: String
    signOff: String
    errorDownload: String
    overall: String
    cubeQueue: String
    cubeLoad: String
    cubeTradeEtl: String
    subCubeQueue: String
    subCubeLoad: String
    subCubePositionEtl: String
    subCubeOverall: String
    fvaCubeLoad: String
    fvaCubeTradeEtl: String
    fvaSubcubeLoad: String
    fvaSubcubePositionEtl: String
  }

  type PortfolioFeedStatus {
    id: ID
    feedId: ID
    additionalInfo: String
    businessDate: String
    container: Container
    cubeVersion: Int
    cubeLoadID: Int
    cubeLoadTime: String
    isEmpty: Boolean
    isExclusion: Boolean
    isFmFeed: Boolean
    isReload: Boolean
    isRerun: Boolean
    isStale: Boolean
    isProxy: Boolean
    hasSourceSystemError: Boolean
    portfolio: PortfolioInfo
    reportName: String
    sourceSystemEnvironment: String
    status: StatusDetails
    subCubeVersion: Int
  }

  type Container {
    id: ID
    name: String
  }

  type PortfolioInfo {
    id: ID
    name: String
  }

  type RiskDataPricingError {
    businessDate: String
    report: String
    reportDescription: String
    portfolio: String
    skyTradeID: Int
    murexTradeID: Int
    mxFamily: String
    mxType: String
    mxGroup: String
    mxInstrument: String
    counterParty: String
    contractName: String
    jobName: String
    errorMessage: String
  }

  type StatusDetails {
    cubeLoad: String
    cubeQueue: String
    cubeTradeEtl: String
    download: String
    errorDownload: String
    fvaCubeLoad: String
    fvaCubeTradeEtl: String
    fvaSubcubeLoad: String
    fvaSubcubePositionEtl: String
    overall: String
    rdw: String
    riskEngine: String
    signOff: String
    subCubeLoad: String
    subCubeQueue: String
    subCubePositionEtl: String
    subCubeOverall: String
  }

  type RiskDataReport {
    id: ID
    reportId: ID
    description: String
    name: String
    type: Int
    container: String
    exclusionEnabled: Boolean
    hasIntradayFeed: Boolean
    isActive: Boolean
    isCCYRateDependent: Boolean
    isComVolCurveDependent: Boolean
    isFmProcessing: Boolean
    isMreDependent: Boolean
    isRefDependent: Boolean
    proxyEnabled: Boolean
    rerunEnabled: Boolean
    valuationType: String
    sourceSystem: SourceSystemLink
  }

  type SourceSystemLink {
    id: ID
    value: String
  }

  input RerunRequestInput {
    date: Date!
    portfolios: [String]!
    reports: [String]!
    snapshot: String!
    comment: String!
    sourceSystemEnvironments: [String]
    sourceSystemId: ID!
  }

  input SourceSystemEnvironmentInputType {
    id: ID
    text: String
  }

  input ProxyRequestInput {
    date: Date!
    sourceBusinessDate: Date!
    portfolios: [String]!
    reports: [String]!
    snapshot: String!
    comment: String!
    sourceSystemId: ID!
  }

  input ExcludeRequestInput {
    date: Date!
    portfolios: [String]!
    reports: [String]!
    snapshot: String!
    comment: String!
    sourceSystemId: ID!
  }

  input ReloadRequestInput {
    date: Date!
    portfolios: [String]!
    reports: [String]!
    snapshot: String!
    version: Int!
    comment: String!
    sourceSystemId: ID!
  }

  input SignOffRequestInput {
    date: Date!
    portfolios: [String]!
    containers: [String]!
    snapshot: String!
    nodeId: ID!
    isPortfolioNode: Boolean!
    comment: String!
    sourceSystemIds: [ID]!
  }

  input RetryFeedInput {
    feedIDs: [ID]
    retryType: RetryType
  }

  input OverrideFeedStatusInput {
    feedIDs: [ID]
    newStatus: StatusEnum
  }

  enum RetryType {
    Restart
    Download
    Publish
    CubeLoad
    SubCubeLoad
    Abort
    Complete
    RestartJob
  }

  enum StatusEnum {
    COMPLETE
    ABORTED
    NO_DATA
  }

  type FeedLogMessage {
    feedID: ID!
    reportName: String!
    portfolio: String!
    message: String
  }

  type FeedREMEvent {
    id: ID!
    feedID: ID
    historyID: ID
    payloadID: ID
    sourceSystemEnvironment: String
    returnCode: String
    stateCode: String
    statusLog: String
    exceptionLog: String
    addedTime: String
  }

  type CubeVersion {
    id: ID!
    text: String!
  }

  type PreviousCubeVersion {
    id: ID!
    cubeVersion: Int!
    cubeLoadTime: String
    isRerun: Boolean!
    isExclusion: Boolean!
    isProxy: Boolean!
    isReload: Boolean!
  }
`;

const gql = require("graphql-tag");
exports.schema = gql`
  extend input BatchActions {
    replaceCsvConfiguration: UpdateCsvConfiguration
    addCsvConfiguration: UpdateCsvConfiguration
    replaceReconThresholdSetting: UpdateReconThresholdSetting
    addReconThresholdSetting: UpdateReconThresholdSetting
    replaceNotificationConfiguration: UpdateNotificationConfiguration
    addNotificationConfiguration: UpdateNotificationConfiguration
    sendNotificationJobRequest: ManualTriggerNotificationJob
    replaceSystemConfiguration: UpdateSystemConfiguration
  }

  extend type Query {
    CsvConfiguration: [CsvConfiguration]
    FMConfigAuditHistory(
      configTypeId: ID!
      auditId: ID!
    ): FMConfigAuditHistoryType
    FeedMonitorLog(fmConfigTypeId: ID, logId: ID): [FeedMonitorLog]
    NotificationConfiguration: [NotificationConfiguration]
    ReconThresholdSetting(reconType: String): [ReconThresholdSetting]
    SystemConfiguration: [SystemConfiguration]
  }

  type SystemConfiguration {
    id: ID!
    modified: Boolean!
    name: String
    value: String
    added: Added
  }

  type ReconThresholdSetting {
    id: ID!
    modified: Boolean!
    statusName: String
    range: Int
    isActive: Boolean
    reconType: ReconType
    added: Added
  }

  type ReconType {
    id: ID!
    value: String
    displayName: String
  }

  type FeedMonitorLog {
    jobName: String
    startTime: Date
    endTime: Date
    resultMessage: String
    errorMessage: String
  }

  type CsvConfiguration {
    id: ID!
    modified: Boolean!
    name: String
    description: String
    isActive: Boolean
    pollIntervalInMinute: Int
    folderPath: String
    fileNamePattern: String
    tableName: String
    columnsMapping: String
    preUploadSqlStatement: String
    postUploadSqlStatement: String
    etlJobTypeId: Int
    enableFileWatcher: Boolean
    bulkUploadBatchSize: Int
    bulkUploadTimeOutInSeconds: Int
    startFooterLineText: String
    skipFooterLineCount: Int
    specialQuoteHandler: Boolean
    hasHeader: Boolean
    columnDelimiter: String
    textQualifier: String
    escapeCharactor: String
    sendCompleteEmailToOwner: Boolean
    sendErrorEmailToOwner: Boolean
    completeEmailToList: String
    completeEmailCcList: String
    errorEmailToList: String
    errorEmailCcList: String
    added: Added
  }

  type FMConfigAuditHistoryType {
    columns: [AuditHistoryColumnType]
    rows: [JSON]
  }

  type NotificationConfiguration {
    id: ID!
    modified: Boolean!
    name: String
    description: String
    assemblyName: String
    typeName: String
    isActive: Boolean
    pollIntervalInMinute: Int
    sqlStatement: String
    isEmailEnabled: Boolean
    email: NotificationEmail
    event: NotificationEvent
    isEventEnabled: Boolean
    moduleName: String
    additional: NotificationAdditional
    allowManualTrigger: Boolean
    scheduleStart: DateTime
    scheduleEnd: DateTime
    workingDayOnly: Boolean
    added: Added
  }

  type NotificationAdditional {
    param1: String
    param2: String
    param3: String
  }

  type NotificationEvent {
    id: Int
    logName: String
    logSource: String
    eventText: String
  }

  type NotificationEmail {
    templateName: String
    toList: String
    ccList: String
    subjectText: String
    bodyText: String
  }

  input UpdateCsvConfiguration {
    id: ID
    name: String
    description: String
    isActive: Boolean
    pollIntervalInMinute: Int
    folderPath: String
    fileNamePattern: String
    tableName: String
    columnsMapping: String
    preUploadSqlStatement: String
    postUploadSqlStatement: String
    etlJobTypeId: Int
    enableFileWatcher: Boolean
    bulkUploadBatchSize: Int
    bulkUploadTimeOutInSeconds: Int
    startFooterLineText: String
    skipFooterLineCount: Int
    specialQuoteHandler: Boolean
    hasHeader: Boolean
    columnDelimiter: String
    textQualifier: String
    escapeCharactor: String
    sendCompleteEmailToOwner: Boolean
    sendErrorEmailToOwner: Boolean
    completeEmailToList: String
    completeEmailCcList: String
    errorEmailToList: String
    errorEmailCcList: String
  }

  input UpdateReconThresholdSetting {
    id: ID
    statusName: String
    range: Int
    isActive: Boolean
    reconType: String
  }

  input InputNotificationAdditional {
    param1: String
    param2: String
    param3: String
  }

  input InputNotificationEvent {
    id: Int
    logName: String
    logSource: String
    eventText: String
  }

  input InputNotificationEmail {
    templateName: String
    toList: String
    ccList: String
    subjectText: String
    bodyText: String
  }

  input UpdateNotificationConfiguration {
    id: ID
    name: String
    description: String
    assemblyName: String
    typeName: String
    isActive: Boolean
    pollIntervalInMinute: Int
    sqlStatement: String
    isEmailEnabled: Boolean
    email: InputNotificationEmail
    event: InputNotificationEvent
    isEventEnabled: Boolean
    moduleName: String
    additional: InputNotificationAdditional
    allowManualTrigger: Boolean
    scheduleStart: DateTime
    scheduleEnd: DateTime
    workingDayOnly: Boolean
  }

  input ManualTriggerNotificationJob {
    jobId: Int
  }

  input UpdateSystemConfiguration {
    id: ID
    value: String
  }
`;

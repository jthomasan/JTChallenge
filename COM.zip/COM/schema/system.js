const gql = require("graphql-tag");
exports.schema = gql`
  scalar DateTime
  scalar Date
  scalar JSON
  scalar Any

  type Query {
    User: User
  }

  type Mutation

  type User {
    authority: [String]
  }

  type Option {
    id: ID
    text: String
  }
`;

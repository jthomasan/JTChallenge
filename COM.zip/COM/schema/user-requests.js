const gql = require("graphql-tag");
exports.schema = gql`
  enum WorkflowType {
    RERUN
    PROXY
    EXCLUSION
    INCLUSION
    SIGN_OFF
    RELOAD
  }

  extend type Query {
    WorkflowRequests(date: Date!, type: WorkflowType!): [WorkflowRequest]
  }

  type WorkflowRequest {
    id: ID
    type: WorkflowType
    businessDate: Date
    runDate: Date
    report: String
    container: String
    portfolio: String
    status: String
    isProcessed: Boolean
    comment: String
    snapshot: String
    sourceBusinessDate: Date
    sourceSystem: SourceSystem

    portfolioNode: PortfolioInfo
    # sourceFeed: FeedInfo # Not yet needed for signOff

    useVersion: Int

    message: String

    added: Added
    lastUpdated: Added
  }
`;

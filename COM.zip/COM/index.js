exports.schemas = [
  require("./schema/system").schema,
  require("./schema/hierarchy").schema,
  require("./schema/static-data").schema,
  require("./schema/ref-data-configuration").schema,
  require("./schema/risk-data").schema,
  require("./schema/user-requests").schema,
  require("./schema/feed-monitor-configuration").schema,
  require("./schema/recon-reports").schema,
  require("./schema/spec-risk").schema,
];

declare module "merv-web-common" {
  import { gql } from "graphql-tag";
  const schemas: ReturnType<typeof gql>[];
  export { schemas };
}

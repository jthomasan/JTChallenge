import * as express from 'express';
import * as cors from 'cors';
import * as path from 'path';
import * as cookieParser from 'cookie-parser';
import * as bodyParser from 'body-parser'
import './env';
import { createServer } from './server';
import { getNormalisedFileData } from './utils/normaliseFileData';
import loginHandler from './routes/login';
import oidcAuthorizeHandler from './routes/oidc-authorize';
import logger from './utils/loggingUtil';
import createLogger from './middleware/logger';

const app = express();

const resolverConfigs = getNormalisedFileData(
  path.resolve(__dirname, '../api-mappings'),
  path.resolve(__dirname, '../schemas/RestToGqlSchema.json'),
);
const server = createServer(resolverConfigs);

app.set('port', process.env.PORT);
app.set('host', process.env.HOST);
app.use(bodyParser({ limit: '5mb' }));
app.use(cookieParser());
app.use(cors());
app.use(createLogger(logger));
app.use(server.getMiddleware());

app.get('/version', (req, res) =>
  res.send({
    app: `merv-web-api@${process.env.npm_package_version}`,
  }),
);

// register login route
app.post('/login', loginHandler);
app.get('/oidc/authorize', oidcAuthorizeHandler);

const expressServer = app.listen(app.get('port'), () => {
  logger.info(`Server listening at http://${process.env.HOST}:${process.env.PORT}`);
});

expressServer.timeout = 300000;

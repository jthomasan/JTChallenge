import { getPathFromUrlTemplate } from '../utils';
import RESTDataSourceWithLog from './RESTDataSourceWithLog';

export enum Method {
  get = 'get',
  post = 'post',
  put = 'put',
  patch = 'patch',
  delete = 'delete',
}

export default class GenericAPIDataSource extends RESTDataSourceWithLog {
  constructor() {
    super();
    this.baseURL = process.env.API_HOST;
  }

  willSendRequest(request) {
    super.willSendRequest(request);
    let authHeader = null;

    if (this.context.headers.authorization) {
      authHeader = this.context.headers.authorization;
    } else if (this.context.token) {
      authHeader = `Bearer ${this.context.token}`;
    }

    if (authHeader) {
      request.headers.set('Authorization', authHeader);
    }

    request.headers.set('Accept-Encoding', 'gzip');
  }

  async getRestResources(
    urlTemplate: string,
    parentEntity,
    additionalLookups: Record<string, Record<string, any>>,
  ) {
    const path = getPathFromUrlTemplate(urlTemplate, parentEntity, additionalLookups);
    const result = await this.get(encodeURI(path));
    return result.data;
  }

  /**
   * Generic restful write function
   *
   * @param {Method enum} method - http method to use
   * @param {string} endpointURI - uri for resource
   * @param {object} resource - rest payload
   */
  async write(method: Method, endpointURI: string, resource: object, configHeaders?: object) {
    const methodLC = method.toLowerCase();
    const headers = { ...configHeaders };

    if (method === Method.patch) {
      headers['Content-Type'] = 'application/json-patch+json';
    }

    if (this[methodLC]) {
      return this[methodLC](endpointURI, resource, {
        headers,
      });
    }
    return null;
  }
}

import GenericAPI, { Method } from './genericAPI';

const mocks = {
  post: jest.fn(),
  put: jest.fn(),
  patch: jest.fn(),
  delete: jest.fn(),
};

const genericAPI = new GenericAPI();
(genericAPI as any).post = mocks.post;
(genericAPI as any).put = mocks.put;
(genericAPI as any).patch = mocks.patch;
(genericAPI as any).delete = mocks.delete;

describe('Generic API writes', () => {
  beforeEach(() => {
    mocks.post.mockReset();
    mocks.put.mockReset();
    mocks.delete.mockReset();
  });

  it('should use the given method', async () => {
    await genericAPI.write(Method.put, '', {});
    await genericAPI.write(Method.delete, '', {});
    await genericAPI.write(Method.put, '', {});
    await genericAPI.write(Method.post, '', {});

    expect(mocks.put).toBeCalledTimes(2);
    expect(mocks.delete).toBeCalledTimes(1);
    expect(mocks.post).toBeCalledTimes(1);
  });

  it('should use the given method, uri and resource', async () => {
    const uri = 'to/some/resource';
    const resource = {
      a: 'z',
      b: 'y',
    };

    await genericAPI.write(Method.put, uri, resource);

    expect(mocks.put).toBeCalledTimes(1);
    expect(mocks.put).toBeCalledWith(uri, resource, { headers: {} });
  });

  it('should use the given method, uri, resource, and add custom headers for patch', async () => {
    const uri = 'to/some/resource';
    const resource = [
      {
        a: 'z',
        b: 'y',
      },
    ];

    await genericAPI.write(Method.patch, uri, resource);

    expect(mocks.patch).toBeCalledTimes(1);
    expect(mocks.patch).toBeCalledWith(uri, resource, {
      headers: { 'Content-Type': 'application/json-patch+json' },
    });
  });
});

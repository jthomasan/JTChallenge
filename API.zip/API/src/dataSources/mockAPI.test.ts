import { parse } from 'graphql';
import MockAPI from './mockAPI';
import { mockNodes, mockPortfolios } from './__mocks__/mockApi';

const mocks = {
  post: jest.fn(),
};

const mockAPI = new MockAPI();
(mockAPI as any).post = mocks.post;

const defaultArgs = {
  nodeId: 7,
  titleSearch: '',
};

const NODE_QUERY = `
  query {
    Nodes(type: RISK_PORTFOLIO) {
      id
      title
      type
      portfolios {
        id
        isActive
        createdOn
      }
    }
  }
`;

const PORTFOLIO_QUERY = `
 query {
  Portfolios {
    id
    title
    source
    classification {
        assetType
        capitalMultiplier
        syntheticPortfolio
        hyperionUnit
    }
  } 
}
`;

const getQueryAST = (query: string) => {
  const { selectionSet } = parse(query).definitions[0] as any;
  return selectionSet.selections;
};

describe('Mock API tests', () => {
  it('should return node lists from mock api', async () => {
    // Create field nodes from graphql query
    const fieldNodes = getQueryAST(NODE_QUERY);

    mocks.post.mockReturnValue({ data: { Nodes: mockNodes } });

    const res = await mockAPI.queryMock({
      fieldName: 'Nodes',
      fieldNodes,
      args: defaultArgs,
    });

    expect(res).toEqual(mockNodes);
  });

  it('should return portfolios from mock api', async () => {
    // Create field nodes from graphql query
    const fieldNodes = getQueryAST(PORTFOLIO_QUERY);

    mocks.post.mockReturnValue({ data: { Portfolios: mockPortfolios } });

    const res = await mockAPI.queryMock({
      fieldName: 'Portfolios',
      fieldNodes,
      args: defaultArgs,
    });

    expect(res).toEqual(mockPortfolios);
  });

  it('should handle errors from mock api', async () => {
    // Create field nodes from graphql query
    const fieldNodes = getQueryAST(PORTFOLIO_QUERY);
    mocks.post.mockRejectedValue('Error');

    const res = await mockAPI.queryMock({
      fieldName: 'Portfolios',
      fieldNodes,
      args: defaultArgs,
    });

    expect(res).toEqual([]);
  });

  it('should render different argument type', async () => {
    // Int List
    let query = ` query {
      Nodes(bar: [1, 2, 3, 4, 5]) {
        id
      }
    }`;
    // Create field nodes from graphql query
    let queryAST = getQueryAST(query)[0];
    let res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // String List
    query = ` query {
      Nodes(bar: ["a", "b", "c", "d"]) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // Object List
    query = ` query {
      Nodes(bar: [{ a: "foo", b: { c: 1 } }, { a: "foo", b: { c: 1 } }]) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // Object
    query = ` query {
      Nodes(bar: { a: "foo", b: { c: 1 } }) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // String
    query = ` query {
      Nodes(bar: "foo") {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // Int
    query = ` query {
      Nodes(bar: 1) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // Enum
    query = ` query {
      Nodes(type: RISK_PORTFOLIO) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();
  });

  it('should render different data types when passing from variables', async () => {
    // Int & String
    (mockAPI as any).defResolverArgs = { arg1: 7, arg2: '7' };
    let query = ` query getNodes($arg1: Int, $arg2: String) {
      Nodes(arg1: $arg1, arg2: $arg2) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    let queryAST = getQueryAST(query)[0];
    let res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // Int List
    (mockAPI as any).defResolverArgs = { arg: [1, 2, 3, 4] };
    query = ` query getNodes($arg: [Int]) {
      Nodes(arg: $arg) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // String List
    (mockAPI as any).defResolverArgs = { arg: ['a', 'b', 'c', 'd'] };
    query = ` query getNodes($arg: [String]) {
      Nodes(arg: $arg) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // Object
    (mockAPI as any).defResolverArgs = { arg: { a: 'foo', b: { c: 1 } } };
    query = ` query getNodes($arg: Any) {
      Nodes(arg: $arg) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // Object List
    (mockAPI as any).defResolverArgs = {
      arg: [
        { a: 'foo', b: { c: 1 } },
        { a: 'foo', b: { c: 1 } },
      ],
    };
    query = ` query getNodes($arg: [Any]) {
      Nodes(arg: $arg) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();

    // Multiple arguments
    (mockAPI as any).defResolverArgs = {
      intArg: 7,
      stringArg: 'First Node',
      objectArg: { a: 'foo', b: { c: 1 } },
      objectListArg: [
        { a: 'foo', b: { c: 1 } },
        { a: 'foo', b: { c: 1 } },
      ],
    };
    query = ` query getNodes($intArg: ID, $stringArg: String, $objectArg: Any, $objectListArg: [Any]) {
      Nodes(intArg: $intArg, stringArg: $stringArg, objectArg: $objectArg, objectListArg: $objectListArg) {
        id
      }
    }`;
    // eslint-disable-next-line prefer-destructuring
    queryAST = getQueryAST(query)[0];
    res = mockAPI.nodeToQuery(queryAST);

    expect(res).toMatchSnapshot();
  });
});

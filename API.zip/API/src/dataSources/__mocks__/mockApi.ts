export const mockNodes = [
  {
    id: '1',
    title: 'GQL ANZ Group',
    type: 'RISK_PORTFOLIO',
    portfolios: [
      {
        id: -57,
        isActive: true,
        createdOn: '2020-02-05',
      },
      {
        id: 10,
        isActive: true,
        createdOn: '2020-02-05',
      },
    ],
  },
  {
    id: '2',
    title: 'ANZ ETFS',
    type: 'FINANCE_BUSINESS',
    portfolios: [
      {
        id: 3,
        isActive: true,
        createdOn: '2020-02-05',
      },
      {
        id: -30,
        isActive: true,
        createdOn: '2020-02-05',
      },
    ],
  },
  {
    id: '3',
    title: 'Electricity',
    type: 'FINANCE_BUSINESS',
    portfolios: [
      {
        id: -40,
        isActive: true,
        createdOn: '2020-02-05',
      },
      {
        id: -21,
        isActive: true,
        createdOn: '2020-02-05',
      },
    ],
  },
];

export const mockPortfolios = [
  {
    id: 1,
    title: 'AU CORP BKG',
    source: 'MX2.11',
    classification: {
      assetType: '1',
      capitalMultiplier: '6',
      syntheticPortfolio: '3',
      hyperionUnit: '4',
    },
  },
  {
    id: 2,
    title: 'GSF AU',
    source: 'MX2.11',
    classification: {
      assetType: '2',
      capitalMultiplier: '17',
      syntheticPortfolio: '3',
      hyperionUnit: '1',
    },
  },
  {
    id: 3,
    title: 'IPM FG CCY SG',
    source: 'MX2.11',
    classification: {
      assetType: '5',
      capitalMultiplier: '10',
      syntheticPortfolio: '3',
      hyperionUnit: '1',
    },
  },
];

export default class MockAPI {
  mockNodes = mockNodes;
}

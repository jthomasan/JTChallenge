export default class GenericAPI {
  constructor(urlTemplate: string) {
    return urlTemplate;
  }
}

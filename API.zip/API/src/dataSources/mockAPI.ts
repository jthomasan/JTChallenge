/* eslint-disable @typescript-eslint/lines-between-class-members */
import { FieldNode, ArgumentNode } from 'graphql';
import RESTDataSourceWithLog from './RESTDataSourceWithLog';

export interface MockOptions {
  fieldName: string;
  fieldNodes: FieldNode[];
  args: any;
}

const capitaliseValue = (value: string): string => {
  return value.charAt(0).toUpperCase() + value.slice(1);
};

export default class MockNodeAPI extends RESTDataSourceWithLog {
  baseURL = process.env.MOCK_API_HOST;

  private queryName: string;
  private defResolverArgs: any;

  public async queryMock(opts: MockOptions) {
    const { fieldNodes, fieldName, args } = opts;
    const queryName = capitaliseValue(fieldName);
    this.queryName = queryName;
    this.defResolverArgs = args;
    let query = fieldNodes.reduce((acc, fieldNode) => `${acc} ${this.nodeToQuery(fieldNode)}`, '');

    query = `query{
      ${query}
    }`;

    try {
      const response = await this.post('', {
        query,
      });

      return response.data[queryName];
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error(error);
    }

    return [];
  }

  public nodeToQuery(node: FieldNode) {
    let fields = '';
    let args = '';
    let name = node.name.value;

    if (capitaliseValue(name) === this.queryName) {
      name = capitaliseValue(name);
    }

    if (node.selectionSet) {
      fields = `{
        ${node.selectionSet.selections.reduce((acc, selection: FieldNode) => {
          return `${acc} ${this.nodeToQuery(selection)}`;
        }, '')}
      }`;

      if (node.arguments.length > 0) {
        args = `(
          ${node.arguments.map(this.getQueryArgument.bind(this))}
        )`;
      }
    }

    return `${name}${args}${fields}`;
  }

  // eslint-disable-next-line class-methods-use-this
  private getQueryArgument(arg: ArgumentNode) {
    const { name: argNames, value: argValues, fields: argFields }: any = arg;
    const argKind = (arg.value && arg.value.kind) || arg.kind;

    switch (argKind) {
      case 'StringValue': {
        if (argNames) {
          return `${argNames.value}:"${argValues.value}"`;
        }
        return `"${argValues.value || argValues}"`;
      }

      case 'ListValue': {
        return `${argNames.value}: [${argValues.values.map(this.getQueryArgument.bind(this))}]`;
      }

      case 'ObjectValue': {
        const fields = (argValues && argValues.fields) || argFields;

        if (argNames) {
          return `${argNames.value}: {${fields.map(this.getQueryArgument.bind(this))}}`;
        }

        return `{${fields.map(this.getQueryArgument.bind(this))}}`;
      }

      case 'Variable': {
        return `${argNames.value}:"${this.defResolverArgs[argNames.value]}"`;
      }

      default: {
        if (argNames) {
          return `${argNames.value}:${argValues.value}`;
        }
        return `${argValues.value || argValues}`;
      }
    }
  }
}

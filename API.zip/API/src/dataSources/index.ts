import MockAPI from './mockAPI';
import GenericAPIDataSource from './genericAPI';

export interface DataSources {
  mockAPI: MockAPI;
  genericAPI: GenericAPIDataSource;
}

export default () => ({
  mockAPI: new MockAPI(),
  genericAPI: new GenericAPIDataSource(),
});

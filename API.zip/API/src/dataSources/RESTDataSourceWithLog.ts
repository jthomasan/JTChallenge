import { RESTDataSource } from 'apollo-datasource-rest';
import * as bodyParser from 'body-parser'

export default class RESTDataSourceWithLog extends RESTDataSource {
  willSendRequest(request) {
    const { logger, reqId } = this.context;
    logger.info({ body: request.body }, `${request.method} ${this.baseURL}/${request.path}`);
    if (reqId) {
      request.headers.set('X-Request-Id', reqId);
    }
  }

  async didReceiveResponse<TResult = any>(response: any, _request: any): Promise<TResult> {
    if (response.ok) {
      const result = await super.parseBody(response);
      this.context.logger.info({
        method: _request.method,
        url: response.url,
        body: _request.body ? _request.body.toString('utf8') : '',
        status: response.status,
        statusText: response.statusText,
      });
      return (result as any) as Promise<TResult>;
    }
    const error = await super.errorFromResponse(response);
    throw error;
  }
}

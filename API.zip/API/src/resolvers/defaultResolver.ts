import { GraphQLResolveInfo } from 'graphql';
import { DataSources } from '../dataSources';
import { handleResolvedData } from '../utils/resolverUtil';

const getDataFromSource = async (dataSources: DataSources, args: any, info: GraphQLResolveInfo) => {
  const response = await dataSources.mockAPI.queryMock({
    fieldNodes: Object.assign(info.fieldNodes),
    fieldName: info.fieldName,
    args,
  });
  return response;
};

export const defaultResolver = (source: any, args: any, context: any, info: GraphQLResolveInfo) => {
  const { dataSources } = context;

  // Resolve root level queries
  if (source === undefined) {
    return getDataFromSource(dataSources, args, info);
  }

  return handleResolvedData(source, info);
};

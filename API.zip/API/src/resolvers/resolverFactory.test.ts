import { GraphQLResolveInfo } from 'graphql';
import { ApolloContext } from '../server';
import { generateGenericResolver } from './resolverFactory';

describe('resolverFactory', () => {
  const info: any = {
    path: {
      prev: undefined,
      key: 'root',
    },
    rootValue: undefined,
  } as GraphQLResolveInfo;

  const resolverContext = ({
    root: { name: 'root', isAvailable: true },
  } as unknown) as ApolloContext;

  const dataSources = {
    genericAPI: {
      getRestResources: jest.fn(),
    },
  };

  const context = ({
    dataSources,
    resolverContext,
  } as unknown) as ApolloContext;

  beforeEach(() => {
    dataSources.genericAPI.getRestResources.mockReset();
  });

  it('should return a field mapping if field config is a string', async () => {
    const resolver = generateGenericResolver({ fieldConfig: '$.nodeId' });
    const parentEntity = {
      nodeId: '1',
      nodeName: 'Test node',
    };
    const resolvedField = await resolver(
      parentEntity,
      null,
      ({ dataSources: null, resolverContext } as unknown) as ApolloContext,
      info,
    );
    expect(resolvedField).toEqual('1');
  });

  it('should get entity from datasource if datasource is specified', async () => {
    // Given
    const resolver = generateGenericResolver({
      url: '/',
      dataPath: '$.nodes',
    });
    const nodeList = [{ nodeId: '1' }, { nodeId: '2' }];
    dataSources.genericAPI.getRestResources.mockReturnValue({ nodes: nodeList });

    // When
    const resolvedData = await resolver(null, null, (context as unknown) as ApolloContext, info);

    // Then
    expect(resolvedData).toEqual(nodeList);
  });

  it('should return data object contain additional data', async () => {
    // Given
    const resolver = generateGenericResolver({
      url: '/',
      dataPath: '$',
      additionalData: {
        hierarchyType: '{args.type}',
      },
    });
    const args = { type: 1 };
    dataSources.genericAPI.getRestResources.mockReturnValue({ nodeId: '1' });

    // When
    const resolvedData = await resolver(null, args, (context as unknown) as ApolloContext, info);

    // Then
    expect(resolvedData).toEqual({
      nodeId: '1',
      hierarchyType: 1,
    });
  });

  it('should return the data formated when decorator added', async () => {
    const resolver = generateGenericResolver({
      dataPath: '$.net1m',
      decorators: [
        { name: 'roundNumber', params: { decimalPlaces: 1, applyToDecimalsOnly: true } },
      ],
    });
    const parentEntity = {
      term: '10y',
      modified: false,
      net1m: '10.583',
      net3m: '0',
      net6m: '0',
      net1y: '0',
      net2y: '0',
      net3y: '0',
      net4y: '0',
      net5y: '0',
      net7y: '0',
      net10y: '100.15',
      net15y: '0',
      net20y: '0',
      net25y: '0',
      net30yPlus: '0',
    };

    const resolvedField = await resolver(
      parentEntity,
      null,
      ({ dataSources: null, resolverContext, logger: console } as unknown) as ApolloContext,
      info,
    );
    expect(resolvedField).toEqual('10.6');
  });

  it('should return array of data object contain additional data in each object in array', async () => {
    // Given
    const resolver = generateGenericResolver({
      url: '/',
      dataPath: '$.nodes',
      additionalData: {
        hierarchyType: '{args.type}',
      },
    });
    const args = {
      type: 1,
    };
    const nodeList = [
      {
        nodeId: '1',
      },
      {
        nodeId: '2',
      },
    ];

    dataSources.genericAPI.getRestResources.mockReturnValue({ nodes: nodeList });

    // When
    const resolvedData = await resolver(null, args, (context as unknown) as ApolloContext, info);

    // Then
    expect(resolvedData).toEqual([
      {
        nodeId: '1',
        hierarchyType: 1,
      },
      {
        nodeId: '2',
        hierarchyType: 1,
      },
    ]);
  });

  it('should return the passed data when resolver not exist', async () => {
    const rootQuery = {
      prev: {
        prev: undefined,
        key: 'Nodes',
      },
      key: '0',
    };

    const nodesInfo = { ...info, path: { ...info.path } };
    nodesInfo.path.prev = rootQuery;
    nodesInfo.fieldName = 'nodes';
    const mockResolverContext = {
      Nodes: {
        name: 'Nodes',
        isAvailable: false,
      },
    };

    const resolver = generateGenericResolver({});
    const parentEntity = {
      nodes: {
        nodeId: '1',
        nodeName: 'Test node',
      },
    };
    const resolvedField = await resolver(
      parentEntity,
      null,
      ({ dataSources: null, resolverContext: mockResolverContext } as unknown) as ApolloContext,
      nodesInfo,
    );

    expect(resolvedField).toEqual(parentEntity.nodes);
  });

  it('should call a preprocessor when provided and override values as desired', async () => {
    const preprocessor = jest.fn();

    const fieldConfig = {
      $extra: {},
      additionalData: {},
      dataPath: '$',
      decorators: [],
      url: '',
    };

    const resolver = generateGenericResolver({
      ...fieldConfig,
      preprocessor,
    });

    const args = {};
    const rootData = {};

    preprocessor.mockImplementation(() => {
      return {
        url: 'override',
        rootData: { overridden: 123 },
        args: { overridden: true },
        dataPath: '$.overriddenPath',
        additionalData: {
          additional: '{args.overridden}',
        },
      };
    });

    dataSources.genericAPI.getRestResources.mockImplementation(() => ({
      overriddenPath: {
        value: 'data',
      },
    }));

    expect(await resolver(rootData, args, context, info)).toStrictEqual({
      value: 'data',
      additional: true,
    });

    expect(preprocessor).toHaveBeenCalledTimes(1);
    expect(preprocessor).toHaveBeenCalledWith({
      ...fieldConfig,
      args,
      rootData,
      fieldConfig: null,
    });

    expect(dataSources.genericAPI.getRestResources).toHaveBeenCalledWith(
      'override',
      { overridden: 123 },
      { args: { overridden: true } },
    );
  });

  it('should default to current fieldData if not overridden by preprocessor', async () => {
    const preprocessor = jest.fn();

    const fieldConfig = {
      $extra: {},
      additionalData: {},
      dataPath: '$',
      decorators: [],
      url: 'default-url',
    };

    const resolver = generateGenericResolver({
      ...fieldConfig,
      preprocessor,
    });

    dataSources.genericAPI.getRestResources.mockImplementation(() => ({
      value: 'test',
    }));

    expect(await resolver({}, {}, context, info)).toStrictEqual({
      value: 'test',
    });

    expect(preprocessor).toHaveBeenCalledTimes(1);
    expect(preprocessor).toHaveBeenCalledWith({
      ...fieldConfig,
      args: {},
      rootData: {},
      fieldConfig: null,
    });

    expect(dataSources.genericAPI.getRestResources).toHaveBeenCalledWith(
      'default-url',
      {},
      {
        args: {},
      },
    );
  });
});

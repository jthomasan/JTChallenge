import { GraphQLResolveInfo } from 'graphql';
import { JSONPath } from 'jsonpath-plus';
import Logger from 'bunyan';
import { ApolloContext } from '../server';
import { getConfigParamValue, isConfigParam, replaceStringTemplate } from '../utils';
import { handleResolvedData, getRootQueryObject, ResolverContext } from '../utils/resolverUtil';
import decoratorFunctions from '../decorators';
import { ResolutionPreProcessor } from './query/preprocessors/types';

export interface DecoratorConfig {
  name: string;
  params: Record<string, any>;
}

interface GenericResolverFactoryProcessorConfig {
  $extra?: Record<string, any>;
  preprocessor?: ResolutionPreProcessor;
  postprocessor?: any;
}

interface GenericResolverFactoryConfigurationDirectMapping
  extends GenericResolverFactoryProcessorConfig {
  fieldConfig?: any;
}

interface GenericResolverFactoryConfiguration extends GenericResolverFactoryProcessorConfig {
  url?: string;
  dataPath: string;
  additionalData?: { [key: string]: any };
  decorators?: DecoratorConfig[];
  decorateIndividualArrayItems?: boolean;
}

export const generateGenericResolver = (
  config: GenericResolverFactoryConfiguration | GenericResolverFactoryConfigurationDirectMapping,
) => async (
  parentEntity: any,
  args: Record<string, any>,
  context: ApolloContext,
  info: GraphQLResolveInfo,
) => {
  const { preprocessor, postprocessor } = config as GenericResolverFactoryConfiguration &
    GenericResolverFactoryConfigurationDirectMapping;

  let {
    $extra,
    url,
    dataPath,
    additionalData,
    decorators,
    decorateIndividualArrayItems,
    fieldConfig = null,
  } = config as GenericResolverFactoryConfiguration &
    GenericResolverFactoryConfigurationDirectMapping;
  let finalArgs = args;

  let newData: any;
  let rootData = parentEntity;
  let jsonPath: any;
  const { dataSources, resolverContext, logger } = context;

  // Get requested query's root query name.
  const rootQueryName = getRootQueryObject(info.path, info.rootValue).key;
  const resolverInfo = resolverContext[rootQueryName] as ResolverContext;

  // Skip resolvers when data has been solved in default  resolver.
  if (!resolverInfo.isAvailable) {
    return handleResolvedData(parentEntity, info);
  }

  // Run and allow the preprocessor to alter any of the fieldConfig values + args
  if (preprocessor) {
    ({
      fieldConfig = fieldConfig,
      $extra = $extra,
      url = url,
      dataPath = dataPath,
      additionalData = additionalData,
      decorators = decorators,
      decorateIndividualArrayItems = decorateIndividualArrayItems,
      rootData = rootData,
      args: finalArgs = finalArgs,
    } =
      preprocessor({
        fieldConfig,
        $extra,
        url,
        rootData,
        dataPath,
        decorators,
        decorateIndividualArrayItems,
        additionalData,
        args,
      }) || {});
  }

  // fieldConfig is only provided for static, direct mappings e.g. 2, true, etc
  if (fieldConfig !== null) {
    if (/^\$/g.test(fieldConfig)) {
      jsonPath = fieldConfig;
    } else if (/{\$\..*?}/g.test(fieldConfig)) {
      rootData = replaceStringTemplate(fieldConfig, parentEntity, {
        args,
      });
    } else {
      rootData = fieldConfig;
    }
  }

  if (dataPath) {
    jsonPath = dataPath;
  }

  if (url && dataSources?.genericAPI) {
    rootData = await dataSources.genericAPI.getRestResources(url, rootData, {
      args: finalArgs,
    });
  }

  if (jsonPath) {
    const endsWithSquareBraceRegEx = /]$/;
    const modifiedJsonPath = replaceStringTemplate(jsonPath, parentEntity, {
      args: finalArgs,
      parent: parentEntity,
    });

    const resolverData = JSONPath({
      path: modifiedJsonPath,
      json: rootData,
    });

    if (
      (($extra?.unwrapArray === undefined && !endsWithSquareBraceRegEx.test(dataPath)) ||
        $extra?.unwrapArray) &&
      resolverData
    ) {
      [newData] = resolverData;
    } else {
      newData = resolverData;
    }
  } else {
    newData = rootData;
  }

  if (additionalData) {
    const isReturnDataArray = Array.isArray(newData);
    if (!isReturnDataArray) {
      newData = { ...newData };
    }

    Object.entries(additionalData).forEach(([key, value]) => {
      const additionalDataField = typeof value === 'string' ? value : '';

      const configParamValue = isConfigParam(additionalDataField)
        ? getConfigParamValue(additionalDataField, rootData, {
            args: finalArgs,
            parent: parentEntity,
          })
        : replaceStringTemplate(additionalDataField, rootData, {
            args: finalArgs,
            parent: parentEntity,
          });

      if (configParamValue !== null && configParamValue !== undefined) {
        if (isReturnDataArray) {
          newData = newData.map((data) => {
            return { ...data, [key]: configParamValue };
          });
        } else {
          newData[key] = configParamValue;
        }
      }
    });
  }

  if (decorators) {
    if (Array.isArray(newData) && decorateIndividualArrayItems !== false) {
      newData = newData.map((data, index) =>
        decorateNewData({
          data,
          decorators,
          index,
          logger,
          resolverInfo: info,
          additionalContext: {
            args: finalArgs,
            parent: parentEntity,
          },
        }),
      );
    } else {
      newData = decorateNewData({
        data: newData,
        decorators,
        index: 0,
        logger,
        resolverInfo: info,
        additionalContext: {
          args: finalArgs,
          parent: parentEntity,
        },
      });
    }
  }

  if (postprocessor) {
    return await postprocessor(newData, finalArgs, { dataSources });
  }

  return newData;
};

function decorateNewData({
  data,
  decorators,
  index,
  logger,
  resolverInfo,
  additionalContext,
}: {
  data: any;
  decorators: DecoratorConfig[];
  index: number;
  logger: Logger;
  resolverInfo: GraphQLResolveInfo;
  additionalContext: {
    args: Record<string, any>;
    parent: any;
  };
}) {
  return decorators.reduce((acc, curr) => {
    if (!decoratorFunctions[curr.name]) {
      logger.error(`${curr.name} decorator does not exist!`);
    }

    try {
      return decoratorFunctions[curr.name](acc, curr.params, index, {
        resolverInfo,
        additionalContext,
      });
    } catch (err) {
      logger.error(err);
      return acc;
    }
  }, data);
}

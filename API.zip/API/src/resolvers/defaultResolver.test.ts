import { parse } from 'graphql';
import { defaultResolver } from './defaultResolver';
import { mockNodes, mockPortfolios } from '../dataSources/__mocks__/mockApi';

const NODE_QUERY = `
  query {
    Nodes {
      id
      title
      type
      portfolios {
        id
        isActive
        createdOn
      }
    }
  }
`;

const PORTFOLIO_QUERY = `
 query {
  Portfolios {
    id
    title
    source
    classification {
        assetType
        capitalMultiplier
        syntheticPortfolio
        hyperionUnit
    }
  } 
}
`;

describe('GraphQL Default Resolver tests', () => {
  const mockContext = {
    dataSources: {
      mockAPI: { queryMock: jest.fn() },
    },
  };
  const { queryMock } = mockContext.dataSources.mockAPI;
  const info: any = {};

  it('should return node lists', async () => {
    info.fieldName = 'Nodes';
    // Create field nodes from graphql query
    info.fieldNodes = parse(NODE_QUERY);

    queryMock.mockReturnValueOnce(mockNodes);
    const res = await defaultResolver(undefined, {}, mockContext, info);
    expect(res).toEqual(mockNodes);
  });

  it('should return all portfolios list', async () => {
    info.fieldName = 'Portfolios';
    info.fieldNodes = parse(PORTFOLIO_QUERY);

    queryMock.mockReturnValueOnce(mockPortfolios);
    const res = await defaultResolver(undefined, {}, mockContext, info);
    expect(res).toEqual(mockPortfolios);
  });

  it('should return the default object or value if nothing to resolve', async () => {
    info.fieldName = 'classification';
    let res = await defaultResolver(mockPortfolios[0], {}, mockContext, info);
    expect(res).toEqual(mockPortfolios[0].classification);

    info.fieldName = 'id';
    res = await defaultResolver(mockPortfolios[0].id, {}, mockContext, info);
    expect(res).toEqual(mockPortfolios[0].id);
  });
});

import { ApolloError } from 'apollo-server-express';
import { Method } from '../../dataSources/genericAPI';
import transactionalActions from './transactionalActions';

const genericAPI = {
  write: jest.fn(),
};

describe('Transactional action resolver', () => {
  beforeEach(() => {
    genericAPI.write.mockReset();
  });

  it('should add all actions into one request and commits with body and headers', async () => {
    const config = {
      uri: '/test/api',
      method: Method.post,
      headers: {
        'Custom-Header': 'Header',
      },
      body: {
        op: '{args.op}',
        id: '{args.id}',
        a: '{args.a}',
        b: '{args.b}',
        c: '{args.c}',
        d: 'dd',
        e: {
          f: '{args.f}',
          g: '{args.unknown}',
        },
        h: false,
      },
    };

    const { add, commit } = await transactionalActions(config, genericAPI);

    add({ id: '1', a: 'a1', f: 'a' }, 'Entity', 'replace');
    add({ id: '2', c: 'c1', b: 'b1' }, 'Entity', 'add');
    add({ id: '1', a: 'a2', b: 'b2' }, 'Entity', 'replace');
    add({ id: '2', a: 'a3', b: 'b3' }, 'Entity', 'replace');

    commit({});
    expect(genericAPI.write).toHaveBeenCalledWith(
      'post',
      '/test/api',
      expect.arrayContaining([
        {
          op: 'replace',
          id: '1',
          a: 'a2',
          b: 'b2',
          d: 'dd',
          e: {
            f: 'a',
          },
          h: false,
        },
        {
          op: 'add',
          a: 'a3',
          b: 'b3',
          c: 'c1',
          d: 'dd',
          h: false,
        },
      ]),
      {
        'Custom-Header': 'Header',
      },
    );
  });

  it('should throw an error if action added has no id field', async () => {
    const config = {
      uri: '/test/api',
      method: Method.post,
      headers: {
        'Custom-Header': 'Header',
      },
      body: {},
    };

    const { add } = await transactionalActions(config, genericAPI);

    try {
      add({ a: 'a' }, 'replaceEntity', 'replace');
    } catch (e) {
      expect(e.message).toEqual(
        'Invalid batch actionArgs - id not found. { replaceEntity: {"a":"a"} }',
      );
    }
  });

  it('should thown an error if the api request fails', async () => {
    const config = {
      uri: '/test/api',
      method: Method.post,
      headers: {
        'Custom-Header': 'Header',
      },
      body: {
        op: '{args.op}',
        id: '{args.id}',
        a: '{args.a}',
        b: '{args.b}',
      },
    };

    genericAPI.write.mockImplementation(() => {
      throw new ApolloError('some error', 'some code');
    });

    const { add, commit } = await transactionalActions(config, genericAPI);

    add({ id: '1', a: 'a2', b: 'b2' }, 'replaceEntity', 'replace');

    try {
      await commit({});
    } catch (e) {
      expect(e.extensions).toEqual(
        expect.objectContaining({
          action: {
            actionsMap: { 'replaceEntity-1': { a: 'a2', b: 'b2', id: '1', op: 'replace' } },
            transactionalScopeConfig: config,
          },
          code: 'some code',
        }),
      );
    }
  });
});

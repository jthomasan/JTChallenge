import { merge } from 'lodash';

import { ApolloError } from 'apollo-server-express';
import { getPathFromUrlTemplate, replaceArgsInObject, replaceIdsWithNull } from '../../utils';

export default (transactionalScopeConfig: any, genericAPI: any) => {
  const actionsMap = {};
  const { body: templateBody } = transactionalScopeConfig;

  const add = (actionArgs: any, actionName: string, actionType: string) => {
    if (!actionArgs.id) {
      throw new ApolloError(
        `Invalid batch actionArgs - id not found. { ${actionName}: ${JSON.stringify(actionArgs)} }`,
      );
    }
    const key = `${actionName}-${actionArgs.id}`;
    const existingData = actionsMap[key] || {};

    const args = actionArgs;
    const op = existingData.op || actionType;
    if (op === 'add' && args.id) {
      delete args.id;
    }

    const actionBody = replaceArgsInObject(
      templateBody,
      {
        ...args,
        op: existingData.op || actionType,
      },
      true,
      replaceIdsWithNull
    );
    actionsMap[key] = merge({}, existingData, actionBody);
  };

  const commit = async (args: any) => {
    try {
      if (!transactionalScopeConfig.ignore) {
        const { uri, method } = transactionalScopeConfig;
        const requestBody = Object.values(actionsMap);
        await genericAPI.write(
          method,
          getPathFromUrlTemplate(uri, args.actions, {}),
          requestBody,
          transactionalScopeConfig.headers,
        );
      }
    } catch (e) {
      e.extensions = merge({}, e.extensions || {}, {
        action: { actionsMap, transactionalScopeConfig },
      });
      throw e;
    }
    return Object.keys(actionsMap);
  };

  return { add, commit };
};

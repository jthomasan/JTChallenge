import GenericAPIDataSource, { Method } from '../../dataSources/genericAPI';
import { ReplaceMap } from '../batchMutation';

interface NodeId {
  nodeId: string;
}

export interface Argument {
  nodeId: string;
  parent: NodeId;
  title: string;
  typeId: string;
}

export interface Node {
  fullPath: string;
  nodeId: number;
  nodeName: string;
  parentNodeId: number;
  parentNodeName: string;
  typeId: number;
  typeInfo: any;
  type: string;
}

export interface Results {
  data: Node[];
}

const endpoint = (hierarchyType: string, nodeId: string) =>
  `/hierarchy/v1/hierarchies/${hierarchyType}/nodes/${nodeId}`;

export default async (
  args: Argument,
  genericAPI: GenericAPIDataSource,
  results: Results,
): Promise<ReplaceMap | null> => {
  const { nodeId, parent, title, typeId } = args;

  const newNodeInfo = results.data.find(
    (data) => data.nodeName === nodeId && data.parentNodeId.toString() === parent.nodeId,
  );

  await genericAPI.write(Method.patch, endpoint(typeId, newNodeInfo.nodeId.toString()), [
    {
      op: 'replace',
      path: '/nodeName',
      value: title,
    },
  ]);

  return {
    nodeId: [{ from: nodeId, to: newNodeInfo.nodeId }],
  };
};

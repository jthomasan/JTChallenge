import { Method } from '../../dataSources/genericAPI';
import { replaceArgsInString, replaceArgsInObject, replaceIdsWithNull } from '../../utils';

export type GenericActionConfig = {
  ignore?: boolean;
  method: Method;
  uri: string;
  body: object;
};

export default async (actionConfig: GenericActionConfig, args, genericAPI) => {
  const { method, uri: configURI, body: configBody } = actionConfig;

  const endpoint = replaceArgsInString(configURI, args, false);
  let requestBody: any;

  if (Array.isArray(configBody)) {
    requestBody = configBody.map((body) =>
      replaceArgsInObject(body, args, false, replaceIdsWithNull),
    );
  } else {
    requestBody = replaceArgsInObject(configBody, args, false, replaceIdsWithNull);
  }

  return genericAPI.write(method, endpoint, requestBody);
};

import GenericAPIDataSource, { Method } from '../../dataSources/genericAPI';
import { ReplaceMap } from '../batchMutation';

const endpoint = (hierarchyType: string) => `/api/hierarchy/${hierarchyType}/nodes/`;

export default async (args: any, genericAPI: GenericAPIDataSource): Promise<ReplaceMap | null> => {
  const { nodeId, parent, title, typeId } = args;
  const body = {
    nodeId,
    parent,
    title,
  };

  // integrate with api
  const resp = await genericAPI.write(Method.post, endpoint(typeId), body);

  // return either null or field-value a replacement map. Assume new id is returned from API. More likely we may need to query something else to get the new id
  return {
    nodeId: [{ from: nodeId, to: resp.id }],
  };
};

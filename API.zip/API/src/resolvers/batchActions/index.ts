import addNode from './addNode';

export default {
  addNode,
};

import { Method } from '../../dataSources/genericAPI';
import genericAction from './genericAction';

const genericAPI = {
  write: jest.fn(),
};

describe('Generic action', () => {
  beforeEach(() => {});

  it('replaces uri and body values with those in args', async () => {
    const config = {
      uri: '/test/{args.test}/api',
      method: Method.put,
      body: {
        a: '{args.a}',
        b: '{args.b}',
        c: '{args.c}',
        d: 'dd',
        e: {
          f: '{args.f}',
          g: '{args.unknown}',
        },
        h: false,
      },
    };

    const args = {
      test: 'test1',
      a: 'a1',
      b: 'b1',
      c: 'c1',
      f: 'f1',
    };

    await genericAction(config, args, genericAPI);

    expect(genericAPI.write).toHaveBeenCalledWith('put', '/test/test1/api', {
      a: 'a1',
      b: 'b1',
      c: 'c1',
      d: 'dd',
      e: {
        f: 'f1',
        g: '',
      },
      h: false,
    });
  });

  it('replaces body config that is an array', async () => {
    const config = {
      uri: '/test/{args.test}/api',
      method: Method.put,
      body: [
        {
          a: '{args.a}',
          b: '{args.b}',
          c: '{args.c}',
          d: 'dd',
          e: {
            f: '{args.f}',
            g: '{args.unknown}',
          },
          h: false,
        },
      ],
    };

    const args = {
      test: 'test1',
      a: 'a1',
      b: 'b1',
      c: 'c1',
      f: 'f1',
    };

    await genericAction(config, args, genericAPI);

    expect(genericAPI.write).toHaveBeenCalledWith('put', '/test/test1/api', [
      {
        a: 'a1',
        b: 'b1',
        c: 'c1',
        d: 'dd',
        e: {
          f: 'f1',
          g: '',
        },
        h: false,
      },
    ]);
  });
});

import addNode, { Argument } from './addNode';
import { nodes } from './__mocks__/mockData';

const genericAPI = {
  write: jest.fn(() => Promise.resolve({})),
};

describe('Add Node Tests', () => {
  it('should return added node info after adding a new node', async () => {
    const args: Argument = {
      nodeId: 'Temp Id',
      parent: { nodeId: '6670' },
      title: 'Temp Id',
      typeId: '1',
    };

    const res = await addNode(args, genericAPI as any, { data: nodes });

    expect(res).toEqual({ nodeId: [{ from: 'Temp Id', to: 11826 }] });
  });
});

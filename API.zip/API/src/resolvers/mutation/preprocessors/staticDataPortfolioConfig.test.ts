import staticDataPortfolioConfig from './staticDataPortfolioConfig';

describe('staticDataPortfolioConfig Tests', () => {
  it('should return strings of sources when providing sources list', () => {
    const sourceSystems = [
      {
        id: 'Murex',
        text: 'Murex',
      },
      {
        id: 'QRM',
        text: 'QRM',
      },
      {
        id: 'SKY',
        text: 'SKY',
      },
      {
        id: 'ARM',
        text: 'ARM',
      },
    ];

    const [actionName, args] = staticDataPortfolioConfig('staticDataPortfolioConfig', {
      id: '1',
      sources: sourceSystems,
    });

    expect(actionName).toEqual('staticDataPortfolioConfig');
    expect(args).toMatchSnapshot();
  });

  it('should return rest of the fields when not providing sources list', () => {
    const [actionName, args] = staticDataPortfolioConfig('staticDataPortfolioConfig', {
      id: '1',
      portfolio: {
        id: '1',
        text: '1',
      },
    });

    expect(actionName).toEqual('staticDataPortfolioConfig');
    expect(args).toMatchSnapshot();
  });
});

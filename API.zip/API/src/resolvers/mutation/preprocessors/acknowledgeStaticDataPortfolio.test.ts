import acknowledgeStaticDataPortfolio from './acknowledgeStaticDataPortfolio';

describe('AcknowledgeStaticDataPortfolio Preprocessor Tests', () => {
  it('should return reviewer and review date when calling the preprocessor', () => {
    jest.spyOn(global.Date, 'now').mockImplementationOnce(() => new Date(`2020-01-01`).valueOf());

    const [actionName, args] = acknowledgeStaticDataPortfolio(
      'acknowledgeStaticDataPortfolio',
      { id: '1' },
      {
        tokenInfo: {
          sub: 'test@test.com',
        },
      },
    );

    expect(actionName).toEqual('replaceStaticDataPortfolio');
    expect(args).toEqual({ id: '1', reviewDate: '2020-04-01T00:00:00Z', reviewer: { id: 'test' } });
  });
});

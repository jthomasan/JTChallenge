import * as moment from 'moment';

export interface Args {
  date: string;
  portfolios: string[];
  reports: string[];
  snapshot: string;
  comment: string;
  sourceSystemEnvironments?: string[];
  sourceSystemId: number;
}

export interface Response extends Args {
  runDate: string;
  sourceSystemIDs: number[];
}

export default (actionName: string, args: Args): [string, Response] => {
  const requestParams = {
    ...args,
    runDate: moment().format('YYYY-MM-DD'),
    sourceSystemIDs: [Number(args.sourceSystemId)],
  };

  return [actionName, requestParams];
};

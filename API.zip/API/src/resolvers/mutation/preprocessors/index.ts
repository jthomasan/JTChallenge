import acknowledgeStaticDataPortfolio from './acknowledgeStaticDataPortfolio';
import staticDataPortfolioConfig from './staticDataPortfolioConfig';
import staticDataInstrument from './staticDataInstrument';
import riskDataUserRequest from './riskDataUserRequest';

interface PreprocessorEntities {
  [name: string]: (actionName: string, args: any, context: any) => [string, any];
}

export default {
  acknowledgeStaticDataPortfolio,
  addStaticDataPortfolioConfig: staticDataPortfolioConfig,
  replaceStaticDataPortfolioConfig: staticDataPortfolioConfig,
  replaceStaticDataInstrument: staticDataInstrument,
  sendRerunRequest: riskDataUserRequest,
  sendProxyRequest: riskDataUserRequest,
  sendExcludeRequest: riskDataUserRequest,
  sendReloadRequest: riskDataUserRequest,
  sendSignOffRequest: riskDataUserRequest,
} as PreprocessorEntities;

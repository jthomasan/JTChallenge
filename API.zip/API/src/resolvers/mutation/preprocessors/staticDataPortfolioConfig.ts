export interface IDValueProp {
  id: string;
  text: string;
}

export interface Args {
  id: string;
  portfolio?: IDValueProp;
  sources?: IDValueProp[] | string;
  officialSource?: IDValueProp;
  isActive?: Boolean;
}

export default (actionName: string, args: Args): [string, any] => {
  const requestParams = {
    ...args,
  };

  if (Array.isArray(args.sources)) {
    const sources = args.sources.reduce(
      (acc, curr, index) => `${acc}${index > 0 ? ',' : ''}${curr.id}`,
      '',
    );

    requestParams.sources = sources;
  }

  return [actionName, requestParams];
};

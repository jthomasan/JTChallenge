const getPerpetualValue = (perpetual: string) => {
  if (perpetual === 'Y') {
    return 'true';
  }

  if (perpetual === 'N') {
    return 'false';
  }

  return 'null';
};

export default (actionName: string, args: any): [string, any] => {
  const requestParams = {
    ...args,
  };

  if (args.perpetual != null) {
    requestParams.perpetual = getPerpetualValue(args.perpetual);
  }

  if (args.isGuaranteed != null && args.isGuaranteed === false) {
    requestParams.guaranteeIssuer = {
      id: null,
    };
  }

  return [actionName, requestParams];
};

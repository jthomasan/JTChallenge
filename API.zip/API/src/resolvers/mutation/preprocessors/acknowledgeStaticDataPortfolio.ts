import * as moment from 'moment';

export default (actionName: string, args: any, context: any): [string, any] => {
  const { tokenInfo } = context;
  const [userInfo] = tokenInfo.sub.split('@');
  const lanId = userInfo.replace('admin', '');

  const requestParams = {
    ...args,
    reviewer: {
      id: lanId,
    },
    reviewDate: moment()
      .add(3, 'months')
      .utc()
      .format(),
  };

  delete requestParams.isReviewed;

  return ['replaceStaticDataPortfolio', requestParams];
};

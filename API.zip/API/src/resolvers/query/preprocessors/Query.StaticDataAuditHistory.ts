import { ApolloError } from 'apollo-server-express';
import { ResolutionPreProcessor } from './types';

export default ((fieldConfig): ReturnType<ResolutionPreProcessor> => {
  const { args, $extra } = fieldConfig;

  if (!args.staticDataTypeId) {
    throw new ApolloError('staticDataTypeId type not found');
  }

  const typeMap = $extra?.AuditHistoryTypeSystemIdMap;

  if (typeMap?.[args.staticDataTypeId]) {
    return typeMap[args.staticDataTypeId];
  }

  return fieldConfig;
}) as ResolutionPreProcessor<
  {
    staticDataTypeId?: string;
  },
  {
    AuditHistoryTypeSystemIdMap: Record<string, Record<string, any>>;
  }
>;

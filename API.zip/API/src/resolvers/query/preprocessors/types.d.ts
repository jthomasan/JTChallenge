import { DecoratorConfig } from '../../resolverFactory';

type Args = Record<string, any>;
type Extra = Record<string, any>;

export interface ResolutionPreProcessorParams<
  ArgsT extends Args = Args,
  ExtraT extends Extra = Extra
> {
  fieldConfig?: any;
  args: ArgsT;
  $extra: ExtraT;
  url: string;
  rootData: any;
  dataPath?: string;
  additionalData?: Record<string, any>;
  decorators?: DecoratorConfig[];
  decorateIndividualArrayItems?: boolean;
}

export interface ResolutionPreProcessor<
  BeforeArgs extends Args = Args,
  BeforeExtra extends Extra = Extra,
  AfterArgs extends Args = BeforeArgs,
  AfterExtra extends Extra = BeforeExtra
> {
  (fieldConfig: ResolutionPreProcessorParams<BeforeArgs, BeforeExtra>): Partial<
    ResolutionPreProcessorParams<AfterArgs, AfterExtra>
  >;
}

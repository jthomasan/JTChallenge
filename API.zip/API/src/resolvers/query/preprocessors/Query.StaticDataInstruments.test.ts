import preprocessor from './Query.StaticDataInstruments';

describe('Query.StaticDataInstruments', () => {
  it('should throw an error if no value for the type argument is set', () => {
    expect(() => {
      preprocessor({
        $extra: { InstrumentsTypeMap: {} },
        args: {},
      } as Parameters<typeof preprocessor>[0]);
    }).toThrowError(`instrument type not found`);
  });

  it('should not error when no type map is defined', () => {
    const fieldConfig = {
      args: { type: 'NOT_MATURED' },
      $extra: {},

      url: 'default_url',
      dataPath: '$.default',
    };

    expect(preprocessor((fieldConfig as unknown) as Parameters<typeof preprocessor>[0])).toEqual(
      fieldConfig,
    );
  });

  it('should not error when $extras field is not defined', () => {
    const fieldConfig = {
      args: { type: 'NOT_MATURED' },

      url: 'default_url',
      dataPath: '$.default',
    };

    expect(preprocessor((fieldConfig as unknown) as Parameters<typeof preprocessor>[0])).toEqual(
      fieldConfig,
    );
  });

  it('should return the initial fieldConfig if no type mapping is found', () => {
    const fieldConfig = {
      args: { type: 'NO_MATCH_MAPPING' },
      $extra: {
        InstrumentsTypeMap: {
          NOT_MATURED: {
            url: 'not_matured_test',
            dataPath: '$',
          },
        },
      },

      url: 'default_url',
      dataPath: '$.default',
    };

    expect(preprocessor((fieldConfig as unknown) as Parameters<typeof preprocessor>[0])).toEqual(
      fieldConfig,
    );
  });

  it('should return the mapped fieldConfig if a matching type mapping is found', () => {
    const fieldConfig = {
      args: { type: 'NOT_MATURED' },
      $extra: {
        InstrumentsTypeMap: {
          NOT_MATURED: {
            url: 'not_matured_test',
            dataPath: '$',
          },
        },
      },

      url: 'default_url',
      dataPath: '$.default',
    };

    expect(preprocessor((fieldConfig as unknown) as Parameters<typeof preprocessor>[0])).toEqual(
      fieldConfig.$extra.InstrumentsTypeMap.NOT_MATURED,
    );
  });
});

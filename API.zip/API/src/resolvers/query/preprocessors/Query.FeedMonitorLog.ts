import { ApolloError } from 'apollo-server-express';
import { ResolutionPreProcessor } from './types';

export default ((fieldConfig): ReturnType<ResolutionPreProcessor> => {
  const { args, $extra } = fieldConfig;

  if (!args.fmConfigTypeId) {
    throw new ApolloError('fmConfigTypeId type not found');
  }

  const typeMap = $extra?.FeedMonitorLogTypeSystemIdMap;

  if (typeMap?.[args.fmConfigTypeId]) {
    return typeMap[args.fmConfigTypeId];
  }

  return fieldConfig;
}) as ResolutionPreProcessor<
  {
    fmConfigTypeId?: string;
  },
  {
    FeedMonitorLogTypeSystemIdMap: Record<string, Record<string, any>>;
  }
>;

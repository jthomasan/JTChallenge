import { ResolutionPreProcessor } from './types';

export const PortfolioHierarchiesWithDate: ResolutionPreProcessor<{
  date?: string;
}> = ({ args: { date } }) => {
  if (date) {
    return {
      url: null,
      rootData: {
        currentBusinessDate: date,
      },
    };
  }

  return {};
};

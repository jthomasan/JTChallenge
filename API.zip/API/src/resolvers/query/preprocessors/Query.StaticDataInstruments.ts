import { ApolloError } from 'apollo-server-express';
import { ResolutionPreProcessor } from './types';

export default ((fieldConfig): ReturnType<ResolutionPreProcessor> => {
  const { args, $extra } = fieldConfig;

  if (!args.type) {
    throw new ApolloError('instrument type not found');
  }

  const typeMap = $extra?.InstrumentsTypeMap;

  if (typeMap?.[args.type]) {
    return typeMap[args.type];
  }

  return fieldConfig;
}) as ResolutionPreProcessor<
  {
    type?: string;
  },
  {
    InstrumentsTypeMap: Record<string, Record<string, any>>;
  }
>;

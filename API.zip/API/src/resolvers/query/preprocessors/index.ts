import StaticDataInstruments from './Query.StaticDataInstruments';
import StaticDataAuditHistory from './Query.StaticDataAuditHistory';
import FeedMonitorLog from './Query.FeedMonitorLog';
import { PortfolioHierarchiesWithDate } from './Query.PortfolioHierarchiesWithDate';
import { ResolutionPreProcessor } from './types';

interface PreProcessorMap {
  [type: string]: {
    [fieldName: string]: ResolutionPreProcessor;
  };
}

export default {
  Query: {
    StaticDataInstruments,
    StaticDataAuditHistory,
    PortfolioHierarchiesWithDate,
    FeedMonitorLog,
  },
} as PreProcessorMap;

export interface SourceSystem {
  id: string;
  name: string;
  description?: string;
  isRiskDataSource: boolean;
}

const RiskDataSourceSystems: (
  sourceSystems: SourceSystem[],
  args: { isRiskDataSource: boolean },
) => SourceSystem[] = (sourceSystems, { isRiskDataSource }) => {
  if (isRiskDataSource === null || isRiskDataSource === undefined) {
    return sourceSystems;
  }

  return sourceSystems.filter((sourceSystem) => sourceSystem.isRiskDataSource === isRiskDataSource);
};

export default RiskDataSourceSystems;

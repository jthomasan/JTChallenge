/* eslint-disable no-use-before-define */
export interface HierarchyFeedStatus {
  id: string;
  nodeId: string;
  name: string;
  type: string;
  level: number;
  isSignOffAllowed: boolean;
  overallStatus: string;
  feed: Feed;
  parent: Parent;
  counts: FeedCount;
  isRerunEnabled: boolean;
  $argId: string;
}

export interface Parent {
  id: string;
  name: string;
  nodeId: string;
}

export interface Feed {
  businessDate: string;
  reportName: string;
  containerId: number;
  containerName: string;
  portfolioName: string;
  portfolioId: number;
  sourceSystemEnvironment: string;
  hasSourceSystemError: boolean;
  isEmpty: boolean;
  isRerun: boolean;
  isExclusion: boolean;
  isProxy: boolean;
  isReload: boolean;
  isFmFeed: boolean;
  isStale: boolean;
  hasQuarantine: boolean;
  cubeVersion: number;
  subCubeVersion: number;
  cubeLoadId: number;
  cubeLoadTime: string;
  feedId: number;
  status: FeedLoadStatus;
  additionalInfo: string;
}

interface FeedLoadStatus {
  riskEngine: string;
  download: string;
  rdw: string;
  signOff: string;
  errorDownload: string;
  overall: string;
  cubeQueue: string;
  cubeLoad: string;
  cubeTradeEtl: string;
  subCubeQueue: string;
  subCubeLoadstring: string;
  subCubePositionEtl: string;
  subCubeOverall: string;
  fvaCubeLoad: string;
  fvaCubeTradeEtl: string;
  fvaSubcubeLoad: string;
  fvaSubcubePositionEtl: string;
}

interface FeedCount {
  riskEngine: FeedCountDetail;
  riskEngineError: FeedCountDetail;
  download: FeedCountDetail;
  rdw: FeedCountDetail;
  signOff: FeedCountDetail;
  overall: FeedCountDetail;
  cubeQueue: FeedCountDetail;
  cubeLoad: FeedCountDetail;
  cubeTradeEtl: FeedCountDetail;
  subCubeLoad: FeedCountDetail;
  subCubePositionEtl: FeedCountDetail;
  fvaCubeLoad: FeedCountDetail;
  fvaCubeTradeEtl: FeedCountDetail;
  fvaSubcubeLoad: FeedCountDetail;
  fvaSubcubePositionEtl: FeedCountDetail;
}

export interface FeedCountDetail {
  notStarted: number;
  processing: number;
  completed: number;
  failed: number;
  noData: number;
  aborted: number;
  total: number;
  completedPercentage: number;
}

export enum NodeType {
  PORTFOLIO_NODE = 'PORTFOLIO_NODE',
  PORTFOLIO_LEAF = 'PORTFOLIO_LEAF',
}

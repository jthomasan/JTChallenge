import { HierarchyFeedStatus, NodeType } from './types';

/**
 * @todo The postprocessor will be redundant when we will be having the getconfig api ready
 */
export default (data: HierarchyFeedStatus) =>
  data.type === NodeType.PORTFOLIO_NODE && data.level <= 2;

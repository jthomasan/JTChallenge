import { uniqBy } from 'lodash';

export default (data: any[]) => {
  return uniqBy(
    data.filter((o) => !!o.issuerEquityTicker),
    'issuerEquityTicker',
  );
};

import portfoliosPostprocessor from './portfoliosPostprocessor';

describe('portfoliosPostprocessor', () => {
  it('should postprocessor filter out the portfolios with empty attributes', () => {
    const portfolios = [
      {
        addedBy: 'wongl14',
        addedTime: '2020-01-08T00:31:21.630+0000',
        effEndDate: 20991231,
        effStartDate: 20200108,
        id: 45387,
        portfolioId: 342,
        nodeId: 12275,
        attributes: {
          id: 342,
          name: 'S MKT JP IRS AU',
          comment: '',
          isActive: true,
          isEaR: false,
          isFinance: false,
          reportRunList: '',
          volckerDeskName: '',
          accountingTypeSystem: {
            id: '',
            value: '',
          },
        },
      },
      {
        addedBy: 'lij38',
        addedTime: '2020-06-30T07:38:34.907+0000',
        effEndDate: 20991231,
        effStartDate: 20130101,
        id: 45830,
        portfolioId: 44720,
        nodeId: 12158,
        attributes: {},
        type: 'hierarchyMap',
        latest: true,
      },
      {
        addedBy: 'lij38',
        addedTime: '2020-06-30T07:38:34.907+0000',
        effEndDate: 20991231,
        effStartDate: 20130101,
        id: 45830,
        portfolioId: 44720,
        nodeId: 12158,
        type: 'hierarchyMap',
        latest: true,
      },
    ];

    const processedNodes = portfoliosPostprocessor(portfolios, null, { dataSources: null });
    expect(processedNodes).toEqual([
      {
        addedBy: 'wongl14',
        addedTime: '2020-01-08T00:31:21.630+0000',
        effEndDate: 20991231,
        effStartDate: 20200108,
        id: 45387,
        portfolioId: 342,
        nodeId: 12275,
        attributes: {
          id: 342,
          name: 'S MKT JP IRS AU',
          comment: '',
          isActive: true,
          isEaR: false,
          isFinance: false,
          reportRunList: '',
          volckerDeskName: '',
          accountingTypeSystem: {
            id: '',
            value: '',
          },
        },
      },
    ]);
  });
});

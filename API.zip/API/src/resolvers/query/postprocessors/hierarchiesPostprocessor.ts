enum HierarchyRefEnum {
  RISK_PORTFOLIO = 'RISK_PORTFOLIO',
  GEOGRAPHY = 'GEOGRAPHY',
  LEGAL_ENTITY = 'LEGAL_ENTITY',
  FINANCE_BUSINESS = 'FINANCE_BUSINESS',
  REVENUE = 'REVENUE',
}

const hierarchiesWithClassification = [HierarchyRefEnum.RISK_PORTFOLIO];
const refMapping = {
  1: HierarchyRefEnum.RISK_PORTFOLIO,
  7: HierarchyRefEnum.GEOGRAPHY,
  9: HierarchyRefEnum.LEGAL_ENTITY,
  13: HierarchyRefEnum.FINANCE_BUSINESS,
  14: HierarchyRefEnum.REVENUE,
};

export interface Hierarchy {
  id: number;
  name: string;
  maxLevel: number;
  type: string;
  applyClassification?: boolean;
}

export default (resolverData: Hierarchy[]) =>
  resolverData.map((item) => {
    const ref = refMapping[item.id];

    return {
      ...item,
      applyClassification: hierarchiesWithClassification.includes(ref),
      ref,
    };
  });

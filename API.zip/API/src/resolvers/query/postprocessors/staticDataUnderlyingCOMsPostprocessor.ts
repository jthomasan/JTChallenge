import * as moment from 'moment';

export default {
  agriculturalExpiryMonths: (data: string) => {
    const selectedMonths =
      (data &&
        data.split(',').map((item) => ({
          id: item,
          text: moment()
            .month(Number(item) - 1)
            .format('MMMM'),
        }))) ||
      [];

    return selectedMonths;
  },
};

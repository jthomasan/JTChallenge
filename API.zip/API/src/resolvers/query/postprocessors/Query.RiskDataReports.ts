/* eslint-disable no-plusplus */
import { keyBy } from 'lodash';

export interface Containers {
  cube: string[];
  publish: string[];
}

export interface SourceSystem {
  id: number;
  value: string;
}

export interface RiskDataReport {
  id: number;
  description: string;
  name: string;
  container?: string;
  type: number;
  exclusionEnabled: boolean;
  hasIntradayFeed: boolean;
  isActive: boolean;
  isCCYRateDependent: boolean;
  isComVolCurveDependent: boolean;
  isFmProcessing: boolean;
  isMreDependent: boolean;
  isRefDependent: boolean;
  proxyEnabled: boolean;
  rerunEnabled: boolean;
  valuationType: string;
  sourceSystem: SourceSystem;
  containers: Containers;
}

export interface Args {
  selectedContainers: string[];
  sourceSystemId: number;
}

export default (data: RiskDataReport[], { selectedContainers, sourceSystemId }: Args) => {
  let flattenedData = data.flatMap((report) => {
    if (
      report.sourceSystem.id.toString() === sourceSystemId.toString() ||
      (sourceSystemId.toString() === '4' && report.sourceSystem.id.toString() === '1')
    ) {
      return report.containers.publish.map((container) => ({ ...report, container }));
    }

    return [];
  });

  if (selectedContainers.length) {
    const containersById = keyBy(selectedContainers);
    flattenedData = flattenedData.filter((report) => containersById[report.container]);
  }

  return flattenedData;
};

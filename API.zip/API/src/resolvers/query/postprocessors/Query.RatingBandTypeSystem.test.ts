import postprocessor from './Query.RatingBandTypeSystem';

const rows = [
  { id: 1, system: { id: 1013, name: 'A' } },
  { id: 2, system: { id: 1014, name: 'B' } },
  { id: 3, system: { id: 1013, name: 'A' } },
  { id: 4, system: { id: 1014, name: 'B' } },
];

describe('postprocessor - Query.RatingBandTypeSystem', () => {
  it('does not filter when no agency argument is provided', () => {
    expect(postprocessor(rows, {})).toBe(rows);
  });

  it('filters for 1013 system id when credit rating category id provided and is not 3', () => {
    expect(postprocessor(rows, { sRCategoryId: 1 })).toStrictEqual([rows[0], rows[2]]);
  });

  it('filters for 1014 system id when credit rating category id provided and is 3', () => {
    expect(postprocessor(rows, { sRCategoryId: 3 })).toStrictEqual([rows[1], rows[3]]);
  });

  it("doesn't error when empty data set is passed", () => {
    expect(postprocessor([], { sRCategoryId: 1 })).toStrictEqual([]);
  });
});

import nodesPostprocessor from './nodesPostprocessor';

describe('nodesPostprocessor', () => {
  it('should postprocessor add right children fields to the nodes', () => {
    const nodes = [
      { nodeId: '1', parentNodeId: '-1', nodeName: 'a' },
      { nodeId: '2', parentNodeId: '1', nodeName: 'c' },
      { nodeId: '3', parentNodeId: '1', nodeName: 'b' },
      { nodeId: '4', parentNodeId: '2', nodeName: 'd' },
      { nodeId: '5', parentNodeId: '2', nodeName: 'e' },
      { nodeId: '6', parentNodeId: '3', nodeName: 'f' },
      { nodeId: '7', parentNodeId: '3', nodeName: 'g' },
      { nodeId: '8', parentNodeId: '7', nodeName: 'h' },
      { nodeId: '9', parentNodeId: '8', nodeName: 'i' },
    ];

    const processedNodes = nodesPostprocessor(nodes, null, { dataSources: null });
    expect(processedNodes).toEqual([
      { nodeId: '1', parentNodeId: '', children: ['3', '2'], nodeName: 'a' },
      { nodeId: '3', parentNodeId: '1', children: ['6', '7'], nodeName: 'b' },
      { nodeId: '2', parentNodeId: '1', children: ['4', '5'], nodeName: 'c' },
      { nodeId: '4', parentNodeId: '2', children: [], nodeName: 'd' },
      { nodeId: '5', parentNodeId: '2', children: [], nodeName: 'e' },
      { nodeId: '6', parentNodeId: '3', children: [], nodeName: 'f' },
      { nodeId: '7', parentNodeId: '3', children: ['8'], nodeName: 'g' },
      { nodeId: '8', parentNodeId: '7', children: ['9'], nodeName: 'h' },
      { nodeId: '9', parentNodeId: '8', children: [], nodeName: 'i' },
    ]);
  });
});

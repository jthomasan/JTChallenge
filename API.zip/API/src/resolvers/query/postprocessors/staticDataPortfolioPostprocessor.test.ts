import staticDataPortfolioPostprocessor from './staticDataPortfolioPostprocessor';

const { isReviewed } = staticDataPortfolioPostprocessor;
describe('Static Data Portfolio Postprocessor - isReviewed field', () => {
  it('should return false if review attr is null', () => {
    // Given
    const data = {};

    // When
    const res = isReviewed(data);

    // Then
    expect(res).toEqual(false);
  });

  it('should return false if review date is null', () => {
    // Given
    const data = {
      review: {
        date: null,
      },
    };

    // When
    const res = isReviewed(data);

    // Then
    expect(res).toEqual(false);
  });

  it('should return false if review date is empty', () => {
    // Given
    const data = {
      review: {
        date: '',
      },
    };

    // When
    const res = isReviewed(data);

    // Then
    expect(res).toEqual(false);
  });

  it('should return false if review date < now', () => {
    // Given
    const now = new Date();
    const reviewDate = new Date(now.getTime() - 1);
    const data = {
      review: {
        date: reviewDate.toISOString(),
      },
    };

    // When
    const res = isReviewed(data);

    // Then
    expect(res).toEqual(false);
  });

  it('should return false if review date = now', () => {
    // Given
    const now = new Date();
    const data = {
      review: {
        date: now.toISOString(),
      },
    };

    // When
    const res = isReviewed(data);

    // Then
    expect(res).toEqual(false);
  });

  it('should return true if review date = now', () => {
    // Given
    const now = new Date();
    const reviewDate = new Date(now.getTime() + 100000);
    const data = {
      review: {
        date: reviewDate.toISOString(),
      },
    };

    // When
    const res = isReviewed(data);

    // Then
    expect(res).toEqual(true);
  });
});

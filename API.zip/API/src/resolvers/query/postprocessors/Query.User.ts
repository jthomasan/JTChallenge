import { getAuthorityFromScope } from "../../../authorizationConfig";

/* NB this postprocessor should only be executed when using the 
  authz service rather than the STI scopes ie when USE_STI_SCOPES != '1'
*/
export default (data: string[]) => ({ 
  authority: getAuthorityFromScope(data)
});

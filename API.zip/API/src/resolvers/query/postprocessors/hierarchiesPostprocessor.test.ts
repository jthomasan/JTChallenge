import HierarchiesPostprocessor from './hierarchiesPostprocessor';

describe('HierarchiesPostprocessor Tests', () => {
  it('should return data with classification permission', () => {
    const hierarchies = [
      {
        id: 1,
        name: 'Risk Portfolio Hierarchy',
        maxLevel: 11,
        type: 'hierarchy',
      },
      {
        id: 7,
        name: 'Geography Hierarchy',
        maxLevel: 7,
        type: 'hierarchy',
      },
      {
        id: 9,
        name: 'Legal Entity Hierarchy',
        maxLevel: 4,
        type: 'hierarchy',
      },
    ];

    const response = HierarchiesPostprocessor(hierarchies);
    expect(response).toEqual([
      {
        id: 1,
        name: 'Risk Portfolio Hierarchy',
        maxLevel: 11,
        ref: 'RISK_PORTFOLIO',
        type: 'hierarchy',
        applyClassification: true,
      },
      {
        id: 7,
        name: 'Geography Hierarchy',
        maxLevel: 7,
        type: 'hierarchy',
        ref: 'GEOGRAPHY',
        applyClassification: false,
      },
      {
        id: 9,
        name: 'Legal Entity Hierarchy',
        maxLevel: 4,
        type: 'hierarchy',
        ref: 'LEGAL_ENTITY',
        applyClassification: false,
      },
    ]);
  });
});

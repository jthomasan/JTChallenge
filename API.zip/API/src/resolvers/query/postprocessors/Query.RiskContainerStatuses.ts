export interface MinimalStatusSummary {
  completed: number;
  total: number;
}

export interface StatusSummary extends MinimalStatusSummary {
  completedPercent: number;
}

export interface OverallStatusSummary extends StatusSummary {
  hasFailures: boolean;
}

const overallStatuses = ['cube', 'subCube', 'fvaCube', 'fvaSubCube', 'rdw'] as const;

type StatusTypes = typeof overallStatuses[number] | 'signOff' | 'overall';

type RiskContainerStatus<T extends MinimalStatusSummary> = {
  status: Record<StatusTypes, T>;
};

const calculateMinimumCompleted = (riskContainer: RiskContainerStatus<MinimalStatusSummary>) =>
  Math.min(
    riskContainer.status.cube.completed,
    riskContainer.status.subCube.completed,
    riskContainer.status.rdw.completed,
    riskContainer.status.fvaCube.completed +
      (riskContainer.status.cube.total - riskContainer.status.fvaCube.total),
    riskContainer.status.fvaSubCube.completed +
      (riskContainer.status.subCube.total - riskContainer.status.fvaSubCube.total),
  );

const calculateCompletePercent = (statusSummary: MinimalStatusSummary) =>
  statusSummary.total !== 0 ? (statusSummary.completed / statusSummary.total) * 100 : 0;

const RiskContainerStatusesPostProcessor: (
  riskContainerStatuses: RiskContainerStatus<MinimalStatusSummary>[],
) => RiskContainerStatus<StatusSummary>[] = (riskContainerStatuses) =>
  riskContainerStatuses.map((riskContainerStatus) => {
    const newStatus: RiskContainerStatus<StatusSummary> = {
      ...riskContainerStatus,
    } as RiskContainerStatus<StatusSummary>;

    let hasFailures = false;
    Object.keys(newStatus.status).forEach((statusName) => {
      if (!hasFailures && !!newStatus.status[statusName].failed) {
        hasFailures = true;
      }

      newStatus.status[statusName].completedPercent = calculateCompletePercent(
        newStatus.status[statusName],
      );
    });

    newStatus.status.overall = {
      hasFailures,
      completed: calculateMinimumCompleted(newStatus),
      total: newStatus.status.cube.total,
    } as OverallStatusSummary;

    newStatus.status.overall.completedPercent = calculateCompletePercent(newStatus.status.overall);

    return newStatus;
  });

export default RiskContainerStatusesPostProcessor;

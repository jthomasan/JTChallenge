// eslint-disable-next-line @typescript-eslint/no-unused-vars
export default (resolverData: any, _args: any, { dataSources }: any) => {
  const parentMap = new Map();
  const nodeIdSet = new Set();
  resolverData.sort((a, b) => a.nodeName.localeCompare(b.nodeName));
  resolverData.forEach((node) => {
    nodeIdSet.add(node.nodeId);
    if (parentMap.has(node.parentNodeId)) {
      parentMap.set(node.parentNodeId, parentMap.get(node.parentNodeId).concat(node.nodeId));
    } else {
      parentMap.set(node.parentNodeId, [node.nodeId]);
    }
  });
  return resolverData.map((node) => {
    const mixin: { children: Array<any>; parentNodeId?: string } = {
      children: [],
    };
    if (!nodeIdSet.has(node.parentNodeId)) {
      mixin.parentNodeId = '';
    }
    if (parentMap.has(node.nodeId)) {
      mixin.children = parentMap.get(node.nodeId);
    }
    return { ...node, ...mixin };
  });
};

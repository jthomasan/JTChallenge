export default (
  rows: { system?: { id: number | string } }[],
  { sRCategoryId }: { sRCategoryId?: string | number },
) => {
  if (typeof sRCategoryId === 'undefined') {
    return rows;
  }

  return sRCategoryId.toString() === '3'
    ? rows.filter((row) => row.system?.id?.toString() === '1014')
    : rows.filter((row) => row.system?.id?.toString() === '1013');
};

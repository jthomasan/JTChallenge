import { userListById } from '../../customResolvers/userListResolver';

export default {
  reviewer: (reviewer) => userListById[reviewer.by] || { id: '', text: '' },
  isReviewed: (data) => {
    return !!(
      data.review &&
      data.review.date &&
      data.review.date.length &&
      new Date(data.review.date) > new Date()
    );
  },
};

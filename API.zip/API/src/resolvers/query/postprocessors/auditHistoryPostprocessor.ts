interface AuditHistoryColumnType {
  name: string;
  type: string;
}

interface AuditHistoryRowType {
  values: any[];
}

interface AuditHistoryType {
  columns: AuditHistoryColumnType[];
  rows: AuditHistoryRowType[];
}

const typeToFilterMap = {
  Decimal: 'numeric',
  Double: 'numeric',
  Int16: 'numeric',
  Int32: 'numeric',
  String: 'text',
  DateTime: 'date',
  Boolean: 'boolean',
  Float: 'numeric',
};

export default (resolverData: any) => {
  const audiHistoryData: AuditHistoryType = resolverData[0];
  const columns = audiHistoryData.columns.map((c: AuditHistoryColumnType) => ({
    field: c.name.replace(/\s/g, ''),
    title: c.name,
    type: typeToFilterMap[c.type],
  }));

  const rows = audiHistoryData.rows.map((r: AuditHistoryRowType) =>
    r.values.reduce(
      (acc: any, cur: any, index: number) => ({
        ...acc,
        [columns[index].field]: cur,
      }),
      {},
    ),
  );
  return { columns, rows };
};

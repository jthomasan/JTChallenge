// eslint-disable-next-line @typescript-eslint/no-unused-vars
export default (resolverData: any, _args: any, { dataSources }: any) =>
  resolverData.filter((p) => p && p.attributes && Object.keys(p.attributes).length > 0);

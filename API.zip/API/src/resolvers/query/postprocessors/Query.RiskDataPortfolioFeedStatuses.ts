/* This is here since processing large amounts of data in a post processor is quicker than using resolvers and field mappings 
   Should have a proper resolution to resolving large data sets and move this back to config json
*/

export interface PortfolioFeedStatus { 
  id: string;
  feedId: string;
  additionalInfo: string;
  businessDate: string;
  container: Container;
  cubeVersion: number;
  cubeLoadID: number;
  cubeLoadTime: string;
  isEmpty: boolean;
  isExclusion: boolean;
  isFmFeed: boolean;
  isReload: boolean;
  isRerun: boolean;
  isStale: boolean;
  isProxy: boolean;
  hasSourceSystemError: boolean;
  portfolio: PortfolioInfo;
  reportName: string;
  sourceSystemEnvironment: string;
  status: StatusDetails;
  subCubeVersion: number;
  $argId: string;
}

interface Container {
  id: string;
  name: string;
}

interface PortfolioInfo {
  id: string;
  name: string;
}

interface StatusDetails {
  cubeLoad: string;
  cubeQueue: string;
  cubeTradeEtl: string;
  download: string;
  errorDownload: string;
  fvaCubeLoad: string;
  fvaCubeTradeEtl: string;
  fvaSubcubeLoad: string;
  fvaSubcubePositionEtl: string;
  overall: string;
  rdw: string;
  riskEngine: string;
  signOff: string;
  subCubeLoad: string;
  subCubeQueue: string;
  subCubePositionEtl: string;
  subCubeOverall: string;
}

export default (data: PortfolioFeedStatus[]): PortfolioFeedStatus[] => {
  // faster than using array map. Pls don't modify without benchmarking
  for (var i = 0; i < data.length; i++) {
    let el = data[i];
    el.feedId = el.id;
    el.id = `${el.id}:${el.businessDate}:${el.container.id}:${el.portfolio.id}:${el.$argId}`;    
  }
  
  return data;
}

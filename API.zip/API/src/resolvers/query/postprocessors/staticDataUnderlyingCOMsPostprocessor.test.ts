import staticDataUnderlyingCOMPostprocessor from './staticDataUnderlyingCOMsPostprocessor';

const { agriculturalExpiryMonths } = staticDataUnderlyingCOMPostprocessor;

describe('Static Data Underlying COM Postprocessor Tests', () => {
  it('should return months list based on months number', () => {
    jest.spyOn(global.Date, 'now').mockImplementationOnce(() => new Date(`2020-01-01`).valueOf());

    let res = agriculturalExpiryMonths('1,2,3,4');
    expect(res).toEqual([
      { id: '1', text: 'January' },
      { id: '2', text: 'February' },
      { id: '3', text: 'March' },
      { id: '4', text: 'April' },
    ]);

    res = agriculturalExpiryMonths('2, 4, 11');
    expect(res).toEqual([
      { id: '2', text: 'February' },
      { id: ' 4', text: 'April' },
      { id: ' 11', text: 'November' },
    ]);

    res = agriculturalExpiryMonths('');
    expect(res).toEqual([]);

    res = agriculturalExpiryMonths('1,2,3,4,5,6,7,8,9,10,11,12');
    expect(res).toEqual([
      { id: '1', text: 'January' },
      { id: '2', text: 'February' },
      { id: '3', text: 'March' },
      { id: '4', text: 'April' },
      { id: '5', text: 'May' },
      { id: '6', text: 'June' },
      { id: '7', text: 'July' },
      { id: '8', text: 'August' },
      { id: '9', text: 'September' },
      { id: '10', text: 'October' },
      { id: '11', text: 'November' },
      { id: '12', text: 'December' },
    ]);
  });
});

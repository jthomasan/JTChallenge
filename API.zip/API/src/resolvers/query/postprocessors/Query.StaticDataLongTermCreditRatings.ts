export default (rows: { agency: string }[], { agency }: { agency?: string[] }) =>
  typeof agency === 'undefined' ? rows : rows.filter((row) => agency.includes(row.agency));

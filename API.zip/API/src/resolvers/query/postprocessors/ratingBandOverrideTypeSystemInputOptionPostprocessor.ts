export interface Args {
  id: number;
  text: string;
}

export default {
  displayName: (data: Args) => {
    if (data.id === 1041) {
      return 'LT-Rating Band Sec';
    }

    if (data.id === 1013) {
      return 'LT-Rating Band';
    }

    if (data.id === 1014) {
      return 'LT-Rating Band Other';
    }

    return 'ST-Rating Band';
  },
};

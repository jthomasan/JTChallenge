import { HierarchyFeedStatus } from "./RiskDataHierarchyFeedStatus/types";
import RiskDataHierarchyFeedStatusIsSignOffAllowed from "./RiskDataHierarchyFeedStatus/RiskDataHierarchyFeedStatus.isSignOffAllowed";
import { DataSources } from "src/dataSources";

/* This is here since processing large amounts of data in a post processor is quicker than using resolvers and field mappings 
   Should have a proper resolution to resolving large data sets and move this back to config json
*/
export default async (data: HierarchyFeedStatus[], args, context: {dataSources: DataSources}): Promise<HierarchyFeedStatus[]> => {
  const { dataSources } = context;
  const rerunEnabledPortfolios = await dataSources.genericAPI.getRestResources('feed-monitor/v1/rerun-enabled-portfolios', data, {
    args,
  });
  const rerunEnabledPortfoliosMap = rerunEnabledPortfolios.reduce((acc, currentValue) => { acc[currentValue.toString()] = true; return acc }, {});

  // faster than a map. Pls don't modify without benchmarking  
  for (var i = 0; i < data.length; i++) {
    let el = data[i];
    el.nodeId = el.id;
    el.id = `${el.id}:${el.$argId}`;
    el.isSignOffAllowed = RiskDataHierarchyFeedStatusIsSignOffAllowed(el);
    el.isRerunEnabled = !!rerunEnabledPortfoliosMap[el.nodeId];
    if (!el.parent || el.parent.id.toString() === '0') {
      el.parent = null;
    }
    else {
      el.parent.nodeId = el.parent.id;
      el.parent.id = `${el.parent.id}:${el.$argId}`
    }
  }
  
  return data;
}

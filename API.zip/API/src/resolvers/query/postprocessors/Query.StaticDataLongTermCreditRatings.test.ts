import postprocessor from './Query.StaticDataLongTermCreditRatings';

const rows = [
  { id: 1, agency: 'TEST' },
  { id: 2, agency: 'TEST' },
  { id: 3, agency: 'TEST_OTHER' },
  { id: 4, agency: 'TEST' },
];

describe('postprocessor - Query.StaticDataLongTermCreditRatings', () => {
  it('does not filter when no agency argument is provided', () => {
    expect(postprocessor(rows, {})).toBe(rows);
  });

  it('filters based on agency when provided', () => {
    expect(postprocessor(rows, { agency: ['TEST'] })).toStrictEqual([rows[0], rows[1], rows[3]]);
  });

  it('filters everything when no match is found', () => {
    expect(postprocessor(rows, { agency: ['NOMATCH'] })).toStrictEqual([]);
  });

  it("doesn't error when empty data set is passed", () => {
    expect(postprocessor([], { agency: ['NOMATCH'] })).toStrictEqual([]);
  });
});

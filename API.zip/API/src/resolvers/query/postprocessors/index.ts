import HierarchiesPostprocessor from './hierarchiesPostprocessor';
import NodesPostprocessor from './nodesPostprocessor';
import PortfoliosPostprocessor from './portfoliosPostprocessor';
import StaticDataPortfolio from './staticDataPortfolioPostprocessor';
import { userListById } from '../../customResolvers/userListResolver';
import StaticDataUnderlyingCOM from './staticDataUnderlyingCOMsPostprocessor';
import AuditHistoryPostprocessor from './auditHistoryPostprocessor';
import RatingBandOverrideTypeSystemInputOption from './ratingBandOverrideTypeSystemInputOptionPostprocessor';
import StaticDataLongTermCreditRatings from './Query.StaticDataLongTermCreditRatings';
import RiskDataReports from './Query.RiskDataReports';
import RatingBandTypeSystem from './Query.RatingBandTypeSystem';
import RiskContainerStatuses from './Query.RiskContainerStatuses';
import KeepwellAgreement from './Query.KeepwellAgreement';
import RiskDataSourceSystems from './Query.RiskDataSourceSystems';
import RiskDataPortfolioFeedStatuses from './Query.RiskDataPortfolioFeedStatuses';
import RiskDataHierarchyFeedStatuses from './Query.RiskDataHierarchyFeedStatuses';
import User from './Query.User';

const getFullnameByLanId = (lanId: string) => userListById[lanId]?.text || lanId;

export default {
  Query: {
    Hierarchies: HierarchiesPostprocessor,
    Nodes: NodesPostprocessor,
    Portfolios: PortfoliosPostprocessor,
    ClassificationOptions: () => ({}),
    RiskHierarchy: NodesPostprocessor,
    GeographyHierarchy: NodesPostprocessor,
    FinanceHierarchy: NodesPostprocessor,
    RevenueCodeHierarchy: NodesPostprocessor,
    LegalEntityHierarchy: NodesPostprocessor,
    StaticDataAuditHistory: AuditHistoryPostprocessor,
    FMConfigAuditHistory: AuditHistoryPostprocessor,
    StaticDataLongTermCreditRatings,
    RatingBandTypeSystem,
    KeepwellAgreement,
    RiskContainerStatuses,
    RiskDataReports,
    RiskDataSourceSystems,
    RiskDataPortfolioFeedStatuses,
    RiskDataHierarchyFeedStatuses,
    User,
  },
  StaticDataPortfolio,
  StaticDataUnderlyingCOM,
  RatingBandOverrideTypeSystemInputOption,
  Added: {
    by: getFullnameByLanId,
  },
  Exclusion: {
    by: getFullnameByLanId,
  },
  SystemUser: {
    text: getFullnameByLanId,
  }
};

import RiskDataReports from './Query.RiskDataReports';
import { reports } from './__mocks__/reports';

describe('RiskDataReports Tests', () => {
  it('should return reports by mapping one container per report', () => {
    let res = RiskDataReports([reports[1]], { selectedContainers: [], sourceSystemId: 1 });
    expect(res).toMatchSnapshot();

    res = RiskDataReports([reports[0]], { selectedContainers: [], sourceSystemId: 1 });
    expect(res).toMatchSnapshot();

    res = RiskDataReports(reports, { selectedContainers: [], sourceSystemId: 1 });
    expect(res).toMatchSnapshot();
  });

  it('should return reports filtered by selected containers', () => {
    let res = RiskDataReports(reports, { selectedContainers: ['A'], sourceSystemId: 1 });
    expect(res).toMatchSnapshot();

    res = RiskDataReports(reports, { selectedContainers: ['B'], sourceSystemId: 1 });
    expect(res).toMatchSnapshot();
  });
});

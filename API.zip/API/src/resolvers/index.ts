import JSON from 'graphql-type-json';
import batchChange from './batchMutation';
import Source from './customResolvers/sourceResolver';
import UserList from './customResolvers/userListResolver';
import ReturnIdentifiers from './customResolvers/returnIdentifierResolver';
import PerpetualFlagStatus from './customResolvers/perpetualFlagStatusResolver';
import User from './customResolvers/userResolver';
import SourceSystems from './customResolvers/sourceSystemResolver';
import OfficialSources from './customResolvers/officialSourceResolver';
import Months from './customResolvers/monthsResolver';
import Type from './type';
import ReportType from './customResolvers/reportType';

export default {
  Query: {
    Source,
    UserList,
    ReturnIdentifiers,
    User: process.env.USE_STI_SCOPES === '1' ? User : undefined,
    SourceSystems,
    OfficialSources,
    Months,
    ReportType,
    PerpetualFlagStatus,
  },
  Mutation: {
    batchChange,
  },
  JSON,
  ...Type,
};

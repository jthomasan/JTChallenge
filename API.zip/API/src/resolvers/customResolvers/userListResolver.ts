import { keyBy } from 'lodash';

const userList = [
  {
    text: 'VaR Sign Off',
    id: 'VarSignOff',
  },
  {
    text: 'Hypo Sign Off',
    id: 'HypoSignOff',
  },
  {
    text: 'Actual Pnl Feed',
    id: 'ActualFeed',
  },
  {
    text: 'Markets Risk Analytics',
    id: 'MarketsRiskAnalytics',
  },
  {
    text: 'Group',
    id: 'LimitsGroup',
  },
  {
    text: 'MREPOSITION',
    id: 'MREPOSITION',
  },
  {
    text: 'AP Extract Login',
    id: 'APExtractLoginToRDW',
  },
  {
    text: 'System',
    id: 'System',
  },
  {
    text: 'system',
    id: 'system',
  },
  {
    text: 'lout',
    id: 'lout',
  },
  {
    text: 'LegalEntityFeed',
    id: 'LegalEntityFeed',
  },
  {
    text: 'ETL',
    id: 'ETL',
  },
  {
    text: 'Foong, Andy',
    id: 'foonga',
  },
  {
    text: 'Panchal, Himanshu',
    id: 'panchalh',
  },
  {
    text: 'APPDEV\\teokadmin',
    id: 'teokadmin',
  },
  {
    text: 'Khor, Hwai Siang',
    id: 'khorh',
  },
  {
    text: 'APPDEV\\khorhadmin',
    id: 'khorhadmin',
  },
  {
    text: 'APPDEV\\chengj0admin',
    id: 'chengj0admin',
  },
  {
    text: 'Teo, Kim Kiat',
    id: 'teok',
  },
  {
    text: 'Sofi, Simona_Old',
    id: 'sofis0',
  },
  {
    text: 'Madgwick, Andrew',
    id: 'madgwica',
  },
  {
    text: 'Bennett, Andrew',
    id: 'bennetta',
  },
  {
    text: 'Nguyen, Minh',
    id: 'nguyenm6',
  },
  {
    text: 'Phipps, Melissa',
    id: 'phippsm',
  },
  {
    text: 'APPAU182DEV315\\tfs',
    id: 'tfs',
  },
  {
    text: 'Lakshman, Narasimhan',
    id: 'lakshmn2',
  },
  {
    text: 'Norman, Tony',
    id: 'normant2',
  },
  {
    text: 'Marshall, Duncan',
    id: 'marshad3',
  },
  {
    text: 'Santos, Roland',
    id: 'santosr1',
  },
  {
    text: 'Vohra, Yasmeen',
    id: 'vohray',
  },
  {
    text: 'Rana, Nitin',
    id: 'ranan1',
  },
  {
    text: 'Parsons, Ben',
    id: 'parsonsb',
  },
  {
    text: 'Bhatia, Sarabjit',
    id: 'bhatias1',
  },
  {
    text: 'Test1',
    id: 'test1',
  },
  {
    text: 'Test User11',
    id: 'test11',
  },
  {
    text: 'ANZ-WIN2K3\\Administrator',
    id: 'administrator',
  },
  {
    text: 'Lynch, Ray',
    id: 'lynchr',
  },
  {
    text: 'Neal, Braden',
    id: 'nealb',
  },
  {
    text: 'Sugathan, Santhosh',
    id: 'santhoss',
  },
  {
    text: 'Cheng, Justin',
    id: 'chengj0',
  },
  {
    text: 'Parsons, Ben (Singapore)',
    id: 'parsonb1',
  },
  {
    text: 'Smith, Wade',
    id: 'smithw10',
  },
  {
    text: 'Power, Beth',
    id: 'powerb',
  },
  {
    text: 'Manifold, Jonathan',
    id: 'manifolj',
  },
  {
    text: 'Gulluyan, Lara',
    id: 'gulluyal',
  },
  {
    text: 'Cronje, Peter',
    id: 'cronjep',
  },
  {
    text: 'Bhadauria, Anshu_Old',
    id: 'bhadaua1',
  },
  {
    text: 'Wu, David (Mkt Risk)',
    id: 'wud3',
  },
  {
    text: 'Zilberman, Alex',
    id: 'zilberma',
  },
  {
    text: 'Baines, Cheryl',
    id: 'bainesc',
  },
  {
    text: 'Macdonald, Gary',
    id: 'macdong1',
  },
  {
    text: 'Weatherby, Ray',
    id: 'weatherr',
  },
  {
    text: 'Rogers, Andrew',
    id: 'rogersa1',
  },
  {
    text: 'Soon, Hon',
    id: 'soonh',
  },
  {
    text: 'Ellwood, Nicholas (NZ)',
    id: 'ellwoon',
  },
  {
    text: 'Harrington, Tim',
    id: 'harrint1',
  },
  {
    text: 'Liden, Roger',
    id: 'lidenr',
  },
  {
    text: 'Bright, William',
    id: 'brightw',
  },
  {
    text: 'Vorster, Johan',
    id: 'vorsterj',
  },
  {
    text: 'Yuen, Zena',
    id: 'yuenz',
  },
  {
    text: 'Higgins, Keith1',
    id: 'higgink3',
  },
  {
    text: 'Joubert, Liana',
    id: 'joubertl',
  },
  {
    text: 'Salvi, Viraj',
    id: 'salviv',
  },
  {
    text: 'Shoukat Ali, Nazeer',
    id: 'shoukan1',
  },
  {
    text: 'Liberman, Michael',
    id: 'libermam',
  },
  {
    text: 'Saini, Gurjit',
    id: 'sainig',
  },
  {
    text: 'Lakau, Sjamsul',
    id: 'lakaus',
  },
  {
    text: 'Kloman, Anthony',
    id: 'klomana',
  },
  {
    text: 'Meechouay, Tadravee',
    id: 'meechot1',
  },
  {
    text: 'Imbriano, Mark',
    id: 'imbrianm',
  },
  {
    text: 'Lisette, Stephan',
    id: 'lisettes',
  },
  {
    text: 'Tarraran, Daniel',
    id: 'tarrarad',
  },
  {
    text: 'Palacios, Yolanda',
    id: 'palacioy',
  },
  {
    text: 'Bittianda, Vidya',
    id: 'bittiav1',
  },
  {
    text: 'Comito, Ferdie',
    id: 'comitof',
  },
  {
    text: 'Young, Carl (66769)',
    id: 'youngc33',
  },
  {
    text: 'Chan, Debbie',
    id: 'chand11',
  },
  {
    text: 'Lou, Tony',
    id: 'lout1',
  },
  {
    text: 'Power, Tim',
    id: 'powert1',
  },
  {
    text: 'Ngo, Aimee',
    id: 'ngoa',
  },
  {
    text: 'Arun, Agalukote Lakshmipathi',
    id: 'aruna1',
  },
  {
    text: 'Lai, Adeline',
    id: 'laia2',
  },
  {
    text: 'Arora, Vishal',
    id: 'arorav3',
  },
  {
    text: 'Sujathan, Mani',
    id: 'sujatham',
  },
  {
    text: 'Anderson, Shaun',
    id: 'anders15',
  },
  {
    text: 'Manuell, David',
    id: 'manuelld',
  },
  {
    text: 'Linton-Simpkins, Mark',
    id: 'lintonsm',
  },
  {
    text: 'Bryers, Galina (Sydney)',
    id: 'bryersg1',
  },
  {
    text: 'Jegatheesan, Mohan',
    id: 'jegathem',
  },
  {
    text: 'Codd, Matthew',
    id: 'coddm',
  },
  {
    text: 'Cassidy, David',
    id: 'cassidd2',
  },
  {
    text: 'Elsworth, Frank',
    id: 'elswortf',
  },
  {
    text: 'Taylor, Lachlan',
    id: 'taylorl2',
  },
  {
    text: 'Gillett, Christopher',
    id: 'gilletcc',
  },
  {
    text: 'Marshall, Colin',
    id: 'marshalc',
  },
  {
    text: 'Lidyana1, Margareth',
    id: 'lidyanam',
  },
  {
    text: 'Kapuganty, Venkat',
    id: 'kapuganv',
  },
  {
    text: 'Tachimoto, Yoshio',
    id: 'tachimoy',
  },
  {
    text: 'Li, Stanley',
    id: 'lis20',
  },
  {
    text: 'Kay, Stephen_Old',
    id: 'kays1',
  },
  {
    text: 'Estivalet, Damien',
    id: 'estivald',
  },
  {
    text: 'Pearson, Ian',
    id: 'pearsoni',
  },
  {
    text: 'Powell, Richard',
    id: 'powellr',
  },
  {
    text: 'Keenan, Aaron',
    id: 'keenana',
  },
  {
    text: 'Kim, Eunjue',
    id: 'kime3',
  },
  {
    text: 'Liang, Tifen',
    id: 'liangt',
  },
  {
    text: 'Shen, Jie',
    id: 'shenjie',
  },
  {
    text: 'Chong, Joel',
    id: 'chongj',
  },
  {
    text: 'Wright, Norm',
    id: 'wrightn2',
  },
  {
    text: 'Starcheus, Gennadiy',
    id: 'starchg',
  },
  {
    text: 'Starcheus, Gennadiy',
    id: 'starcheg',
  },
  {
    text: 'Sureshkumar, Swaminathan (Suresh)',
    id: 'sureshks',
  },
  {
    text: 'Jordon, Samantha',
    id: 'jordons',
  },
  {
    text: 'Imre, Kristen',
    id: 'imrek',
  },
  {
    text: 'Lu, Yumei',
    id: 'luy',
  },
  {
    text: 'Tseung, Sophie',
    id: 'tseungs',
  },
  {
    text: 'Gangopadhyay, Chiranjit',
    id: 'gangopac',
  },
  {
    text: 'Mittal, Manu',
    id: 'mittalm1',
  },
  {
    text: 'Raghavendran, Sangeetha',
    id: 'raghaves',
  },
  {
    text: 'Khan, Pradeep',
    id: 'khanp',
  },
  {
    text: 'Sheshadri, Satyan',
    id: 'sheshads',
  },
  {
    text: 'Patil, Nitin',
    id: 'patiln2',
  },
  {
    text: 'Murthy, B M Narsimha',
    id: 'murthyn',
  },
  {
    text: 'Yellamilli, Ashok Kumar',
    id: 'yallama',
  },
  {
    text: 'Abdul, Irfan',
    id: 'abduli',
  },
  {
    text: 'Yellamilli, Ashok',
    id: 'yellama',
  },
  {
    text: 'Langdon, Stuart',
    id: 'langdons',
  },
  {
    text: 'Gray, Alexis',
    id: 'graya2',
  },
  {
    text: 'Perez, Clem',
    id: 'perezc',
  },
  {
    text: 'Wang, Tom',
    id: 'wangt3',
  },
  {
    text: 'Karnali, Leona Agustine',
    id: 'karnalil',
  },
  {
    text: 'Lu, Wei (66986)',
    id: 'luw1',
  },
  {
    text: 'Williamson, Ricky',
    id: 'williar2',
  },
  {
    text: 'Halliday, James',
    id: 'hallidaj',
  },
  {
    text: 'Parsons, Ben (OCEANIATST)',
    id: 'parsonb1admin',
  },
  {
    text: 'Parikh, Kuntal',
    id: 'parikhk',
  },
  {
    text: 'Khoo, Christopher',
    id: 'khooc',
  },
  {
    text: 'Howard, Frank',
    id: 'howardf0',
  },
  {
    text: 'Gauld, Oliver',
    id: 'gauldo',
  },
  {
    text: 'Gillett, Christopher (Singapore)',
    id: 'gilletc2',
  },
  {
    text: 'Sewambar, Soraya',
    id: 'sewambas',
  },
  {
    text: 'Ho, Shu Wing',
    id: 'hos10',
  },
  {
    text: 'Randall, Jonathan',
    id: 'randalj1',
  },
  {
    text: 'Elias, John',
    id: 'eliasj',
  },
  {
    text: 'Renton-Green, Fritha',
    id: 'rentogf0',
  },
  {
    text: 'smnd',
    id: 'laksh',
  },
  {
    text: 'Anabo, Christopher',
    id: 'anaboc',
  },
  {
    text: 'Pham, Phong',
    id: 'phamp',
  },
  {
    text: 'Wheatley, Christopher',
    id: 'wheatlc1',
  },
  {
    text: 'Vimolkul, Jitpiya (October)',
    id: 'vimolkuj',
  },
  {
    text: 'Shi, Tengda',
    id: 'tengdas',
  },
  {
    text: 'Greer, Jason',
    id: 'greerj2',
  },
  {
    text: 'Fenton, Stewart',
    id: 'fentonsadmin',
  },
  {
    text: 'Kotova, Joanna',
    id: 'kotovaj',
  },
  {
    text: 'Nibali, Anthony',
    id: 'nibalia',
  },
  {
    text: "D'Cruz, Denver",
    id: 'dcruzd',
  },
  {
    text: 'Yuen, Michelle (Singapore)',
    id: 'yuenm2',
  },
  {
    text: 'Sanghai, Saurav',
    id: 'sanghais',
  },
  {
    text: 'Jordan, Samantha',
    id: 'jordas0',
  },
  {
    text: 'Sidorenko, Kirill',
    id: 'sidorek1',
  },
  {
    text: 'Chi, William',
    id: 'chiw',
  },
  {
    text: 'Wang, Zhuojun',
    id: 'wangj9',
  },
  {
    text: 'Lie, Cicilia',
    id: 'liec',
  },
  {
    text: 'Elsaadi, Robbie (Insights)',
    id: 'elsaadir',
  },
  {
    text: 'Button, Ellie',
    id: 'buttone',
  },
  {
    text: 'Cook, David (Markets)',
    id: 'cookd3',
  },
  {
    text: 'Hildage, Jamie',
    id: 'hildagj1',
  },
  {
    text: 'Yau, Benson',
    id: 'yaub',
  },
  {
    text: 'Chong, Shih-Ya',
    id: 'chongsy',
  },
  {
    text: 'McNicol, Simon',
    id: 'mcnicols',
  },
  {
    text: 'Law, Leonard',
    id: 'lawy1',
  },
  {
    text: 'Stone, Richard (Aus)',
    id: 'stoner4',
  },
  {
    text: 'Vander Straaten, Trudy',
    id: 'vanderst',
  },
  {
    text: 'Cho, John',
    id: 'choj2',
  },
  {
    text: 'Sutherland, Bruce',
    id: 'sutherb1',
  },
  {
    text: 'Wu, Daisy',
    id: 'wud1',
  },
  {
    text: 'Muir, Edward',
    id: 'muire',
  },
  {
    text: 'Riley, Leighton',
    id: 'rileyl2',
  },
  {
    text: 'Shaikh, Shamim',
    id: 'shaikhs1',
  },
  {
    text: 'Williams, Roger',
    id: 'williar9',
  },
  {
    text: 'Moore, Jennifer',
    id: 'moorej5',
  },
  {
    text: 'Juergens, Susanne',
    id: 'juergens',
  },
  {
    text: 'Yiu, Kelly',
    id: 'yiuk',
  },
  {
    text: 'Kapuganty, Venkat (New York)',
    id: 'kapugav1',
  },
  {
    text: 'Zhang, Ke',
    id: 'zhangk1',
  },
  {
    text: 'Gokaldas, Dishell',
    id: 'gokaldad',
  },
  {
    text: 'Yang, George',
    id: 'yangg1',
  },
  {
    text: 'Nalwaya, Nitesh',
    id: 'nalwayan',
  },
  {
    text: 'March, Catriona',
    id: 'marchc',
  },
  {
    text: 'Bachalakuri, Rambabu',
    id: 'bachalr',
  },
  {
    text: 'Chauhan, Raghvendra',
    id: 'chrvdra',
  },
  {
    text: 'Lazar, Justin',
    id: 'lazarj',
  },
  {
    text: 'Greer, Jason Douglas',
    id: 'greerjd',
  },
  {
    text: 'Hrvatin, Rebecca',
    id: 'hrvatinr',
  },
  {
    text: 'Collins, Shayne',
    id: 'collis11',
  },
  {
    text: 'Loo, Irwin',
    id: 'loos1',
  },
  {
    text: 'Roussel, Jerome',
    id: 'roussej0',
  },
  {
    text: 'Coppinger, Sean',
    id: 'coppings',
  },
  {
    text: 'Boisson, Tony',
    id: 'boissont',
  },
  {
    text: 'Ota, Jason',
    id: 'otaj',
  },
  {
    text: 'Leverkuehn, Christopher',
    id: 'leverkuc',
  },
  {
    text: 'Jayanand, Nithin',
    id: 'jayanann',
  },
  {
    text: 'Jayanna, Gururaja',
    id: 'jayannag',
  },
  {
    text: 'M, Arun',
    id: 'marun1',
  },
  {
    text: 'Gupta, Neeru',
    id: 'guptan5',
  },
  {
    text: 'Baben, Britto',
    id: 'babenb',
  },
  {
    text: 'Judd, Jamison',
    id: 'juddj1',
  },
  {
    text: 'Do, Viet',
    id: 'dov',
  },
  {
    text: 'Karri, Surya',
    id: 'suryak',
  },
  {
    text: 'Cheah, Aaron',
    id: 'cheaha',
  },
  {
    text: 'Sy, Alfred',
    id: 'magallaa',
  },
  {
    text: 'Ng, Mervyn',
    id: 'ngm3',
  },
  {
    text: 'Trafford, David (Singapore)',
    id: 'traffod1',
  },
  {
    text: 'Madaan, Sameer',
    id: 'madaans',
  },
  {
    text: 'Foh, Gavin',
    id: 'fohg',
  },
  {
    text: 'Baker, Hannah',
    id: 'bakerh2',
  },
  {
    text: 'Malhotra, Subhash',
    id: 'malhotrs',
  },
  {
    text: 'Chen, Sean',
    id: 'chens6',
  },
  {
    text: 'Singh, Rohit',
    id: 'rohits',
  },
  {
    text: 'Shaw, Daniel',
    id: 'shawd',
  },
  {
    text: 'Pakshong, Andrew',
    id: 'pakshona',
  },
  {
    text: 'Lee, Ryan',
    id: 'leer6',
  },
  {
    text: 'Guo, Karen',
    id: 'guok',
  },
  {
    text: 'Orozco Trejo, Luis',
    id: 'orozcol',
  },
  {
    text: 'Wong, Michael (Singapore)',
    id: 'wongm31',
  },
  {
    text: 'Chan, Sam',
    id: 'chans2',
  },
  {
    text: 'Gulliver, Ben',
    id: 'gulliveb',
  },
  {
    text: 'Credit Trading & DCM Risk',
    id: 'cretdcm_email',
  },
  {
    text: 'Francis, Anthony',
    id: 'francia1',
  },
  {
    text: 'Barton-Hills, Jared',
    id: 'bartonhj',
  },
  {
    text: 'Scott, Benjamin',
    id: 'scottb1',
  },
  {
    text: 'Shao, Dan',
    id: 'shaod',
  },
  {
    text: 'Velugoti, Vivekananda',
    id: 'velugotv',
  },
  {
    text: 'Kelly, Cameron',
    id: 'kellyc',
  },
  {
    text: 'Surapreddy, Ravendra Nadh',
    id: 'suraprer',
  },
  {
    text: 'Malhi, Raj',
    id: 'malhir',
  },
  {
    text: 'Zhang, George',
    id: 'zhangg1',
  },
  {
    text: 'White, Jamie',
    id: 'whitej5',
  },
  {
    text: 'Lee, Shaun',
    id: 'lees11',
  },
  {
    text: 'Weigel, Peter',
    id: 'weigelp',
  },
  {
    text: 'Xue, Feng',
    id: 'xuef2',
  },
  {
    text: 'Dumir, Neeraj',
    id: 'dumirn',
  },
  {
    text: 'Hayrapetyan, Khachatur',
    id: 'hayrapek',
  },
  {
    text: 'Kniznikov, Jonathan',
    id: 'kniznikj',
  },
  {
    text: 'Mishra, Partha',
    id: 'mishrap5',
  },
  {
    text: 'Phani, Rama Krishna',
    id: 'phanir',
  },
  {
    text: 'Bhadauria, Anshu',
    id: 'bhadaura',
  },
  {
    text: 'Wong, Roger (Hong Kong)',
    id: 'wongr9',
  },
  {
    text: 'Ng, Florinna',
    id: 'ngf3',
  },
  {
    text: 'Chan, Daniel',
    id: 'chand13',
  },
  {
    text: 'Donis, Alexandra',
    id: 'donisa',
  },
  {
    text: 'Ong, Yik (Hong Kong)',
    id: 'ongy1',
  },
  {
    text: 'Chan, Wendee',
    id: 'chanw2',
  },
  {
    text: 'Yang, Ying',
    id: 'yangy',
  },
  {
    text: 'Van Willies, Andrew',
    id: 'williea',
  },
  {
    text: 'Bretz, Holger',
    id: 'bretzh',
  },
  {
    text: 'Popinski, Henry',
    id: 'popinsh0',
  },
  {
    text: 'Loh, Nicky1',
    id: 'lohn',
  },
  {
    text: 'Lalgudi, Madhu',
    id: 'lalgudim',
  },
  {
    text: 'Chase, John',
    id: 'chasej',
  },
  {
    text: 'Ligot, Xavier',
    id: 'ligotx',
  },
  {
    text: 'Sofi, Simona',
    id: 'sofis',
  },
  {
    text: 'Miri, Mehdi',
    id: 'mehdim',
  },
  {
    text: 'Dillon, Rob',
    id: 'dillonr',
  },
  {
    text: 'Khoo, Diana',
    id: 'khood',
  },
  {
    text: 'Chin, Denise',
    id: 'chind1',
  },
  {
    text: 'Chaurusno, Andy',
    id: 'chaurusa',
  },
  {
    text: 'Selvam, Keerthana',
    id: 'selvamk1',
  },
  {
    text: 'McBride, William',
    id: 'mcbridew',
  },
  {
    text: 'Mason, Mark',
    id: 'masonm',
  },
  {
    text: 'Lam, Timothy',
    id: 'lamt10',
  },
  {
    text: 'Arms, David',
    id: 'armsd',
  },
  {
    text: 'Harvell, Chris',
    id: 'harvellc',
  },
  {
    text: 'Lai, Benjamin',
    id: 'laib6',
  },
  {
    text: 'Yip, Jean',
    id: 'yipp',
  },
  {
    text: 'Sun, Ran',
    id: 'sunr',
  },
  {
    text: 'Matsuda, Natsumi',
    id: 'matsudan',
  },
  {
    text: 'Clayton, Louise',
    id: 'claytonl',
  },
  {
    text: 'Sprague, Ben',
    id: 'spragueb',
  },
  {
    text: 'Nolan, Jvala',
    id: 'nolanj1',
  },
  {
    text: 'Gupta, Ankit Kumar',
    id: 'guptaak',
  },
  {
    text: 'Gangal, Tanmay',
    id: 'gangalt',
  },
  {
    text: 'Ong, Chun Siew',
    id: 'ongc4',
  },
  {
    text: 'Hill, Christopher',
    id: 'hillc2',
  },
  {
    text: 'Huaman Campos, Jason',
    id: 'huamancj',
  },
  {
    text: 'Lim, Eliza',
    id: 'limc7',
  },
  {
    text: 'Mehta, Rai',
    id: 'mehtar2',
  },
  {
    text: 'Ongkowijaya, Helen',
    id: 'kowijho1',
  },
  {
    text: 'Sri Ratnam, Chrishanthini',
    id: 'sriratnc',
  },
  {
    text: 'Donovan, Kate',
    id: 'donovank',
  },
  {
    text: 'Chor, Yiing Feng',
    id: 'choryf',
  },
  {
    text: 'Zappulla, Robert',
    id: 'zappullr',
  },
  {
    text: 'Marissa, Maria',
    id: 'marissam',
  },
  {
    text: 'Cheah, Cherlene',
    id: 'cheahc',
  },
  {
    text: 'Hong, Tchiapeen',
    id: 'hongt2',
  },
  {
    text: 'Pan, Zhemin',
    id: 'panz1',
  },
  {
    text: 'Wang, Judy (Hong Kong)',
    id: 'wangj22',
  },
  {
    text: 'Ang, Yan En',
    id: 'angy',
  },
  {
    text: 'Ha, Michelle',
    id: 'ham',
  },
  {
    text: 'Smith, Adam (PC)',
    id: 'smitha10',
  },
  {
    text: 'Kennedy, Stephen',
    id: 'kenneds1',
  },
  {
    text: 'Wei, Sun',
    id: 'weis',
  },
  {
    text: 'Srinivas, Mohan Kumar',
    id: 'mohanks',
  },
  {
    text: 'Kulandai Vel, Vini',
    id: 'kulandv1',
  },
  {
    text: 'Nevada, Gerald (Oceania)',
    id: 'nevadag',
  },
  {
    text: 'Thimmaraju, Suraj (Oceania)',
    id: 'thimmars',
  },
  {
    text: 'Buckley, Terese',
    id: 'bucklet2',
  },
  {
    text: 'McRae, Tamara',
    id: 'mcraet',
  },
  {
    text: 'Bowles, Don',
    id: 'bowlesd',
  },
  {
    text: 'Martin, Christina',
    id: 'martinc3',
  },
  {
    text: 'Attard, Andrew',
    id: 'attarda3',
  },
  {
    text: 'Lim, Andrew',
    id: 'lima3',
  },
  {
    text: 'Morris, Blair',
    id: 'morrisb3',
  },
  {
    text: 'Gibson, Jessica',
    id: 'gibsonj',
  },
  {
    text: 'Truong, Duc',
    id: 'truongd3',
  },
  {
    text: 'Bradley, Nicholas',
    id: 'bradlen',
  },
  {
    text: 'Tran, Corey',
    id: 'tranc',
  },
  {
    text: 'Longo, Simon',
    id: 'longos',
  },
  {
    text: 'Abraham, Mathew',
    id: 'amathew',
  },
  {
    text: 'Tang, Danny',
    id: 'tangd4',
  },
  {
    text: 'Cheuk, Dallas',
    id: 'cheukd',
  },
  {
    text: 'Shen, Anna',
    id: 'shena2',
  },
  {
    text: 'Ho, Michelle',
    id: 'hom23',
  },
  {
    text: 'Campbell, Philippa',
    id: 'campbep0',
  },
  {
    text: 'Soul, Kiera',
    id: 'soulk',
  },
  {
    text: 'Yip, Kin',
    id: 'yipk',
  },
  {
    text: 'Dawson, Darren',
    id: 'dawsond4',
  },
  {
    text: 'Van Rest, Cornelis',
    id: 'vanrestc',
  },
  {
    text: 'Wagstaff, Mark',
    id: 'wagstafm',
  },
  {
    text: 'Fan, Katie',
    id: 'fank1',
  },
  {
    text: 'Marasco, Steven',
    id: 'marascos',
  },
  {
    text: 'Korff, Marcus',
    id: 'korffm',
  },
  {
    text: 'Sim, Alvin (AUS)',
    id: 'sima5',
  },
  {
    text: 'Bleakley, David',
    id: 'bleakled',
  },
  {
    text: 'Manalac, Freddie',
    id: 'manalacf',
  },
  {
    text: 'Barton, Geoff (AU)',
    id: 'bartong1',
  },
  {
    text: 'Khoury, Suzanne',
    id: 'khourys',
  },
  {
    text: 'Chan, June',
    id: 'chanj7',
  },
  {
    text: 'Gazzola, Santo',
    id: 'gazzolas',
  },
  {
    text: 'Hegarty, Keith',
    id: 'hegartyk',
  },
  {
    text: 'Thierry Merand',
    id: 'merandt',
  },
  {
    text: 'Khoo, Ian (KHOOI)',
    id: 'khooi',
  },
  {
    text: 'Aluri, Madhuri',
    id: 'alurim',
  },
  {
    text: 'Fiasco, Sam',
    id: 'fiascos',
  },
  {
    text: 'Joshi, Santosh',
    id: 'joshis6',
  },
  {
    text: 'Su, Rachel',
    id: 'sur',
  },
  {
    text: 'Tran, Albert',
    id: 'trana6',
  },
  {
    text: 'Vella, Lisa',
    id: 'vellal',
  },
  {
    text: 'Walkenhorst, Joseph',
    id: 'walkenhj',
  },
  {
    text: 'Klym, Andrew',
    id: 'andrewk2',
  },
  {
    text: 'Santos, Michael',
    id: 'santosm6',
  },
  {
    text: 'Liew, Ban Fah (Ben)',
    id: 'liewb',
  },
  {
    text: 'Sarmiento, Edijer',
    id: 'sarmiee1',
  },
  {
    text: 'Beaumont, Anthony',
    id: 'beaumoa0',
  },
  {
    text: 'Garikapati, Vijay',
    id: 'garikapv',
  },
  {
    text: 'Kostic, Branko',
    id: 'kosticb',
  },
  {
    text: 'Shanmugasundaram, Thirusenthil',
    id: 'shanmut1',
  },
  {
    text: 'Holmes, Bill',
    id: 'holmesb1',
  },
  {
    text: 'Schweppe, Nora',
    id: 'schweppn',
  },
  {
    text: 'Kessler, Nora',
    id: 'kesslern',
  },
  {
    text: 'Brien, Laurel',
    id: 'brienl',
  },
  {
    text: 'Gupta, Deepak (Singapore)',
    id: 'guptad6',
  },
  {
    text: 'Dharmalingam, Raja',
    id: 'dharmar0',
  },
  {
    text: 'Romero, Silvia',
    id: 'romeros',
  },
  {
    text: 'Yin, Angela',
    id: 'yina',
  },
  {
    text: 'Spells, Susana',
    id: 'spellss',
  },
  {
    text: 'Boisrond, Lynne',
    id: 'boisronl',
  },
  {
    text: 'Chuah, Travis',
    id: 'chuaht',
  },
  {
    text: 'Maglio, Jarrod',
    id: 'maglioj',
  },
  {
    text: 'James Stanton',
    id: 'stantoj1',
  },
  {
    text: 'Bellamkonda, Shreyas',
    id: 'bellams',
  },
  {
    text: 'Varadarajan, Srinivasa Krishnan',
    id: 'varadasr',
  },
  {
    text: 'M V, Manjunatha',
    id: 'mvm1',
  },
  {
    text: 'Nair, Ramya',
    id: 'nairr',
  },
  {
    text: 'Agarwal, Priya',
    id: 'agarwapr',
  },
  {
    text: 'Tzelepis, Phillip',
    id: 'tzelepip',
  },
  {
    text: 'Choi, Jacinta',
    id: 'choij6',
  },
  {
    text: 'Mittal, Shankul',
    id: 'mittals2',
  },
  {
    text: 'Saddala, Anil',
    id: 'sanilp2',
  },
  {
    text: 'Narayanan, Venkatesh',
    id: 'nvenkat2',
  },
  {
    text: 'Javeri, Mahavir',
    id: 'javerim',
  },
  {
    text: 'Jayaprakash, Satish',
    id: 'satishj',
  },
  {
    text: 'Mickova, Josipa',
    id: 'mickovaj',
  },
  {
    text: 'Ashkettle, Benjamin',
    id: 'ashkettb',
  },
  {
    text: 'Mangala, Rithuu',
    id: 'mangalar',
  },
  {
    text: 'Ayaz, Mohammad',
    id: 'ayazm1',
  },
  {
    text: 'Afzal, Fehrial',
    id: 'afzalf',
  },
  {
    text: 'Agarwal, Puneet',
    id: 'agarwap4',
  },
  {
    text: 'Aho, Otolose',
    id: 'ahoo',
  },
  {
    text: 'Alexander, Kayvon',
    id: 'alexandk',
  },
  {
    text: 'Allan, Matthew',
    id: 'allanm4',
  },
  {
    text: 'Allen, Ross',
    id: 'allenr1',
  },
  {
    text: 'Altamura, Stephen',
    id: 'altamurs',
  },
  {
    text: 'Anderson, Sam',
    id: 'anders16',
  },
  {
    text: 'Ann, Mui Ling',
    id: 'annm',
  },
  {
    text: 'Attwood, Mike',
    id: 'attwoodm',
  },
  {
    text: 'Aw, Rachel',
    id: 'awr',
  },
  {
    text: 'Baggio, Gregoire',
    id: 'baggiog',
  },
  {
    text: 'Balakrishnan, Raju',
    id: 'balakr1',
  },
  {
    text: 'Barrington, Christopher',
    id: 'barringc',
  },
  {
    text: 'Barsaiyan, Mridul',
    id: 'barsaiym',
  },
  {
    text: 'Battson, Quinn',
    id: 'battsonq',
  },
  {
    text: 'Baumgartner, Chris',
    id: 'baumgarc',
  },
  {
    text: 'Bazzucchini, Peter',
    id: 'bazzuccp',
  },
  {
    text: 'Beia, Raakiti',
    id: 'beiar3',
  },
  {
    text: 'Bermange, Ian',
    id: 'bermangi',
  },
  {
    text: 'Boden, Emily',
    id: 'bodene',
  },
  {
    text: 'Borg, Kevin',
    id: 'borgk1',
  },
  {
    text: 'Bosha, Trust',
    id: 'boshat',
  },
  {
    text: 'Bowen, Andy',
    id: 'bowena',
  },
  {
    text: 'Boyd, Andrew',
    id: 'boyda2',
  },
  {
    text: 'Brennan, Claire',
    id: 'brennac1',
  },
  {
    text: 'Tai, Bryan Yee Hwang',
    id: 'bryant1',
  },
  {
    text: 'Calderon, Mel',
    id: 'calderm',
  },
  {
    text: 'Calleja, Ronan',
    id: 'callejar',
  },
  {
    text: 'Campbell, Angus',
    id: 'campbeg3',
  },
  {
    text: 'Carrington, Andrew',
    id: 'carrina1',
  },
  {
    text: 'Cassidy, Aidan',
    id: 'cassidya',
  },
  {
    text: 'Cavallo, Aldo',
    id: 'cavalloa',
  },
  {
    text: 'Chalklen, David',
    id: 'chalkled',
  },
  {
    text: 'Chan, Aaron (Global Markets)',
    id: 'chana51',
  },
  {
    text: 'Chan, Caroline',
    id: 'chanc19',
  },
  {
    text: 'Chan, Dianne',
    id: 'chand2',
  },
  {
    text: 'Chandan, Vyomesh',
    id: 'chandanv',
  },
  {
    text: 'Chandran, Sanjay',
    id: 'chandras',
  },
  {
    text: 'Chang, Anny',
    id: 'changa2',
  },
  {
    text: 'Chang, Connie (Taiwan)',
    id: 'changc7',
  },
  {
    text: 'Chang, Lewis',
    id: 'changl4',
  },
  {
    text: 'Chao, Ming Hung',
    id: 'chaom',
  },
  {
    text: 'Chapman, Scott',
    id: 'chapmas2',
  },
  {
    text: 'Chapman, Timothy',
    id: 'chapmat2',
  },
  {
    text: 'Chee, Yin Chia',
    id: 'cheey',
  },
  {
    text: 'Chen, Camy',
    id: 'chenc12',
  },
  {
    text: 'Chen, Ellen',
    id: 'chene4',
  },
  {
    text: 'Cheng, Hao',
    id: 'chengh',
  },
  {
    text: 'Cheng, Juyuan',
    id: 'chengj9',
  },
  {
    text: 'Chen, Leo',
    id: 'chenl8',
  },
  {
    text: 'Chen, Nancy',
    id: 'chenn2',
  },
  {
    text: 'Chen, Zhirong',
    id: 'chenz1',
  },
  {
    text: 'Chew, Jonathan',
    id: 'chewj5',
  },
  {
    text: 'Chew, Julian',
    id: 'chewj7',
  },
  {
    text: 'Chhen, Sokmean',
    id: 'chhens1',
  },
  {
    text: 'Chin, Maria',
    id: 'chinm1',
  },
  {
    text: 'Chorazyczewski, Richard',
    id: 'chorazyr',
  },
  {
    text: 'Chua, Yi Wen (Global Markets)',
    id: 'chuay',
  },
  {
    text: 'Chu, Thi Duyen',
    id: 'chud',
  },
  {
    text: 'Chugh, Amit',
    id: 'chugha',
  },
  {
    text: 'Clear, Geoff',
    id: 'clearg1',
  },
  {
    text: 'Coakley, Eavan',
    id: 'coakleye',
  },
  {
    text: 'Colak, Osman',
    id: 'colako',
  },
  {
    text: 'Coltman, Thomas',
    id: 'coltmant',
  },
  {
    text: 'Contreras, Mayu',
    id: 'contrerm',
  },
  {
    text: 'Cooke, Alex',
    id: 'cookea1',
  },
  {
    text: 'Cordery, Hugh',
    id: 'corderyh',
  },
  {
    text: 'Cork, Nicholas',
    id: 'corkn',
  },
  {
    text: 'Costantino, Cathryn',
    id: 'costantc',
  },
  {
    text: 'Costello, Nicholas',
    id: 'costelln',
  },
  {
    text: 'Crombie, Andrew',
    id: 'crombiea',
  },
  {
    text: 'Daniel, Ray',
    id: 'danielsr',
  },
  {
    text: 'Darby, Luke',
    id: 'darbyl',
  },
  {
    text: 'David, Rita',
    id: 'davidr5',
  },
  {
    text: 'De Silva, Mel',
    id: 'desilvam',
  },
  {
    text: 'Dick, Anna',
    id: 'dicka1',
  },
  {
    text: 'Dickie, Jeff',
    id: 'dickiej',
  },
  {
    text: 'Dimmock, David',
    id: 'dimmd',
  },
  {
    text: 'Downie, Tim',
    id: 'downiet1',
  },
  {
    text: 'Draunibaka, Aporosa',
    id: 'drauniba',
  },
  {
    text: 'DRozario, Tracey',
    id: 'drozarit',
  },
  {
    text: 'Eckhoff, Simon',
    id: 'eckhofs1',
  },
  {
    text: 'Eikeland, Harald',
    id: 'eikelanh',
  },
  {
    text: 'Ellison, Clinton',
    id: 'ellisonc',
  },
  {
    text: 'Ellis, Sam',
    id: 'elliss8',
  },
  {
    text: 'Esquilant, Stuart',
    id: 'esquilas',
  },
  {
    text: 'Falta, Dan',
    id: 'faltad',
  },
  {
    text: 'Fang, Agnes',
    id: 'fanga',
  },
  {
    text: 'Fenech, Peter',
    id: 'fenechp',
  },
  {
    text: 'Fimmano, Matthew',
    id: 'fimmanom',
  },
  {
    text: 'Findlay, John (Markets)',
    id: 'findlaj1',
  },
  {
    text: 'Fitzgerald, Kate',
    id: 'fitzgek1',
  },
  {
    text: 'Fong, Adrian',
    id: 'fonga1',
  },
  {
    text: 'Meredith-Foster, Bryn',
    id: 'fosterb',
  },
  {
    text: 'Franco, Stefano',
    id: 'francos',
  },
  {
    text: 'Freedman, Andrew',
    id: 'freedmaa',
  },
  {
    text: 'Fu, Fish',
    id: 'fus5',
  },
  {
    text: 'Fussell, David',
    id: 'fusselld',
  },
  {
    text: 'Garcia, Antonio',
    id: 'garciaa1',
  },
  {
    text: 'Garewal, Yad',
    id: 'garewaly',
  },
  {
    text: 'Garland, Lucy',
    id: 'garlandl',
  },
  {
    text: 'Gatrell, Alec',
    id: 'gatrella',
  },
  {
    text: 'Gawi, Delicia (Solomon Islands)',
    id: 'gawid2',
  },
  {
    text: 'Gawn, Steve',
    id: 'gawns',
  },
  {
    text: 'Mantri, Gunjan',
    id: 'ghanshyg',
  },
  {
    text: 'Gibbons, Pat',
    id: 'gibbonsp',
  },
  {
    text: 'Gondokusumo, Yan',
    id: 'gondokuy',
  },
  {
    text: 'Gordon-Brown, Paul',
    id: 'gordonbp',
  },
  {
    text: 'Greenwood, Simon',
    id: 'greenwos',
  },
  {
    text: 'Gregory, Matthew',
    id: 'gregorym',
  },
  {
    text: 'Guanzon, Jr., Antonio',
    id: 'guanzona',
  },
  {
    text: 'Guba, Willie',
    id: 'gubaw1',
  },
  {
    text: 'Guerin, Robert',
    id: 'guerinr',
  },
  {
    text: 'Hains, Christian',
    id: 'hainsc',
  },
  {
    text: 'Halbach, Johannes',
    id: 'halbachj',
  },
  {
    text: 'Hall, Adam',
    id: 'halla5',
  },
  {
    text: 'Hall, Tony',
    id: 'hallt',
  },
  {
    text: 'Han, E J',
    id: 'hane2',
  },
  {
    text: 'Han, Priscilla',
    id: 'hanp1',
  },
  {
    text: 'Hasek, Francis',
    id: 'hasekf',
  },
  {
    text: 'Hayes, Deirdre',
    id: 'hayesd2',
  },
  {
    text: 'Henderson, Jo',
    id: 'henderj8',
  },
  {
    text: 'Hennessy, Edward',
    id: 'hennesse',
  },
  {
    text: 'Herman, Ricky',
    id: 'hermanr1',
  },
  {
    text: 'Hermawan, Sintia',
    id: 'hermawas',
  },
  {
    text: 'Hicks, Jerry',
    id: 'hicksj1',
  },
  {
    text: 'Hicks, Neil',
    id: 'hicksn',
  },
  {
    text: 'Hiraiwa, Mana',
    id: 'hiraiwam',
  },
  {
    text: 'Hoang, Thi Minh Phuong',
    id: 'hoangp2',
  },
  {
    text: 'Ho, Carmen (Singapore)',
    id: 'hoc7',
  },
  {
    text: 'Hoe, Ee Wern',
    id: 'hoee',
  },
  {
    text: 'Hoey, Suzie',
    id: 'hoeys',
  },
  {
    text: 'Hogan, Ben',
    id: 'hoganb',
  },
  {
    text: 'Holdaway, Bevan',
    id: 'holdawab',
  },
  {
    text: 'Holt, Duncan',
    id: 'holtd',
  },
  {
    text: 'Hsu, Michelle',
    id: 'hsum1',
  },
  {
    text: 'Huang, Allen S K',
    id: 'huanga5',
  },
  {
    text: 'Huang, Kate',
    id: 'huangk5',
  },
  {
    text: 'Hume, Andrew (London)',
    id: 'humea',
  },
  {
    text: 'Hungerford, Nick',
    id: 'hungerfn',
  },
  {
    text: 'Hutchings, Christian',
    id: 'hutchic2',
  },
  {
    text: 'Hutchison, Linda',
    id: 'hutchisl',
  },
  {
    text: 'Pipe, Amanda',
    id: 'hutta',
  },
  {
    text: 'Huynh, Binh',
    id: 'huynhb',
  },
  {
    text: 'Hyde, Deirdre',
    id: 'hyded',
  },
  {
    text: 'Jacobs, Christopher',
    id: 'jacobsc',
  },
  {
    text: 'Jain, Nikhil',
    id: 'jainn1',
  },
  {
    text: 'James, Peter',
    id: 'jamesp',
  },
  {
    text: 'Jampala, Rakesh',
    id: 'jampalar',
  },
  {
    text: 'Janett, Phil',
    id: 'janettp',
  },
  {
    text: 'Jarvis, Christopher',
    id: 'jarvisc',
  },
  {
    text: 'Johnstone, Hayley',
    id: 'johnstoh',
  },
  {
    text: 'Jones, Steven (Markets)',
    id: 'joness26',
  },
  {
    text: 'Junikatriawan, Daman',
    id: 'junikatd',
  },
  {
    text: 'Kahn, Jason',
    id: 'kahnj',
  },
  {
    text: 'Kalinauskas, Raymond',
    id: 'kalinaur',
  },
  {
    text: 'Kanaley, Phillip',
    id: 'kanaleyp',
  },
  {
    text: 'Kapoor, Dhruv',
    id: 'kapoord',
  },
  {
    text: 'Kashiwagi, Shinichi',
    id: 'kashiwas',
  },
  {
    text: 'Ka, Tadamasa',
    id: 'kat',
  },
  {
    text: 'Katsenos, Con',
    id: 'katsenoc',
  },
  {
    text: 'Kayaoka, Miki',
    id: 'kayaokam',
  },
  {
    text: 'Keane, Simon',
    id: 'keanes',
  },
  {
    text: 'Keays, Colin (keaysc)',
    id: 'keaysc',
  },
  {
    text: 'Kemp, Andrew (Qld)',
    id: 'kempa1',
  },
  {
    text: 'Keng, Kanika',
    id: 'kengk',
  },
  {
    text: 'Kenney, Paul',
    id: 'kenneyp',
  },
  {
    text: 'Kewalramani, Amit',
    id: 'kewala1',
  },
  {
    text: 'Khieu, Hong Van',
    id: 'khieuh',
  },
  {
    text: 'Khin, Nande',
    id: 'khinh',
  },
  {
    text: 'Khoo, Geraldine (NZ)',
    id: 'khoog',
  },
  {
    text: 'Kim, Do Hee',
    id: 'kimd1',
  },
  {
    text: 'Kim, H S',
    id: 'kimh5',
  },
  {
    text: 'Kim, Hyun Bae',
    id: 'kimh6',
  },
  {
    text: 'Kim, J Y',
    id: 'kimj5',
  },
  {
    text: 'Kirby, Matthew',
    id: 'kirbym',
  },
  {
    text: 'Kirby, Matt',
    id: 'kirbym5',
  },
  {
    text: 'Kizilkaya, Nilufer',
    id: 'kizilkan',
  },
  {
    text: 'Kohler, Alan',
    id: 'kohlera',
  },
  {
    text: 'Ko, Jay',
    id: 'koj1',
  },
  {
    text: 'Krkalo, Hrvoje',
    id: 'krkaloh',
  },
  {
    text: 'Kumar, Francis',
    id: 'kumarf',
  },
  {
    text: 'Kumbeli, Melinda',
    id: 'kumbelim',
  },
  {
    text: 'Kuo, Shania',
    id: 'kuos',
  },
  {
    text: 'Kurniawan, Basuki',
    id: 'kurniawb',
  },
  {
    text: 'Kwak, Ha Rim',
    id: 'kwakh',
  },
  {
    text: 'Kwok, Puay San',
    id: 'kwokp',
  },
  {
    text: 'Lambourn, Chris',
    id: 'lambourc',
  },
  {
    text: 'Lam, Gerald (Singapore)',
    id: 'lamg',
  },
  {
    text: 'Larkin, Aimon',
    id: 'larkina1',
  },
  {
    text: 'La Rosa, Jessica',
    id: 'larosaj1',
  },
  {
    text: 'Lash, Rachel',
    id: 'lashr',
  },
  {
    text: 'Lau, Titus',
    id: 'laut',
  },
  {
    text: 'Law, Elvin',
    id: 'lawe2',
  },
  {
    text: 'Leckie, George',
    id: 'leckieg',
  },
  {
    text: 'Lee, Byung Joon',
    id: 'leeb10',
  },
  {
    text: 'Lee, Christopher',
    id: 'leec11',
  },
  {
    text: 'Lee, Harry',
    id: 'leeh14',
  },
  {
    text: 'Lee, Hyun Seok',
    id: 'leeh7',
  },
  {
    text: 'Lee, Jason',
    id: 'leej',
  },
  {
    text: 'Le, Huy (London)',
    id: 'leh4',
  },
  {
    text: 'Leighton, Michael',
    id: 'leightom',
  },
  {
    text: 'Le, Gia Phong',
    id: 'lep5',
  },
  {
    text: 'Lewis, Scott',
    id: 'lewiss7',
  },
  {
    text: 'Liao, Claire',
    id: 'liaoc',
  },
  {
    text: 'Liew, Gerald',
    id: 'liewg',
  },
  {
    text: 'Li, Dat Long',
    id: 'lil4',
  },
  {
    text: 'Lim, Alvin',
    id: 'lima13',
  },
  {
    text: 'Lim, Anne',
    id: 'lima5',
  },
  {
    text: 'Lim, Irene',
    id: 'limi',
  },
  {
    text: 'Lim, Valerie',
    id: 'limv2',
  },
  {
    text: 'Lim, Zhining',
    id: 'limz8',
  },
  {
    text: 'Lin, Howard',
    id: 'linh1',
  },
  {
    text: 'Li, Tina (TW Markets)',
    id: 'lit2',
  },
  {
    text: 'Little, Joe',
    id: 'littlej2',
  },
  {
    text: 'Liu, Bruce',
    id: 'liub2',
  },
  {
    text: 'Liu, Chang',
    id: 'liuc',
  },
  {
    text: 'Logan, Paul',
    id: 'loganp0',
  },
  {
    text: 'Long, Borareaksmey',
    id: 'longb1',
  },
  {
    text: 'Lowcock, Andrew',
    id: 'lowcocka',
  },
  {
    text: 'Low, Emma',
    id: 'lowe4',
  },
  {
    text: 'Lyford, Michael',
    id: 'lyfordm',
  },
  {
    text: 'Lynch, Neil',
    id: 'lynchn',
  },
  {
    text: 'Madoc, Allan',
    id: 'madoca',
  },
  {
    text: 'Maharana, Sambit',
    id: 'maharans',
  },
  {
    text: 'Malivindi, Joe',
    id: 'malivinj',
  },
  {
    text: 'Malone, Robert',
    id: 'maloner2',
  },
  {
    text: 'Manuel, Kat',
    id: 'manuelm',
  },
  {
    text: 'Mao, Grace',
    id: 'maog',
  },
  {
    text: 'Marau, Desmond',
    id: 'maraud',
  },
  {
    text: 'Marnell, Brian',
    id: 'marnellb',
  },
  {
    text: 'Martin, William',
    id: 'martinw',
  },
  {
    text: 'Mason, Veronica',
    id: 'masonv3',
  },
  {
    text: 'Masri, Yurike',
    id: 'masriyur',
  },
  {
    text: 'Mastrocostas, Helen',
    id: 'mastroch',
  },
  {
    text: 'Mather, Simon',
    id: 'mathers1',
  },
  {
    text: 'Maui, Mii',
    id: 'mauim',
  },
  {
    text: 'Mayne, Adam',
    id: 'maynea4',
  },
  {
    text: 'McAlpine, Matthew',
    id: 'mcalpinm',
  },
  {
    text: 'McCarthy, Patrick',
    id: 'mccartp2',
  },
  {
    text: 'McGivern, Nick',
    id: 'mcgivern',
  },
  {
    text: 'McGregor, Andrew',
    id: 'mcgregoa',
  },
  {
    text: 'Mcnee, Paul',
    id: 'mcneep',
  },
  {
    text: 'McNeil, Ewen',
    id: 'mcneile',
  },
  {
    text: 'McPherson, Rachel',
    id: 'mcphersr',
  },
  {
    text: 'McRae, Richard',
    id: 'mcraer2',
  },
  {
    text: 'Medson, Luke',
    id: 'medsonl',
  },
  {
    text: 'Meer, Sol',
    id: 'meers',
  },
  {
    text: 'Menon, Sandhya',
    id: 'menons1',
  },
  {
    text: 'Mercado, Joey',
    id: 'mercadoj',
  },
  {
    text: 'Millen, James',
    id: 'millenj',
  },
  {
    text: 'Min, Bunnarin',
    id: 'minb',
  },
  {
    text: 'Mitchell, Andrew',
    id: 'mitchea6',
  },
  {
    text: 'Mitchell, David (London)',
    id: 'mitched4',
  },
  {
    text: 'Mok, Lucia',
    id: 'mokl',
  },
  {
    text: 'Monaghan, Fabian',
    id: 'monaghaf',
  },
  {
    text: 'Moor, Adam',
    id: 'moora',
  },
  {
    text: 'Moore, David (Mkts Trd)',
    id: 'moored1',
  },
  {
    text: 'Moore, Keith',
    id: 'moorek1',
  },
  {
    text: 'Moore, Paul',
    id: 'moorep',
  },
  {
    text: 'Morawski, Luke',
    id: 'morawskl',
  },
  {
    text: 'Morgan, Andrew',
    id: 'morgana',
  },
  {
    text: 'Morley, Rebekah',
    id: 'morleyr1',
  },
  {
    text: 'Morrah, Elizabeth',
    id: 'morrahe',
  },
  {
    text: 'Morton, Stewart',
    id: 'mortons',
  },
  {
    text: 'Muir, Dean',
    id: 'muird',
  },
  {
    text: 'Mulhearn, Sean',
    id: 'mulhears',
  },
  {
    text: 'Murphy, Rowan',
    id: 'murphyr2',
  },
  {
    text: 'Najm, Sam',
    id: 'najms',
  },
  {
    text: 'Nakamura, Yoshinobu',
    id: 'nakamury',
  },
  {
    text: 'Natalia, Erline',
    id: 'nataliae',
  },
  {
    text: 'Natrajan, Rakshith',
    id: 'natrajar',
  },
  {
    text: 'Navarro, Carlo',
    id: 'navarroc',
  },
  {
    text: 'Nellore, Sandeep',
    id: 'nellores',
  },
  {
    text: 'Neo, Willy',
    id: 'neow1',
  },
  {
    text: 'Newbury, John',
    id: 'newburyj',
  },
  {
    text: 'Ng, Chin Leng',
    id: 'ngc3',
  },
  {
    text: 'Nguyen, Viet Anh',
    id: 'nguyena15',
  },
  {
    text: 'Nguyen, Dang Khoa',
    id: 'nguyendk',
  },
  {
    text: 'Nguyen, Thi Thanh Nga',
    id: 'nguyenn12',
  },
  {
    text: 'Nguyen, Huyen Trang',
    id: 'nguyet76',
  },
  {
    text: 'Nursey, Ravi',
    id: 'nurseyr',
  },
  {
    text: 'OBrien, Christopher',
    id: 'obrienc8',
  },
  {
    text: 'OBrien, Mark',
    id: 'obrienm3',
  },
  {
    text: 'OConnor, Nick',
    id: 'oconnon1',
  },
  {
    text: 'OConnor, Kaitlen',
    id: 'oconnork',
  },
  {
    text: 'ODonnell, Lucy',
    id: 'odonnell',
  },
  {
    text: 'ODriscoll, Paul',
    id: 'odriscp1',
  },
  {
    text: 'Ok, Somanika',
    id: 'oks1',
  },
  {
    text: 'Oliver, Julie',
    id: 'oliverj2',
  },
  {
    text: 'Olphert, Tim',
    id: 'olphertt',
  },
  {
    text: 'Omeri, Allan',
    id: 'omeria',
  },
  {
    text: 'Ong, Kay',
    id: 'ongk',
  },
  {
    text: 'Orchard, Timothy',
    id: 'orchardt',
  },
  {
    text: 'OSullivan, Bevan',
    id: 'osullib2',
  },
  {
    text: 'OSullivan, Timothy',
    id: 'osullit2',
  },
  {
    text: 'Oyo, Malika',
    id: 'oyom',
  },
  {
    text: 'Palmer, Chris',
    id: 'palmerc',
  },
  {
    text: 'Pandya, Mihir',
    id: 'pandyam',
  },
  {
    text: 'Pantzikis, George',
    id: 'pantzikg',
  },
  {
    text: 'Park, D H (Eddie)',
    id: 'parkd2',
  },
  {
    text: 'Park, Young Jin',
    id: 'parky1',
  },
  {
    text: 'Pearl, Marcus (Singapore)',
    id: 'pearlm1',
  },
  {
    text: 'Peermamode, Mark',
    id: 'peermamm',
  },
  {
    text: 'Pepping, Joe (Hong Kong)',
    id: 'peppingj1',
  },
  {
    text: 'Pereira, Antonio',
    id: 'pereiraa',
  },
  {
    text: 'Periwal, Anand',
    id: 'periwala',
  },
  {
    text: 'Perry, Paul',
    id: 'perryp1',
  },
  {
    text: 'Peua, Teautoa (CK)',
    id: 'peuat',
  },
  {
    text: 'Phan, Huu Duy',
    id: 'phand1',
  },
  {
    text: 'Piedois, Laurent',
    id: 'piedoisl',
  },
  {
    text: 'Pillay, Neel',
    id: 'pillayn',
  },
  {
    text: 'Pismiris, Cindy',
    id: 'pismiric',
  },
  {
    text: 'Prabhakaran, Ragu',
    id: 'prabhar1',
  },
  {
    text: 'Prain, Chris',
    id: 'prainc',
  },
  {
    text: 'Pulham, Sue',
    id: 'pulhams',
  },
  {
    text: 'Purba, Mutiara Lusiana',
    id: 'Purbamul',
  },
  {
    text: 'Putra, Krisna Aditya',
    id: 'putrakri',
  },
  {
    text: 'Qiao, Jenny',
    id: 'qiaoj',
  },
  {
    text: 'Qin, Yan',
    id: 'qiny1',
  },
  {
    text: 'Rahmayanti, Reni',
    id: 'rahmayr1',
  },
  {
    text: 'Ramadhany, Hazrati',
    id: 'ramadhah',
  },
  {
    text: 'Ramoni, Samuel',
    id: 'ramonis',
  },
  {
    text: 'Ravenscroft, Ian',
    id: 'ravensci',
  },
  {
    text: 'Rawcliffe, Gerard',
    id: 'rawclifj',
  },
  {
    text: 'Rees, Rohan',
    id: 'reesr',
  },
  {
    text: 'Reyes, Steven Michael',
    id: 'reyess',
  },
  {
    text: 'Richards, Clive',
    id: 'richarc9',
  },
  {
    text: 'Riddington, Rachael',
    id: 'riddingr',
  },
  {
    text: 'Rogers, Michael',
    id: 'rogersm5',
  },
  {
    text: 'Romero, Kristy',
    id: 'romerok',
  },
  {
    text: 'Roriki, Tautongo',
    id: 'rorikit',
  },
  {
    text: 'Royds, Anna',
    id: 'roydsa',
  },
  {
    text: 'Rustam, Sherley S',
    id: 'rustamss',
  },
  {
    text: 'Ryan, David',
    id: 'ryand',
  },
  {
    text: 'Ryan, Martin',
    id: 'ryanm',
  },
  {
    text: 'Rye, Alen',
    id: 'ryea',
  },
  {
    text: 'Ryff, Anneke',
    id: 'ryffa',
  },
  {
    text: 'Salumbides, Gina',
    id: 'salumbmv',
  },
  {
    text: 'Sannoh, Annette',
    id: 'sannoha',
  },
  {
    text: 'Santoso, Albert',
    id: 'santosal',
  },
  {
    text: 'Saunders, Paul (Markets)',
    id: 'saundep1',
  },
  {
    text: 'Senkevics, Gary',
    id: 'senkevg1',
  },
  {
    text: 'Sheils, Gary',
    id: 'sheilsg',
  },
  {
    text: 'Shen, Eileen',
    id: 'shene',
  },
  {
    text: 'Shen, Lei',
    id: 'shenl2',
  },
  {
    text: 'Shimazaki, Masaru',
    id: 'shimazam',
  },
  {
    text: 'Shinoda, Hiroki',
    id: 'shinodah',
  },
  {
    text: 'Siebel, Stephanie',
    id: 'siebels',
  },
  {
    text: 'Siek, Thomas',
    id: 'siekt',
  },
  {
    text: 'Siew, Fabian',
    id: 'siewf',
  },
  {
    text: 'Simioni, Richard',
    id: 'simionir',
  },
  {
    text: 'Simon, Benjamin',
    id: 'simonb1',
  },
  {
    text: 'Simpson, Michael',
    id: 'simpsom1',
  },
  {
    text: 'Sin, Norman',
    id: 'sinn',
  },
  {
    text: 'Sinton, Alex',
    id: 'sintona',
  },
  {
    text: 'Siu, Mandy (Shanghai)',
    id: 'sium3',
  },
  {
    text: 'Skinner, George',
    id: 'skinnerg',
  },
  {
    text: 'Smith, Grant (Wgtn)',
    id: 'smithg6',
  },
  {
    text: 'Smith, Jeremy',
    id: 'smithj48',
  },
  {
    text: 'Snowden, Paul',
    id: 'snowdenp',
  },
  {
    text: 'Socratous, Nicholas',
    id: 'socraton',
  },
  {
    text: 'Sodhani, Ankur',
    id: 'sodhania',
  },
  {
    text: 'Solanki, Chetan',
    id: 'solankc',
  },
  {
    text: 'Song, Jae Ho',
    id: 'songj1',
  },
  {
    text: 'Sopp, Oliver',
    id: 'soppo1',
  },
  {
    text: 'Sorensen, Glen',
    id: 'sorenseg',
  },
  {
    text: 'Sorenson, Mark',
    id: 'sorensm1',
  },
  {
    text: 'Soun, Leakkhena',
    id: 'sounl',
  },
  {
    text: 'Spicer, Dean',
    id: 'spicerd',
  },
  {
    text: 'Spicer, Matt',
    id: 'spicerm',
  },
  {
    text: 'Stokie, Matthew',
    id: 'stokiem',
  },
  {
    text: 'Sugano, Ikumi',
    id: 'suganoi',
  },
  {
    text: 'Suseno, Evelyn',
    id: 'susenoe',
  },
  {
    text: 'Sutedja, Elsa',
    id: 'sutedjae',
  },
  {
    text: 'Ta, Thanh Hoa',
    id: 'tah1',
  },
  {
    text: 'Taing, Sothira',
    id: 'taings',
  },
  {
    text: 'Tait, Greg',
    id: 'taitg',
  },
  {
    text: 'Talbot, John',
    id: 'talbotj',
  },
  {
    text: 'Tang, Tom',
    id: 'tangt2',
  },
  {
    text: 'Tanna, Sawan',
    id: 'tannas',
  },
  {
    text: 'Tarrant-Cowan, Rachel',
    id: 'tarranr1',
  },
  {
    text: 'Taviri, Veuga',
    id: 'taviriv',
  },
  {
    text: 'Taylor, Angus',
    id: 'taylora9',
  },
  {
    text: 'Teo, Maverick',
    id: 'teom',
  },
  {
    text: 'Tezel, Murat',
    id: 'tezelm',
  },
  {
    text: 'Thang, Chang King',
    id: 'thangc',
  },
  {
    text: 'Tidswell, Robert',
    id: 'tidswer1',
  },
  {
    text: 'Tigani, Carlo',
    id: 'tiganic',
  },
  {
    text: 'Tiwari, Prince',
    id: 'tiwarip3',
  },
  {
    text: 'Tiwari, Vaibhav',
    id: 'tiwariv2',
  },
  {
    text: 'To, Andrew',
    id: 'toa1',
  },
  {
    text: 'Tomlinson, Lee',
    id: 'tomlinsl',
  },
  {
    text: 'Tong, Phuong',
    id: 'tongp',
  },
  {
    text: 'Tran, Bich Ngoc',
    id: 'trann1',
  },
  {
    text: 'Truong, Thi Phuong Thao',
    id: 'truongt7',
  },
  {
    text: 'Tsukakoshi, Jamie',
    id: 'tsukakoj',
  },
  {
    text: 'Tupouniua, Elizabeth',
    id: 'tupounie',
  },
  {
    text: 'Turley, Hamish',
    id: 'turleyh',
  },
  {
    text: 'Turner, Darren (London)',
    id: 'turnerd',
  },
  {
    text: 'Turner, Luke',
    id: 'turnerl1',
  },
  {
    text: 'Tyler, Ben',
    id: 'tylerb',
  },
  {
    text: 'Underwood, Damian',
    id: 'underwod',
  },
  {
    text: 'Vantarakis, Paul',
    id: 'vantarap',
  },
  {
    text: 'Vouziotis, Jim',
    id: 'vouzioj',
  },
  {
    text: 'Vo, Hoang Ngoc Van',
    id: 'vov',
  },
  {
    text: 'Vu, Ngoc Diep',
    id: 'vud2',
  },
  {
    text: 'Walker, David',
    id: 'walkerd3',
  },
  {
    text: 'Wang, Jen',
    id: 'wangj17',
  },
  {
    text: 'Wan, Nicky',
    id: 'wann',
  },
  {
    text: 'Weaver, Andrew (MO)',
    id: 'weavera1',
  },
  {
    text: 'Webb, Craig (POR)',
    id: 'webbc6',
  },
  {
    text: 'Wee, Renee',
    id: 'weer',
  },
  {
    text: 'Whittaker, Derek',
    id: 'whittakd',
  },
  {
    text: 'Wilson, Elyssa',
    id: 'wilsone1',
  },
  {
    text: 'Wilson, Greg',
    id: 'wilsong2',
  },
  {
    text: 'Wilson, James (London)',
    id: 'wilsonj6',
  },
  {
    text: 'Wilson, Matt (Markets)',
    id: 'wilsonm3',
  },
  {
    text: 'Wilson, Michael',
    id: 'wilsonm5',
  },
  {
    text: 'Winata, Andri',
    id: 'winataa',
  },
  {
    text: 'Wise, Karl',
    id: 'wisek2',
  },
  {
    text: 'Wisely, Patrick Hendro',
    id: 'wiselypa',
  },
  {
    text: 'Wo, Ming (Singapore)',
    id: 'wom2',
  },
  {
    text: 'Wong, Brenda',
    id: 'wongb',
  },
  {
    text: 'Wong, Carina',
    id: 'wongc6',
  },
  {
    text: 'Wong, Winston',
    id: 'wongch',
  },
  {
    text: 'Wong, Jocelyn',
    id: 'wongj40',
  },
  {
    text: 'Woods, Kristy',
    id: 'woodsk1',
  },
  {
    text: 'Wood, Timothy',
    id: 'woodt6',
  },
  {
    text: 'Woodward, Paul',
    id: 'woodwarp',
  },
  {
    text: 'Woo, Sara',
    id: 'woos1',
  },
  {
    text: 'Wu, Theresa',
    id: 'wut2',
  },
  {
    text: 'Xu, Carrie',
    id: 'xuc4',
  },
  {
    text: 'Yamanaka, Keiichiro',
    id: 'yamanakk',
  },
  {
    text: 'Yang, Ferdinand',
    id: 'yangf4',
  },
  {
    text: 'Yang, Mark (Shanghai)',
    id: 'yangm2',
  },
  {
    text: 'Yan, H K',
    id: 'yanh2',
  },
  {
    text: 'Yap, Jocelyn',
    id: 'yapj3',
  },
  {
    text: 'Yap, Kwok Leong',
    id: 'yapk5',
  },
  {
    text: 'Yeoh, Herr-Ling',
    id: 'yeohh',
  },
  {
    text: 'Yiu, Andy (FX)',
    id: 'yiua',
  },
  {
    text: 'Young, Patrick',
    id: 'youngp',
  },
  {
    text: 'Zeine, Claude',
    id: 'zeinec',
  },
  {
    text: 'Zhou, Jonathan',
    id: 'zhouj1',
  },
  {
    text: 'Zhu, Ellen',
    id: 'zhue6',
  },
  {
    text: 'K, Juhi',
    id: 'juhi1',
  },
  {
    text: 'Devarajan, Sendil',
    id: 'dsendil',
  },
  {
    text: 'Sankpal, Prasad',
    id: 'sankpalp',
  },
  {
    text: 'Sim, Andrew (Singapore)',
    id: 'sima3',
  },
  {
    text: 'Arora, Sakshi',
    id: 'aroras',
  },
  {
    text: 'Sikka, Deepak',
    id: 'sikkadp',
  },
  {
    text: 'Yang, Helen',
    id: 'yangh1',
  },
  {
    text: 'Higgins, Keith',
    id: 'higginsk',
  },
  {
    text: 'Britto, John',
    id: 'brittoj',
  },
  {
    text: 'Tan, Matthew',
    id: 'tanm12',
  },
  {
    text: 'Srivastava, Anirban',
    id: 'srivasta',
  },
  {
    text: 'Cheung, Maggie',
    id: 'cheungm5',
  },
  {
    text: 'Zhou, Silynda',
    id: 'zhous3',
  },
  {
    text: 'Gianniris, Nikolaos',
    id: 'giannirn',
  },
  {
    text: 'Vautrin, Alexandre',
    id: 'vautrina',
  },
  {
    text: 'Lo, Rammy',
    id: 'lor',
  },
  {
    text: 'Chugh, Rohit',
    id: 'chughroh',
  },
  {
    text: 'Radomski, Mikael',
    id: 'radomskm',
  },
  {
    text: 'Gao, Adele',
    id: 'gaow',
  },
  {
    text: 'Wang, David',
    id: 'wangd2',
  },
  {
    text: 'Hu, Yi',
    id: 'huy',
  },
  {
    text: 'Sasson, David',
    id: 'sassond',
  },
  {
    text: 'Samuel, Sunil',
    id: 'samuelsu',
  },
  {
    text: 'G, Vivek',
    id: 'gvivek',
  },
  {
    text: 'S, Sree Krishna',
    id: 'ssreek',
  },
  {
    text: 'Connolly, Richard',
    id: 'connolr2',
  },
  {
    text: 'Scott, Murray',
    id: 'murrays8',
  },
  {
    text: 'Dammermann, Nikolaus',
    id: 'dammermn',
  },
  {
    text: 'Cresswell, Cameron',
    id: 'cressc',
  },
  {
    text: 'Squadrito, Cameron',
    id: 'squadric',
  },
  {
    text: 'Daniel, Simons',
    id: 'simonsd',
  },
  {
    text: 'Stanley, Jeremy',
    id: 'stanlej1',
  },
  {
    text: 'Pokuri, Ramakrishna',
    id: 'pokuriv1',
  },
  {
    text: 'Singh, Mukesh',
    id: 'singh11',
  },
  {
    text: 'Naomi, Nithya',
    id: 'naomini',
  },
  {
    text: 'Rathaur, Manish Singh',
    id: 'rathaum',
  },
  {
    text: 'Bapat, Rahul',
    id: 'bapatr',
  },
  {
    text: 'Wilkie, Luke',
    id: 'wilkiel',
  },
  {
    text: 'Buckle, John',
    id: 'bucklej',
  },
  {
    text: 'Margareth, Lidyana',
    id: 'lidyanma',
  },
  {
    text: 'Seah, Simon',
    id: 'seahs2',
  },
  {
    text: 'Prakash, Saranya',
    id: 'prakashs',
  },
  {
    text: 'Karri, Surya(Melb)',
    id: 'suryak1',
  },
  {
    text: 'McGrath, Casey',
    id: 'mcgrathc',
  },
  {
    text: 'Agrawal, Shail',
    id: 'agrawal7',
  },
  {
    text: 'Dahan, Assaf',
    id: 'dahana',
  },
  {
    text: 'Levy, Hila',
    id: 'levyh',
  },
  {
    text: 'Mor, Alex1',
    id: 'mora',
  },
  {
    text: 'Raiter, Omri<script>alert(1)</script>',
    id: 'raitero',
  },
  {
    text: 'Agostinho, Edson',
    id: 'agostine',
  },
  {
    text: 'Deller, Ryan',
    id: 'dellerr',
  },
  {
    text: 'Goh, Alex',
    id: 'goha1',
  },
  {
    text: 'Berry, Jan',
    id: 'berryj',
  },
  {
    text: 'Neti, Nageswara',
    id: 'neting1',
  },
  {
    text: 'Naik, Mohan',
    id: 'naikmoha',
  },
  {
    text: 'Makarov, Alexander',
    id: 'makarova',
  },
  {
    text: 'Ruggiero, Quintin',
    id: 'ruggieq',
  },
  {
    text: 'Atkinson, Tom',
    id: 'atkinsot',
  },
  {
    text: 'Chiew, Anson Ann Sheng',
    id: 'chiewa1',
  },
  {
    text: 'Shipton, Craig',
    id: 'shiptonc',
  },
  {
    text: 'Song, Shawn',
    id: 'songs4',
  },
  {
    text: 'Mittal, Shilpi',
    id: 'mittals5',
  },
  {
    text: 'Wong, Liang Hung',
    id: 'wongl14',
  },
  {
    text: 'Shikhare, Suhas',
    id: 'shikhars',
  },
  {
    text: 'Kothiyal, Rathin',
    id: 'kothiyar',
  },
  {
    text: 'Neal, Marah',
    id: 'nealm1',
  },
  {
    text: 'Elboury, Ghada',
    id: 'ghadab',
  },
  {
    text: 'Ong, Adam',
    id: 'onga1',
  },
  {
    text: 'Thompson, Peter',
    id: 'thompsp3',
  },
  {
    text: 'Chin, Seung',
    id: 'chins6',
  },
  {
    text: 'B L, Shilpa',
    id: 'bhutegos',
  },
  {
    text: 'Wylie, Paul',
    id: 'wyliep',
  },
  {
    text: 'Kay, Stephen',
    id: 'kays2',
  },
  {
    text: 'Pan, Anna',
    id: 'pana1',
  },
  {
    text: 'Williamson, Guthrie',
    id: 'williag9',
  },
  {
    text: 'Roux, Remi',
    id: 'rouxa',
  },
  {
    text: 'Boonkhetpitak, Pimonporn',
    id: 'boonkhep',
  },
  {
    text: 'Leung, Anthony',
    id: 'leunga11',
  },
  {
    text: 'Lena, Panagiou',
    id: 'panagioe',
  },
  {
    text: 'Tan, Keit',
    id: 'tank19',
  },
  {
    text: 'Bortolozzi, Laura',
    id: 'bortolol',
  },
  {
    text: 'Kleitman, David',
    id: 'kleitmad',
  },
  {
    text: 'Woodhead, Justin',
    id: 'woodheaj',
  },
  {
    text: 'Gupta, Vinay',
    id: 'guptav8',
  },
  {
    text: 'Patodia, Gaurabh',
    id: 'patodiag',
  },
  {
    text: 'Chhikara, Naveen Kumar',
    id: 'chhikarn',
  },
  {
    text: 'Joshi, Santosh Kumar',
    id: 'joshis9',
  },
  {
    text: 'Yeo, Javier',
    id: 'yeoj2',
  },
  {
    text: 'Makarov, Alexey',
    id: 'makaroa',
  },
  {
    text: 'C, Lalithkumar',
    id: 'clalith',
  },
  {
    text: 'Dobrinski, Martin',
    id: 'dobrinsmadmin',
  },
  {
    text: 'Rasool, Zia',
    id: 'rasoolzadmin',
  },
  {
    text: 'White, David(65956)',
    id: 'whited4',
  },
  {
    text: 'Lai, Adeline Foong Ye',
    id: 'laia10',
  },
  {
    text: 'Kotian, Prashant',
    id: 'kotianp1',
  },
  {
    text: 'Ooi, Tay Zen',
    id: 'ooit',
  },
  {
    text: 'Watson, Simon',
    id: 'watsons3',
  },
  {
    text: 'Lee, Samuel',
    id: 'lees38',
  },
  {
    text: 'Andrew, Dickinson-Smith',
    id: 'dickina2',
  },
  {
    text: 'Oey, Hasna',
    id: 'hasnahas',
  },
  {
    text: 'Van Kampen, Annalies',
    id: 'vankampa',
  },
  {
    text: 'Yan, Victor',
    id: 'yanv1',
  },
  {
    text: 'Magbanua, Ma. Donna Grace',
    id: 'magbanum',
  },
  {
    text: 'Vaz, Elite',
    id: 'vaze1',
  },
  {
    text: 'Xiao, Lily',
    id: 'xiaol',
  },
  {
    text: 'Luo, Hayden',
    id: 'luohadmin',
  },
  {
    text: 'N K, SRIKANTH',
    id: 'nks1',
  },
  {
    text: 'Dujari, Pratishtha',
    id: 'dujaripadmin',
  },
  {
    text: 'Wang, Hongliang',
    id: 'wangh11',
  },
  {
    text: 'Bo, Tao',
    id: 'botadmin',
  },
  {
    text: 'Boyd, Darran (Admin)',
    id: 'boyddadmin',
  },
  {
    text: 'Ghosh, Kunal',
    id: 'ghoshk',
  },
  {
    text: 'Kher, Onkar',
    id: 'khero',
  },
  {
    text: 'Pienaar, Phillip',
    id: 'pienaarp',
  },
  {
    text: 'Kievondy, Tan',
    id: 'tank26',
  },
  {
    text: 'Dhillon, Nicky',
    id: 'dhillonn',
  },
  {
    text: 'Bhatia, Kanuneet',
    id: 'bhatiaka',
  },
  {
    text: 'Kentwell, Glenn',
    id: 'kentwelgadmin',
  },
  {
    text: 'Khare, Vipul',
    id: 'kharev1',
  },
  {
    text: 'Khan, Imran',
    id: 'khani1',
  },
  {
    text: 'Sharma, Raunak',
    id: 'sharmr32admin',
  },
  {
    text: 'Ramesh, Chethan',
    id: 'rameshc',
  },
  {
    text: 'Barulkar, Anup',
    id: 'barulkaa',
  },
  {
    text: 'Smith, Ayden(MRA)',
    id: 'smitha34',
  },
  {
    text: 'Parr-Whalley, Alvin',
    id: 'parrwhaa',
  },
  {
    text: 'Rajagopalan, Sriram',
    id: 'rajagos1',
  },
  {
    text: 'Bhatter, Nidhi',
    id: 'bhattern',
  },
  {
    text: 'Modi, Sourav',
    id: 'modis3',
  },
  {
    text: 'Vine, Cameron',
    id: 'vinec',
  },
  {
    text: 'Mummidi Ethirajulu, Sri Yogesh',
    id: 'yogeshm1',
  },
  {
    text: 'Druzhinin, Vladimir',
    id: 'druzhinv',
  },
  {
    text: 'Mei, Wenhong',
    id: 'meiw1',
  },
  {
    text: 'Kotha Balasainath, Deepak',
    id: 'kothad1',
  },
  {
    text: 'Cale, Larissa',
    id: 'calel',
  },
  {
    text: 'Yang, Yang',
    id: 'yangl4',
  },
  {
    text: 'Bao, Louie',
    id: 'baol1',
  },
  {
    text: 'To, Thuan',
    id: 'tot3',
  },
  {
    text: 'Gledhill, Dan',
    id: 'gledhid2',
  },
  {
    text: 'Veera Raj Shekar, Deepthi',
    id: 'veerarad',
  },
  {
    text: 'Shriwastav, Abhishek',
    id: 'shriwasa',
  },
  {
    text: 'Gazawada, Santhosh',
    id: 'gazawads',
  },
  {
    text: 'Tang, Karla',
    id: 'tangy2',
  },
  {
    text: 'Saxena, Shruti',
    id: 'saxenas7',
  },
  {
    text: 'Shrivastava, Palak',
    id: 'shrivap1',
  },
  {
    text: 'Uppal, Rahul',
    id: 'uppalr',
  },
  {
    text: 'Sharma, Divya',
    id: 'sharmd13',
  },
  {
    text: 'Singh, Sanjoy',
    id: 'singh36',
  },
  {
    text: 'Ramachandran, Gopi Krishna',
    id: 'ramachag',
  },
  {
    text: 'Palakuru, Giri',
    id: 'babug2',
  },
  {
    text: 'Stathi, Triadis',
    id: 'triadiss',
  },
  {
    text: 'Zhang, Wenhai',
    id: 'zhangw8',
  },
  {
    text: 'Simonsen, Michael',
    id: 'simonsem',
  },
  {
    text: 'Cui, Pei Chun',
    id: 'cuip',
  },
  {
    text: 'Zhou, Bo',
    id: 'zhoub',
  },
  {
    text: 'Yuan, Liang',
    id: 'yuanl7',
  },
  {
    text: 'Jayaraman, Ravindhiran',
    id: 'jayaramr',
  },
  {
    text: 'Liu, Zhihang',
    id: 'liuz3',
  },
  {
    text: 'Jin, Scott',
    id: 'jinx',
  },
  {
    text: 'Sainani, Rajiv',
    id: 'sainanr2',
  },
  {
    text: 'Xiao, Ryan',
    id: 'xiaor2admin',
  },
  {
    text: 'Rathin, Kothiyal',
    id: 'kothiyaradmin',
  },
  {
    text: 'Ryan, Xiao',
    id: 'xiaor2',
  },
  {
    text: 'Tock, Shiau',
    id: 'tocks',
  },
  {
    text: 'Li, Wei',
    id: 'liw11',
  },
  {
    text: 'Whiteside, Benjamin',
    id: 'whitesib',
  },
  {
    text: 'Chen, Jie',
    id: 'chenji3',
  },
  {
    text: 'Tainsh, Michael',
    id: 'tainshm',
  },
  {
    text: 'Chen Lin',
    id: 'chenli2',
  },
  {
    text: 'Rangan, Divya',
    id: 'kasturid',
  },
  {
    text: 'Li, Ivy',
    id: 'liy26',
  },
  {
    text: 'Chen, Paul',
    id: 'chenp14',
  },
  {
    text: 'Jereff Ye',
    id: 'yej2',
  },
  {
    text: 'Chigrinov, Sergey',
    id: 'chigrins',
  },
  {
    text: 'Lau, Karen',
    id: 'lauk12',
  },
  {
    text: 'Lazenby, David',
    id: 'lazenbyd',
  },
  {
    text: 'Wong, Yew Jin (Admin)',
    id: 'wongy18admin',
  },
  {
    text: 'Cappelli, Joel',
    id: 'cappelj1',
  },
  {
    text: 'Hoosen, Philip',
    id: 'hoosenp',
  },
  {
    text: 'Varadarajan, Srinivasa Krishnan(Srini)',
    id: 'varadas1',
  },
  {
    text: 'Tang, Nick',
    id: 'tangl1',
  },
  {
    text: 'Kasik, Peter',
    id: 'kasikp',
  },
  {
    text: 'Wright, Magnus',
    id: 'wrightm7',
  },
  {
    text: 'More, Vikram',
    id: 'morev2',
  },
  {
    text: 'Akimochkin, Stefan',
    id: 'akimochs',
  },
  {
    text: 'Janahiram, Sajinthan',
    id: 'janahirs',
  },
  {
    text: 'Lourens, Karina',
    id: 'lourensk',
  },
  {
    text: 'Cai, Kevin',
    id: 'caik2',
  },
  {
    text: 'Prihatnasari, Deassy Aprillia',
    id: 'bouzidn1',
  },
  {
    text: 'Rocas, Maureen',
    id: 'rocasm',
  },
  {
    text: 'Jain, Anmol (Admin)',
    id: 'jaina2admin',
  },
  {
    text: 'Hewitson, Kerry',
    id: 'hewitsok',
  },
  {
    text: 'Li, Jitai',
    id: 'lij38',
  },
  {
    text: 'Yeung, Alan',
    id: 'yeungc4',
  },
  {
    text: 'Singla, Janesh',
    id: 'singlaj',
  },
  {
    text: 'Hayter, Somerled',
    id: 'hayters',
  },
  {
    text: 'Buschini, Charles',
    id: 'buschinc',
  },
  {
    text: 'Thomas, Jacob',
    id: 'thomaj29',
  },
  {
    text: 'Sekar, Midhun',
    id: 'sekarm',
  },
  {
    text: 'Zhao, Zoe',
    id: 'zhaoh2',
  },
  {
    text: 'Neal, Tamarah',
    id: 'nealt',
  },
  {
    text: 'Thiyagarajan, Elamaran',
    id: 'thiyagae',
  },
  {
    text: 'Prihatnasari, Deassy Aprillia',
    id: 'prihadea',
  },
  {
    text: 'Fuchs, Fabian',
    id: 'fuchsf',
  },
  {
    text: 'Teo, David Yong-Wei',
    id: 'teod',
  },
  {
    text: 'Phung, Minh Ngoc',
    id: 'phungn1',
  },
  {
    text: 'Endozo, Michael',
    id: 'endozm',
  },
  {
    text: 'Cambridge, James',
    id: 'cambridj',
  },
];

export const userListById = keyBy(userList, 'id');

export default () => userList;

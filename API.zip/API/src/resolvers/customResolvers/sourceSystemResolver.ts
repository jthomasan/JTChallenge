const sourceSystems = [
  {
    id: 'Murex',
    text: 'Murex',
  },
  {
    id: 'QRM',
    text: 'QRM',
  },
  {
    id: 'SKY',
    text: 'SKY',
  },
  {
    id: 'ARM',
    text: 'ARM',
  },
];

export default () => sourceSystems;

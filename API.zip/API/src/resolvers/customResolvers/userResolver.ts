import { ApolloError } from 'apollo-server-express';

import { decode } from 'jsonwebtoken';
import { getAuthorityFromScope } from '../../authorizationConfig';

export default (source: any, args: any, context: any) => {
  const { token } = context;

  if (token) {
    const decodedToken = decode(token);
    if (!decodedToken['scopes'] || decodedToken['scopes'].length === 0) {
      throw new ApolloError('scopes are missing');
    }

    return {
      authority: getAuthorityFromScope(decodedToken['scopes']),
    };
  }

  throw new ApolloError('user is not authenticated');
};

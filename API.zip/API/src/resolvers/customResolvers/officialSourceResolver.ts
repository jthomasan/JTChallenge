import sourceSystems from './sourceSystemResolver';

export interface Args {
  sources: string[];
}

export default (_: any, { sources }: Args) => {
  return sourceSystems().filter((o) => sources.includes(o.id));
};

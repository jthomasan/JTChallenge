const returnIdentifiers = [
  {
    id: '3075',
    value: 'Market Risk Return 1 - Advanced',
  },
  {
    id: '3076',
    value: 'Market Risk Return 2 - Internal Model - Advanced',
  },
  {
    id: '3077',
    value: 'Market Risk Return 3 - Stress Testing - Advanced',
  },
];

export default () => returnIdentifiers;

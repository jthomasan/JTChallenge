import { range } from 'lodash';
import * as moment from 'moment';

export default () =>
  range(0, 12).map((num) => {
    const month = moment()
      .month(num)
      .format('MMMM');

    return {
      id: (num + 1).toString(),
      text: month,
    };
  });

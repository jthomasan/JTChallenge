interface PerpetualFlagStatus {
  id: String;
  text: String;
}

const perpetualFlagStatuses = [
  {
    id: 'Y',
    text: 'Y',
  },
  {
    id: 'N',
    text: 'N',
  },
  {
    id: '',
    text: '',
  },
];

export default () => perpetualFlagStatuses;

export const reportTypeList = [
  {
    id: 'SpecificRiskIR',
    text: 'SpecificRiskIR',
  },
  {
    id: 'APRACDS',
    text: 'APRACDS',
  },
  {
    id: 'HPR',
    text: 'HPR',
  },
  {
    id: 'APRACreditStress',
    text: 'APRACreditStress',
  },
];

export default () => reportTypeList;

export default () => [
  { id: '1', text: 'MX3.1' },
  { id: '2', text: 'Active Pivot' },
  { id: '3', text: 'Calculated Measure From RDW Data' },
  { id: '4', text: 'UI' },
  { id: '5', text: 'MX2.11' },
  { id: '6', text: 'Finance' },
  { id: '7', text: 'Electricity' },
  { id: '8', text: 'QRM' },
  { id: '9', text: 'Depreciated' },
  { id: '10', text: 'SKY' },
  { id: '11', text: 'ARM' },
];

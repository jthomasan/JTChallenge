import { GraphQLScalarType } from 'graphql';

const Any = new GraphQLScalarType({
  name: 'Any',
  description: 'A type represent any',
  serialize: (value) => value,
  parseValue: (value) => value,
});

export default {
  Any,
};

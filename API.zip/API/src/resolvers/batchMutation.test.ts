import { ApolloError } from 'apollo-server-express';
import batchMutation from './batchMutation';
import batchActions from './batchActions';
import transactionalAction from './batchActions/transactionalActions';
import * as normaliseFileData from '../utils/normaliseFileData';
import genericAction from './batchActions/genericAction';

jest.mock('./batchActions', () => ({
  default: {
    mockAction: jest.fn(),
    mockActionAlsoInConfig: jest.fn(),
    mockActionWithError: jest.fn().mockImplementation(() => {
      throw new ApolloError('some error', 'some code');
    }),
  },
}));

jest.mock('./batchActions/transactionalActions', () => ({
  default: jest.fn(),
}));

jest.mock('../utils/normaliseFileData', () => ({
  getNormalisedFileData: jest.fn().mockReturnValue({
    mockActionInConfig: {
      uri: '/test/{args.test}/api',
      method: 'put',
      body: {
        a: '{args.a}',
        b: '{args.b}',
        c: '{args.c}',
      },
    },
    mockActionAlsoInConfig: {
      uri: '/test/{args.test}/api',
      method: 'put',
      body: {
        a: '{args.a}',
        b: '{args.b}',
        c: '{args.c}',
      },
    },
    actionToIgnore: {
      ignore: true,
      uri: '/test/{args.test}/api',
      method: 'put',
      body: {},
    },
    MockTransactionalAction: {
      ignore: false,
      uri: '/transactionalUpdate',
      method: 'post',
      body: {
        c: 'c',
        d: 'd',
        e: 'e',
      },
    },
    MockAnotherTransactionalAction: {
      ignore: false,
      uri: '/anotherTransactionalUpdate',
      method: 'post',
      body: {
        c: 'c',
        d: 'd',
        e: 'e',
      },
    },
    StaticDataPortfolioScope: {
      ignore: false,
      uri: '/reference-data/portfolios/batchUpdate',
      method: 'post',
      headers: {
        'Custom-Header': 'Header',
      },
      body: {
        op: '{args.op}',
        path: '/',
        value: {
          id: '{args.id}',
          capitalHierarchy: {
            id: '{args.capitalHierarchy.id}',
          },
          isEaR: '{args.isEaR}',
          assetTypeSystem: '{args.assetTypeSystemId}',
          bookTypeSystem: '{args.bookTypeSystemId}',
          otherField: {
            id: '{args.otherField}',
          },
        },
      },
    },
    IgnoreScope: {
      ignore: true,
      uri: '/reference-data/ignoreScope/batchUpdate',
      method: 'post',
      body: {},
    },
  }),
}));

jest.mock('./batchActions/genericAction', () => ({
  ...jest.requireActual('./batchActions/genericAction'),
  default: jest.fn(),
}));

const { mockAction, mockActionAlsoInConfig } = (batchActions as unknown) as {
  mockAction: jest.Mock;
  mockActionAlsoInConfig: jest.Mock;
};
const mockGenericAction = genericAction as jest.Mock;
const mockContext = { dataSources: { genericAPI: 'genericAPI' } };
const mockContextTransactional = { dataSources: { genericAPI: { write: jest.fn() } } };
const mockTransactionalAction = transactionalAction as jest.Mock;

describe('Batch Mutation resolver', () => {
  beforeEach(() => {
    mockAction.mockReset();
    mockActionAlsoInConfig.mockReset();
    mockGenericAction.mockReset();
    mockTransactionalAction.mockReset();
  });

  it('should add transactional actions to resolver and commit', async () => {
    const args = {
      actions: [
        { mockAction: { var1: 'var1', var2: 'var2' } },
        { addMockTransactionalAction: { id: 1, var: '1' } },
        { replaceMockAnotherTransactionalAction: { id: 2, var2: 2 } },
        { replaceMockTransactionalAction: { id: 1, var3: { id: 'a' } } },
        {
          replaceMockAnotherTransactionalAction: { id: 2, var4: { id: 1 } },
        },
      ],
    };

    const mockFirstAdd = jest.fn();
    const mockFirstCommit = jest.fn();
    const mockSecondAdd = jest.fn();
    const mockSecondCommit = jest.fn();

    mockTransactionalAction
      .mockReturnValueOnce({ add: mockFirstAdd, commit: mockFirstCommit })
      .mockReturnValueOnce({ add: mockSecondAdd, commit: mockSecondCommit });

    const {
      MockTransactionalAction,
      MockAnotherTransactionalAction,
    } = normaliseFileData.getNormalisedFileData('', '') as any;

    await batchMutation(null, args, mockContext, null);

    expect(mockAction).toHaveBeenCalledWith({ var1: 'var1', var2: 'var2' }, 'genericAPI');
    expect(mockTransactionalAction).toHaveBeenNthCalledWith(
      1,
      MockTransactionalAction,
      'genericAPI',
    );
    expect(mockTransactionalAction).toHaveBeenNthCalledWith(
      2,
      MockAnotherTransactionalAction,
      'genericAPI',
    );

    expect(mockFirstAdd).toHaveBeenNthCalledWith(
      1,
      { id: 1, var: '1' },
      'MockTransactionalAction',
      'add',
    );
    expect(mockFirstAdd).toHaveBeenNthCalledWith(
      2,
      { id: 1, var3: { id: 'a' } },
      'MockTransactionalAction',
      'replace',
    );
    expect(mockSecondAdd).toHaveBeenNthCalledWith(
      1,
      { id: 2, var2: 2 },
      'MockAnotherTransactionalAction',
      'replace',
    );
    expect(mockSecondAdd).toHaveBeenNthCalledWith(
      2,
      { id: 2, var4: { id: 1 } },
      'MockAnotherTransactionalAction',
      'replace',
    );

    expect(mockFirstCommit).toHaveBeenCalledTimes(1);
    expect(mockSecondCommit).toHaveBeenCalledTimes(1);
  });

  it('should throw an error if transactional action does not match config', async () => {
    const args = {
      actions: [{ replaceUnknownTransactionalAction: { id: 2, var2: 2 } }],
    };

    try {
      await batchMutation(null, args, mockContext, null);
    } catch (e) {
      expect(e.message).toEqual(
        `Unknown batch mutation action 'replaceUnknownTransactionalAction'`,
      );
    }
  });

  it('should throw error if transactional action commit throws error, with current action and successful actions in error', async () => {
    const args = {
      actions: [
        {
          mockAction: { var1: 'var1', var2: 'var2' },
        },
        {
          replaceMockAnotherTransactionalAction: { id: 2, var4: { id: 1 } },
        },
      ],
    };

    const mockAdd = jest.fn();
    const mockCommit = jest.fn().mockImplementation(() => {
      const e = new ApolloError('some error', 'some code');
      e.extensions.action = 'some action';
      throw e;
    });

    mockTransactionalAction.mockReturnValueOnce({ add: mockAdd, commit: mockCommit });

    try {
      await batchMutation(null, args, mockContext, null);
    } catch (e) {
      expect(e.extensions).toEqual(
        expect.objectContaining({
          code: 'some code',
          action: 'some action',
          successfulActions: ['mockAction'],
        }),
      );
    }
  });

  // skipping this as there are dependencies on how actions are implemented low level, making it brittle
  it.skip('should process mixed of actions and call write methods correctly', async () => {
    const args = {
      actions: [
        { replaceIgnoreScope: { id: 1, otherEntity: 1 } },
        { mockAction: { var1: 'var1', var2: 'var2' } },
        { replaceStaticDataPortfolioScope: { id: 1, isEaR: false } },
        { replaceStaticDataPortfolioScope: { id: 2, assetTypeSystemId: 1 } },
        { replaceStaticDataPortfolioScope: { id: 1, capitalHierarchy: { id: 2 } } },
        { replaceStaticDataPortfolioScope: { id: 1, bookTypeSystemId: 1 } },
        { replaceStaticDataPortfolioScope: { id: 1, bookTypeSystemId: 3 } },
        { replaceStaticDataPortfolioScope: { id: 2, capitalHierarchy: { id: 1 } } },
        { replaceStaticDataPortfolioScope: { id: 2, assetTypeSystemId: 3 } },
        { replaceStaticDataPortfolioScope: { id: 3, capitalHierarchy: { id: 1 } } },
        { replaceStaticDataPortfolioScope: { id: 1, capitalHierarchy: { id: 2 } } },
        { replaceStaticDataPortfolioScope: { id: 3, bookTypeSystemId: 1 } },
        { replaceStaticDataPortfolioScope: { id: 1, capitalHierarchy: { id: 1 } } },
      ],
    };
    const replaceStaticDataPortfolioRequest = [
      {
        op: 'replace',
        path: '/',
        value: {
          id: '1',
          isEaR: 'false',
          capitalHierarchy: { id: '1' },
          bookTypeSystem: '3',
        },
      },
      {
        op: 'replace',
        path: '/',
        value: {
          id: '2',
          assetTypeSystem: '3',
          capitalHierarchy: { id: '1' },
        },
      },
      {
        op: 'replace',
        path: '/',
        value: {
          id: '3',
          capitalHierarchy: { id: '1' },
          bookTypeSystem: '1',
        },
      },
    ];

    await batchMutation(null, args, mockContextTransactional, null);
    expect(mockAction).toHaveBeenCalledWith(
      { var1: 'var1', var2: 'var2' },
      mockContextTransactional.dataSources.genericAPI,
    );
    expect(mockContextTransactional.dataSources.genericAPI.write).toBeCalledWith(
      'post',
      '/reference-data/portfolios/batchUpdate',
      replaceStaticDataPortfolioRequest,
      {
        'Custom-Header': 'Header',
      },
    );
  });

  it('should process batch action with custom resolver if available', async () => {
    const args = {
      actions: [
        {
          mockAction: { var1: 'var1', var2: 'var2' },
        },
      ],
    };

    await batchMutation(null, args, mockContext, null);
    expect(mockAction).toHaveBeenCalledWith({ var1: 'var1', var2: 'var2' }, 'genericAPI');
  });

  it('should process batch action with generic action resolver if action is configured', async () => {
    const args = {
      actions: [
        {
          mockActionInConfig: { var1: 'var1', var2: 'var2' },
        },
      ],
    };

    const config = (normaliseFileData.getNormalisedFileData('', '') as any).mockActionInConfig;

    await batchMutation(null, args, mockContext, null);
    expect(mockGenericAction).toHaveBeenCalledWith(
      config,
      { var1: 'var1', var2: 'var2' },
      'genericAPI',
    );
  });

  it('should process batch action with both generic action resolver and custom resolver if defined', async () => {
    const args = {
      actions: [
        {
          mockActionAlsoInConfig: { var1: 'var1', var2: 'var2' },
        },
      ],
    };

    const config = (normaliseFileData.getNormalisedFileData('', '') as any).mockActionAlsoInConfig;
    mockGenericAction.mockReturnValueOnce('gen action result');

    await batchMutation(null, args, mockContext, null);

    expect(mockGenericAction).toHaveBeenCalledWith(
      config,
      { var1: 'var1', var2: 'var2' },
      'genericAPI',
    );

    expect(mockActionAlsoInConfig).toHaveBeenCalledWith(
      { var1: 'var1', var2: 'var2' },
      'genericAPI',
      'gen action result',
    );
  });

  it('should show ignore action if configured with ignore option', async () => {
    const args = {
      actions: [
        {
          actionToIgnore: { var1: 'var1', var2: 'var2' },
        },
      ],
    };

    await batchMutation(null, args, mockContext, null);
    expect(mockGenericAction).toHaveBeenCalledTimes(0);
  });

  it('should replace variable values if action returns replacement map', async () => {
    const args = {
      actions: [
        {
          mockAction: { var1: 'var1', var2: 'var2' },
        },
        {
          mockAction: { var1: 'var1', var2: 'var2' },
        },
        {
          mockAction: { mockObj: { var1: 'var1' }, var2: 'var2' },
        },
      ],
    };

    mockAction.mockReturnValueOnce(
      Promise.resolve({
        var1: { from: 'var1', to: 'newVar1' },
      }),
    );

    await batchMutation(null, args, mockContext, null);
    expect(mockAction).toHaveBeenCalledWith({ var1: 'var1', var2: 'var2' }, 'genericAPI');
    expect(mockAction).toHaveBeenCalledWith({ var1: 'newVar1', var2: 'var2' }, 'genericAPI');
    expect(mockAction).toHaveBeenCalledWith(
      { mockObj: { var1: 'newVar1' }, var2: 'var2' },
      'genericAPI',
    );
  });

  it('should return with success with array of performed actions', async () => {
    const args = {
      actions: [
        {
          mockAction: { var1: 'var1', var2: 'var2' },
        },
        { mockActionInConfig: { var1: 'var1', var2: 'var2' } },

        { actionToIgnore: { var1: 'var1', var2: 'var2' } },
        {
          mockAction: { var1: 'var1', var2: 'var2' },
        },
      ],
    };

    const response = await batchMutation(null, args, mockContext, null);
    expect(response).toEqual({
      success: true,
      actions: ['mockAction', 'mockActionInConfig', 'mockAction'],
    });
  });

  it('should throw error if no actions are defined', async () => {
    const args = {};

    try {
      await batchMutation(null, args, mockContext, null);
    } catch (e) {
      expect(e.message).toEqual('No actions defined for batch mutation');
    }
  });

  it('should throw error if action throws error, with current action and successful actions in error', async () => {
    const args = {
      actions: [
        {
          mockAction: { var1: 'var1', var2: 'var2' },
        },
        { mockActionInConfig: { var1: 'var1', var2: 'var2' } },

        { mockActionWithError: { var1: 'var1', var2: 'var2' } },
        {
          mockAction: { var1: 'var1', var2: 'var2' },
        },
      ],
    };

    try {
      await batchMutation(null, args, mockContext, null);
    } catch (e) {
      expect(e.extensions).toEqual(
        expect.objectContaining({
          action: { mockActionWithError: { var1: 'var1', var2: 'var2' } },
          successfulActions: ['mockAction', 'mockActionInConfig'],
        }),
      );
    }
  });

  it('should throw error if action object is empty', async () => {
    const args = {
      actions: [{}],
    };

    try {
      await batchMutation(null, args, mockContext, null);
    } catch (e) {
      expect(e.message).toEqual('Invalid batch action - name not found');
    }
  });

  it('should throw error if action is not defined anywhere', async () => {
    const args = {
      actions: [{ unknown: {} }],
    };

    try {
      await batchMutation(null, args, mockContext, null);
    } catch (e) {
      expect(e.message).toEqual(`Unknown batch mutation action 'unknown'`);
    }
  });
});

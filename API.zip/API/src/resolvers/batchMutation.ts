/* eslint-disable no-await-in-loop */
/* eslint-disable no-plusplus */
import { GraphQLResolveInfo } from 'graphql';
import * as path from 'path';
import { merge, cloneDeep, isPlainObject } from 'lodash';
import { ApolloError } from 'apollo-server-express';
import GenericAPIDataSource from '../dataSources/genericAPI';
import actionResolvers from './batchActions';
import genericAction, { GenericActionConfig } from './batchActions/genericAction';
import createTransactionalActionScope from './batchActions/transactionalActions';
import { getNormalisedFileData } from '../utils/normaliseFileData';
import preprocessors from './mutation/preprocessors';

type ActionResolver = (
  args: any,
  genericAPI: GenericAPIDataSource,
  results?: any,
) => Promise<ReplaceMap | null>;

type ReplaceValue = {
  from: string | number;
  to: string | number;
};

export type ReplaceMap = {
  [key: string]: Array<ReplaceValue>;
};

export type TransactionalScopeMap = {
  [key: string]: {
    add: (actionArgs: any, actionName: string, actionType: string) => void;
    commit: (args?: any) => Promise<string[]>;
  };
};

const batchActionConfigs = getNormalisedFileData(
  path.resolve(__dirname, '../../api-mappings/mutation-actions'),
  path.resolve(__dirname, '../../schemas/ActionToRestSchema.json'),
);

const getNameFromAction = (action: any) => {
  const keys = Object.keys(action);

  if (keys.length) {
    return keys[0];
  }

  throw new ApolloError('Invalid batch action - name not found');
};

const getTransactionalActionInfoByName = (actionName: string) => {
  const nameArray = actionName.split(/(?=[A-Z])/);
  if (nameArray.length < 2) {
    return null;
  }

  const [actionType, ...rest] = nameArray;
  const transactionalScope = rest.join('');
  const transactionalScopeConfig = batchActionConfigs[transactionalScope];

  if (transactionalScopeConfig) {
    return { actionType, transactionalScope, transactionalScopeConfig };
  }
  return null;
};

/**
 * Process the action by checking for custom resolvers. If not availble then check action config
 * If config is avaiable then will be used to call the generic action resolver
 *
 * return false if action is ignored in config
 */
const processAction = async (
  transactionalScopeMap: TransactionalScopeMap,
  source: any,
  context: any,
  info: GraphQLResolveInfo,
  action: any,
): Promise<ReplaceMap | boolean> => {
  const {
    dataSources: { genericAPI },
  } = context;

  let actionName = getNameFromAction(action);
  let args = action[actionName];

  if (preprocessors[actionName]) {
    [actionName, args] = preprocessors[actionName](actionName, args, context);
  }

  const customResolver: ActionResolver = actionResolvers[actionName];
  const actionConfig: GenericActionConfig = batchActionConfigs[actionName];

  if (actionConfig) {
    if (!actionConfig.ignore) {
      const genericResult = await genericAction(actionConfig, args, genericAPI);

      // can optionally run through custom resolver after generic action if defined with results passed in
      if (customResolver) {
        return customResolver(args, genericAPI, genericResult);
      }

      // assume that generic actions won't return a field replacement map
      return null;
    }

    return false;
  }

  if (customResolver) {
    return customResolver(args, genericAPI);
  }

  // Check if it is transactional action
  const transactionalActionInfo = getTransactionalActionInfoByName(actionName);

  if (transactionalActionInfo) {
    const { transactionalScope, transactionalScopeConfig, actionType } = transactionalActionInfo;
    if (!transactionalScopeMap.hasOwnProperty(transactionalScope)) {
      // eslint-disable-next-line no-param-reassign
      transactionalScopeMap[transactionalScope] = createTransactionalActionScope(
        transactionalScopeConfig,
        genericAPI,
      );
    }

    transactionalScopeMap[transactionalScope].add(args, transactionalScope, actionType);

    return false;
  }

  throw new ApolloError(`Unknown batch mutation action '${actionName}'`);
};

const addToReplacementMap = (newReplacements: ReplaceMap, existingReplacements: ReplaceMap) => {
  if (!newReplacements) {
    return existingReplacements;
  }
  const newMap = cloneDeep(existingReplacements);

  Object.keys(newReplacements).forEach((key) => {
    const newValues: ReplaceValue[] = newReplacements[key];
    const existingValues: ReplaceValue[] = existingReplacements[key] || [];
    newMap[key] = existingValues.concat(newValues);
  });

  return newMap;
};

const replaceActionArgumentsWithMap = (action: any, replacementMap: ReplaceMap) => {
  const newAction = cloneDeep(action);

  const actionName = getNameFromAction(action);
  const args = newAction[actionName];

  Object.keys(args).forEach((arg) => {
    const value = args[arg];

    if (isPlainObject(value)) {
      args[arg] = replaceActionArgumentsWithMap({ [arg]: value }, replacementMap)[arg];
    } else {
      const replacementValue = (replacementMap[arg] || []).find((v) => v.from === value);

      if (replacementValue) {
        args[arg] = replacementValue.to;
      }
    }
  });

  return newAction;
};

/*
 * Process each mutation action.
 * Allow action resolvers to return a ReplaceMap object with instructions to replace a field from one value to another for all following actions
 */
export default async (source: any, args: any, context: any, info: GraphQLResolveInfo) => {
  let replacementMap: ReplaceMap = {};
  const transactionalScopeMap: TransactionalScopeMap = {};
  const successfulActions = [];

  const handleException = (e, action = null) => {
    e.extensions = merge({}, e.extensions || {}, {
      action: action || e.extensions.action,
      successfulActions,
    });

    throw e;
  };

  if (!args.actions) {
    throw new ApolloError(`No actions defined for batch mutation`);
  }

  for (let i = 0; i < args.actions.length; i++) {
    const originalAction = args.actions[i];
    let action = null;

    try {
      action = replaceActionArgumentsWithMap(originalAction, replacementMap);

      const actionName = getNameFromAction(action);

      const newReplacements = await processAction(
        transactionalScopeMap,
        source,
        context,
        info,
        action,
      );
      if (newReplacements !== false) {
        replacementMap = addToReplacementMap(newReplacements as ReplaceMap, replacementMap);

        successfulActions.push(actionName);
      }
    } catch (e) {
      handleException(e, action || originalAction);
    }
  }

  if (transactionalScopeMap) {
    try {
      const transactionalScopeArray = Object.values(transactionalScopeMap);
      for (let i = 0; i < transactionalScopeArray.length; i++) {
        successfulActions.concat(await transactionalScopeArray[i].commit(args));
      }
    } catch (e) {
      handleException(e);
    }
  }

  return {
    success: true,
    actions: successfulActions,
  };
};

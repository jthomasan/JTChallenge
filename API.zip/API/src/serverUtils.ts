import { merge, isPlainObject } from 'lodash';
import { DecoratorConfig, generateGenericResolver } from './resolvers/resolverFactory';
import resolverPostProcessors from './resolvers/query/postprocessors';
import resolverPreProcessors from './resolvers/query/preprocessors';

interface ComplexFieldConfig {
  $extra: Record<string, any>;
  url: string;
  dataPath: string;
  additionalData: Record<any, any>;
  decorators: DecoratorConfig[];
}

type FieldConfig = any | ComplexFieldConfig;

interface RestToGQLConfig {
  [typeName: string]: {
    [fieldName: string]: any | FieldConfig;
  };
}

export const useRestToGQLConfig = (restToGqlConfig: RestToGQLConfig) => {
  const generatedResolvers = {};

  if (restToGqlConfig) {
    Object.entries(restToGqlConfig).forEach(([typeName, typeConfig]) => {
      const entityResolver = {};
      Object.entries(typeConfig).forEach(([fieldName, fieldConfig]) => {
        const preprocessor = resolverPreProcessors?.[typeName]?.[fieldName];
        const postprocessor = resolverPostProcessors?.[typeName]?.[fieldName];

        // complex field mapping
        if (fieldConfig && isPlainObject(fieldConfig)) {
          entityResolver[fieldName] = generateGenericResolver({
            ...(fieldConfig as ComplexFieldConfig),
            preprocessor,
            postprocessor,
          });
        }
        // direct field mapping
        else {
          entityResolver[fieldName] = generateGenericResolver({
            fieldConfig,
            preprocessor,
            postprocessor,
          });
        }
      });

      generatedResolvers[typeName] = entityResolver;
    });
  }

  return {
    generatedResolvers,
  };
};

export const createMergedResolvers = (generatedResolvers, customResolvers) => {
  return merge(generatedResolvers, customResolvers);
};

import { verify } from 'jsonwebtoken';
import * as jwksClient from 'jwks-rsa';
import { Response } from 'express';

import { InterceptedRequest } from '../middleware/logger';

const getPublicKey = (jwtHeader, callback) => {
  const client = jwksClient({
    jwksUri: process.env.JWKS_URI,
    strictSsl: process.env.STRICT_SSL === 'Enabled',
  });
  client.getSigningKey(jwtHeader.kid, (err, key) => {
    const signingKey = !err && key ? key.getPublicKey() : null;
    if (!err && !signingKey) {
      err = new Error('Could not retrieve JWT signing key');
    }
    callback(err, signingKey);
  });
};

const verifyToken = (token: string) => {
  return new Promise((resolve, reject) => {
    verify(token, getPublicKey, (err, decoded) => {
      if (err) {
        reject(err);
      }
      resolve(decoded);
    });
  });
};

const getToken = (authHeader) => authHeader.split(' ')[1];

const sendData = (data) => ({
  data,
  error: null,
});

const sendError = (msg) => ({
  data: {},
  error: { msg },
});

const loginHandler = async (req: InterceptedRequest, res: Response) => {
  try {
    req.logger.info('Login request received');
    if (!req.headers.authorization) {
      throw new Error('Missing authorization header');
    }
    const token = getToken(req.headers.authorization);
    const decodedToken: any = await verifyToken(token);
    req.logger.info('Auth token verified');
    res.cookie('auth_token', token, {
      httpOnly: true,
      expires: new Date(decodedToken.exp * 1000),
      sameSite: true,
    });
    res.status(200).json(sendData(decodedToken));
    req.logger.info(`Login successful [${decodedToken.sub}]`);
  } catch (error) {
    req.logger.error(error);
    res.status(401).json(sendError(error.message));
  }
};

export default loginHandler;

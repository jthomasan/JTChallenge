import { RequestHandler } from 'express';
import * as qs from 'qs';
import { SCOPE } from '../authorizationConfig/stiScopes';

const scopesToRequest = Object.values(SCOPE);

const oidcAuthorizeHandler: RequestHandler = (req, res) => {
  if (!process.env.AUTHORIZE_URI) {
    console.error('AUTHORIZE_URI must be configured');
    res.status(500);
    return;
  }

  const newQuery = { ...req.query };
  const newScopes = new Set([
    ...scopesToRequest,
    ...(newQuery.scope?.toString().split(/\s+/) ?? []),
  ]);

  newQuery.scope = [...newScopes.values()].join(' ');

  const queryString = qs.stringify(newQuery);
  res.redirect(`${process.env.AUTHORIZE_URI}?${queryString}`);
};

export default oidcAuthorizeHandler;

import { NextFunction, Request, Response } from 'express';
import * as querystring from 'querystring';

import oidcAuthorizeHandler from './oidc-authorize';
import { SCOPE } from '../authorizationConfig/stiScopes';

const getUrlQueryParams = (url: URL) => querystring.parse(url.search ? url.search.substr(1) : '');

const mockRequest = (scope?: string) => {
  const request: {
    query: Record<string, string>;
  } = {
    query: {
      client_id: '123-ABC',
      redirect_uri: 'http://merv.anz/auth',
      response_type: 'id_token token',
      state: '123',
      nonce: 'abc',
    },
  };

  if (scope) {
    request.query.scope = scope;
  }

  return request;
};

describe('/oidc/authorize', () => {
  beforeEach(() => {
    console.error = jest.fn();
    process.env.AUTHORIZE_URI = 'http://auth.service/oidc/authorize';
  });

  afterEach(() => {
    (console.error as jest.Mock).mockRestore();
  });

  it('injects all scopes, removing duplicates', () => {
    const req = mockRequest('openid test.additional');

    const res = {
      redirect: jest.fn(),
    };

    const next: NextFunction = jest.fn();

    oidcAuthorizeHandler((req as unknown) as Request, (res as unknown) as Response, next);

    expect(res.redirect).toHaveBeenCalled();
    const url = new URL(res.redirect.mock.calls[0][0]);
    const queryParams = getUrlQueryParams(url);
    expect(url.origin).toMatchInlineSnapshot(`"http://auth.service"`);
    expect(url.pathname).toMatchInlineSnapshot(`"/oidc/authorize"`);
    expect(queryParams).toMatchInlineSnapshot(`
      Object {
        "client_id": "123-ABC",
        "nonce": "abc",
        "redirect_uri": "http://merv.anz/auth",
        "response_type": "id_token token",
        "scope": "openid ALL.ANZ_INTERNAL.ALL.ALL.ALL ALL.ANZ_INTERNAL.UI.ALL.READ ALL.ANZ_INTERNAL.API.ALL.READ ALL.ANZ_INTERNAL.UI.REFERENCEDATA.UPDATE ALL.ANZ_INTERNAL.API.REFERENCEDATA.UPDATE ALL.ANZ_INTERNAL.API.HIERARCHY.UPDATE ALL.ANZ_INTERNAL.API.LIMITSREFERENCEDATA.UPDATE ALL.ANZ_INTERNAL.API.LIMITS.UPDATE ALL.ANZ_INTERNAL.UI.FEEDMONITOR.VIEW ALL.ANZ_INTERNAL.UI.FEEDMONITOR.UPDATE ALL.ANZ_INTERNAL.API.FEEDMONITOR.READ ALL.ANZ_INTERNAL.API.FEEDMONITOR.UPDATE test.additional",
        "state": "123",
      }
    `);

    // existing scopes are still passed through
    expect(queryParams.scope).toBe(`${Object.values(SCOPE).join(' ')} test.additional`);
  });

  it(`injects all scopes, doesn't fail on no existing scopes`, () => {
    const req = mockRequest();
    expect('scope' in req.query).toBeFalsy();

    const res = {
      redirect: jest.fn(),
    };

    const next: NextFunction = jest.fn();

    oidcAuthorizeHandler((req as unknown) as Request, (res as unknown) as Response, next);

    expect(res.redirect).toHaveBeenCalled();
    const url = new URL(res.redirect.mock.calls[0][0]);
    const queryParams = getUrlQueryParams(url);
    expect(url.origin).toMatchInlineSnapshot(`"http://auth.service"`);
    expect(url.pathname).toMatchInlineSnapshot(`"/oidc/authorize"`);
    expect(queryParams).toMatchInlineSnapshot(`
      Object {
        "client_id": "123-ABC",
        "nonce": "abc",
        "redirect_uri": "http://merv.anz/auth",
        "response_type": "id_token token",
        "scope": "openid ALL.ANZ_INTERNAL.ALL.ALL.ALL ALL.ANZ_INTERNAL.UI.ALL.READ ALL.ANZ_INTERNAL.API.ALL.READ ALL.ANZ_INTERNAL.UI.REFERENCEDATA.UPDATE ALL.ANZ_INTERNAL.API.REFERENCEDATA.UPDATE ALL.ANZ_INTERNAL.API.HIERARCHY.UPDATE ALL.ANZ_INTERNAL.API.LIMITSREFERENCEDATA.UPDATE ALL.ANZ_INTERNAL.API.LIMITS.UPDATE ALL.ANZ_INTERNAL.UI.FEEDMONITOR.VIEW ALL.ANZ_INTERNAL.UI.FEEDMONITOR.UPDATE ALL.ANZ_INTERNAL.API.FEEDMONITOR.READ ALL.ANZ_INTERNAL.API.FEEDMONITOR.UPDATE",
        "state": "123",
      }
    `);
    expect(queryParams.scope).toBe(Object.values(SCOPE).join(' '));
  });

  it(`throws 500 if AUTHORIZE_URI is not configured`, () => {
    const req = mockRequest();

    const res = {
      redirect: jest.fn(),
      status: jest.fn(),
    };

    const next: NextFunction = jest.fn();

    delete process.env.AUTHORIZE_URI;
    oidcAuthorizeHandler((req as unknown) as Request, (res as unknown) as Response, next);

    expect(console.error as jest.Mock).toHaveBeenCalled();
    expect(res.redirect).toHaveBeenCalledTimes(0);
    expect(res.status).toHaveBeenCalledWith(500);
  });
});

import { ApolloServer } from 'apollo-server-express';
import { GraphQLSchemaModule } from '@apollographql/apollo-tools';
import { schemas } from 'merv-web-common';
import { decode } from 'jsonwebtoken';
import customResolvers from './resolvers';
import dataSources, { DataSources } from './dataSources';
import { defaultResolver } from './resolvers/defaultResolver';

import { useRestToGQLConfig, createMergedResolvers } from './serverUtils';
import { normaliseContextForResolvers, ResolverContext } from './utils/resolverUtil';
import { apolloLoggerPlugin } from './utils/loggingUtil';
import { InterceptedRequest } from './middleware/logger';

export interface ApolloContext extends Pick<InterceptedRequest, 'headers' | 'reqId' | 'logger'> {
  dataSources: DataSources;
  resolverContext: Record<string, ResolverContext>;
  token?: string;
  tokenInfo?: ReturnType<typeof decode>;
}

const extractToken = (request: InterceptedRequest) =>
  request.cookies?.auth_token ?? request.headers['authorization']?.split(' ', 2)?.[1];

export const createServer = (config) => {
  const { generatedResolvers } = useRestToGQLConfig(config);
  const resolvers = createMergedResolvers(generatedResolvers, customResolvers);

  const modules: GraphQLSchemaModule[] = schemas.map((schema) => ({ typeDefs: schema, resolvers }));

  return new ApolloServer({
    modules,
    fieldResolver: defaultResolver,
    dataSources,
    context: (args): Partial<ApolloContext> => {
      const request = args.req as InterceptedRequest;
      const token = extractToken(request);

      return {
        reqId: request.reqId,
        logger: request.logger,
        token,
        headers: request.headers,
        resolverContext: normaliseContextForResolvers(args, resolvers),
        tokenInfo: decode(token),
      };
    },
    plugins: [apolloLoggerPlugin],
    introspection: true,
  });
};

import * as uuid from 'uuid-random';
import { Request, RequestHandler } from 'express';
import Logger from 'bunyan';

export interface InterceptedRequest extends Request {
  logger: Logger;
  reqId: string;
}

export default (logger: Logger): RequestHandler => (req, res, next) => {
  const reqId = req.headers['x-request-id'] || uuid();
  const childLogger = logger.child({ req_id: reqId });

  Object.assign(req, {
    logger: childLogger,
    reqId,
  });

  next();
};

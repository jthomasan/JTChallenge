import { get, isPlainObject, cloneDeep } from 'lodash';

export interface Property {
  copyFrom: string;
  copyTo: string;
  newFieldName?: string;
}

export interface Args {
  properties: Property[];
}

const copyDataToNewObj = (obj: object, routes: string[], data: any, field: string): object => {
  if (routes.length === 1) {
    const prop = routes[0];

    if (obj[prop] != null) {
      if (!isPlainObject(obj[prop])) {
        throw new Error(`${obj[prop]} not an object`);
      }

      obj[prop][field] = data;
    }

    return obj;
  }

  const [prop, ...childRoutes] = routes;

  if (!obj[prop]) {
    throw new Error(`Object doesnt contain ${prop}`);
  }

  return { [prop]: copyDataToNewObj(obj[prop], childRoutes, data, field) };
};

export default (data: any, params: Args) => {
  const newData = params.properties.reduce((acc, curr) => {
    const { copyFrom, copyTo, newFieldName } = curr;
    const routes = copyTo.split('.');
    const data = get(acc, copyFrom);
    const copyFromList = copyFrom.split('.');
    const field = newFieldName ?? copyFromList[copyFromList.length - 1];

    return {
      ...acc,
      ...copyDataToNewObj(acc, routes, data, field),
    };
  }, data);

  return newData;
};

export default (data: string) => {
  if (!data) {
    throw new Error(`Term doesn't exist`);
  }

  return parseInt(data);
};

import * as moment from 'moment';

export default (data: string) => {
  if (!data) {
    throw new Error(`Term doesn't exist`);
  }

  const str = data.match(/[a-z]+|\d+/gi);
  const totalUnit = str.reduce((acc, curr, index) => {
    if (index % 2 === 0) {
      let unitType: moment.DurationInputArg2 = 'd';
      if (str[index + 1] === 'y') {
        unitType = 'y';
      } else if (str[index + 1] === 'm') {
        unitType = 'M';
      } else if (str[index + 1] === 'w') {
        unitType = 'w';
      }

      const days = moment.duration(curr, unitType).asDays();

      return acc + days;
    }

    return acc;
  }, 0);

  return totalUnit;
};

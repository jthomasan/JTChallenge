import { replaceStringTemplate, getConfigParamValue } from '../utils';
import { DecoratorFunction } from './types';

export const isValueInArray: DecoratorFunction<{
  template: string;
}> = (data, { template }, _, { additionalContext }) => {
  const valueToFind = replaceStringTemplate(template, data, additionalContext);

  if (!Array.isArray(data)) {
    throw new Error(`Value is not an array.`);
  }

  // `valueToFind` is always a string from `replaceStringTemplate`
  return data.findIndex((value) => value.toString() === valueToFind) >= 0;
};

import termUnit from './genericTermPillarsTermUnit';

describe('Generic Term Pillars Tests', () => {
  it('should return term units when passing terms', () => {
    let unit = termUnit('c1');
    expect(unit).toEqual(1);

    unit = termUnit('c38');
    expect(unit).toEqual(38);

    unit = termUnit('c64');
    expect(unit).toEqual(64);

    unit = termUnit('c45');
    expect(unit).toEqual(45);
  });
});

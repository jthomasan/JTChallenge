export default (data: any) => ({ ...data, modified: false });

import { userListById } from '../resolvers/customResolvers/userListResolver';

export default (data: any) => ({
  ...data,
  added: { ...data.added, by: userListById[data.added.by]?.text || data.added.by },
});

import { uniqBy } from 'lodash';

export interface Args {
  field: string;
}

export default (data: any[], params: Args): any[] => uniqBy(data, params.field);

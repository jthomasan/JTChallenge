export default (data: string, { separator }: { separator: string }) => {
  if (data === null || typeof data === 'undefined' || !data.split) {
    return [];
  }

  return data.split(separator);
};

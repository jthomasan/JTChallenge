import { get } from 'lodash';

export default (data: any) => {
  const { compositeKey } = data;

  if (!compositeKey) {
    throw new Error(`Composite key doesn't exist`);
  }

  return (compositeKey as string[]).reduce(
    (acc, curr, index) => `${acc}${index ? '-' : ''}${get(data, curr)}`,
    '',
  );
};

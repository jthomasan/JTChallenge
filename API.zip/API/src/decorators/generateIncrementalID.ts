export default (data: any, params: any, dataIndex: number) =>
  params?.generatedFieldName
    ? {
        ...data,
        [params.generatedFieldName]: dataIndex + 1,
      }
    : {
        ...data,
        id: dataIndex + 1,
      };

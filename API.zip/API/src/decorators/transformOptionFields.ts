export interface Args {
  fields: string[];
}

export default (data: any, { fields }: Args) => {
  const mixin = {};
  fields.forEach((f: string) => {
    if (Array.isArray(data[f])) {
      mixin[f] = data[f].map((item) => ({
        ...item,
        id: item.id,
        text: item.value,
      }));
    } else {
      mixin[f] = data[f]
        ? {
            ...data[f],
            id: data[f].id,
            text: data[f].value,
          }
        : null;
    }
  });
  return { ...data, ...mixin };
};

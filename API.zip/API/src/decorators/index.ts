import roundNumber from './roundNumber';
import vegaBuckerTermUnit from './vegaBuckerTermUnit';
import genericTermPillarsTermUnit from './genericTermPillarsTermUnit';
import pillarsTermUnit from './pillarsTermUnit';
import populateModifiedFlag from './populateModifiedFlag';
import createIDFromCompositeKey from './createIDFromCompositeKey';
import transformOptionFields from './transformOptionFields';
import populateFullnameByLanId from './populateFullnameByLanId';
import split from './split';
import nullEmptyString from './nullEmptyString';
import generateIncrementalID from './generateIncrementalID';
import mapField from './mapField';
import populateStaticFields from './populateStaticFields';
import copyProperties from './copyProperties';
import distinctBy from './distinctBy';
import { nullIfTemplateEvaluatesTo } from './nullIfTemplateEvaluatesTo';
import { isValueInArray } from './isValueInArray';
import { DecoratorFunction } from './types';

export default {
  roundNumber,
  genericTermPillarsTermUnit,
  vegaBuckerTermUnit,
  pillarsTermUnit,
  populateModifiedFlag,
  createIDFromCompositeKey,
  transformOptionFields,
  populateFullnameByLanId,
  split,
  nullEmptyString,
  generateIncrementalID,
  mapField,
  populateStaticFields,
  copyProperties,
  distinctBy,
  nullIfTemplateEvaluatesTo,
  isValueInArray,
} as Record<string, DecoratorFunction>;

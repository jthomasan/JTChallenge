import distinctBy from './distinctBy';

const list = [
  {
    a: '1',
    b: '2',
    c: '3',
  },
  {
    a: '4',
    b: '5',
    c: '6',
  },
  {
    a: '1',
    b: '2',
    c: '3',
  },
];

describe('distinctBy Tests', () => {
  it('should return the list by distinct values', () => {
    const res = distinctBy(list, { field: 'a' });

    expect(res).toEqual([list[0], list[1]]);
  });
});

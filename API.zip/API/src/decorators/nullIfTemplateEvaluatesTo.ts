import { replaceStringTemplate } from '../utils';
import { DecoratorFunction } from './types';

export const nullIfTemplateEvaluatesTo: DecoratorFunction<{
  template: string;
  value: string;
}> = (data, { template, value }, _, { additionalContext }) => {
  if (replaceStringTemplate(template, data, additionalContext) === value) {
    return null;
  }

  return data;
};

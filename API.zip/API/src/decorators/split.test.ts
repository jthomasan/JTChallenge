import decorator from './split';

describe('split decorator', () => {
  it('splits valid strings', () => {
    expect(decorator('a,b,c', { separator: ',' })).toStrictEqual(['a', 'b', 'c']);
    expect(decorator('abc', { separator: ',' })).toStrictEqual(['abc']);
  });

  it('returns empty array on an null, undefined or invalid value', () => {
    expect(decorator(null, { separator: ',' })).toStrictEqual([]);
    expect(decorator(undefined, { separator: ',' })).toStrictEqual([]);
    expect(decorator(false as any, { separator: ',' })).toStrictEqual([]);
    expect(decorator(12 as any, { separator: ',' })).toStrictEqual([]);
  });
});

import { get } from 'lodash';

export interface MapFieldParams {
  /**
   * new field created on first level on data object
   */
  newField: string;
  /**
   * original field of data object in dot seperated string eg: 'modifiedDate' or 'Added.date'
   */
  originalField: string;
}

/**
 * map original field to a new field
 * @param data original data
 * @param param param doing the mapping
 */
export default (data: any, { newField, originalField }: MapFieldParams) => ({
  ...data,
  [newField]: get(data, originalField),
});

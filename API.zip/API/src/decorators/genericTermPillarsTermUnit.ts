export default (data: string) => {
  if (!data) {
    throw new Error(`Term doesn't exist`);
  }
  const totalUnit = data.replace('c', '');

  return Number(totalUnit);
};

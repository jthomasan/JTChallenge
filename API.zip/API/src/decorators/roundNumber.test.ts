import roundNumber from './roundNumber';

describe('Format Decimals Tests', () => {
  it('should return data by format the decimals', () => {
    let res = roundNumber('11.11', { decimalPlaces: 1 });

    expect(res).toEqual('11.1');

    res = roundNumber('11', { decimalPlaces: 1 });

    expect(res).toEqual('11.0');

    res = roundNumber('4744.475', { decimalPlaces: 2 });

    expect(res).toEqual('4744.48');

    res = roundNumber('4744.475', { decimalPlaces: 2, applyToDecimalsOnly: true });

    expect(res).toEqual('4744.48');

    res = roundNumber('11', { decimalPlaces: 2, applyToDecimalsOnly: true });

    expect(res).toEqual('11');
  });
});

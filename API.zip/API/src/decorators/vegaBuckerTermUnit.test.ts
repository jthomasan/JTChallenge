import termUnit from './vegaBuckerTermUnit';

describe('Vega Buckets Term Unit Tests', () => {
  it('should return term units when passing terms', () => {
    jest.spyOn(global.Date, 'now').mockImplementationOnce(() => new Date(`2020-01-01`).valueOf());

    // Years
    let unit = termUnit('1y');
    expect(unit).toEqual(365);

    unit = termUnit('10y');
    expect(unit).toEqual(3652);

    // Months
    unit = termUnit('1m');
    expect(unit).toEqual(30);

    unit = termUnit('10m');
    expect(unit).toEqual(304);

    // Days
    unit = termUnit('1d');
    expect(unit).toEqual(1);

    unit = termUnit('10d');
    expect(unit).toEqual(10);

    // Years and Months
    unit = termUnit('1y3m');
    expect(unit).toEqual(456);

    unit = termUnit('10y1m');
    expect(unit).toEqual(3682);
  });
});

export default (data: unknown) => (data === '' ? null : data);

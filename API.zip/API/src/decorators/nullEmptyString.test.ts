import decorator from './nullEmptyString';

describe('nullEmptyString decorator', () => {
  it('returns null on an empty string', () => {
    expect(decorator('')).toBeNull();
  });

  it('returns data on a non-empty string value', () => {
    expect(decorator('asd')).toBe('asd');
    expect(decorator(true)).toBe(true);
    expect(decorator(['abc'])).toStrictEqual(['abc']);
  });
});

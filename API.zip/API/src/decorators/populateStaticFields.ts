export default (data: any, staticFields: any) => ({ ...data, ...staticFields });

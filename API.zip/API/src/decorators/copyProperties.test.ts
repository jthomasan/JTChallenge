import copyProperties from './copyProperties';

describe('copyProperties Decorator Tests', () => {
  it('should return a data row with the modifications provided', () => {
    const data = {
      a: '1',
      b: {
        c: '1',
      },
    };

    const res = copyProperties(data, {
      properties: [
        {
          copyFrom: 'a',
          copyTo: 'b',
        },
      ],
    });

    expect(res).toEqual({ a: '1', b: { c: '1', a: '1' } });
  });

  it('should return a data row with the modifications provided', () => {
    const data = {
      a: '1',
      b: '2',
      c: {
        c: '1',
      },
      d: {
        a: '1',
      },
    };

    const res = copyProperties(data, {
      properties: [
        {
          copyFrom: 'a',
          copyTo: 'c',
        },
        {
          copyFrom: 'b',
          copyTo: 'd',
        },
      ],
    });

    expect(res).toEqual({
      a: '1',
      b: '2',
      c: {
        c: '1',
        a: '1',
      },
      d: {
        a: '1',
        b: '2',
      },
    });
  });

  it('should return a data row with the provided mapping and new name', () => {
    const data = {
      a: '1',
      b: '2',
      c: {
        c: '1',
      },
      d: {
        a: '1',
      },
    };

    const res = copyProperties(data, {
      properties: [
        {
          copyFrom: 'a',
          copyTo: 'c',
          newFieldName: 'e',
        },
        {
          copyFrom: 'b',
          copyTo: 'd',
          newFieldName: 'i',
        },
      ],
    });

    expect(res).toEqual({
      a: '1',
      b: '2',
      c: {
        c: '1',
        e: '1',
      },
      d: {
        a: '1',
        i: '2',
      },
    });
  });

  it('should return a data row with complex mappings', () => {
    const data = {
      a: { b: { g: '1' } },
      b: { a: '2' },
      c: {
        c: { a: '1' },
      },
      d: {
        a: { c: '1' },
      },
    };

    const res = copyProperties(data, {
      properties: [
        {
          copyFrom: 'a',
          copyTo: 'c',
        },
        {
          copyFrom: 'b.a',
          copyTo: 'd.a',
          newFieldName: 'i',
        },
      ],
    });

    expect(res).toEqual({
      a: { b: { g: '1' } },
      b: { a: '2' },
      c: {
        c: { a: '1' },
        a: { b: { g: '1' } },
      },
      d: {
        a: { c: '1', i: '2' },
      },
    });
  });
});

export interface Args {
  decimalPlaces: number;
  applyToDecimalsOnly?: boolean;
}

const roundNumber = (data: any, decimalPlaces: number) => {
  if (Number.isNaN(data)) {
    throw new Error(`Expected a number but received ${data}`);
  }

  return Number(data).toFixed(decimalPlaces);
};

export default (data: string, { decimalPlaces, applyToDecimalsOnly }: Args) => {
  const [, isDataContainsDecimals] = data?.split('.');

  if (typeof decimalPlaces === 'undefined') {
    throw new Error(`Decimals places doesn't exist in the api configs`);
  }

  if (!applyToDecimalsOnly || isDataContainsDecimals) {
    return roundNumber(data, decimalPlaces);
  }

  return data;
};

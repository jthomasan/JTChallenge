import { GraphQLResolveInfo } from 'graphql';

export interface DecoratorAdditionalParameters<AdditionalContext> {
  additionalContext: AdditionalContext;
  resolverInfo: GraphQLResolveInfo;
}

export type DecoratorFunction<
  ParamsType extends Record<string, any> | null = Record<string, any>,
  AdditionalContext extends Record<string, any> = {
    args: Record<string, any>;
    parent: any;
  },
  DataType = any,
  ReturnDataType = any
> = (
  data: DataType,
  params: ParamsType,
  index: number,
  additonalParams: DecoratorAdditionalParameters<AdditionalContext>,
) => ReturnDataType;

import AUTHORITY from './authority';

export enum SCOPE {
  'openid' = 'openid',
  'ALL.ALL.ALL' = 'ALL.ALL.ALL',
  'UI.ALL.READ' = 'UI.ALL.READ',
  'API.ALL.READ' = 'API.ALL.READ',

  'UI.REFERENCEDATA.UPDATE' = 'UI.REFERENCEDATA.UPDATE',
  'API.REFERENCEDATA.UPDATE' = 'API.REFERENCEDATA.UPDATE',
  'API.HIERARCHY.UPDATE' = 'API.HIERARCHY.UPDATE',
  'API.LIMITSREFERENCEDATA.UPDATE' = 'API.LIMITSREFERENCEDATA.UPDATE',
  'API.LIMITS.UPDATE' = 'API.LIMITS.UPDATE',

  'UI.FEEDMONITOR.VIEW' = 'UI.FEEDMONITOR.VIEW',
  'UI.FEEDMONITOR.UPDATE' = 'UI.FEEDMONITOR.UPDATE',
  'API.FEEDMONITOR.READ' = 'API.FEEDMONITOR.READ',
  'API.FEEDMONITOR.UPDATE' = 'API.FEEDMONITOR.UPDATE',
}

const SCOPE_TO_AUTHORITY = {
  [SCOPE['ALL.ALL.ALL']]: Object.values(AUTHORITY),
  [SCOPE['UI.ALL.READ']]: Object.values(AUTHORITY).filter((authorityName) =>
    authorityName.endsWith('READ'),
  ),
  [SCOPE['UI.FEEDMONITOR.READ']]: Object.values(AUTHORITY).filter(
    (authorityName) => authorityName.startsWith('FEED_MONITOR') && authorityName.endsWith('READ'),
  ),
  [SCOPE['UI.REFERENCEDATA.UPDATE']]: [
    AUTHORITY.REF_DATA_HIERARCHY_WRITE,
    AUTHORITY.REF_DATA_STATIC_DATA_WRITE,
    AUTHORITY.REF_DATA_CONFIGURATION_WRITE,
    AUTHORITY.FEED_MONITOR_RISK_DATA_WRITE,
  ],
};

export const getAuthorityFromScope = (scopes: string[]) =>
  scopes.reduce((acc, scope) => acc.concat(SCOPE_TO_AUTHORITY[scope] || []), []);

import * as stiScopes from './stiScopes'; 
import * as authzServiceScopes from './authzServiceScopes'; 

let scopesConfig:any = authzServiceScopes;

if (process.env.USE_STI_SCOPES === '1') {
  scopesConfig = stiScopes;
}

export const { SCOPE, getAuthorityFromScope } = scopesConfig;

import { JSONPath } from 'jsonpath-plus';

export const splitFirst = (str: string, separator: string) => {
  const index = str.indexOf(separator);
  if (index < 0) {
    return [str];
  }

  return [str.substring(0, index), str.substring(index + separator.length)];
};

export const isConfigParam = (paramString: string) => paramString.match(/^{[^}]*?}$/g);

export const getConfigParamValue = (
  paramString: string,
  entity: any,
  additionalLookups: Record<string, any>,
) => {
  if (isConfigParam(paramString)) {
    const param = paramString.substring(1, paramString.length - 1);
    const [argsKeyword, path] = splitFirst(param, '.');
    if (param.startsWith('$') && entity) {
      const [content] = JSONPath({ path: param, json: entity });
      return content;
    }

    if (argsKeyword in additionalLookups) {
      if (path?.length) {
        const [content] = JSONPath({ path: `$.${path}`, json: additionalLookups[argsKeyword] });
        return content;
      }
      return additionalLookups[argsKeyword];
    }
  }

  return null;
};

export const replaceStringTemplate = (
  stringTemplate: string,
  entity: any,
  additionalLookups: Record<string, any>,
) => {
  return stringTemplate.replace(
    /{.*?}/g,
    (matchString) => getConfigParamValue(matchString, entity, additionalLookups) ?? '',
  );
};

export const getPathFromUrlTemplate = (urlTemplate, parentEntity, additionalLookups) => {
  // process url to remove empty queryString
  const urlArray = replaceStringTemplate(urlTemplate, parentEntity, additionalLookups).split('?');
  const path = urlArray[0];
  const queryStringArray =
    urlArray.length > 1 ? urlArray[1].split('&').filter((qs: string) => !!qs.split('=')[1]) : [];

  return queryStringArray.length > 0 ? `${path}?${queryStringArray.join('&')}` : path;
};

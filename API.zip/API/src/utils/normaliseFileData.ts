import * as fs from 'fs';
import * as Ajv from 'ajv';
import { merge } from 'lodash';

export interface FileValidation {
  isDataValid: boolean;
  errors: null | Array<Ajv.ErrorObject>;
}

const readFileData = (path: string): Object => {
  try {
    const data = fs.readFileSync(path, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    throw new Error(error);
  }
};

// Merge all file data from directory
const handleFileData = (path: string): Object => {
  const files = fs.readdirSync(path, { withFileTypes: true });
  return files.reduce((acc, curr) => {
    if (curr.isDirectory()) {
      return acc;
    }
    const file = readFileData(`${path}/${curr.name}`);
    const merged = merge({}, acc, file);

    return merged;
  }, {});
};

export const validateFileData = (fileData: Object, schemaData: Object): FileValidation => {
  const ajv = new Ajv();
  const validate = ajv.compile(schemaData);
  const isDataValid = validate(fileData) as boolean;

  return { isDataValid, errors: validate.errors };
};

export const getNormalisedFileData = (filePath: string, schemaPath: string): Object => {
  const fileData = handleFileData(filePath);
  const schemaData = readFileData(schemaPath);
  const { isDataValid, errors } = validateFileData(fileData, schemaData);

  if (isDataValid) {
    return fileData;
  }

  // eslint-disable-next-line @typescript-eslint/no-throw-literal
  throw { message: 'Invalid file data detected.', errors };
};

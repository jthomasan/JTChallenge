import { getNormalisedFileData, validateFileData } from './normaliseFileData';
import { config, schema } from './__mocks__/mockData';

describe('NormaliseFileData tests', () => {
  it('should return file data after successful validation check', () => {
    const fileData = getNormalisedFileData(
      './src/utils/__mocks__/mockConfigs',
      './src/utils/__mocks__/RestToGqlSchema.json',
    );

    expect(fileData).toMatchSnapshot();
  });

  it('should throw error when file not exist', () => {
    try {
      getNormalisedFileData(
        './src/utils/__mocks__/invalidDirectoryName',
        './src/utils/__mocks__/RestToGqlSchema.json',
      );
    } catch (e) {
      expect(e).toMatchSnapshot();
    }
  });

  it('should return true when data is align with schema', async () => {
    const { isDataValid, errors } = await validateFileData(config, schema);

    expect(isDataValid).toEqual(true);
    expect(errors).toEqual(null);
  });

  it('should throw errors when data is misalign with schema', async () => {
    // When datapath is missing
    let invalidConfig = {
      ...config,
    };
    (invalidConfig.Node.portfolios as any) = {};
    let results = await validateFileData(config, schema);

    expect(results.isDataValid).toEqual(false);
    expect(results.errors).toMatchSnapshot();

    // When datapath specified as boolean
    invalidConfig = {
      ...config,
    };
    (invalidConfig.Node.portfolios.dataPath as any) = true;
    results = await validateFileData(invalidConfig, schema);

    expect(results.isDataValid).toEqual(false);
    expect(results.errors).toMatchSnapshot();

    // When config specified as not object type
    invalidConfig = {
      ...config,
    };
    (invalidConfig.Node as any) = 'Some Data';
    results = await validateFileData(invalidConfig, schema);

    expect(results.isDataValid).toEqual(false);
    expect(results.errors).toMatchSnapshot();
  });

  it('should throw error with validation errors when data is incorrect', () => {
    try {
      getNormalisedFileData(
        './src/utils/__mocks__/mockConfigsInvalid',
        './src/utils/__mocks__/RestToGqlSchema.json',
      );
    } catch (e) {
      expect(e).toMatchSnapshot();
    }
  });
});

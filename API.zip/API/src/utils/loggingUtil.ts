import * as bunyan from 'bunyan';

const logger = bunyan.createLogger({ name: 'merv-web-api' });

export const apolloLoggerPlugin = {
  serverWillStart() {
    logger.info('Apollo Server is ready for requests');
  },
  requestDidStart(requestContext) {
    if (requestContext.request.operationName !== 'IntrospectionQuery') {
      requestContext.context.logger.info(requestContext.request);
    }

    return {
      didEncounterErrors(requestContext) {
        requestContext.context.logger.error(requestContext.errors);
      },
    };
  },
};

export default logger;

import { ExpressContext } from 'apollo-server-express/dist/ApolloServer';
import {
  GraphQLResolveInfo,
  parse,
  ExecutableDefinitionNode,
  SelectionNode,
  FieldNode,
} from 'graphql';
import { isEqual } from 'lodash';
import { Path } from 'graphql/jsutils/Path';

export interface ResolverContext {
  name: string;
  alias?: string;
  isAvailable: boolean;
}

const isValidSource = (value: Object): boolean => {
  return typeof value === 'object' && value !== null;
};

// Create document AST from the requested query
const getQueryDocumentAST = (query: string): ReadonlyArray<SelectionNode> => {
  const { selectionSet } = parse(query).definitions[0] as ExecutableDefinitionNode;
  return selectionSet.selections;
};

export const getRootQueryObject = (path: Path, rootValue: any): Path => {
  if (!isEqual(path.prev, rootValue)) {
    return getRootQueryObject(path.prev, rootValue);
  }

  return path;
};

export const handleResolvedData = (source: any, info: GraphQLResolveInfo) => {
  if (isValidSource(source)) {
    const property = source[info.fieldName];

    return property;
  }

  return source;
};

export const normaliseContextForResolvers = (
  { req }: ExpressContext,
  resolvers: any,
): Record<string, ResolverContext> => {
  if (req.body.query) {
    const { Query: rootQueries } = resolvers;
    // List availability of all root query resolvers
    return getQueryDocumentAST(req.body.query).reduce(
      (acc, curr: FieldNode) => ({
        ...acc,
        [curr.alias?.value ?? curr.name.value]: {
          name: curr.name.value,
          alias: curr.alias?.value,
          isAvailable: !!rootQueries[curr.name.value],
        } as ResolverContext,
      }),
      {},
    );
  }

  return {};
};

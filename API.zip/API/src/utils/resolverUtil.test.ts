import { normaliseContextForResolvers } from './resolverUtil';

const QUERY = `
  query {
    Nodes {
    id
    portfolios {
      id
      }
    }
    Portfolios {
      id
      classification {
        assetType
      }
    }
    Hierarchies {
      id
    }
  }
`;

const QUERY_WITH_ALIAS = `
  query {
    A: Nodes {
        id
        portfolios {
          id
        }
      }
    B: Portfolios {
        id
        classification {
          assetType
        }
      }
    C: Hierarchies {
      id
    }
  }
`;

describe('ResolverUtil Tests', () => {
  it('should return empty when request body not exist', () => {
    const req = {
      body: {},
    };

    const res = normaliseContextForResolvers({ req } as any, {});
    expect(res).toEqual({});
  });

  it('should return false for availability when resolvers not exist', () => {
    const req = {
      body: { query: QUERY },
    };

    const res = normaliseContextForResolvers({ req } as any, { Query: {} });
    expect(res).toMatchSnapshot();
  });

  it('should return true for availability when resolvers exist', () => {
    // When only nodes available
    const req = {
      body: { query: QUERY },
    };
    let resolvers: any = {
      Query: {
        Nodes: {},
      },
    };

    let res = normaliseContextForResolvers({ req } as any, resolvers);
    expect(res).toMatchSnapshot();

    // When only hierarchies available
    resolvers = {
      Query: {
        Hierarchies: {},
      },
    };

    res = normaliseContextForResolvers({ req } as any, resolvers);
    expect(res).toMatchSnapshot();

    // When all  root resolvers available
    resolvers = {
      Query: {
        Nodes: {},
        Portfolios: {},
        Hierarchies: {},
      },
    };

    res = normaliseContextForResolvers({ req } as any, resolvers);
    expect(res).toMatchSnapshot();
  });

  it('should return resolver context with alias names when alias provides', () => {
    const req = {
      body: { query: QUERY_WITH_ALIAS },
    };
    const resolvers = {
      Query: {
        Nodes: {},
        Portfolios: {},
        Hierarchies: {},
      },
    };

    const res = normaliseContextForResolvers({ req } as any, resolvers);
    expect(res).toMatchSnapshot();
  });
});

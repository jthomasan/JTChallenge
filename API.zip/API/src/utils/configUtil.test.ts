import {
  splitFirst,
  getConfigParamValue,
  replaceStringTemplate,
  getPathFromUrlTemplate,
} from './configUtil';

describe('utils test', () => {
  describe('splitFirst', () => {
    it('should only split on the first occurrence', () => {
      expect(splitFirst('args.parent.child.grandchild', '.')).toStrictEqual([
        'args',
        'parent.child.grandchild',
      ]);

      expect(splitFirst('args.', '.')).toStrictEqual(['args', '']);
    });

    it('should not fail when no split is possible', () => {
      expect(splitFirst('args', '.')).toStrictEqual(['args']);
      expect(splitFirst('', '.')).toStrictEqual(['']);
    });

    it('should support multi-character separators', () => {
      expect(splitFirst('args.:.parent.:.child.:.grandchild', '.:.')).toStrictEqual([
        'args',
        'parent.:.child.:.grandchild',
      ]);
    });
  });

  describe('parseConfigParam', () => {
    it('should return null if the string is not config param', () => {
      const input = '$args.dummy';
      const output = getConfigParamValue(input, {}, { args: { dummy: 'dummyValue' } });
      expect(output).toBe(null);
    });
    it('should return json path if the string is json path', () => {
      const input = '{$.nodeAK}';
      const output = getConfigParamValue(input, { nodeAK: '1' }, {});
      expect(output).toEqual('1');
    });
    it('should return args name if the string is args', () => {
      const input = '{args.nodeAK}';
      const output = getConfigParamValue(input, {}, { args: { nodeAK: '2' } });
      expect(output).toEqual('2');
    });
    it('should return the entire args object if the string is args alone', () => {
      const input = '{args}';
      const output = getConfigParamValue(input, {}, { args: { nodeAK: '2' } });
      expect(output).toEqual({ nodeAK: '2' });
    });
    it('should return values that evalute falsey', () => {
      const input = '{args.nodeAK}';
      const output = getConfigParamValue(input, {}, { args: { nodeAK: 0 } });
      expect(output).toEqual(0);
    });
    it('should return null if the root key is not found in the data set', () => {
      const input = '{missing.nodeAK}';
      const output = getConfigParamValue(input, {}, { args: { nodeAK: 0 } });
      expect(output).toEqual(null);
    });
    it('should return deeply nested values', () => {
      const input = '{args.parent.child.grandchild.value}';
      const output = getConfigParamValue(
        input,
        {},
        {
          args: {
            parent: {
              child: {
                grandchild: {
                  value: 'check',
                },
              },
            },
          },
        },
      );

      expect(output).toEqual('check');
    });
    it('should replace string template to right string', () => {
      const stringTemplate = '$[?(@.nodeId == {$.nodeId})]';
      const parentEntity = {
        nodeId: '100',
      };

      const stringVal = replaceStringTemplate(stringTemplate, parentEntity, { args: {} });

      expect(stringVal).toEqual('$[?(@.nodeId == 100)]');
    });
    it('should generate right path with variable values', () => {
      // Given
      const urlTemplate =
        'referenceData/hierarchies/{args.type}/nodes/{$.nodeAK}/portfolios/{args.portfolioId}?test1={args.test1}&test2={$.test2}&test3={args.test3}';
      const parentEntity = {
        nodeAK: 1101,
        test2: 'test2Value',
      };
      const args = {
        type: 1,
        test1: 'test1Value',
      };

      // When
      const path = getPathFromUrlTemplate(urlTemplate, parentEntity, { args });

      // Then
      expect(path).toEqual(
        'referenceData/hierarchies/1/nodes/1101/portfolios/?test1=test1Value&test2=test2Value',
      );
    });
    it('should generate right path with different variable values', () => {
      // Given
      const urlTemplate =
        'feed-monitor/v1/source-system-errors?date={args.cob}&isPortfolioNode={args.isPortfolioNode}&test={args.test}';
      const parentEntity = {};
      const args = {
        cob: '2021-02-19',
        isPortfolioNode: false,
        test: 1,
      };

      // When
      const path = getPathFromUrlTemplate(urlTemplate, parentEntity, { args });

      // Then
      expect(path).toEqual(
        'feed-monitor/v1/source-system-errors?date=2021-02-19&isPortfolioNode=false&test=1',
      );
    });
  });
});

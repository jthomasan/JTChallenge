import { get, isPlainObject, isEmpty, cloneDeep } from 'lodash';
import { getConfigParamValue } from './configUtil';

interface Model {
  $value: string;
  $type: string;
  $nullable?: string;
}

interface ArrayConfigModel extends Model {
  $type: 'array';
  $elementMapping: any[];
}

type FieldConfig = Model | ArrayConfigModel;

type ReturnType = string | number | boolean | object;

interface Types {
  [type: string]: (value: string) => ReturnType;
}

interface TypeArray {
  array: (value: any[], elementMapping: any, shouldRemoveUndefined: boolean) => any[];
}


/*
 * replace any occurence of {args.argName} in str with args[argName]
 */
export const replaceArgsInString = (str: string, args: object, shouldRemoveUndefined: boolean) => {
  try {
    return str.replace(/\{args\.(.+?)\}/g, (_match, arg) => {
      const value = get(args, arg);
      if (shouldRemoveUndefined && value === undefined) {
        throw new Error('value not found in args');
      }

      return value ?? '';
    });
  } catch (e) {
    return null;
  }
};

/*
 * Check whether the object is an interface for api defined in the api mappings json
 */
const containsMetaData = (obj: any): boolean => {
  if (!isPlainObject(obj)) {
    return false;
  }

  const expectedTypeConfig = ['$value', '$type'];

  return expectedTypeConfig.every((item) => item in obj);
};

const isObjectEmpty = (mutatedValue: any): boolean =>
  mutatedValue == null || (isPlainObject(mutatedValue) && isEmpty(mutatedValue));

/*
 * replace any occurence of {args.argName} in an object's value with args[argName]
 */
export function replaceArgsInObject(
  obj: any | FieldConfig,
  args: any,
  shouldRemoveUndefined: boolean,
  additionalFieldProcessor?: (mutatedField: {[key: string]: any}) => ({[key: string]: any})
): object | string | number | boolean {
  if (Array.isArray(obj)) {
    return obj.map((item) => replaceArgsInObject(item, args, shouldRemoveUndefined, additionalFieldProcessor));
  }

  return Object.entries(obj).reduce((acc, [key, template]: [string, any]) => {
    const { $nullable = false } = template;
    const mutatedValue = replaceArgsInTemplate(template, args, shouldRemoveUndefined, additionalFieldProcessor);

    if (
      (shouldRemoveUndefined && isObjectEmpty(mutatedValue) && !$nullable) ||
      ($nullable && mutatedValue === undefined)
    ) {
      return acc;
    }

    let newEntry = { [key]: mutatedValue };
    if (additionalFieldProcessor) {
      newEntry = additionalFieldProcessor(newEntry);
    }

    return {
      ...acc,
      ...newEntry
    };
  }, {});
}

function replaceArgsInTemplate(
  template: any,
  args: object,
  shouldRemoveUndefined: boolean,
  additionalFieldProcessor?: (mutatedField: {[key: string]: any}) => ({[key: string]: any})
): object {
  let mutatedValue: any;

  switch (typeof template) {
    case 'string':
      mutatedValue = replaceArgsInString(template, args, shouldRemoveUndefined);
      break;

    case 'object':
      if (containsMetaData(template)) {
        const { $type, $elementMapping, $value } = template;
        const extractedData = getConfigParamValue($value, {}, { args });
        
        mutatedValue = convertValuesToGivenVariableType(extractedData, $type, $elementMapping, shouldRemoveUndefined);
      }
      else {
        mutatedValue = replaceArgsInObject(template, args, shouldRemoveUndefined, additionalFieldProcessor);
      }
      break;

    default:
      mutatedValue = template;
      break;
  }

  return mutatedValue;
}

function convertValuesToGivenVariableType(
  value: any,
  toType: string,
  elementMapping: any,
  shouldRemoveUndefined: boolean,
) {
  if (value === null || typeof value === 'undefined') return value;
  
  const typeConvertors: Types | TypeArray = {
    string: (value) => value.toString(),
    number: (value) => Number(value),
    boolean: (value) => (value || value === 'true' ? true : false),
    array: (value) => {
      if (!elementMapping) {
        throw new Error('Cannot find $elementMapping property on api mapping');
      }
  
      return value.map((item) => replaceArgsInTemplate(elementMapping, item, shouldRemoveUndefined));
    },
  };

  const convertToType = typeConvertors[toType];
  return convertToType? convertToType(value) : value;
}

export function replaceIdsWithNull(body: { [key: string]: any }) { 
  const newBody = cloneDeep(body);
  for (const key in newBody) {
    if (Object.prototype.hasOwnProperty.call(newBody, key)) {
      if (key === 'id' && newBody[key] === '') {
        newBody[key] = null;
      }
    }
  }
  return newBody;
}
import { replaceArgsInString, replaceArgsInObject } from './batchActionUtil';

describe('batchActionUtil', () => {
  it('should replace args in string', () => {
    const result = replaceArgsInString('prefix: {args.test}', { test: 'testValue' }, false);
    expect(result).toEqual('prefix: testValue');
  });

  it('should replace args in string with empty string if value not found and shouldRemoveUndefined is false', () => {
    const result = replaceArgsInString('prefix/{args.test}', { test1: 'testValue' }, false);
    expect(result).toEqual('prefix/');
  });

  it('should return null if value not found and shouldRemoveUndefined is true', () => {
    const result = replaceArgsInString('prefix: {args.test}', { test1: 'testValue' }, true);
    expect(result).toEqual(null);
  });

  it('should return object with value defined in args', () => {
    const object = {
      a: '{args.test1}',
      b: '{args.test2}',
      c: '{args.test3}',
      d: '{args.test4}',
    };
    const args = {
      test1: 'valueA',
      test2: 'valueB',
      test3: 'valueC',
      test4: 'valueD',
    };
    const result = replaceArgsInObject(object, args, false);
    expect(result).toEqual({
      a: 'valueA',
      b: 'valueB',
      c: 'valueC',
      d: 'valueD',
    });
  });

  it('should return object with value defined in args and remove undefined when shouldRemoveUndefined is true', () => {
    const object = {
      a: '{args.test1}',
      b: '{args.test2}',
      c: '{args.test3}',
      d: '{args.test5}',
    };
    const args = {
      test1: 'valueA',
      test2: 'valueB',
      test3: 'valueC',
      test4: 'valueD',
    };
    const result = replaceArgsInObject(object, args, true);
    expect(result).toEqual({
      a: 'valueA',
      b: 'valueB',
      c: 'valueC',
    });
  });

  it('should return object with value typed in args and remove undefined when shouldRemoveUndefined is true', () => {
    const object = {
      op: '{args.op}',
      path: '/',
      value: [
        {
          term: '{args.term}',
          sp_id: { $value: '{args.sp_id}', $type: 'number' },
          net3m: { $value: '{args.net3m}', $type: 'number' },
          net1y: { $value: '{args.net1y}', $type: 'number' },
          net3y: { $value: '{args.net3y}', $type: 'number' },
          net10y: { $value: '{args.net10y}', $type: 'number' },
          net20y: { $value: '{args.net20y}', $type: 'number' },
        },
      ],
    };

    const args = { id: '2d', term: '2d', sp_id: '7', net1y: '1', op: 'replace' };

    const result = replaceArgsInObject(object, args, true);
    expect(result).toMatchSnapshot();
  });

  it('should return value with multiple objects in args and remove undefined when shouldRemoveUndefined is true', () => {
    const object = {
      op: '{args.op}',
      path: '/',
      value: [
        {
          term: '{args.term}',
          sp_id: { $value: '{args.sp_id}', $type: 'number' },
          net1y: { $value: '{args.net1y}', $type: 'number' },
        },
        {
          term: '{args.term}',
          sp_id: { $value: '{args.sp_id}', $type: 'number' },
          net3m: { $value: '{args.net3m}', $type: 'number' },
        },
      ],
    };

    const args = { id: '2d', term: '2d', sp_id: '7', net3m: '1', net1y: '1', op: 'replace' };

    const result = replaceArgsInObject(object, args, true);
    expect(result).toMatchSnapshot();
  });

  it('should return value with arrays in args and remove undefined when shouldRemoveUndefined is true', () => {
    const object = {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        nameofUnderlying: {
          $value: '{args.nameofUnderlying}',
          $type: 'array',
          $elementMapping: {
            id: '{args.id}',
            weight: '{args.weight}',
          },
        },
      },
    };

    const args = {
      id: '1',
      nameofUnderlying: [
        {
          id: '1',
          text: 'A',
          weight: 1,
        },
        {
          id: '2',
          text: 'B',
          weight: 2,
        },
        {
          id: '3',
          text: 'C',
        },
      ],
    };

    const result = replaceArgsInObject(object, args, true);

    expect(result).toEqual({
      path: '/',
      value: {
        id: '1',
        nameofUnderlying: [
          {
            id: '1',
            weight: '1',
          },
          {
            id: '2',
            weight: '2',
          },
          {
            id: '3',
          },
        ],
      },
    });
  });

  it('should return value with arrays in args by converting to given data type', () => {
    const object = {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        nameofUnderlying: {
          $value: '{args.nameofUnderlying}',
          $type: 'array',
          $elementMapping: {
            id: '{args.id}',
            weight: { $value: '{args.weight}', $type: 'number' },
          },
        },
      },
    };

    const args = {
      id: '1',
      nameofUnderlying: [
        {
          id: '1',
          text: 'A',
          weight: 1,
        },
        {
          id: '2',
          text: 'B',
          weight: 2,
        },
        {
          id: '3',
          text: 'C',
        },
      ],
    };

    const result = replaceArgsInObject(object, args, true);

    expect(result).toEqual({
      path: '/',
      value: {
        id: '1',
        nameofUnderlying: [
          {
            id: '1',
            weight: 1,
          },
          {
            id: '2',
            weight: 2,
          },
          {
            id: '3',
          },
        ],
      },
    });
  });

  it('should return value with nested object arrays in args by converting to given data type', () => {
    const object = {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        nameofUnderlying: {
          $value: '{args.nameofUnderlying}',
          $type: 'array',
          $elementMapping: {
            id: '{args.id}',
            weight: { $value: '{args.weight}', $type: 'number' },
            extras: {
              id: '{args.extras.id}',
              data: {
                $value: '{args.extras.data}',
                $type: 'array',
                $elementMapping: {
                  id: '{args.id}',
                  weight: { $value: '{args.weight}', $type: 'number' },
                },
              },
            },
          },
        },
      },
    };

    const args = {
      id: '1',
      nameofUnderlying: [
        {
          id: '1',
          text: 'A',
          weight: 1,
          extras: {
            id: '1',
            data: [
              {
                id: '1',
                weight: 1,
              },
            ],
          },
        },
      ],
    };

    const result = replaceArgsInObject(object, args, true);

    expect(result).toEqual({
      path: '/',
      value: {
        id: '1',
        nameofUnderlying: [
          {
            id: '1',
            weight: 1,
            extras: {
              id: '1',
              data: [
                {
                  id: '1',
                  weight: 1,
                },
              ],
            },
          },
        ],
      },
    });
  });

  it('should return values with null in args when set nullable on config', () => {
    const object = {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        objectWithNullConfig: {
          id: { $value: '{args.objectWithNullConfig.id}', $type: 'string', $nullable: true },
        },
        objectDoesntExist: {
          id: { $value: '{args.objectDoesntExist.id}', $type: 'string', $nullable: true },
        },
      },
    };

    const args = {
      id: '1',
      objectWithNullConfig: {
        id: null,
      },
    };

    const result = replaceArgsInObject(object, args, true);

    expect(result).toEqual({
      path: '/',
      value: {
        id: '1',
        objectWithNullConfig: {
          id: null,
        },
      },
    });
  });

  it('should return value with string arrays in args by converting to given data type', () => {
    const object = {
      op: '{args.op}',
      path: '/',
      value: {
        id: '{args.id}',
        stringArray: {
          $value: '{args.stringArray}',
          $type: 'array',
          $elementMapping: { $value: '{args}', $type: 'string' },
        },
      },
    };

    const args = {
      id: '1',
      stringArray: ['1', '2'],
    };

    const result = replaceArgsInObject(object, args, true);

    expect(result).toEqual({
      path: '/',
      value: {
        id: '1',
        stringArray: ['1', '2'],
      },
    });
  });
});

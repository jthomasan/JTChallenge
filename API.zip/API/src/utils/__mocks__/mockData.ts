export const config = {
  Query: {
    Nodes: {
      url: 'reference-data/hierarchies/{args.type}/nodes?date={args.cob}',
      dataPath: '$',
      additionalData: {
        hierarchyType: '{args.type}',
      },
    },
  },
  Node: {
    id: '$.nodeId',
    type: '',
    title: '$.nodeName',
    portfolios: {
      url: 'reference-data/hierarchies/{$.hierarchyType}/nodes/{$.nodeAK}/portfolios',
      dataPath: '$',
    },
    fullPath: '$.fullPath',
    parent: '$.parentNodeId',
    children: '',
    classification: '',
  },
  Portfolio: {
    id: '$.leafID',
    title: '$.name',
    fullPath: '',
    parent: '$.nodeAK',
    createdOn: {
      dataPath: '$.dateAdded',
      decorator: 'prettifyTimestamp',
    },
  },
};

export const schema = {
  $schema: 'http://json-schema.org/draft-07/schema#',
  definitions: {
    fieldInfo: {
      $id: '#dataInfoFields',
      type: 'object',
      properties: {
        url: { type: 'string' },
        dataPath: { type: 'string' },
        decorator: { type: 'string' },
        additionalData: { type: 'object' },
      },
      additionalProperties: false,
      required: ['dataPath'],
    },
    gqlTypes: {
      $id: '#gqlTypes',
      type: 'object',
      patternProperties: {
        '^[A-Za-z_][A-Za-z0-9_]*$': {
          type: ['string', 'object'],
          if: { type: 'object' },
          then: {
            $ref: '#dataInfoFields',
          },
        },
      },
      additionalProperties: true,
    },
  },
  type: 'object',
  properties: {},
  additionalProperties: { $ref: '#gqlTypes' },
};

import { useRestToGQLConfig } from './serverUtils';
import postprocessors from './resolvers/query/postprocessors';
import preprocessors from './resolvers/query/preprocessors';

jest.mock('./resolvers/resolverFactory', () => {
  return {
    generateGenericResolver: (arg) => {
      // eslint-disable-next-line no-param-reassign
      Object.keys(arg).forEach((key) => (arg[key] === undefined ? delete arg[key] : {}));
      return arg;
    },
  };
});
jest.mock('./dataSources/genericAPI');

const mockRestToGqlConfig = {
  Query: {
    Nodes: {
      url: 'reference-data/hierarchies/{args.type}/nodes?date={args.cob}',
      dataPath: '$',
      additionalData: {
        hierarchyType: '{args.type}',
      },
    },
    StaticDataInstruments: {
      url: 'instruments',
      dataPath: '$',
    },
  },
  Node: {
    id: '$.nodeId',
    title: '$.nodeName',
    portfolios: {
      url: 'reference-data/hierarchies/{$.hierarchyType}/nodes/{$.nodeAK}/portfolios',
      dataPath: '$',
    },
    fullPath: '$.fullPath',
    parent: '$.parentNodeId',
    classification: '',
  },
};

describe('serverUtils', () => {
  it('should server utils generate right resolvers from the config', () => {
    const { generatedResolvers } = useRestToGQLConfig(mockRestToGqlConfig);
    expect(generatedResolvers).toEqual({
      Query: {
        Nodes: {
          dataPath: '$',
          url: 'reference-data/hierarchies/{args.type}/nodes?date={args.cob}',
          additionalData: {
            hierarchyType: '{args.type}',
          },
          postprocessor: postprocessors.Query.Nodes,
        },
        StaticDataInstruments: {
          url: 'instruments',
          dataPath: '$',
          preprocessor: preprocessors.Query.StaticDataInstruments,
        },
      },
      Node: {
        id: { fieldConfig: '$.nodeId' },
        title: { fieldConfig: '$.nodeName' },
        portfolios: {
          dataPath: '$',
          url: 'reference-data/hierarchies/{$.hierarchyType}/nodes/{$.nodeAK}/portfolios',
        },
        fullPath: { fieldConfig: '$.fullPath' },
        parent: { fieldConfig: '$.parentNodeId' },
        classification: { fieldConfig: '' },
      },
    });
  });
});
